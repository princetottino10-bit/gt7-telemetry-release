@echo off
rem Plays a recorded lap back through the live view, to try it without driving.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=runtime\python.exe"
if not exist "%PY%" set "PY=python"

echo ライブ画面のデモを始めます。録った周を流し直します。
"%PY%" -X utf8 demo_live.py
echo.
pause
