"""Notices when the driver has moved to a different circuit mid-recording.

A session file is only meaningful if every lap in it was driven on the same
track: the report resamples all laps onto one distance grid, so two circuits in
one file produce an average of two different shapes. Folders keep sessions
apart, but nothing stopped a single recording from spanning a trip back to the
menu and out onto somewhere else entirely.

Two things have to be true before this calls it a track change, because either
one alone gives false positives:

  * the car moved further between two consecutive packets than it possibly
    could have driven - at 60 Hz even 400 km/h covers under two metres, so
    anything past a few hundred is a teleport, and

  * it landed outside the area this stint has been driving in. Being sent back
    to the track after an off is also a teleport, but it puts the car back
    inside the same circuit, and splitting the session there would be wrong.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

import numpy as np

from telemetry.session import Lap, ReferenceLap, SessionRecorder

# Far beyond anything a car covers in one 60 Hz frame, so this only ever fires
# on a teleport of some kind - a reset, a restart, or a different circuit.
JUMP_M = 500.0
# How far outside the driven area still counts as the same circuit. Generous,
# since the box only covers the parts of the track visited so far.
BOX_MARGIN_RATIO = 0.25
BOX_MARGIN_MIN_M = 200.0
# Until the stint has seen this much, the driven area is too small to judge
# against - at 60 Hz this is ten seconds.
MIN_SAMPLES = 600


@dataclass
class Bounds:
    """The area a stint has been driving in."""

    x_min: float = math.inf
    x_max: float = -math.inf
    z_min: float = math.inf
    z_max: float = -math.inf

    def widen(self, x: float, z: float) -> None:
        self.x_min = min(self.x_min, x)
        self.x_max = max(self.x_max, x)
        self.z_min = min(self.z_min, z)
        self.z_max = max(self.z_max, z)

    @property
    def is_empty(self) -> bool:
        return self.x_min > self.x_max

    def contains(self, x: float, z: float) -> bool:
        """Whether a point is inside the driven area, allowing for a margin."""
        if self.is_empty:
            return True
        margin = max(
            (self.x_max - self.x_min) * BOX_MARGIN_RATIO,
            (self.z_max - self.z_min) * BOX_MARGIN_RATIO,
            BOX_MARGIN_MIN_M,
        )
        return (
            self.x_min - margin <= x <= self.x_max + margin
            and self.z_min - margin <= z <= self.z_max + margin
        )


class TrackChangeWatcher:
    """Watches positions and reports the moment the circuit changes."""

    def __init__(
        self,
        *,
        jump_m: float = JUMP_M,
        min_samples: int = MIN_SAMPLES,
    ) -> None:
        self.jump_m = jump_m
        self.min_samples = min_samples
        self.bounds = Bounds()
        self.samples = 0
        self._last: tuple[float, float] | None = None

    def reset(self) -> None:
        """Starts a fresh stint, forgetting where the last one was driven."""
        self.bounds = Bounds()
        self.samples = 0
        self._last = None

    def note(self, packet: Any) -> bool:
        """Feeds one packet in. True means this packet is on a different circuit.

        On a True the watcher has already started the next stint, so the caller
        can close the old session and carry straight on.
        """
        x, _y, z = packet.position
        previous = self._last
        self._last = (x, z)

        if previous is None:
            self.samples += 1
            self.bounds.widen(x, z)
            return False

        jumped = math.dist(previous, (x, z)) >= self.jump_m
        settled = self.samples >= self.min_samples
        if jumped and settled and not self.bounds.contains(x, z):
            self.reset()
            self.samples = 1
            self._last = (x, z)
            self.bounds.widen(x, z)
            return True

        self.samples += 1
        self.bounds.widen(x, z)
        return False


# ---------------------------------------------------------------------------
# The rule above is not enough by itself. GT7 places every circuit around the
# origin of its own world, so their coordinate boxes overlap: across the ten
# circuits recorded so far, the start of one lay inside the box of another in
# 80 of the 90 possible moves, and those moves went unnoticed. What does tell
# circuits apart is the road itself. Once a lap has been completed its path is
# known, and a car on the same circuit never strays far from it - 27 m at most
# over six real recordings, pit lanes, offs and restarts included.

# Further than this from every point of the stint's best lap is not this circuit.
OFF_PATH_M = 150.0
# ...once it has lasted this long (two seconds), so one wild sample decides nothing.
OFF_PATH_SAMPLES = 120
# The best lap is thinned to this many points; the gaps between them are a few
# metres, nothing next to OFF_PATH_M.
PATH_POINTS = 800

# Where the stream stops being one continuous drive: back from a menu, a
# restart, or a new circuit. Whatever follows is held until it is clear which.
BREAK_TICKS = 120
# The same two seconds, by the clock, for the live capture.
SILENCE_S = 2.0
BREAK_JUMP_M = 100.0
# Fifteen minutes of packets. A lap is settled long before that; this only
# stops a car parked in the pits from being held for ever.
HELD_PACKETS_MAX = 60 * 60 * 15

# Two layouts of one circuit share most of their road, so the path alone may
# never object. Their laps differ in length, though, by far more than driving
# wide or tight ever changes one.
LAYOUT_LENGTH_TOLERANCE = 0.10


@dataclass
class Stint:
    """One circuit's worth of a recording, banked when the track changes."""

    recorder: SessionRecorder
    started_at: datetime
    raw_start: int
    raw_end: int


@dataclass
class Fed:
    """What one packet did to the recording."""

    # Laps completed by this packet. More than one only when a held stretch of
    # driving was handed to a new stint all at once.
    laps: list[Lap]
    # How many laps were banked as their own session because the circuit
    # changed; None when it did not change.
    banked_laps: int | None = None


class Recording:
    """Turns a stream of packets into stints, one per circuit driven.

    Owns the recorder for the circuit being driven now and the stints already
    banked. Used by the live capture and by the recovery of an interrupted one,
    so both cut a drive into sessions the same way.
    """

    def __init__(self, started_at: datetime | None = None, *, clock=datetime.now) -> None:
        self._clock = clock
        self.recorder = SessionRecorder()
        self.started_at = started_at or clock()
        self.stints: list[Stint] = []
        self._raw_start = 0
        self._watcher = TrackChangeWatcher()
        self._previous: Any = None
        self._off_path = 0
        self._path_of: Lap | None = None
        self._path: np.ndarray | None = None
        # Packets since the stream last broke, until a lap settles the circuit.
        self._held: list[Any] | None = None
        self._held_raw_start = 0

    def feed(self, packet: Any, raw_index: int = 0, *, after_silence: bool = False) -> Fed:
        """Adds one packet. `raw_index` is its place in the raw packet log.

        `after_silence` says the console had gone quiet before this packet. A
        trip through the menus always looks like that from here, whatever the
        packet counter did meanwhile, and only the live capture can see it.
        """
        if self._previous is not None and (after_silence or self._is_break(packet)):
            self._held = []
            self._held_raw_start = raw_index
            self._off_path = 0
        self._previous = packet
        if self._held is not None:
            self._held.append(packet)
            if len(self._held) > HELD_PACKETS_MAX:
                self._held = None

        if self._watcher.note(packet) or self._left_the_path(packet):
            return self._split(raw_index)

        finished = self.recorder.feed(packet)
        if finished is None:
            return Fed([])
        if self._held is not None:
            if self._is_another_layout(finished):
                self._forget(finished)
                return self._split(raw_index)
            # A whole lap of the same length on the same road: same circuit.
            self._held = None
        return Fed([finished])

    def finish(self, raw_end: int = 0) -> list[Stint]:
        """Banks the circuit being driven and returns every stint."""
        if self.recorder.laps:
            self.stints.append(Stint(self.recorder, self.started_at, self._raw_start, raw_end))
            self.recorder = SessionRecorder()
        return self.stints

    # ---------- telling circuits apart ----------

    def _is_break(self, packet: Any) -> bool:
        previous = self._previous
        step = packet.packet_id - previous.packet_id
        if step <= 0 or step > BREAK_TICKS:
            return True
        if packet.lap_count < previous.lap_count:
            return True
        (x0, _y0, z0), (x1, _y1, z1) = previous.position, packet.position
        return math.hypot(x1 - x0, z1 - z0) >= BREAK_JUMP_M

    def _left_the_path(self, packet: Any) -> bool:
        best = self.recorder.best_lap
        if best is None or packet.is_paused:
            return False
        if best is not self._path_of:
            samples = best.samples[:: max(1, len(best.samples) // PATH_POINTS)]
            self._path = np.array([(s.position[0], s.position[2]) for s in samples])
            self._path_of = best
        x, _y, z = packet.position
        offset = self._path - (x, z)
        nearest_sq = float(np.min(offset[:, 0] ** 2 + offset[:, 1] ** 2))
        self._off_path = self._off_path + 1 if nearest_sq > OFF_PATH_M**2 else 0
        return self._off_path >= OFF_PATH_SAMPLES

    def _is_another_layout(self, lap: Lap) -> bool:
        others = sorted(other.distance_m for other in self.recorder.laps if other is not lap)
        if not others:
            return False
        usual = others[len(others) // 2]
        return usual > 0 and abs(lap.distance_m - usual) / usual > LAYOUT_LENGTH_TOLERANCE

    def _forget(self, lap: Lap) -> None:
        """Takes back a lap that turned out to belong to the next circuit."""
        recorder = self.recorder
        recorder.laps.remove(lap)
        if recorder.best_lap is lap:
            recorder.best_lap = min(recorder.laps, key=lambda other: other.lap_time_s)
            recorder.reference = ReferenceLap(recorder.best_lap)

    def _split(self, raw_index: int) -> Fed:
        """Banks the laps so far and starts the next circuit.

        The driving since the stream last broke is on the new circuit, so it is
        given to the new stint from its first packet: without that, the lap in
        progress when the change was noticed would start part way round and be
        dropped like any other partial lap.
        """
        held = self._held or [self._previous]
        seam = self._held_raw_start if self._held else raw_index
        banked = len(self.recorder.laps)
        if banked:
            self.stints.append(Stint(self.recorder, self.started_at, self._raw_start, seam))

        self.recorder = SessionRecorder()
        self.started_at = self._clock() - timedelta(seconds=len(held) / 60.0)
        self._raw_start = seam
        self._watcher.reset()
        self._off_path = 0
        self._path_of = self._path = None
        # Still held: this circuit is no more settled than the last one was.
        self._held = list(held)
        self._held_raw_start = seam

        laps: list[Lap] = []
        for packet in held:
            self._watcher.note(packet)
            finished = self.recorder.feed(packet)
            if finished is not None:
                laps.append(finished)
        if laps:
            self._held = None
        return Fed(laps, banked_laps=banked)
