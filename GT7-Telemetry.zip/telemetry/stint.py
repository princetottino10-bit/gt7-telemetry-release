"""Notices when the driver has moved to a different circuit mid-recording.

A session file is only meaningful if every lap in it was driven on the same
track: the report resamples all laps onto one distance grid, so two circuits in
one file produce an average of two different shapes. Folders keep sessions
apart, but nothing stopped a single recording from spanning a trip back to the
menu and out onto somewhere else entirely.

Two things have to be true before this calls it a track change, because either
one alone gives false positives:

  * the car moved further between two consecutive packets than it possibly
    could have driven - at 60 Hz even 400 km/h covers under two metres, so
    anything past a few hundred is a teleport, and

  * it landed outside the area this stint has been driving in. Being sent back
    to the track after an off is also a teleport, but it puts the car back
    inside the same circuit, and splitting the session there would be wrong.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

# Far beyond anything a car covers in one 60 Hz frame, so this only ever fires
# on a teleport of some kind - a reset, a restart, or a different circuit.
JUMP_M = 500.0
# How far outside the driven area still counts as the same circuit. Generous,
# since the box only covers the parts of the track visited so far.
BOX_MARGIN_RATIO = 0.25
BOX_MARGIN_MIN_M = 200.0
# Until the stint has seen this much, the driven area is too small to judge
# against - at 60 Hz this is ten seconds.
MIN_SAMPLES = 600


@dataclass
class Bounds:
    """The area a stint has been driving in."""

    x_min: float = math.inf
    x_max: float = -math.inf
    z_min: float = math.inf
    z_max: float = -math.inf

    def widen(self, x: float, z: float) -> None:
        self.x_min = min(self.x_min, x)
        self.x_max = max(self.x_max, x)
        self.z_min = min(self.z_min, z)
        self.z_max = max(self.z_max, z)

    @property
    def is_empty(self) -> bool:
        return self.x_min > self.x_max

    def contains(self, x: float, z: float) -> bool:
        """Whether a point is inside the driven area, allowing for a margin."""
        if self.is_empty:
            return True
        margin = max(
            (self.x_max - self.x_min) * BOX_MARGIN_RATIO,
            (self.z_max - self.z_min) * BOX_MARGIN_RATIO,
            BOX_MARGIN_MIN_M,
        )
        return (
            self.x_min - margin <= x <= self.x_max + margin
            and self.z_min - margin <= z <= self.z_max + margin
        )


class TrackChangeWatcher:
    """Watches positions and reports the moment the circuit changes."""

    def __init__(
        self,
        *,
        jump_m: float = JUMP_M,
        min_samples: int = MIN_SAMPLES,
    ) -> None:
        self.jump_m = jump_m
        self.min_samples = min_samples
        self.bounds = Bounds()
        self.samples = 0
        self._last: tuple[float, float] | None = None

    def reset(self) -> None:
        """Starts a fresh stint, forgetting where the last one was driven."""
        self.bounds = Bounds()
        self.samples = 0
        self._last = None

    def note(self, packet: Any) -> bool:
        """Feeds one packet in. True means this packet is on a different circuit.

        On a True the watcher has already started the next stint, so the caller
        can close the old session and carry straight on.
        """
        x, _y, z = packet.position
        previous = self._last
        self._last = (x, z)

        if previous is None:
            self.samples += 1
            self.bounds.widen(x, z)
            return False

        jumped = math.dist(previous, (x, z)) >= self.jump_m
        settled = self.samples >= self.min_samples
        if jumped and settled and not self.bounds.contains(x, z):
            self.reset()
            self.samples = 1
            self._last = (x, z)
            self.bounds.widen(x, z)
            return True

        self.samples += 1
        self.bounds.widen(x, z)
        return False
