"""Names a circuit after the fact, from a page instead of the console.

Asking for the name while recording meant someone had to come back to the
keyboard before the report appeared. Now an unrecognised circuit is filed by its
length, and the driver names it from the report or the listing whenever they
like. Naming it teaches the registry the shape, moves its sessions into the
named folder, and rebuilds their reports so every page says the new name.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from telemetry import sessions, tracks

# Where learned shapes are kept: beside the tool, so it travels with it.
DEFAULT_REGISTRY = Path(__file__).resolve().parent.parent / tracks.REGISTRY_FILENAME


def fingerprint_from_session(directory: Path) -> tracks.Fingerprint:
    """The shape of a session's best lap, read back from the saved laps."""
    # Imported here: only naming needs the report loader and its numpy.
    import analyze_gt7 as core
    from webreport import loader

    reference = loader.select_laps(loader.load_laps(directory, core.DEFAULT_CARS_CSV)).reference
    found = tracks.fingerprint_from_positions(
        zip(reference.x.tolist(), reference.y.tolist(), reference.z.tolist()),
        float(reference.distance_m[-1]),
    )
    # numpy scalars do not survive json.dumps; the registry is plain JSON.
    return tracks.Fingerprint(
        length_m=float(found.length_m),
        width_m=float(found.width_m),
        depth_m=float(found.depth_m),
        height_m=float(found.height_m),
        clockwise=None if found.clockwise is None else bool(found.clockwise),
    )


def name_track(
    root: Path, directory: Path, name: str, *, registry_path: Path = DEFAULT_REGISTRY, rebuild: bool = True
) -> Path:
    """Gives the circuit of the session in `directory` a name. Returns the
    session's folder after the move."""
    name = " ".join(name.split())
    if not name or tracks.is_placeholder(name):
        raise ValueError("コース名を入力してください")
    meta = sessions.read_meta(directory)
    if meta is None:
        raise ValueError(f"{directory} は走行記録のフォルダではありません")

    registry = tracks.Registry(registry_path)
    registry.remember(name, fingerprint_from_session(directory))
    if not tracks.is_placeholder(meta.track) and meta.track != name:
        # Putting a wrong name right: the same shape must not answer to both.
        registry.forget(meta.track)
    registry.save()

    old_folder = directory.parent
    new_folder = root / tracks.slug(name)
    moved: list[Path] = []
    for child in sorted(old_folder.iterdir()) if old_folder != new_folder else []:
        target = new_folder / child.name
        if target.exists():
            # A circuit named before keeps its own corner names; a session of
            # the same minute cannot exist twice, so only files collide here.
            continue
        is_session = child.is_dir()
        new_folder.mkdir(parents=True, exist_ok=True)
        shutil.move(str(child), str(target))
        if is_session:
            moved.append(target)
    if old_folder != new_folder:
        shutil.rmtree(old_folder, ignore_errors=True)
    else:
        moved = [path for path in old_folder.iterdir() if path.is_dir()]

    for session_dir in moved:
        _rename_meta(session_dir, name)
    if rebuild:
        from telemetry import rebuild as rebuild_module

        for session_dir in moved:
            try:
                rebuild_module.rebuild(root, session_dir)
            except Exception:  # noqa: BLE001 - the name is saved; a report can be rebuilt later
                continue
    sessions.write_index(root, registry)
    return new_folder / directory.name


def _rename_meta(directory: Path, name: str) -> None:
    meta = sessions.read_meta(directory)
    if meta is None:
        return
    sessions._rewrite_track_name(directory, name)
