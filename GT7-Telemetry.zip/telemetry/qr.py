"""A small QR encoder, enough to put a URL on screen.

Typing "192.168.10.115:8770" into a phone once per session is the kind of
friction that stops a feature being used at all, so the live page shows a code
to point a camera at instead. Only what that needs is here: byte mode, error
correction level L, versions 1 to 4 - which covers any URL on a home network
with room to spare. Levels above L and multi-block versions are left out
because nothing here would use them.

Written out rather than pulled in as a dependency: the distributed build
downloads its own Python on first run, and every extra download is another
thing that can fail on someone else's machine.
"""

from __future__ import annotations

# Data codewords, error correction codewords, and the alignment pattern centre
# for each supported version at level L. Every one of these is a single block,
# which is why no interleaving appears below.
VERSIONS: dict[int, tuple[int, int, int | None]] = {
    1: (19, 7, None),
    2: (34, 10, 18),
    3: (55, 15, 22),
    4: (80, 20, 26),
}

# Byte mode. The character count is 8 bits wide for versions 1 to 9.
MODE_BYTE = 0b0100
COUNT_BITS = 8
# Alternated to fill whatever room is left after the data.
PAD_BYTES = (0xEC, 0x11)

# The generator polynomial for the field QR uses.
_GF_PRIMITIVE = 0x11D


def _build_tables() -> tuple[list[int], list[int]]:
    """Exponent and logarithm tables for GF(256)."""
    exponents = [0] * 512
    logarithms = [0] * 256
    value = 1
    for power in range(255):
        exponents[power] = value
        logarithms[value] = power
        value <<= 1
        if value & 0x100:
            value ^= _GF_PRIMITIVE
    for power in range(255, 512):
        exponents[power] = exponents[power - 255]
    return exponents, logarithms


_EXP, _LOG = _build_tables()


def _multiply(left: int, right: int) -> int:
    if left == 0 or right == 0:
        return 0
    return _EXP[_LOG[left] + _LOG[right]]


def _generator_polynomial(degree: int) -> list[int]:
    """The polynomial whose roots the error correction codewords come from."""
    polynomial = [1]
    for power in range(degree):
        polynomial = _multiply_polynomials(polynomial, [1, _EXP[power]])
    return polynomial


def _multiply_polynomials(left: list[int], right: list[int]) -> list[int]:
    result = [0] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        if a == 0:
            continue
        for j, b in enumerate(right):
            result[i + j] ^= _multiply(a, b)
    return result


def error_correction(data: list[int], count: int) -> list[int]:
    """Reed-Solomon codewords for `data`, `count` of them."""
    generator = _generator_polynomial(count)
    remainder = list(data) + [0] * count
    for position in range(len(data)):
        coefficient = remainder[position]
        if coefficient == 0:
            continue
        for offset, factor in enumerate(generator):
            remainder[position + offset] ^= _multiply(factor, coefficient)
    return remainder[len(data) :]


def _choose_version(length: int) -> int:
    """The smallest version that holds `length` bytes, header included."""
    for version, (data_codewords, _ecc, _align) in sorted(VERSIONS.items()):
        # Four bits of mode and eight of length, so two codewords of overhead.
        if length + 2 <= data_codewords:
            return version
    raise ValueError(
        f"{length}バイトはこのQRエンコーダの容量を超えています（最大{VERSIONS[4][0] - 2}バイト）"
    )


def _encode_data(text: str, version: int) -> list[int]:
    """The data codewords: mode, length, the bytes themselves, then padding."""
    payload = text.encode("utf-8")
    data_codewords, _ecc, _align = VERSIONS[version]

    bits: list[int] = []

    def append(value: int, width: int) -> None:
        for shift in range(width - 1, -1, -1):
            bits.append((value >> shift) & 1)

    append(MODE_BYTE, 4)
    append(len(payload), COUNT_BITS)
    for byte in payload:
        append(byte, 8)

    # A terminator of up to four zero bits, then out to a byte boundary.
    capacity_bits = data_codewords * 8
    bits.extend([0] * min(4, capacity_bits - len(bits)))
    bits.extend([0] * (-len(bits) % 8))

    codewords = [
        int("".join(str(bit) for bit in bits[index : index + 8]), 2)
        for index in range(0, len(bits), 8)
    ]
    while len(codewords) < data_codewords:
        codewords.append(PAD_BYTES[(len(codewords) - len(bits) // 8) % 2])
    return codewords


class _Matrix:
    """The module grid, with a record of which cells are structure.

    Structure cells - finders, timing, format - are laid down first and then
    skipped when the data is threaded through, so both passes work off the same
    `reserved` map rather than each re-deriving where the patterns are.
    """

    def __init__(self, version: int) -> None:
        self.version = version
        self.size = 17 + 4 * version
        self.modules = [[False] * self.size for _ in range(self.size)]
        self.reserved = [[False] * self.size for _ in range(self.size)]

    def set(self, row: int, column: int, dark: bool, *, structure: bool = True) -> None:
        self.modules[row][column] = dark
        if structure:
            self.reserved[row][column] = True


def _place_finder(matrix: _Matrix, row: int, column: int) -> None:
    """One 7x7 finder plus the light separator around it."""
    for delta_row in range(-1, 8):
        for delta_column in range(-1, 8):
            r, c = row + delta_row, column + delta_column
            if not (0 <= r < matrix.size and 0 <= c < matrix.size):
                continue
            inside = 0 <= delta_row <= 6 and 0 <= delta_column <= 6
            if not inside:
                matrix.set(r, c, False)
                continue
            ring = max(abs(delta_row - 3), abs(delta_column - 3))
            matrix.set(r, c, ring != 2)


def _place_alignment(matrix: _Matrix, centre: int) -> None:
    for delta_row in range(-2, 3):
        for delta_column in range(-2, 3):
            ring = max(abs(delta_row), abs(delta_column))
            matrix.set(centre + delta_row, centre + delta_column, ring != 1)


def _place_structure(matrix: _Matrix) -> None:
    size = matrix.size
    _place_finder(matrix, 0, 0)
    _place_finder(matrix, 0, size - 7)
    _place_finder(matrix, size - 7, 0)

    _alignment = VERSIONS[matrix.version][2]
    if _alignment is not None:
        _place_alignment(matrix, _alignment)

    # Timing patterns run between the finders, alternating from their edge.
    for index in range(8, size - 8):
        dark = index % 2 == 0
        matrix.set(6, index, dark)
        matrix.set(index, 6, dark)

    # The one module that is always dark, just above the lower-left finder.
    matrix.set(size - 8, 8, True)

    # Format information goes in later but its cells must be off limits now.
    for index in range(9):
        if index != 6:
            matrix.set(8, index, False)
            matrix.set(index, 8, False)
    # Eight cells along row 8, but only seven up column 8: the eighth would be
    # the always-dark module set just above, and blanking it here left the code
    # unreadable to some scanners while others still managed it.
    for index in range(8):
        matrix.set(8, size - 1 - index, False)
    for index in range(7):
        matrix.set(size - 1 - index, 8, False)


def _place_data(matrix: _Matrix, codewords: list[int]) -> None:
    """Threads the codewords up and down the free columns, right to left."""
    bits = [(byte >> shift) & 1 for byte in codewords for shift in range(7, -1, -1)]
    cursor = 0
    size = matrix.size
    column = size - 1
    upward = True
    while column > 0:
        if column == 6:
            # The vertical timing pattern is not a data column at all.
            column -= 1
        rows = range(size - 1, -1, -1) if upward else range(size)
        for row in rows:
            for offset in (0, 1):
                target = column - offset
                if matrix.reserved[row][target]:
                    continue
                bit = bits[cursor] if cursor < len(bits) else 0
                cursor += 1
                matrix.set(row, target, bit == 1, structure=False)
        column -= 2
        upward = not upward


# The eight mask patterns, by their spec numbering.
MASKS = (
    lambda r, c: (r + c) % 2 == 0,
    lambda r, c: r % 2 == 0,
    lambda r, c: c % 3 == 0,
    lambda r, c: (r + c) % 3 == 0,
    lambda r, c: (r // 2 + c // 3) % 2 == 0,
    lambda r, c: (r * c) % 2 + (r * c) % 3 == 0,
    lambda r, c: ((r * c) % 2 + (r * c) % 3) % 2 == 0,
    lambda r, c: ((r + c) % 2 + (r * c) % 3) % 2 == 0,
)


def _apply_mask(matrix: _Matrix, mask: int) -> list[list[bool]]:
    rule = MASKS[mask]
    return [
        [
            cell != rule(row, column) if not matrix.reserved[row][column] else cell
            for column, cell in enumerate(line)
        ]
        for row, line in enumerate(matrix.modules)
    ]


def _find(sequence: list[bool], pattern: list[bool], start: int) -> int:
    """The first index at or after `start` where `pattern` appears, or -1."""
    width = len(pattern)
    for index in range(start, len(sequence) - width + 1):
        if sequence[index : index + width] == pattern:
            return index
    return -1


# The four penalty features the standard scores a masked symbol on. Kept as
# separate functions because each one had to be checked against a reference
# implementation on its own - the total hides which rule is wrong.

LOOKALIKE = [True, False, True, True, True, False, True]


def _run_score(lines: list[list[bool]]) -> int:
    """Runs of five or more modules of one colour."""
    score = 0
    for line in lines:
        run = 1
        for index in range(1, len(line)):
            if line[index] == line[index - 1]:
                run += 1
                continue
            if run >= 5:
                score += 3 + (run - 5)
            run = 1
        if run >= 5:
            score += 3 + (run - 5)
    return score


def _block_score(modules: list[list[bool]]) -> int:
    """Solid two-by-two blocks, counted where they overlap."""
    size = len(modules)
    score = 0
    for row in range(size - 1):
        for column in range(size - 1):
            block = (
                modules[row][column],
                modules[row][column + 1],
                modules[row + 1][column],
                modules[row + 1][column + 1],
            )
            if all(block) or not any(block):
                score += 3
    return score


def _lookalike_score(sequence: list[bool], size: int) -> int:
    """The finder-like 1:1:3:1:1 run, next to four light modules.

    This is the rule that stops a scanner reading data as a corner marker, and
    the details decide which mask gets chosen. An occurrence flush against the
    edge counts - the quiet zone is the light area - and each occurrence scores
    once however many of its sides are light. Scoring it twice made the masks
    that produce these look no worse than the ones that avoid them, and the
    encoder duly picked them; the codes it produced then failed to scan.
    """
    score = 0
    index = _find(sequence, LOOKALIKE, 0)
    while index != -1:
        offset = index + 7
        if (
            index in (0, size - 7)
            or not any(sequence[max(index - 4, 0) : index])
            or not any(sequence[offset : offset + 4])
        ):
            score += 40
        else:
            # Occurrences can overlap; resume inside this one.
            offset = index + 4
        index = _find(sequence, LOOKALIKE, offset)
    return score


def _balance_score(modules: list[list[bool]]) -> int:
    """Drift away from an even split of dark and light."""
    size = len(modules)
    dark = sum(cell for line in modules for cell in line)
    percent = dark * 100 / (size * size)
    return 10 * int(abs(percent - 50) // 5)


def _penalty(modules: list[list[bool]]) -> int:
    """The standard's readability score; lower is better."""
    size = len(modules)
    lines = list(modules) + [list(column) for column in zip(*modules)]
    return (
        _run_score(lines)
        + _block_score(modules)
        + sum(_lookalike_score(line, size) for line in lines)
        + _balance_score(modules)
    )


# Level L is 01 in the format field.
_FORMAT_ECC_BITS = 0b01
_FORMAT_MASK = 0b101010000010010
_FORMAT_GENERATOR = 0b10100110111


def _format_bits(mask: int) -> list[int]:
    """The 15 bit format field: BCH-protected, then masked."""
    value = (_FORMAT_ECC_BITS << 3) | mask
    remainder = value << 10
    for shift in range(14, 9, -1):
        if remainder & (1 << shift):
            remainder ^= _FORMAT_GENERATOR << (shift - 10)
    combined = ((value << 10) | remainder) ^ _FORMAT_MASK
    return [(combined >> shift) & 1 for shift in range(14, -1, -1)]


def _place_format(modules: list[list[bool]], mask: int) -> None:
    bits = _format_bits(mask)
    size = len(modules)
    # The first copy wraps the top-left finder; the second is split between the
    # other two, so that a code stays readable if one corner is damaged.
    for index, bit in enumerate(bits):
        dark = bit == 1
        if index < 6:
            modules[8][index] = dark
        elif index == 6:
            modules[8][7] = dark
        elif index == 7:
            modules[8][8] = dark
        elif index == 8:
            modules[7][8] = dark
        else:
            modules[14 - index][8] = dark

        # The second copy runs up column 8 from the bottom, then along row 8 to
        # the right edge. The split falls after bit 6, not bit 7.
        if index < 7:
            modules[size - 1 - index][8] = dark
        else:
            modules[8][size - 15 + index] = dark


def encode(text: str) -> list[list[bool]]:
    """The module grid for `text`; True is a dark module."""
    payload_length = len(text.encode("utf-8"))
    version = _choose_version(payload_length)
    data_codewords, ecc_count, _align = VERSIONS[version]

    data = _encode_data(text, version)
    codewords = data + error_correction(data, ecc_count)
    assert len(data) == data_codewords

    matrix = _Matrix(version)
    _place_structure(matrix)
    _place_data(matrix, codewords)

    best: list[list[bool]] | None = None
    best_score = None
    for mask in range(8):
        candidate = _apply_mask(matrix, mask)
        _place_format(candidate, mask)
        score = _penalty(candidate)
        if best_score is None or score < best_score:
            best, best_score = candidate, score
    assert best is not None
    return best


def to_svg(text: str, *, module_px: int = 8, quiet: int = 4) -> str:
    """The code as an SVG, dark on white regardless of the page around it.

    The quiet zone is part of the code, not decoration: scanners need the light
    border to find the edges, and a code butted against a dark panel often will
    not read at all.
    """
    modules = encode(text)
    size = len(modules)
    span = (size + quiet * 2) * module_px
    squares = [
        f'<rect x="{(column + quiet) * module_px}" y="{(row + quiet) * module_px}"'
        f' width="{module_px}" height="{module_px}"/>'
        for row, line in enumerate(modules)
        for column, cell in enumerate(line)
        if cell
    ]
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{span}" height="{span}" '
        f'viewBox="0 0 {span} {span}" shape-rendering="crispEdges">'
        f'<rect width="{span}" height="{span}" fill="#ffffff"/>'
        f'<g fill="#000000">{"".join(squares)}</g>'
        "</svg>"
    )
