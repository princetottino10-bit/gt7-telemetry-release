"""Turns a stream of packets into laps, and tracks the live delta while driving.

The console reports a lap counter and the time of the lap that just finished, but
not distance or any running comparison. Both are reconstructed here: distance by
integrating speed, and the delta by looking up where the reference lap was at the
same distance.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import numpy as np

from telemetry.packet import GT7Packet

# The console streams at 60 Hz and stamps every packet with a counter, so time
# between samples comes from the counter rather than from arrival time.
TICK_HZ = 60.0
# Ignore absurd counter jumps (a session restart rather than a dropped packet).
MAX_TICK_GAP = 240
# A lap needs at least this many samples before it is worth keeping.
MIN_SAMPLES = 300


@dataclass(frozen=True)
class Sample:
    """One 60 Hz sample, with the channels the report and the live view need."""

    tick: int
    time_s: float
    distance_m: float
    speed_kmh: float
    throttle_pct: float
    brake_pct: float
    gear: int
    rpm: float
    position: tuple[float, float, float]
    yaw: float
    # Channels GT7 Dashboard does not record.
    tire_temps: tuple[float, float, float, float]
    tire_slip: tuple[float, float, float, float]
    suspension_travel: tuple[float, float, float, float]
    slide_angle_deg: float
    boost: float
    water_temp: float
    oil_temp: float
    clutch_pedal: float
    fuel_level: float
    # Whether traction control was cutting power on this sample. The setting
    # itself never reaches the packet, but the moment it intervenes does.
    tcs_active: bool = False


# Established against a live console, not from documentation: the four floats at
# 0x1C read as (w, x, y, z), and the heading they give sits 90 degrees off the
# direction of travel. With both corrections the slide angle on a straight comes
# out at -0.18 deg mean / 0.89 deg standard deviation over 2179 samples.
QUATERNION_HEADING_OFFSET_RAD = math.pi / 2


def _yaw_from_rotation(rotation: tuple[float, float, float, float]) -> float:
    """Heading around the vertical axis, in radians, from the packet quaternion."""
    w, x, y, z = rotation
    return math.atan2(2.0 * (w * y + x * z), 1.0 - 2.0 * (y * y + z * z))


# Below this the ratio stops meaning anything: a wheel turning while the car is
# barely moving sends it to 100 and swamps every chart it appears in. Measured on
# a real session, everything above 10 m/s sits in a sane 0.6-1.5 band.
SLIP_MIN_SPEED_MPS = 10.0
SLIP_LIMIT = 3.0


def _tire_slip(packet: GT7Packet) -> tuple[float, float, float, float]:
    """Ratio of wheel surface speed to car speed, per wheel.

    1.0 means the wheel is rolling with the car. Above 1.0 is wheelspin, below is
    locking. Reported as 1.0 below walking pace, where the ratio is meaningless.
    """
    speed = abs(packet.speed_mps)
    if speed < SLIP_MIN_SPEED_MPS:
        return (1.0, 1.0, 1.0, 1.0)
    return tuple(
        min(SLIP_LIMIT, abs(rps) * radius / speed)
        for rps, radius in zip(packet.wheel_rps, packet.tire_radius)
    )


def _slide_angle_deg(packet: GT7Packet) -> float:
    """Angle between where the car points and where it is actually going.

    Verified against a real session: near zero on the straights, and it changes
    sign between left and right corners as it should.
    """
    velocity_x, _velocity_y, velocity_z = packet.velocity
    planar_speed = math.hypot(velocity_x, velocity_z)
    if planar_speed < 1.0:
        return 0.0
    heading = _yaw_from_rotation(packet.rotation)
    course = math.atan2(velocity_z, velocity_x)
    difference = math.degrees(course - heading - QUATERNION_HEADING_OFFSET_RAD)
    # Normalise onto [-180, 180].
    return (difference + 180.0) % 360.0 - 180.0


@dataclass
class Lap:
    """One completed or in-progress lap."""

    number: int
    car_code: int
    samples: list[Sample] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    ended_at: datetime | None = None
    # Filled in from the console's own timing when the lap closes.
    finish_time_ms: int = 0
    # Whether the recording was already running when this lap crossed the start
    # line. When it was not, the console still reports the whole lap's time for
    # it, so the lap looks complete by the clock while only part of it was ever
    # captured. There is nothing in the packet that says so - only the recorder
    # knows, because it either saw the lap counter tick over or it did not.
    from_line: bool = True

    @property
    def lap_time_s(self) -> float:
        if self.finish_time_ms > 0:
            return self.finish_time_ms / 1000.0
        return self.samples[-1].time_s if self.samples else 0.0

    @property
    def distance_m(self) -> float:
        return self.samples[-1].distance_m if self.samples else 0.0

    @property
    def is_usable(self) -> bool:
        """Whether this lap was seen from one start line to the next.

        Both ends have to have been observed: `from_line` says the recording was
        running when the lap began, and `finish_time_ms` is only set when the
        counter ticked over at the end. A lap missing the first of those still
        carries the console's full lap time, and taking it as the live reference
        made the delta read 50 seconds ahead before going blank the moment the
        driver passed where the reference stopped.
        """
        return (
            self.from_line
            and self.finish_time_ms > 0
            and len(self.samples) >= MIN_SAMPLES
        )

    def channel(self, name: str) -> np.ndarray:
        return np.array([getattr(sample, name) for sample in self.samples], dtype=float)


# Long enough that a sector means something, short enough to point at a part of
# the circuit. Circuits vary from under 3 km to over 13, so the count follows.
SECTOR_TARGET_M = 500.0
MIN_SECTORS = 4
MAX_SECTORS = 10


class ReferenceLap:
    """A lap held as a distance-to-time curve, for comparing against live."""

    def __init__(self, lap: Lap) -> None:
        self.lap = lap
        self.distance = lap.channel("distance_m")
        self.time = lap.channel("time_s")
        # Rescale so the curve ends exactly on the official lap time.
        if self.time[-1] > 0:
            self.time = self.time * (lap.lap_time_s / self.time[-1])
        self.total_distance = float(self.distance[-1])

    def sector_bounds(self, target_length_m: float = SECTOR_TARGET_M) -> list[float]:
        """Equal slices of the lap, each about `target_length_m` long.

        Split by distance rather than by corner: the corner detection needs the
        whole lap and a name for every piece, which is the report's job. Here
        the question is only "which part of the lap is costing me", and it has
        to be answerable on the lap it is being asked about.
        """
        if self.total_distance <= 0:
            return []
        count = max(MIN_SECTORS, min(MAX_SECTORS, round(self.total_distance / target_length_m)))
        step = self.total_distance / count
        return [step * index for index in range(1, count + 1)]

    def time_at(self, distance_m: float) -> float | None:
        """Where this lap's clock stood at a given distance."""
        if distance_m <= 0 or self.total_distance <= 0:
            return 0.0
        if distance_m > self.total_distance:
            return None
        return float(np.interp(distance_m, self.distance, self.time))


class SessionRecorder:
    """Consumes packets, emits completed laps and exposes the live state."""

    def __init__(self, *, reference: Lap | None = None) -> None:
        self.laps: list[Lap] = []
        # How many times the driver restarted mid-lap. Counted so the capture can
        # say why a lap it was part way through never appeared.
        self.restarts = 0
        self.current: Lap | None = None
        self.reference: ReferenceLap | None = ReferenceLap(reference) if reference else None
        self.best_lap: Lap | None = reference

        self._last_tick: int | None = None
        self._last_lap_count: int | None = None
        self._distance_m = 0.0
        self._time_s = 0.0
        self._latest: GT7Packet | None = None
        self._delta_s: float | None = None
        self._delta_history: list[tuple[float, float]] = []
        # Time gained or lost in each slice of the lap so far, so the live
        # view can say where it is going rather than only how much.
        self._sector_deltas: list[float | None] = []
        self._sector_entry_s: float = 0.0

    # ---------- ingestion ----------

    def feed(self, packet: GT7Packet) -> Lap | None:
        """Adds one packet. Returns a lap when one has just been completed."""
        self._latest = packet

        # Only `paused` is trusted here. On a real console the `on_track` bit never
        # sets while driving and `loading` flickers on mid-lap, so gating on either
        # would silently record nothing.
        if packet.is_paused:
            return None

        completed: Lap | None = None
        if self._last_lap_count is not None and packet.lap_count != self._last_lap_count:
            if packet.lap_count < self._last_lap_count:
                # The counter went backwards: the driver restarted or hit retry.
                # The lap in progress never reached the line, and the console's
                # last_lap_ms still describes some earlier lap - closing it here
                # banked five seconds of driving as a fifteen second lap.
                self.restarts += 1
                self.current = None
                self._begin_lap(packet)
            else:
                completed = self._close_lap(packet)
                self._begin_lap(packet)
        elif self.current is None and packet.lap_count > 0:
            # Recording started part way round: this lap's start line went by
            # before anyone was watching.
            self._begin_lap(packet, from_line=False)
        self._last_lap_count = packet.lap_count

        if self.current is not None:
            self._append_sample(packet)
        return completed

    def _begin_lap(self, packet: GT7Packet, *, from_line: bool = True) -> None:
        if packet.lap_count <= 0:
            self.current = None
            return
        self.current = Lap(
            number=packet.lap_count, car_code=packet.car_code, from_line=from_line
        )
        self._distance_m = 0.0
        self._time_s = 0.0
        self._last_tick = packet.packet_id
        self._delta_s = None
        self._delta_history = []
        self._sector_deltas = [None] * len(self._sector_bounds())
        self._sector_entry_s = 0.0

    def _sector_bounds(self) -> list[float]:
        return self.reference.sector_bounds() if self.reference else []

    def _update_sectors(self) -> None:
        """Closes off each slice of the lap as the car leaves it.

        Only whole sectors are reported. Half of one tells the driver nothing
        they can act on, and a number that moves while they are still inside the
        sector is the delta they already have, shown twice.
        """
        bounds = self._sector_bounds()
        if len(self._sector_deltas) != len(bounds):
            self._sector_deltas = [None] * len(bounds)
        if self.reference is None:
            return
        for index, bound in enumerate(bounds):
            if self._sector_deltas[index] is not None or self._distance_m < bound:
                continue
            reference_time = self.reference.time_at(bound)
            if reference_time is None:
                continue
            previous = self.reference.time_at(bounds[index - 1]) if index else 0.0
            if previous is None:
                continue
            mine = self._time_s - self._sector_entry_s
            self._sector_deltas[index] = mine - (reference_time - previous)
            self._sector_entry_s = self._time_s

    def _close_lap(self, packet: GT7Packet) -> Lap | None:
        lap = self.current
        self.current = None
        if lap is None:
            return None
        # The console reports the finished lap's time in the first packet of the
        # next lap, which is the only authoritative timing available.
        lap.finish_time_ms = packet.last_lap_ms
        lap.ended_at = datetime.now()
        if not lap.is_usable:
            return None

        self.laps.append(lap)
        if self.best_lap is None or lap.lap_time_s < self.best_lap.lap_time_s:
            self.best_lap = lap
            self.reference = ReferenceLap(lap)
        return lap

    def _append_sample(self, packet: GT7Packet) -> None:
        assert self.current is not None
        elapsed_ticks = 1
        if self._last_tick is not None:
            step = packet.packet_id - self._last_tick
            if step <= 0 or step > MAX_TICK_GAP:
                step = 1
            elapsed_ticks = step
        self._last_tick = packet.packet_id

        step_s = elapsed_ticks / TICK_HZ
        self._time_s += step_s
        self._distance_m += packet.speed_mps * step_s

        self.current.samples.append(
            Sample(
                tick=packet.packet_id,
                time_s=self._time_s,
                distance_m=self._distance_m,
                speed_kmh=packet.speed_kmh,
                throttle_pct=packet.throttle_pct,
                brake_pct=packet.brake_pct,
                gear=packet.gear,
                rpm=packet.rpm,
                position=packet.position,
                yaw=_yaw_from_rotation(packet.rotation),
                tire_temps=packet.tire_temps,
                tire_slip=_tire_slip(packet),
                suspension_travel=packet.suspension_travel,
                slide_angle_deg=_slide_angle_deg(packet),
                boost=packet.boost,
                water_temp=packet.water_temp,
                oil_temp=packet.oil_temp,
                clutch_pedal=packet.clutch_pedal,
                fuel_level=packet.fuel_level,
                tcs_active=packet.flag("tcs_active"),
            )
        )

        self._update_delta()

    def _update_delta(self) -> None:
        if self.reference is None:
            self._delta_s = None
            return
        reference_time = self.reference.time_at(self._distance_m)
        if reference_time is None:
            self._delta_s = None
            return
        self._delta_s = self._time_s - reference_time
        self._update_sectors()
        self._delta_history.append((self._distance_m, self._delta_s))
        # Keep the trace bounded; the live view only draws a sparkline.
        if len(self._delta_history) > 4000:
            del self._delta_history[:2000]

    # ---------- live view ----------

    @property
    def delta_s(self) -> float | None:
        return self._delta_s

    def live_state(self) -> dict[str, Any]:
        """A snapshot for the live UI. Safe to call from another thread."""
        packet = self._latest
        if packet is None:
            return {"connected": False}

        sparkline = self._delta_history[-600::4]
        return {
            "connected": True,
            "carId": packet.car_code,
            "onTrack": packet.on_track,
            "paused": packet.is_paused,
            "lapNumber": packet.lap_count,
            "lapsInRace": packet.laps_in_race,
            "lapTimeS": self._time_s,
            "distanceM": self._distance_m,
            "deltaS": self._delta_s,
            "speedKmh": packet.speed_kmh,
            "gear": packet.gear,
            "suggestedGear": packet.suggested_gear,
            "rpm": packet.rpm,
            "rpmAlertMin": packet.rpm_alert_min,
            "rpmAlertMax": packet.rpm_alert_max,
            "throttlePct": packet.throttle_pct,
            "brakePct": packet.brake_pct,
            "position": [packet.position[0], packet.position[2]],
            "tireTemps": list(packet.tire_temps),
            "tireSlip": list(_tire_slip(packet)),
            "slideAngleDeg": _slide_angle_deg(packet),
            "fuelLevel": packet.fuel_level,
            "fuelCapacity": packet.fuel_capacity,
            "waterTemp": packet.water_temp,
            "oilTemp": packet.oil_temp,
            "bestLapS": self.best_lap.lap_time_s if self.best_lap else None,
            "lastLapS": packet.last_lap_ms / 1000.0 if packet.last_lap_ms > 0 else None,
            "completedLaps": len(self.laps),
            "referenceDistanceM": self.reference.total_distance if self.reference else None,
            "deltaSparkline": [[round(d, 1), round(v, 3)] for d, v in sparkline],
            "sectors": self._sector_view(),
            "trackPath": self._track_path(),
        }

    def _sector_view(self) -> list[dict[str, Any]] | None:
        """Each slice of the lap, its delta once finished, and where the car is."""
        bounds = self._sector_bounds()
        if not bounds:
            return None
        current = next(
            (index for index, bound in enumerate(bounds) if self._distance_m < bound),
            len(bounds) - 1,
        )
        return [
            {
                "label": f"S{index + 1}",
                "deltaS": (
                    round(self._sector_deltas[index], 3)
                    if index < len(self._sector_deltas)
                    and self._sector_deltas[index] is not None
                    else None
                ),
                "current": index == current,
            }
            for index in range(len(bounds))
        ]

    def _track_path(self) -> list[list[float]] | None:
        """The reference lap's outline, sent once for the live mini map."""
        if self.best_lap is None:
            return None
        samples = self.best_lap.samples
        if len(samples) < 50:
            return None
        step = max(1, len(samples) // 400)
        return [
            [round(sample.position[0], 1), round(sample.position[2], 1)]
            for sample in samples[::step]
        ]
