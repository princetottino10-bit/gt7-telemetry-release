"""Names for cars the bundled table does not know.

`assets/db/cars.csv` came from GT7 Dashboard and stops at 569 cars. GT7 keeps
adding them, so a recent car shows up in the report as CAR-ID-3395 with no way
to fix it. This works the same way circuit names do: say it once, and every
later session with that car uses the name.
"""

from __future__ import annotations

import json
from pathlib import Path

REGISTRY_FILENAME = "known_cars.json"


def registry_path(root: Path | None = None) -> Path:
    """Where learned car names live: beside the tool, so they travel with it."""
    base = root or Path(__file__).resolve().parent.parent
    return base / REGISTRY_FILENAME


def load(path: Path | None = None) -> dict[int, str]:
    """Car names taught to this installation, keyed by car id."""
    source = path or registry_path()
    if not source.exists():
        return {}
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        # A corrupt file costs a car name, not a session.
        return {}
    entries = payload.get("cars") if isinstance(payload, dict) else payload
    if not isinstance(entries, dict):
        return {}

    names: dict[int, str] = {}
    for key, value in entries.items():
        try:
            car_id = int(key)
        except (TypeError, ValueError):
            continue
        if isinstance(value, str) and value.strip():
            names[car_id] = value.strip()
    return names


def remember(car_id: int, name: str, path: Path | None = None) -> Path:
    """Records a name for one car id, keeping whatever else is already there."""
    source = path or registry_path()
    names = load(source)
    names[int(car_id)] = name.strip()
    payload = {
        "notes": [
            "Car names taught to this tool, for cars the bundled table predates.",
            "Safe to edit or delete. Keys are the car id GT7 puts in the packet.",
        ],
        "cars": {str(key): value for key, value in sorted(names.items())},
    }
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return source
