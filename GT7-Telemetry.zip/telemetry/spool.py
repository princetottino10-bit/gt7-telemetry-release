"""Keeps a recording safe on disk while it is still being driven.

A session used to live in memory until it ended: the laps, and the raw packets
behind them, were written only when the driver pressed stop. Closing the window
during a drive - or a crash, or the PC going to sleep - lost all of it, an hour
and a quarter in the longest session recorded so far. So every packet is also
appended to a file as it arrives. A recording that ends normally deletes the
file; one that does not leaves it behind, and the next start turns it into
sessions exactly as if the drive had just finished.

The file is the same length-prefixed format as raw.bin, so `--replay` reads it.
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

# Inside the sessions folder, beside what it will become. The underscore keeps
# it apart from the circuit folders, which the listing walks.
FOLDER = "_記録中"
SUFFIX = ".bin"
STAMP = "%Y-%m-%d_%H%M%S"
# One second of packets. Flushing hands them to Windows, which keeps them even
# if this process is killed the next moment.
FLUSH_EVERY = 60


class Spool:
    """The file one live recording is appending its packets to."""

    def __init__(self, path: Path, handle) -> None:
        self.path = path
        self._handle = handle
        self._pending = 0

    @classmethod
    def start(cls, sessions_root: Path, started_at: datetime) -> "Spool | None":
        """Opens the file, or returns None where it cannot be written.

        A full disk or a read-only folder must not stop the drive from being
        recorded the way it always was.
        """
        try:
            folder = Path(sessions_root) / FOLDER
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / f"{started_at.strftime(STAMP)}{SUFFIX}"
            return cls(path, open(path, "ab"))
        except OSError:
            return None

    def write(self, datagram: bytes) -> None:
        if self._handle is None:
            return
        try:
            self._handle.write(struct.pack("<H", len(datagram)) + datagram)
            self._pending += 1
            if self._pending >= FLUSH_EVERY:
                self._handle.flush()
                self._pending = 0
        except OSError:
            # The disk filled up mid-drive. The laps in memory are unaffected.
            self.close()

    def close(self) -> None:
        if self._handle is not None:
            try:
                self._handle.close()
            except OSError:
                pass
            self._handle = None

    def discard(self) -> None:
        """Removes the file: the recording reached its end and was saved."""
        self.close()
        _remove(self.path)


@dataclass
class Leftover:
    """A recording that never reached its end."""

    path: Path
    started_at: datetime

    def discard(self) -> None:
        _remove(self.path)

    def set_aside(self) -> Path:
        """Renames the file so it is kept but not tried again at every start."""
        kept = self.path.with_suffix(".failed")
        try:
            os.replace(self.path, kept)
        except OSError:
            return self.path
        return kept


def leftovers(sessions_root: Path) -> list[Leftover]:
    """Recordings left behind by a run that did not end, oldest first.

    A file another window is still writing to is not one of them. Windows
    refuses to rename a file that is open elsewhere, so each is claimed by
    renaming it, and one that cannot be renamed is left alone.
    """
    folder = Path(sessions_root) / FOLDER
    found: list[Leftover] = []
    try:
        candidates = sorted(folder.glob(f"*{SUFFIX}"))
    except OSError:
        return found
    for path in candidates:
        if path.name.endswith(f".claimed{SUFFIX}"):
            claimed, stamp = path, path.name[: -len(f".claimed{SUFFIX}")]
        else:
            stamp = path.stem
            claimed = path.with_name(f"{stamp}.claimed{SUFFIX}")
            try:
                os.replace(path, claimed)
            except OSError:
                continue
        try:
            started_at = datetime.strptime(stamp, STAMP)
        except ValueError:
            started_at = datetime.fromtimestamp(claimed.stat().st_mtime)
        found.append(Leftover(claimed, started_at))
    return found


def _remove(path: Path) -> None:
    try:
        path.unlink()
    except OSError:
        pass
    try:
        path.parent.rmdir()  # Only succeeds once the folder is empty.
    except OSError:
        pass
