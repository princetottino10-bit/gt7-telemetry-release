"""Finds the console on the local network, so nobody has to look up an IP.

GT7 only streams to whoever asks it to, so discovery is simply asking everyone:
a one byte heartbeat goes to every address on the local subnet, and the first
machine that answers with a decodable packet is the console.
"""

from __future__ import annotations

import ipaddress
import socket
import time
from dataclasses import dataclass, field
from pathlib import Path

from telemetry import packet as packet_module
from telemetry.packet import GT7Packet, PacketError

# One byte to 254 addresses is nothing; the wait is all in the reply.
DEFAULT_TIMEOUT_S = 6.0
# Re-ask this often while waiting, in case the first heartbeat was dropped.
RETRY_INTERVAL_S = 1.5
BUFFER_BYTES = 4096

# Where a confirmed address is remembered between runs.
SETTINGS_FILE = Path(__file__).resolve().parent.parent / "gt7-console.txt"


@dataclass
class DiscoveryResult:
    """What discovery found, and what it had to do to find it."""

    host: str | None
    packet: GT7Packet | None = None
    scanned: int = 0
    elapsed_s: float = 0.0
    subnets: list[str] = field(default_factory=list)

    @property
    def found(self) -> bool:
        return self.host is not None


def local_ipv4_addresses() -> list[str]:
    """Addresses this machine holds, most likely one first."""
    addresses: list[str] = []

    # The address used to reach the outside world is the one on the LAN the
    # console is most likely to share.
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        addresses.append(probe.getsockname()[0])
    except OSError:
        pass
    finally:
        probe.close()

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            address = info[4][0]
            if address not in addresses:
                addresses.append(address)
    except socket.gaierror:
        pass

    return [address for address in addresses if not address.startswith("127.")]


def subnet_hosts(address: str, prefix: int = 24) -> list[str]:
    """Every usable address on the same subnet as `address`."""
    network = ipaddress.ip_network(f"{address}/{prefix}", strict=False)
    return [str(host) for host in network.hosts()]


def remembered_host() -> str | None:
    """The console address confirmed on a previous run, if any."""
    try:
        value = SETTINGS_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return None
    return value


def remember_host(host: str) -> None:
    """Saves a working address so the next run connects straight away."""
    try:
        SETTINGS_FILE.write_text(host + "\n", encoding="utf-8")
    except OSError:
        pass  # A read-only install is not a reason to fail a capture.


def discover(
    *,
    timeout_s: float = DEFAULT_TIMEOUT_S,
    receive_port: int = packet_module.RECEIVE_PORT,
    send_port: int = packet_module.SEND_PORT,
    extra_hosts: list[str] | None = None,
    on_progress=None,
) -> DiscoveryResult:
    """Asks every address on the local subnet for telemetry; returns the responder."""
    started = time.monotonic()
    locals_ = local_ipv4_addresses()

    targets: list[str] = list(extra_hosts or [])
    subnets: list[str] = []
    for address in locals_:
        network = ipaddress.ip_network(f"{address}/24", strict=False)
        subnets.append(str(network))
        for host in subnet_hosts(address):
            if host != address and host not in targets:
                targets.append(host)

    result = DiscoveryResult(host=None, scanned=len(targets), subnets=subnets)
    if not targets:
        result.elapsed_s = time.monotonic() - started
        return result

    listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        listener.bind(("0.0.0.0", receive_port))
        listener.settimeout(0.4)

        last_sweep = 0.0
        while time.monotonic() - started < timeout_s:
            if time.monotonic() - last_sweep >= RETRY_INTERVAL_S:
                if on_progress is not None:
                    on_progress(len(targets))
                for host in targets:
                    try:
                        sender.sendto(packet_module.HEARTBEAT, (host, send_port))
                    except OSError:
                        continue  # Unreachable address on this interface.
                last_sweep = time.monotonic()

            try:
                data, address = listener.recvfrom(BUFFER_BYTES)
            except socket.timeout:
                continue

            try:
                decoded = packet_module.decode(data)
            except PacketError:
                continue

            result.host = address[0]
            result.packet = decoded
            break
    finally:
        listener.close()
        sender.close()

    result.elapsed_s = time.monotonic() - started
    return result


def resolve_host(explicit: str | None, *, timeout_s: float = DEFAULT_TIMEOUT_S, on_progress=None) -> DiscoveryResult:
    """Works out which console to talk to: the given one, the remembered one, or
    whatever answers on the network."""
    if explicit:
        return DiscoveryResult(host=explicit)

    saved = remembered_host()
    result = discover(timeout_s=timeout_s, extra_hosts=[saved] if saved else None, on_progress=on_progress)
    if result.found:
        remember_host(result.host)
    return result
