"""Recognises which circuit a lap was driven on.

GT7 does not put the track name in the packet, so the only thing available is
the shape of the lap itself. A lap's length and the size of the box its
coordinates occupy are enough to tell circuits apart in practice, and both are
stable between sessions because they come from the game's own world coordinates.

The registry starts empty and learns: name a track once, and every later session
on it is recognised without being asked.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

REGISTRY_FILENAME = "known_tracks.json"

# A lap driven wide differs from one driven tight, and a lap can be cut short by
# a spin, so the match has to tolerate a few percent either way while still
# separating circuits that genuinely differ in size.
LENGTH_TOLERANCE = 0.03
EXTENT_TOLERANCE = 0.06


@dataclass(frozen=True)
class Fingerprint:
    """What a lap looks like, reduced to a few numbers.

    `clockwise` is what tells a reverse layout from the circuit it reverses.
    Length and the size of the coordinate box are identical for the two, so
    without it a reverse lap joins the forward circuit's folder and every
    segment in the shared definition lands in the wrong place.
    """

    length_m: float
    width_m: float
    depth_m: float
    height_m: float
    # None on entries written before direction was recorded; those still match
    # either way round rather than being silently dropped.
    clockwise: bool | None = None

    def matches(self, other: "Fingerprint") -> bool:
        if not _within(self.length_m, other.length_m, LENGTH_TOLERANCE):
            return False
        if (
            self.clockwise is not None
            and other.clockwise is not None
            and self.clockwise != other.clockwise
        ):
            return False
        # Orientation is fixed by the game, so width and depth are comparable
        # directly rather than as an unordered pair.
        return _within(self.width_m, other.width_m, EXTENT_TOLERANCE) and _within(
            self.depth_m, other.depth_m, EXTENT_TOLERANCE
        )


def _within(value: float, reference: float, tolerance: float) -> bool:
    if reference <= 0:
        return value <= 0
    return abs(value - reference) / reference <= tolerance


def fingerprint_from_positions(positions: Iterable[tuple[float, float, float]], length_m: float) -> Fingerprint:
    """Builds a fingerprint from a lap's world coordinates."""
    xs: list[float] = []
    ys: list[float] = []
    zs: list[float] = []
    for x, y, z in positions:
        xs.append(x)
        ys.append(y)
        zs.append(z)
    if not xs:
        return Fingerprint(length_m=round(length_m, 1), width_m=0.0, depth_m=0.0, height_m=0.0)
    return Fingerprint(
        length_m=round(length_m, 1),
        width_m=round(max(xs) - min(xs), 1),
        depth_m=round(max(zs) - min(zs), 1),
        height_m=round(max(ys) - min(ys), 1),
        clockwise=_runs_clockwise(xs, zs),
    )


def _runs_clockwise(xs: list[float], zs: list[float]) -> bool | None:
    """Which way round the lap was driven, by the sign of the area it encloses.

    Screen Y follows world Z downward, so a positive shoelace area is the loop a
    viewer reads as clockwise. A lap too short to enclose anything gives None
    rather than a coin toss.
    """
    if len(xs) < 8:
        return None
    centre_x = sum(xs) / len(xs)
    centre_z = sum(zs) / len(zs)
    area = 0.0
    for index in range(len(xs)):
        following = (index + 1) % len(xs)
        area += (xs[index] - centre_x) * (zs[following] - centre_z) - (
            xs[following] - centre_x
        ) * (zs[index] - centre_z)
    if abs(area) < 1.0:
        return None
    # World Z runs down the screen, so a positive shoelace area in (x, z) is the
    # loop that reads as clockwise - the same convention the track map draws in.
    return area > 0


def fingerprint_from_lap(lap: Any) -> Fingerprint:
    """Builds a fingerprint from a recorded lap."""
    return fingerprint_from_positions(
        (sample.position for sample in lap.samples), lap.distance_m
    )


# What a circuit is called before anyone has said what it is. The length is in
# the name so two unnamed circuits do not collide, and so the driver has
# something to recognise it by.
PLACEHOLDER_PREFIX = "未設定のコース"


def placeholder_name(length_m: float) -> str:
    return f"{PLACEHOLDER_PREFIX} {length_m / 1000:.3f}km"


def is_placeholder(name: str) -> bool:
    return name.startswith(PLACEHOLDER_PREFIX)


_PLACEHOLDER_LENGTH = re.compile(r"(\d+\.\d+)\s*km")


def display_name(name: str) -> str:
    """How a circuit is shown on screen.

    The placeholder stays what it always was on disk, so folders and the
    registry written by earlier versions keep matching. Only what the driver
    reads changes: "未設定" read as a chore left undone, while the length alone
    is something to recognise the circuit by.
    """
    if not is_placeholder(name):
        return name
    found = _PLACEHOLDER_LENGTH.search(name)
    return f"{found.group(1)}kmのコース" if found else "名前の無いコース"


def slug(name: str) -> str:
    """A filesystem-safe folder name, keeping Japanese names readable."""
    normalised = unicodedata.normalize("NFKC", name).strip()
    # Spaces and separators become hyphens; anything a filesystem dislikes goes.
    normalised = re.sub(r"[\s_/\\]+", "-", normalised)
    normalised = re.sub(r'[<>:"|?*\x00-\x1f]', "", normalised)
    normalised = re.sub(r"-{2,}", "-", normalised).strip("-.")
    return normalised.lower() or "unknown-track"


REFERENCE_LENGTHS = Path(__file__).resolve().parent.parent / "assets" / "db" / "circuit_lengths.json"
# How far a published length may sit from the measured one and still be offered.
# The one circuit measured so far came out 2 m from its published figure, but a
# lap driven wide, or one cut short, moves it further than that.
SUGGESTION_TOLERANCE = 0.04


def suggest_names(fingerprint: "Fingerprint", *, limit: int = 4, path: Path | None = None) -> list[tuple[str, float]]:
    """Circuits whose published length is close to the one just driven.

    Only ever a prompt for the driver to confirm. Nothing here is measured from
    the game, so nothing here may name a track on its own.
    """
    source = path or REFERENCE_LENGTHS
    if not source.exists():
        return []
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    measured_km = fingerprint.length_m / 1000
    if measured_km <= 0:
        return []

    scored: list[tuple[str, float]] = []
    for entry in payload.get("circuits", []):
        try:
            name = str(entry["name"])
            km = float(entry["km"])
        except (KeyError, TypeError, ValueError):
            continue
        if km <= 0:
            continue
        error = abs(measured_km - km) / km
        if error <= SUGGESTION_TOLERANCE:
            scored.append((name, km))
    scored.sort(key=lambda item: abs(measured_km - item[1]))
    return scored[:limit]


# Shapes of circuits a driver has already named, shipped with the tool so a new
# installation recognises them on the first lap. Each one was measured from a
# real session and named by the person who drove it; length alone is not enough
# (Suzuka measures 5.746 km, nearer Daytona's published length than its own).
BUNDLED_SHAPES = Path(__file__).resolve().parent.parent / "assets" / "db" / "known_shapes.json"


def _read_entries(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        # A corrupt registry costs a name, not a session.
        return []
    entries = payload.get("tracks") if isinstance(payload, dict) else payload
    if not isinstance(entries, list):
        return []
    return [entry for entry in entries if isinstance(entry, dict) and entry.get("name")]


def _closest(entries: list[dict[str, Any]], fingerprint: Fingerprint) -> str | None:
    """The closest-length entry whose shape matches, if any."""
    best: tuple[float, str] | None = None
    for entry in entries:
        try:
            known = Fingerprint(
                length_m=float(entry["length_m"]),
                width_m=float(entry["width_m"]),
                depth_m=float(entry["depth_m"]),
                height_m=float(entry.get("height_m", 0.0)),
                clockwise=entry.get("clockwise"),
            )
        except (KeyError, TypeError, ValueError):
            continue
        if not fingerprint.matches(known):
            continue
        # Several circuits can be a similar size; take the closest length.
        error = abs(fingerprint.length_m - known.length_m)
        if best is None or error < best[0]:
            best = (error, str(entry["name"]))
    return best[1] if best else None


class Registry:
    """The set of circuits this installation has been told the names of."""

    def __init__(self, path: Path, *, bundled: Path | None = BUNDLED_SHAPES) -> None:
        self.path = path
        self.entries: list[dict[str, Any]] = _read_entries(path)
        # Consulted only when this installation's own entries have no match, so
        # a name the driver gave always wins over the shipped one.
        self.bundled: list[dict[str, Any]] = _read_entries(bundled)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "notes": [
                "Learned circuit fingerprints. Safe to edit or delete.",
                "A track is matched on lap length and the size of its coordinate box.",
            ],
            "tracks": self.entries,
        }
        self.path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )

    def identify(self, fingerprint: Fingerprint) -> str | None:
        """The name of the circuit this fingerprint belongs to, if it is known."""
        own = _closest(self.entries, fingerprint)
        if own is not None and not is_placeholder(own):
            return own
        return _closest(self.bundled, fingerprint) or own

    def name_for_slug(self, folder_slug: str) -> str | None:
        """The circuit whose slug is `folder_slug`, if one is registered."""
        for entry in self.entries:
            name = str(entry["name"])
            if slug(name) == folder_slug:
                return name
        return None

    def name_for_length(self, length_m: float) -> str | None:
        """The one registered circuit of this length, when it is unambiguous.

        Length alone is weaker than a full fingerprint, so anything that could
        be two circuits is left alone rather than guessed at.
        """
        hits = [
            str(entry["name"])
            for entry in self.entries
            if _within(length_m, float(entry.get("length_m", 0.0)), LENGTH_TOLERANCE)
        ]
        return hits[0] if len(hits) == 1 else None

    def remember(self, name: str, fingerprint: Fingerprint) -> None:
        """Records a name for this shape, replacing any previous entry for it.

        A real name also replaces the placeholder this shape was filed under, so
        the circuit is not identified as both.
        """
        self.entries = [
            entry
            for entry in self.entries
            if (str(entry.get("name")) != name and (is_placeholder(name) or not is_placeholder(str(entry.get("name")))))
            or not Fingerprint(
                length_m=float(entry.get("length_m", 0.0)),
                width_m=float(entry.get("width_m", 0.0)),
                depth_m=float(entry.get("depth_m", 0.0)),
                height_m=float(entry.get("height_m", 0.0)),
            ).matches(fingerprint)
        ]
        self.entries.append({"name": name, "slug": slug(name), **asdict(fingerprint)})
        self.entries.sort(key=lambda entry: str(entry.get("name", "")))

    def forget(self, name: str) -> None:
        """Drops a name, e.g. one typed wrong and since put right."""
        self.entries = [entry for entry in self.entries if str(entry.get("name")) != name]
