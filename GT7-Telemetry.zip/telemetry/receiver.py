"""UDP client for the GT7 simulator interface.

The console only streams while it is being asked to: a one byte heartbeat has to
be sent periodically or the packets stop. Everything else is a plain UDP read at
60 Hz.
"""

from __future__ import annotations

import socket
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass

from telemetry import packet as packet_module
from telemetry.packet import GT7Packet, PacketError

# Re-send the heartbeat this often. The console stops streaming after a few
# seconds of silence, so this has to stay well inside that window.
HEARTBEAT_INTERVAL_S = 1.0
# A read timeout short enough to keep the heartbeat on schedule.
READ_TIMEOUT_S = 0.5
BUFFER_BYTES = 4096


@dataclass
class ReceiverStats:
    """Counters that make a capture session diagnosable after the fact."""

    received: int = 0
    decoded: int = 0
    undecodable: int = 0
    dropped: int = 0
    duplicated: int = 0
    heartbeats: int = 0
    # Reads that came back "host unreachable" - the console is not listening
    # right now. Counted rather than fatal.
    unreachable: int = 0
    first_packet_id: int | None = None
    last_packet_id: int | None = None

    def note_packet_id(self, packet_id: int) -> None:
        """Tracks gaps in the console's packet counter."""
        if self.first_packet_id is None:
            self.first_packet_id = packet_id
        elif self.last_packet_id is not None:
            step = packet_id - self.last_packet_id
            if step <= 0:
                self.duplicated += 1
            elif step > 1:
                self.dropped += step - 1
        self.last_packet_id = packet_id

    def summary(self) -> str:
        return (
            f"received {self.received}, decoded {self.decoded}, "
            f"undecodable {self.undecodable}, dropped {self.dropped}, "
            f"duplicated {self.duplicated}, heartbeats {self.heartbeats}"
            + (f", 無応答 {self.unreachable}" if self.unreachable else "")
        )


class GT7Receiver:
    """Streams decoded packets from a console on the local network."""

    def __init__(
        self,
        host: str,
        *,
        send_port: int = packet_module.SEND_PORT,
        receive_port: int = packet_module.RECEIVE_PORT,
        heartbeat_interval_s: float = HEARTBEAT_INTERVAL_S,
        read_timeout_s: float = READ_TIMEOUT_S,
    ) -> None:
        self.host = host
        self.send_port = send_port
        self.receive_port = receive_port
        self.heartbeat_interval_s = heartbeat_interval_s
        self.read_timeout_s = read_timeout_s
        self.stats = ReceiverStats()
        self._socket: socket.socket | None = None
        self._last_heartbeat = 0.0

    def __enter__(self) -> "GT7Receiver":
        self.open()
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def open(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.receive_port))
        sock.settimeout(self.read_timeout_s)
        self._socket = sock
        self._last_heartbeat = 0.0
        self.send_heartbeat()

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    def send_heartbeat(self) -> None:
        """Asks the console to keep streaming."""
        if self._socket is None:
            raise RuntimeError("receiver is not open")
        self._socket.sendto(packet_module.HEARTBEAT, (self.host, self.send_port))
        self._last_heartbeat = time.monotonic()
        self.stats.heartbeats += 1

    def raw_datagrams(
        self,
        *,
        stop_after_s: float | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> Iterator[bytes]:
        """Yields raw datagrams, keeping the heartbeat alive between reads.

        `should_stop` is checked between reads rather than only after a packet
        arrives. GT7 stops streaming in menus and while paused, which is exactly
        when someone reaches for the stop button, and a caller that could only
        act on the next packet would sit there until the driver went back on
        track just to end the session.
        """
        if self._socket is None:
            raise RuntimeError("receiver is not open; use it as a context manager")

        started = time.monotonic()
        while True:
            if should_stop is not None and should_stop():
                return
            if stop_after_s is not None and time.monotonic() - started >= stop_after_s:
                return
            if time.monotonic() - self._last_heartbeat >= self.heartbeat_interval_s:
                self.send_heartbeat()
            try:
                data, _address = self._socket.recvfrom(BUFFER_BYTES)
            except socket.timeout:
                continue
            except ConnectionResetError:
                # UDP has no connection to reset, but Windows raises this on the
                # read that follows an ICMP port-unreachable - which is what a
                # console that has gone to the menu, been switched off or gone to
                # sleep replies to the heartbeat with. It is a lull, not a
                # failure: keep asking, and the stream comes back when the driver
                # goes out again. Before this it ended the recording outright.
                self.stats.unreachable += 1
                continue
            self.stats.received += 1
            yield data

    def packets(
        self,
        *,
        stop_after_s: float | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> Iterator[GT7Packet]:
        """Yields decoded packets, skipping anything that fails to decode."""
        for data in self.raw_datagrams(stop_after_s=stop_after_s, should_stop=should_stop):
            try:
                decoded = packet_module.decode(data)
            except PacketError:
                self.stats.undecodable += 1
                continue
            self.stats.decoded += 1
            self.stats.note_packet_id(decoded.packet_id)
            yield decoded


class ReplaySource:
    """Replays raw datagrams captured earlier, so the tooling can be developed
    and tested without a console on the network."""

    def __init__(self, datagrams: list[bytes], *, realtime: bool = False) -> None:
        self.datagrams = datagrams
        self.realtime = realtime
        self.stats = ReceiverStats()

    def __enter__(self) -> "ReplaySource":
        return self

    def __exit__(self, *_exc: object) -> None:
        return None

    def raw_datagrams(
        self,
        *,
        stop_after_s: float | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> Iterator[bytes]:
        """The undecoded datagrams, matching the live receiver's interface.

        Without this, anything that asks for raw packets quietly captured
        nothing when fed a replay, which makes that path impossible to test.
        """
        started = time.monotonic()
        for data in self.datagrams:
            if should_stop is not None and should_stop():
                return
            if stop_after_s is not None and time.monotonic() - started >= stop_after_s:
                return
            self.stats.received += 1
            if self.realtime:
                time.sleep(1 / 60)
            yield data

    def packets(
        self,
        *,
        stop_after_s: float | None = None,
        should_stop: Callable[[], bool] | None = None,
    ) -> Iterator[GT7Packet]:
        for data in self.raw_datagrams(stop_after_s=stop_after_s, should_stop=should_stop):
            try:
                decoded = packet_module.decode(data)
            except PacketError:
                self.stats.undecodable += 1
                continue
            self.stats.decoded += 1
            self.stats.note_packet_id(decoded.packet_id)
            yield decoded


def read_raw_capture(path) -> list[bytes]:
    """Reads a raw capture file: each datagram prefixed with its 2 byte length."""
    import struct
    from pathlib import Path

    data = Path(path).read_bytes()
    datagrams: list[bytes] = []
    cursor = 0
    while cursor + 2 <= len(data):
        (length,) = struct.unpack_from("<H", data, cursor)
        cursor += 2
        if cursor + length > len(data):
            break
        datagrams.append(data[cursor : cursor + length])
        cursor += length
    return datagrams


def write_raw_capture(path, datagrams: list[bytes]) -> None:
    """Writes datagrams with a 2 byte length prefix each."""
    import struct
    from pathlib import Path

    buffer = bytearray()
    for datagram in datagrams:
        buffer += struct.pack("<H", len(datagram)) + datagram
    # Left uncompressed on purpose. These are Salsa20 ciphertext: gzip took a
    # measured 10.8 MB capture to 10.8 MB, all of the cost and none of the gain.
    # The session JSON beside it goes to a third, and that is where the space is.
    Path(path).write_bytes(bytes(buffer))
