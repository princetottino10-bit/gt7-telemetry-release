"""GT7 simulator interface packet: decryption and field layout.

The console encrypts each packet with Salsa20 using a fixed key. The nonce is
carried inside the packet itself: a 32 bit word at offset 0x40, paired with the
same word XORed against a constant.

IMPORTANT: the field offsets below are the community-documented layout and have
not been confirmed against a live console in this project. `describe()` and the
`--raw` mode of capture_gt7.py exist so the layout can be checked against a real
session before the data is trusted.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Any

from telemetry import salsa20

# The key is the ASCII name of the interface, truncated to Salsa20's key length.
KEY = b"Simulator Interface Packet GT7 ver 0.0"[:32]
NONCE_OFFSET = 0x40
NONCE_XOR = 0xDEADBEAF

# Decrypted packets start with this marker; anything else is not a GT7 packet.
MAGIC = 0x47375330
PACKET_SIZE = 0x128

# Ports the console listens on and replies to.
SEND_PORT = 33739
RECEIVE_PORT = 33740
HEARTBEAT = b"A"

FLAG_BITS = {
    "on_track": 0,
    "paused": 1,
    "loading": 2,
    "in_gear": 3,
    "has_turbo": 4,
    "rev_limiter": 5,
    "handbrake": 6,
    "lights": 7,
    "high_beam": 8,
    "low_beam": 9,
    "asm_active": 10,
    "tcs_active": 11,
}


class PacketError(ValueError):
    """Raised when a datagram is not a decodable GT7 packet."""


def decrypt(raw: bytes) -> bytes:
    """Decrypts one datagram, deriving the nonce from the packet itself."""
    if len(raw) < NONCE_OFFSET + 4:
        raise PacketError(f"datagram too short to hold a nonce: {len(raw)} bytes")

    iv1 = struct.unpack_from("<I", raw, NONCE_OFFSET)[0]
    iv2 = iv1 ^ NONCE_XOR
    nonce = struct.pack("<II", iv2, iv1)
    plain = salsa20.crypt(raw, KEY, nonce)

    magic = struct.unpack_from("<I", plain, 0)[0]
    if magic != MAGIC:
        raise PacketError(f"bad magic after decryption: 0x{magic:08x}")
    return plain


@dataclass(frozen=True)
class GT7Packet:
    """One 60 Hz sample of car and session state."""

    packet_id: int
    position: tuple[float, float, float]
    velocity: tuple[float, float, float]
    rotation: tuple[float, float, float, float]
    angular_velocity: tuple[float, float, float]
    ride_height: float
    rpm: float
    fuel_level: float
    fuel_capacity: float
    speed_mps: float
    boost: float
    oil_pressure: float
    water_temp: float
    oil_temp: float
    tire_temps: tuple[float, float, float, float]
    lap_count: int
    laps_in_race: int
    best_lap_ms: int
    last_lap_ms: int
    time_of_day_ms: int
    pre_race_position: int
    num_cars: int
    rpm_alert_min: int
    rpm_alert_max: int
    calculated_max_speed: int
    flags: int
    gear: int
    suggested_gear: int
    throttle: int
    brake: int
    road_plane: tuple[float, float, float]
    road_plane_distance: float
    wheel_rps: tuple[float, float, float, float]
    tire_radius: tuple[float, float, float, float]
    suspension_travel: tuple[float, float, float, float]
    clutch_pedal: float
    clutch_engagement: float
    gearbox_rpm: float
    transmission_top_speed: float
    gear_ratios: tuple[float, ...]
    car_code: int

    @property
    def speed_kmh(self) -> float:
        return self.speed_mps * 3.6

    @property
    def throttle_pct(self) -> float:
        return self.throttle * 100.0 / 255.0

    @property
    def brake_pct(self) -> float:
        return self.brake * 100.0 / 255.0

    @property
    def boost_kpa(self) -> float:
        """Manifold pressure relative to atmospheric, as the game reports it."""
        return (self.boost - 1.0) * 100.0

    def flag(self, name: str) -> bool:
        return bool(self.flags & (1 << FLAG_BITS[name]))

    @property
    def is_paused(self) -> bool:
        return self.flag("paused")

    @property
    def is_loading(self) -> bool:
        return self.flag("loading")

    @property
    def on_track(self) -> bool:
        return self.flag("on_track")


def parse(plain: bytes) -> GT7Packet:
    """Reads the decrypted byte layout into a packet."""
    if len(plain) < PACKET_SIZE:
        raise PacketError(f"packet too short: {len(plain)} bytes, need {PACKET_SIZE}")

    read_floats = lambda offset, count: struct.unpack_from(f"<{count}f", plain, offset)
    gear_byte = struct.unpack_from("<B", plain, 0x90)[0]

    return GT7Packet(
        packet_id=struct.unpack_from("<i", plain, 0x70)[0],
        position=read_floats(0x04, 3),
        velocity=read_floats(0x10, 3),
        rotation=read_floats(0x1C, 4),
        angular_velocity=read_floats(0x2C, 3),
        ride_height=read_floats(0x38, 1)[0],
        rpm=read_floats(0x3C, 1)[0],
        fuel_level=read_floats(0x44, 1)[0],
        fuel_capacity=read_floats(0x48, 1)[0],
        speed_mps=read_floats(0x4C, 1)[0],
        boost=read_floats(0x50, 1)[0],
        oil_pressure=read_floats(0x54, 1)[0],
        water_temp=read_floats(0x58, 1)[0],
        oil_temp=read_floats(0x5C, 1)[0],
        tire_temps=read_floats(0x60, 4),
        lap_count=struct.unpack_from("<h", plain, 0x74)[0],
        laps_in_race=struct.unpack_from("<h", plain, 0x76)[0],
        best_lap_ms=struct.unpack_from("<i", plain, 0x78)[0],
        last_lap_ms=struct.unpack_from("<i", plain, 0x7C)[0],
        time_of_day_ms=struct.unpack_from("<i", plain, 0x80)[0],
        pre_race_position=struct.unpack_from("<h", plain, 0x84)[0],
        num_cars=struct.unpack_from("<h", plain, 0x86)[0],
        rpm_alert_min=struct.unpack_from("<h", plain, 0x88)[0],
        rpm_alert_max=struct.unpack_from("<h", plain, 0x8A)[0],
        calculated_max_speed=struct.unpack_from("<h", plain, 0x8C)[0],
        flags=struct.unpack_from("<H", plain, 0x8E)[0],
        gear=gear_byte & 0x0F,
        # The console writes 15 when it has no gear to suggest; report that as 0
        # so the live view does not announce a fifteenth gear.
        suggested_gear=0 if (gear_byte >> 4) & 0x0F == 0x0F else (gear_byte >> 4) & 0x0F,
        throttle=struct.unpack_from("<B", plain, 0x91)[0],
        brake=struct.unpack_from("<B", plain, 0x92)[0],
        road_plane=read_floats(0x94, 3),
        road_plane_distance=read_floats(0xA0, 1)[0],
        wheel_rps=read_floats(0xA4, 4),
        tire_radius=read_floats(0xB4, 4),
        suspension_travel=read_floats(0xC4, 4),
        clutch_pedal=read_floats(0xF4, 1)[0],
        clutch_engagement=read_floats(0xF8, 1)[0],
        gearbox_rpm=read_floats(0xFC, 1)[0],
        transmission_top_speed=read_floats(0x100, 1)[0],
        gear_ratios=read_floats(0x104, 8),
        car_code=struct.unpack_from("<i", plain, 0x124)[0],
    )


def decode(raw: bytes) -> GT7Packet:
    """Decrypts and parses one datagram."""
    return parse(decrypt(raw))


# Plausibility ranges used to sanity check a live capture. These are deliberately
# wide: they catch a misread layout, not a slow lap.
PLAUSIBLE = {
    "rpm": (0.0, 20000.0),
    "speed_kmh": (0.0, 500.0),
    "throttle_pct": (0.0, 100.0),
    "brake_pct": (0.0, 100.0),
    "gear": (0, 10),
    "water_temp": (-50.0, 200.0),
    "oil_temp": (-50.0, 300.0),
    "fuel_level": (-1.0, 1000.0),
}


def implausible_fields(packet: GT7Packet) -> list[str]:
    """Names the fields whose values fall outside a physically sensible range.

    A non-empty result on a real capture means the offsets in this module do not
    match the console's current packet format.
    """
    problems: list[str] = []
    for name, (low, high) in PLAUSIBLE.items():
        value = getattr(packet, name)
        if not (low <= value <= high):
            problems.append(f"{name}={value!r} outside [{low}, {high}]")
    return problems


def describe(packet: GT7Packet) -> str:
    """A one-screen dump used to eyeball a live capture against the game."""
    lines = [
        f"packet #{packet.packet_id}  lap {packet.lap_count}/{packet.laps_in_race}",
        f"  speed   {packet.speed_kmh:7.1f} km/h   rpm {packet.rpm:7.0f}   gear {packet.gear}",
        f"  pedals  throttle {packet.throttle_pct:5.1f}%  brake {packet.brake_pct:5.1f}%",
        f"  position {packet.position[0]:9.2f} {packet.position[1]:8.2f} {packet.position[2]:9.2f}",
        f"  tyres   {' '.join(f'{t:5.1f}' for t in packet.tire_temps)} degC",
        f"  fluids  water {packet.water_temp:5.1f}  oil {packet.oil_temp:5.1f}  press {packet.oil_pressure:5.2f}",
        f"  fuel    {packet.fuel_level:6.2f} / {packet.fuel_capacity:6.2f}",
        f"  laps    best {packet.best_lap_ms} ms   last {packet.last_lap_ms} ms",
        f"  flags   0x{packet.flags:04x}  " + " ".join(
            name for name in FLAG_BITS if packet.flag(name)
        ),
    ]
    return "\n".join(lines)


def encode_for_test(packet_fields: dict[str, Any], *, iv: int = 0x11223344) -> bytes:
    """Builds an encrypted packet from field values, for tests without a console."""
    plain = bytearray(PACKET_SIZE)
    struct.pack_into("<I", plain, 0, MAGIC)

    layout: dict[str, tuple[str, int]] = {
        "position": ("<3f", 0x04),
        "velocity": ("<3f", 0x10),
        "rotation": ("<4f", 0x1C),
        "angular_velocity": ("<3f", 0x2C),
        "ride_height": ("<f", 0x38),
        "rpm": ("<f", 0x3C),
        "fuel_level": ("<f", 0x44),
        "fuel_capacity": ("<f", 0x48),
        "speed_mps": ("<f", 0x4C),
        "boost": ("<f", 0x50),
        "oil_pressure": ("<f", 0x54),
        "water_temp": ("<f", 0x58),
        "oil_temp": ("<f", 0x5C),
        "tire_temps": ("<4f", 0x60),
        "packet_id": ("<i", 0x70),
        "lap_count": ("<h", 0x74),
        "laps_in_race": ("<h", 0x76),
        "best_lap_ms": ("<i", 0x78),
        "last_lap_ms": ("<i", 0x7C),
        "time_of_day_ms": ("<i", 0x80),
        "pre_race_position": ("<h", 0x84),
        "num_cars": ("<h", 0x86),
        "rpm_alert_min": ("<h", 0x88),
        "rpm_alert_max": ("<h", 0x8A),
        "calculated_max_speed": ("<h", 0x8C),
        "flags": ("<H", 0x8E),
        "throttle": ("<B", 0x91),
        "brake": ("<B", 0x92),
        "road_plane": ("<3f", 0x94),
        "road_plane_distance": ("<f", 0xA0),
        "wheel_rps": ("<4f", 0xA4),
        "tire_radius": ("<4f", 0xB4),
        "suspension_travel": ("<4f", 0xC4),
        "clutch_pedal": ("<f", 0xF4),
        "clutch_engagement": ("<f", 0xF8),
        "gearbox_rpm": ("<f", 0xFC),
        "transmission_top_speed": ("<f", 0x100),
        "gear_ratios": ("<8f", 0x104),
        "car_code": ("<i", 0x124),
    }

    for name, value in packet_fields.items():
        if name in ("gear", "suggested_gear"):
            continue
        fmt, offset = layout[name]
        if isinstance(value, (tuple, list)):
            struct.pack_into(fmt, plain, offset, *value)
        else:
            struct.pack_into(fmt, plain, offset, value)

    gear = packet_fields.get("gear", 0) & 0x0F
    suggested = (packet_fields.get("suggested_gear", 0) & 0x0F) << 4
    struct.pack_into("<B", plain, 0x90, gear | suggested)

    # The console carries the nonce in the ciphertext, so the encrypted packet is
    # patched to hold it. Whatever that overwrites decrypts to noise, which is
    # why no field is mapped to 0x40.
    nonce = struct.pack("<II", iv ^ NONCE_XOR, iv)
    cipher = bytearray(salsa20.crypt(bytes(plain), KEY, nonce))
    struct.pack_into("<I", cipher, NONCE_OFFSET, iv)
    return bytes(cipher)
