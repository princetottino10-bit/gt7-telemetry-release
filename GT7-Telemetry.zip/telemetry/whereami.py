"""Which circuit the car is on, and where on it, before a lap has been completed.

The packets carry no track id, so the circuit is otherwise only known once a
whole lap's shape has been matched (tracks.py), and the live view's "next
corner" box stayed empty for the whole first lap. The console's positions are
the same world coordinates every time a circuit is driven, so the car's last
few hundred metres are laid over the line of a lap already recorded there this
week: the circuit whose line they follow, in the direction it was driven, is
the one being driven, and the nearest point of that line says how far round
the lap the car is.

Only circuits with a report this week are tried, since only they have targets
to show; the shape of the first full lap still has the last word.
"""

from __future__ import annotations

import gzip
import json
import math
import threading
from datetime import date
from pathlib import Path
from typing import Any

from telemetry import focus, sessions

# A point closer than this to a line is on it: the track is 12-15 m wide and
# the driver's line moves about within it.
ON_LINE_M = 15.0
# Trail points are kept this far apart, which also skips a parked car.
STEP_M = 5.0
# How far the car has to have gone before a circuit is named. Shorter than
# this, a straight on one circuit could pass for a straight on another.
MIN_TRAIL_M = 400.0
TRAIL_POINTS = 160
# Farther than this between two readings is a new circuit or a restart.
JUMP_M = 150.0
SHARE_ON_LINE = 0.9
SHARE_FORWARD = 0.8
CELL_M = 20.0


class CircuitLine:
    """One recorded lap's line, with a grid for finding the nearest point fast."""

    def __init__(self, xs: list[float], zs: list[float], ds: list[float]) -> None:
        self.xs, self.zs = xs, zs
        self.length = ds[-1] if ds and ds[-1] > 0 else 1.0
        self.ds = ds
        self.grid: dict[tuple[int, int], list[int]] = {}
        for i, (x, z) in enumerate(zip(xs, zs)):
            self.grid.setdefault(self._cell(x, z), []).append(i)

    @staticmethod
    def _cell(x: float, z: float) -> tuple[int, int]:
        return int(math.floor(x / CELL_M)), int(math.floor(z / CELL_M))

    def nearest(self, x: float, z: float, near: int | None = None) -> tuple[int, float] | None:
        """The closest point within ON_LINE_M, preferring one just after `near`.

        Where the line crosses itself (Suzuka) two points are equally close; the
        one following the last known place is the one the car is at.
        """
        cx, cz = self._cell(x, z)
        best: tuple[float, int] | None = None
        count = len(self.xs)
        for gx in (cx - 1, cx, cx + 1):
            for gz in (cz - 1, cz, cz + 1):
                for i in self.grid.get((gx, gz), ()):
                    gap = math.hypot(self.xs[i] - x, self.zs[i] - z)
                    if gap > ON_LINE_M:
                        continue
                    score = gap
                    if near is not None and (i - near) % count > count // 4:
                        score += ON_LINE_M  # far from the last place: only if nothing nearer
                    if best is None or score < best[0]:
                        best = (score, i)
        if best is None:
            return None
        i = best[1]
        return i, math.hypot(self.xs[i] - x, self.zs[i] - z)

    def follows(self, trail: list[tuple[float, float]]) -> bool:
        """Whether the trail lies on this line, driven the same way round."""
        found = [self.nearest(x, z) for x, z in trail]
        on = [hit[0] for hit in found if hit is not None]
        if len(on) < SHARE_ON_LINE * len(trail):
            return False
        count = len(self.xs)
        steps = [(b - a) % count for a, b in zip(on, on[1:])]
        forward = sum(1 for step in steps if 0 <= step < count // 4)
        return bool(steps) and forward >= SHARE_FORWARD * len(steps)


def read_line(folder: Path) -> CircuitLine | None:
    """The fastest lap's line in a session folder."""
    try:
        raw = (folder / sessions.SESSION_FILENAME).read_bytes()
        if raw[:2] == b"\x1f\x8b":
            raw = gzip.decompress(raw)
        laps = json.loads(raw)
    except (OSError, ValueError):
        return None
    usable = [
        lap
        for lap in laps
        if isinstance(lap, dict) and lap.get("data_distance_m") and lap.get("data_position_x") and lap.get("lap_finish_time", 0) > 0
    ]
    if not usable:
        return None
    lap = min(usable, key=lambda lap: lap["lap_finish_time"])
    xs, zs, ds = lap["data_position_x"], lap["data_position_z"], lap["data_distance_m"]
    # About a metre apart at 60 Hz; every few metres is plenty to lay a trail on.
    keep = [0]
    for i in range(1, len(xs)):
        if math.hypot(xs[i] - xs[keep[-1]], zs[i] - zs[keep[-1]]) >= 2.0:
            keep.append(i)
    return CircuitLine([xs[i] for i in keep], [zs[i] for i in keep], [ds[i] for i in keep])


def this_weeks_lines(root: Path, today: date | None = None) -> dict[str, CircuitLine]:
    """Each circuit with a report this week, by folder name, with its line."""
    lines: dict[str, CircuitLine] = {}
    if not root.is_dir():
        return lines
    for track in sorted(path for path in root.iterdir() if path.is_dir()):
        report = focus.latest_report(root, track.name, today)
        if not report:
            continue
        line = read_line((root / report[len("/sessions/") :]).parent)
        if line is not None:
            lines[track.name] = line
    return lines


class TrackGuess:
    """Follows the car's positions and names the circuit once they fit one."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self._lock = threading.Lock()
        self._lines: dict[str, CircuitLine] | None = None
        self._loading = False
        self._trail: list[tuple[float, float]] = []
        self._travelled = 0.0
        self._slug: str | None = None
        self._place: int | None = None
        self._added = 0
        self._tried_at = 0

    def _ensure_lines(self) -> dict[str, CircuitLine] | None:
        with self._lock:
            if self._lines is not None or self._loading:
                return self._lines
            self._loading = True
        # Reading a week of sessions takes a moment; the view must not wait for it.
        threading.Thread(target=self._load, daemon=True).start()
        return None

    def _load(self) -> None:
        try:
            lines = this_weeks_lines(self.root)
        except Exception:  # noqa: BLE001 - no guess is better than a stopped recording
            lines = {}
        with self._lock:
            self._lines = lines
            self._loading = False

    def observe(self, x: float, z: float) -> None:
        with self._lock:
            if self._trail:
                lx, lz = self._trail[-1]
                gap = math.hypot(x - lx, z - lz)
                if gap > JUMP_M:
                    # Another circuit, or back to the pits: start again.
                    self._trail, self._travelled, self._slug, self._place = [], 0.0, None, None
                elif gap < STEP_M:
                    return
                else:
                    self._travelled += gap
            self._trail.append((x, z))
            self._added += 1
            del self._trail[:-TRAIL_POINTS]

    def slug(self) -> str | None:
        """The circuit being driven, once the trail has said so."""
        lines = self._ensure_lines()
        with self._lock:
            if self._slug is not None or not lines or self._travelled < MIN_TRAIL_M:
                return self._slug
            # Laying the trail on every line is cheap but not free; once per
            # few new points is enough.
            if self._tried_at and self._added - self._tried_at < 5:
                return None
            self._tried_at = self._added
            trail = list(self._trail)
        fits = [slug for slug, line in lines.items() if line.follows(trail)]
        with self._lock:
            # Two circuits sharing a stretch (a short layout) both fit for a
            # while; the guess waits until only one does.
            if len(fits) == 1:
                self._slug = fits[0]
            return self._slug

    def where(self, slug: str, x: float, z: float) -> tuple[float, float] | None:
        """How far round the lap of `slug` the car is, and that lap's length, in metres."""
        lines = self._ensure_lines()
        line = (lines or {}).get(slug)
        if line is None:
            return None
        with self._lock:
            near = self._place
        hit = line.nearest(x, z, near)
        if hit is None:
            return None
        with self._lock:
            self._place = hit[0]
        return line.ds[hit[0]], line.length
