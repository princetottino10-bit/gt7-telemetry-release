"""Asks the console for its other packet formats, to see what else it will send.

The standard packet the recorder uses carries a car ID but nothing that names
the circuit — checked byte by byte against a real session, where the only values
constant for the whole run were the car code, the gearbox ratios and a block of
zeros. Since GT7 1.42 the console also answers to different heartbeat bytes with
longer packets, and this reports what those contain so the question can be
settled from data rather than guessed at.

    .venv\\Scripts\\python.exe capture_gt7.py --probe
"""

from __future__ import annotations

import socket
import struct
from dataclasses import dataclass

from telemetry import packet as packet_module

# 'A' is the format this tool records. The other two were added later and return
# longer packets; whether they hold anything new worth reading is what we check.
HEARTBEATS: dict[bytes, str] = {
    b"A": "標準 (296バイト)",
    b"B": "拡張B",
    b"~": "拡張C",
}
LISTEN_SECONDS = 3.0


@dataclass
class ProbeResult:
    heartbeat: bytes
    label: str
    packets: int
    size: int | None
    decodes: bool
    extra_bytes: int
    nonzero_extra: list[int]

    def describe(self) -> str:
        if self.packets == 0:
            return f"  {self.heartbeat!r} {self.label}: 応答なし"
        head = (
            f"  {self.heartbeat!r} {self.label}: {self.packets}パケット / {self.size}バイト"
        )
        if not self.decodes:
            return head + " / 復号できません（別形式の可能性）"
        if self.extra_bytes <= 0:
            return head + " / 標準と同じ内容"
        if not self.nonzero_extra:
            return head + f" / 追加{self.extra_bytes}バイトはすべてゼロ"
        spans = ", ".join(f"0x{offset:03X}" for offset in self.nonzero_extra[:12])
        more = "..." if len(self.nonzero_extra) > 12 else ""
        return head + f" / 追加{self.extra_bytes}バイト、値が入っている位置: {spans}{more}"


def probe_one(host: str, heartbeat: bytes, *, seconds: float = LISTEN_SECONDS) -> ProbeResult:
    """Sends one heartbeat variant and reports what comes back."""
    label = HEARTBEATS.get(heartbeat, "不明")
    received: list[bytes] = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind(("0.0.0.0", packet_module.RECEIVE_PORT))
        sock.settimeout(0.5)
        sock.sendto(heartbeat, (host, packet_module.SEND_PORT))
        deadline = seconds
        while deadline > 0 and len(received) < 30:
            try:
                data, _ = sock.recvfrom(4096)
            except socket.timeout:
                deadline -= 0.5
                continue
            received.append(data)
    finally:
        sock.close()

    if not received:
        return ProbeResult(heartbeat, label, 0, None, False, 0, [])

    sample = max(received, key=len)
    try:
        plain = packet_module.decrypt(sample)
        decodes = True
    except Exception:  # noqa: BLE001 - an undecodable reply is itself the finding
        return ProbeResult(heartbeat, label, len(received), len(sample), False, 0, [])

    extra = len(plain) - packet_module.PACKET_SIZE
    nonzero = [
        offset
        for offset in range(packet_module.PACKET_SIZE, len(plain), 4)
        if struct.unpack_from("<I", plain, offset)[0] != 0
    ] if extra > 0 else []
    return ProbeResult(heartbeat, label, len(received), len(sample), decodes, max(extra, 0), nonzero)


def run(host: str, *, seconds: float = LISTEN_SECONDS) -> list[ProbeResult]:
    """Tries every known heartbeat and returns what each produced."""
    return [probe_one(host, beat, seconds=seconds) for beat in HEARTBEATS]
