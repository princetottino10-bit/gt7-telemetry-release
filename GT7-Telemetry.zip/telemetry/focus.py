"""The one thing to work on, shown on the live view while the driver is out.

Each report saves its "first thing to do" beside itself (webreport/first.py).
Driving, nobody reads a paragraph, so the live view carries that one line:
the corner, the number, the action. It has to be the line for the circuit
being driven, and the circuit is only known once a lap has been completed and
its shape matched; until then the most recent line from any circuit is shown,
named as such, since it is usually the circuit the driver is about to run.
"""

from __future__ import annotations

import re
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

from telemetry import sessions, tracks

REPORT_FIRST = Path(sessions.REPORT_FILENAME).stem + ".first.json"


def _read(path: Path) -> dict[str, Any] | None:
    from webreport import first  # the capture side may run without the report pipeline

    return first.read(path)


def latest_line(root: Path, track_slug: str | None = None) -> dict[str, Any] | None:
    """The newest saved line, for one circuit or for any."""
    if not root.is_dir():
        return None
    pattern = f"{track_slug}/*/{REPORT_FIRST}" if track_slug else f"*/*/{REPORT_FIRST}"
    # Folders are named by start time, and a session started later may have
    # been rebuilt earlier, so the folder name orders them rather than mtime.
    for path in sorted(root.glob(pattern), key=lambda path: path.parent.name, reverse=True):
        line = _read(path)
        if line:
            return line
    return None


def _week_of(folder: Path) -> date | None:
    """The Monday starting the week a session folder was recorded in.

    The same Daily Race week rule as webreport/history.py, read from the folder
    name alone so the capture side needs nothing from the report pipeline.
    """
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})_", folder.name)
    if not match:
        return None
    try:
        day = date(*(int(part) for part in match.groups()))
    except ValueError:
        return None
    return day - timedelta(days=day.weekday())


def latest_report(root: Path, track_slug: str, today: date | None = None) -> str | None:
    """The newest report on this circuit from this Daily Race week, as a URL path.

    The live view reads each corner's target speeds out of it. A report from
    another week may have been driven on other tyres, so none is better.
    """
    if not root.is_dir():
        return None
    today = today or datetime.now().date()
    week = today - timedelta(days=today.weekday())
    folders = sorted((root / track_slug).glob(f"*/{sessions.REPORT_FILENAME}"), key=lambda path: path.parent.name, reverse=True)
    this_week = [path for path in folders if _week_of(path.parent) == week]
    # The driver's own report carries the model's lap as well; the model's own
    # report is used only before the driver has one this week.
    own = [path for path in this_week if not sessions.is_model(path.parent)]
    for path in own or this_week:
        return "/sessions/" + path.relative_to(root).as_posix()
    return None


MODEL_RECHECK_S = 5.0


def latest_model(root: Path, track_slug: str | None = None, today: date | None = None) -> dict[str, Any] | None:
    """The newest model marked this week, on one circuit or on any.

    Shown on the live view from the start, so the driver can see what is being
    chased before a lap has told the view which circuit this is.
    """
    if not root.is_dir():
        return None
    today = today or datetime.now().date()
    week = today - timedelta(days=today.weekday())
    pattern = f"{track_slug}/*/{sessions.META_FILENAME}" if track_slug else f"*/*/{sessions.META_FILENAME}"
    for path in sorted(root.glob(pattern), key=lambda path: path.parent.name, reverse=True):
        if _week_of(path.parent) != week:
            continue
        meta = sessions.read_meta(path.parent)
        if meta is None or not meta.model:
            continue
        return {
            "track": tracks.display_name(meta.track),
            "lapTimeS": meta.best_lap_s,
            "carName": meta.car_name,
            "matched": track_slug is not None,
        }
    return None


# The theoretical-best code the live view calls inside a report. A report made
# before it existed (before 2026.10.23) has no targets to give, and the live view
# then showed nothing and said nothing; such a report is built again first.
TARGETS_MARK = b"function theoryComparison"


def has_targets(report: Path) -> bool:
    try:
        return TARGETS_MARK in report.read_bytes()
    except OSError:
        return False


def bring_up_to_date(root: Path, report: Path) -> bool:
    """Builds an old report again so it carries the targets. True when it does."""
    if has_targets(report):
        return True
    try:
        from telemetry import rebuild  # the capture side may run without the report pipeline

        rebuild.rebuild(root, report.parent)
    except Exception:  # noqa: BLE001 - no targets is better than a stopped recording
        return False
    return has_targets(report)


class LiveFocus:
    """Works out which saved line belongs on the live view right now."""

    def __init__(self, root: Path, registry_factory: Callable[[], tracks.Registry]) -> None:
        self.root = root
        self.registry_factory = registry_factory
        self._lock = threading.Lock()
        self._laps_seen: int | None = None
        self._value: dict[str, Any] | None = None
        self._report: str | None = None
        self._rebuilding: set[Path] = set()
        self._slug: str | None = None
        self._model: tuple[float, str | None, dict[str, Any] | None] | None = None

    def current(self, recorder: Any) -> dict[str, Any] | None:
        laps = list(recorder.laps)
        with self._lock:
            # Matching a shape walks every sample of a lap; once per lap is plenty.
            if self._laps_seen == len(laps):
                return self._value
            self._laps_seen = len(laps)
            self._value = self._work_out(laps, getattr(recorder, "best_lap", None))
            return self._value

    def report(self, recorder: Any) -> str | None:
        """This week's latest report on the circuit being driven, once it is known."""
        self.current(recorder)
        with self._lock:
            return self._report

    def model(self, recorder: Any) -> dict[str, Any] | None:
        """The model being chased: this circuit's once known, else the newest."""
        self.current(recorder)
        with self._lock:
            slug = self._slug
            cached = self._model
        # The page asks several times a second; the folders are read every few
        # seconds at most, which still shows a model marked a moment ago.
        now = time.monotonic()
        if cached is not None and cached[1] == slug and now - cached[0] < MODEL_RECHECK_S:
            return cached[2]
        try:
            found = latest_model(self.root, slug)
        except OSError:
            found = None
        with self._lock:
            self._model = (now, slug, found)
        return found

    def refresh(self) -> None:
        """Forgets the cached answer, e.g. after a new report has been written."""
        with self._lock:
            self._laps_seen = None

    def _work_out(self, laps: list[Any], best: Any) -> dict[str, Any] | None:
        name = None
        if laps:
            try:
                # The lap capture_gt7.identify_track would name the session by.
                reference = best or laps[-1]
                name = self.registry_factory().identify(tracks.fingerprint_from_lap(reference))
            except Exception:  # noqa: BLE001 - a missing line must never stop a recording
                name = None
        self._slug = tracks.slug(name) if name else None
        report = latest_report(self.root, tracks.slug(name)) if name else None
        self._report = None
        if report:
            path = self.root / report[len("/sessions/") :]
            if has_targets(path):
                # Stamped with the file's time, so the view reads the targets
                # again when the report is rebuilt (a model marked meanwhile).
                self._report = f"{report}?v={int(path.stat().st_mtime)}"
            else:
                # Rebuilding takes seconds to minutes; the view picks the report
                # up on the next lap once it is ready.
                if path not in self._rebuilding:
                    self._rebuilding.add(path)
                    threading.Thread(target=bring_up_to_date, args=(self.root, path), daemon=True).start()
        if name:
            line = latest_line(self.root, tracks.slug(name))
            return {**line, "matched": True} if line else None
        line = latest_line(self.root)
        return {**line, "matched": False} if line else None
