"""Serves the live view over HTTP, using server-sent events.

The recorder runs on the capture thread; this only reads the snapshot it
publishes. Server-sent events are enough because the stream is one-way, and they
need no dependencies beyond the standard library.
"""

from __future__ import annotations

import json
from html import escape as html_escape
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, quote, unquote, urlsplit

from telemetry import qr

try:
    import icons
except ImportError:  # pragma: no cover - the page reads fine without them
    icons = None

UI_FILE = Path(__file__).parent / "live_ui.html"
DEFAULT_PORT = 8770
# The console streams at 60 Hz; the eye does not need that, and the browser has
# to draw between updates.
STREAM_HZ = 20


def _live_page() -> bytes:
    """The live view, with the shared icons folded in.

    Read fresh each time rather than cached: editing the page during a session
    and reloading the tab is how it gets worked on, and a capture can run for
    hours.
    """
    page = UI_FILE.read_text(encoding="utf-8")
    return (
        page.replace("__SPRITE__", icons.sprite() if icons else "")
        .replace("__FAVICON__", icons.favicon_link() if icons else "")
        .replace("__ICON_STYLES__", icons.STYLES if icons else "")
    ).encode("utf-8")


class _Handler(BaseHTTPRequestHandler):
    # Injected by LiveServer.
    state_provider: Callable[[], dict[str, Any]]
    on_stop: Callable[[], None] | None = None
    on_resume: Callable[[], None] | None = None
    server_ref: Any = None

    def log_message(self, *_args: Any) -> None:
        """Silence per-request logging; the capture output is the useful stream."""

    def _send_headers(self, status: int, content_type: str, **extra: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        for key, value in extra.items():
            self.send_header(key.replace("_", "-"), value)
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        if self.path.startswith("/events"):
            self._stream_events()
        elif self.path.startswith("/state"):
            payload = json.dumps(type(self).state_provider()).encode("utf-8")
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(payload)
        elif self.path.startswith("/report"):
            self._serve_report()
        elif self.path.startswith("/sessions"):
            self._serve_from_sessions()
        elif self.path.startswith("/qr"):
            self._serve_qr()
        elif self.path.startswith("/update"):
            self._serve_update()
        elif self.path.startswith("/voice"):
            self._serve_voice()
        elif self.path.startswith("/lan"):
            server = type(self).server_ref
            payload = json.dumps({"url": getattr(server, "lan_url", None)})
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(payload.encode("utf-8"))
        elif self.path in ("/", "/index.html"):
            self._send_headers(200, "text/html; charset=utf-8")
            self.wfile.write(_live_page())
        else:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write(b"not found")


    def do_POST(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        if self.path.startswith("/rebuild"):
            self._rebuild()
            return
        if self.path.startswith("/name-track"):
            self._name_track()
            return
        if self.path.startswith("/model"):
            self._mark_model()
            return
        if self.path.startswith("/stop"):
            handler = type(self).on_stop
            if handler is not None:
                handler()
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(b'{"stopping": true}')
            return
        if self.path.startswith("/resume"):
            handler = type(self).on_resume
            if handler is not None:
                handler()
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(b'{"resuming": true}')
            return
        self._send_headers(404, "text/plain; charset=utf-8")
        self.wfile.write(b"not found")

    def _serve_report(self) -> None:
        """Hands over the report once the capture has produced one."""
        server = type(self).server_ref
        path = getattr(server, "report_path", None)
        if path is None or not Path(path).exists():
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("レポートはまだありません".encode("utf-8"))
            return
        self._send_headers(200, "text/html; charset=utf-8")
        body = Path(path).read_bytes()
        body = _with_report_bar(
            body,
            resume=type(self).on_resume is not None,
            phone_path=_sessions_link(server, Path(path)),
            name_picks=_name_picks(Path(path)),
            model=_model_state(Path(path)),
        )
        self.wfile.write(body)

    def _serve_from_sessions(self) -> None:
        """Serves the listing page and the reports underneath it.

        Past sessions are ordinary files on disk, and a browser showing a page
        from this server will not follow a file:// link to them. Handing them
        out here is what makes "look at last week's lap" reachable without
        leaving the tab - or hunting through folders for it.
        """
        root = getattr(type(self).server_ref, "sessions_root", None)
        if root is None:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("走行記録の場所が設定されていません".encode("utf-8"))
            return

        relative = unquote(self.path[len("/sessions") :].split("?", 1)[0]).lstrip("/")
        target = (Path(root) / relative) if relative else (Path(root) / "index.html")
        if target.is_dir():
            target = target / "index.html"

        # Nothing outside the sessions folder, whatever the URL asks for.
        try:
            resolved = target.resolve()
            resolved.relative_to(Path(root).resolve())
        except (ValueError, OSError):
            self._send_headers(403, "text/plain; charset=utf-8")
            self.wfile.write(b"forbidden")
            return

        if not resolved.is_file():
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("見つかりません".encode("utf-8"))
            return

        kind = "text/html; charset=utf-8" if resolved.suffix == ".html" else "application/octet-stream"
        body = resolved.read_bytes()
        # Reports get the bar so one can be sent to a phone from wherever it was
        # opened; the listing already is the way back, so it is left alone.
        if resolved.suffix == ".html" and resolved.name != "index.html":
            # A past report may have been made by an older version, so it can be
            # built again from the laps beside it.
            body = _with_report_bar(
                body,
                resume=False,
                phone_path=_sessions_link(type(self).server_ref, resolved),
                rebuild=True,
                name_picks=_name_picks(resolved),
                model=_model_state(resolved),
            )
        self._send_headers(200, kind)
        self.wfile.write(body)

    def _serve_voice(self) -> None:
        """A line in Zundamon's voice from VOICEVOX, or whether VOICEVOX is there."""
        from telemetry import voice

        server = type(self).server_ref
        path = urlsplit(self.path).path
        if path.startswith("/voice/clip/"):
            clip = voice.recorded(path[len("/voice/clip/"):])
            if clip is None:
                self._send_headers(404, "text/plain; charset=utf-8")
                self.wfile.write(b"not recorded")
                return
            self._send_headers(200, "audio/mpeg")
            self.wfile.write(clip)
            return
        with server.update_lock:
            if server.voice is None:
                server.voice = voice.Voice()
        query = parse_qs(urlsplit(self.path).query)
        text = query.get("text", [""])[0]
        if not text:
            # Asked when the switch is pressed: the moment to start VOICEVOX if
            # needed. The recorded numbers need nothing running.
            ready = voice.has_recordings() or server.voice.start()
            payload = json.dumps({"available": ready})
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(payload.encode("utf-8"))
            return
        wav = server.voice.say(text)
        if wav is None:
            self._send_headers(503, "text/plain; charset=utf-8")
            self.wfile.write("VOICEVOXが起動していません".encode("utf-8"))
            return
        self._send_headers(200, "audio/wav")
        self.wfile.write(wav)

    def _serve_update(self) -> None:
        """Whether a newer version is out. Asked once per run, then remembered."""
        server = type(self).server_ref
        with server.update_lock:
            if server.update_info is None:
                from telemetry import update

                server.update_info = update.check()
        self._send_headers(200, "application/json; charset=utf-8")
        self.wfile.write(json.dumps(server.update_info).encode("utf-8"))

    def _session_file(self, page: str) -> Path | None:
        """The file a `/sessions/...` address names, if it is inside the folder."""
        root = getattr(type(self).server_ref, "sessions_root", None)
        if root is None or not page.startswith("/sessions/"):
            return None
        relative = unquote(page[len("/sessions/") :]).lstrip("/")
        try:
            resolved = (Path(root) / relative).resolve()
            resolved.relative_to(Path(root).resolve())
        except (ValueError, OSError):
            return None
        return resolved if resolved.is_file() else None

    def _rebuild(self) -> None:
        """Builds one past report again with this version of the tool."""
        page = parse_qs(urlsplit(self.path).query).get("path", [""])[0]
        report = self._session_file(page)
        if report is None:
            self._send_headers(404, "application/json; charset=utf-8")
            self.wfile.write(json.dumps({"error": "レポートが見つかりません"}, ensure_ascii=False).encode("utf-8"))
            return
        from telemetry import rebuild

        root = Path(type(self).server_ref.sessions_root)
        try:
            rebuild.rebuild(root, report.parent)
        except Exception as error:  # noqa: BLE001 - the page says why instead
            self._send_headers(500, "application/json; charset=utf-8")
            self.wfile.write(json.dumps({"error": str(error)}, ensure_ascii=False).encode("utf-8"))
            return
        self._send_headers(200, "application/json; charset=utf-8")
        self.wfile.write(b'{"rebuilt": true}')

    def _name_track(self) -> None:
        """Names the circuit of the report the page is showing."""
        server = type(self).server_ref
        query = parse_qs(urlsplit(self.path).query)
        page = query.get("path", [""])[0]
        name = query.get("name", [""])[0]
        if page == "/report":
            current = getattr(server, "report_path", None)
            report = Path(current) if current is not None and Path(current).exists() else None
        else:
            report = self._session_file(page)
        root = getattr(server, "sessions_root", None)
        if report is None or root is None:
            self._send_json(404, {"error": "レポートが見つかりません"})
            return
        from telemetry import naming

        try:
            moved = naming.name_track(
                Path(root),
                report.parent,
                name,
                registry_path=getattr(server, "registry_path", None) or naming.DEFAULT_REGISTRY,
            )
        except ValueError as error:
            self._send_json(400, {"error": str(error)})
            return
        except Exception as error:  # noqa: BLE001 - the page says why instead
            self._send_json(500, {"error": str(error)})
            return
        new_report = moved / report.name
        if page == "/report":
            server.report_path = new_report
            url = "/report"
        else:
            url = _sessions_link(server, new_report)
        self._send_json(200, {"url": url})

    def _mark_model(self) -> None:
        """Marks (or unmarks) the session of the report on show as the model.

        The reports it changes are built again in the background: the model's
        own (it no longer takes in the driver's best) and the driver's newest
        one this week on the circuit, which the live view reads its targets from.
        """
        server = type(self).server_ref
        query = parse_qs(urlsplit(self.path).query)
        page = query.get("path", [""])[0]
        on = query.get("on", ["1"])[0] == "1"
        if page == "/report":
            current = getattr(server, "report_path", None)
            report = Path(current) if current is not None and Path(current).exists() else None
        else:
            report = self._session_file(page)
        root = getattr(server, "sessions_root", None)
        if report is None or root is None:
            self._send_json(404, {"error": "レポートが見つかりません"})
            return
        from telemetry import focus, sessions

        directory = report.parent
        try:
            sessions.set_model(directory, on)
        except (OSError, ValueError) as error:
            self._send_json(500, {"error": str(error)})
            return
        meta = sessions.read_meta(directory)
        targets = [directory]
        if meta is not None:
            own = focus.latest_report(Path(root), meta.track_slug, focus._week_of(directory))
            if own:
                targets.append(Path(root) / own[len("/sessions/") :].split("?", 1)[0])
        threading.Thread(target=_rebuild_all, args=(Path(root), targets), daemon=True).start()
        self._send_json(200, {"model": on})

    def _send_json(self, status: int, payload: dict) -> None:
        self._send_headers(status, "application/json; charset=utf-8")
        self.wfile.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))

    def _serve_qr(self) -> None:
        """The live page's address as a scannable code.

        Drawn here rather than printed in the console window: the terminal's
        colours are the driver's to change, and an inverted code does not scan.
        """
        server = type(self).server_ref
        target = getattr(server, "lan_url", None)
        if not target:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("このPCはネットワーク上のアドレスを持っていません".encode("utf-8"))
            return
        # A report asks for its own address. Only pages this server hands out
        # can be asked for, so the code never points a phone anywhere else.
        page = parse_qs(urlsplit(self.path).query).get("path", [""])[0]
        if page:
            if not (page == "/report" or page.startswith("/sessions/")):
                self._send_headers(400, "text/plain; charset=utf-8")
                self.wfile.write(b"bad path")
                return
            target = target.rstrip("/") + page
        self._send_headers(200, "image/svg+xml; charset=utf-8")
        self.wfile.write(qr.to_svg(target).encode("utf-8"))

    def _stream_events(self) -> None:
        self._send_headers(200, "text/event-stream", connection="keep-alive")
        interval = 1.0 / STREAM_HZ
        try:
            while True:
                payload = json.dumps(type(self).state_provider())
                self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                self.wfile.flush()
                time.sleep(interval)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return  # The browser navigated away.


# Added to a report while this tool is the one serving it: a way to send the
# report to a phone, and - straight after a capture - a way to start another
# session without going back to the desktop. The saved file on disk never
# carries any of it: opened later, or sent to someone else, it is the report
# and nothing more.
REPORT_BAR_STYLE = """
<style>
  #gt7-resume { position: fixed; right: 18px; bottom: 18px; z-index: 9999;
    display: flex; align-items: center; gap: 12px; padding: 10px 14px;
    background: rgba(13, 17, 23, 0.94); border: 1px solid #2b3542;
    border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,.45);
    font-family: system-ui, "Segoe UI", sans-serif; font-size: 13px; color: #8b949e; }
  #gt7-resume button { font: inherit; font-weight: 700; color: #06111a;
    background: #2ad4e8; border: 0; border-radius: 7px; padding: 8px 14px;
    cursor: pointer; }
  #gt7-resume button:hover { filter: brightness(1.08); }
  #gt7-resume button:disabled { background: #46525f; color: #98a4b0; cursor: default; }
  #gt7-resume button.gt7-quiet { color: #2ad4e8; background: transparent;
    border: 1px solid #2b3542; }
  #gt7-resume button[hidden] { display: none; }
  #gt7-resume a { color: #2ad4e8; text-decoration: none; font-weight: 600; }
  #gt7-resume a:hover { text-decoration: underline; }
  #gt7-phone { position: fixed; inset: 0; z-index: 10000; display: grid;
    place-items: center; background: rgba(8, 11, 16, 0.88);
    font-family: system-ui, "Segoe UI", sans-serif; color: #8b949e; text-align: center; }
  #gt7-phone[hidden] { display: none; }
  #gt7-phone img { width: min(46vh, 70vw); height: auto; display: block;
    margin: 0 auto; border-radius: 12px; background: #fff; }
  #gt7-phone p { margin: 0.8rem 0 0; font-size: 14px; }
  #gt7-phone .gt7-url { color: #2ad4e8; font-size: 12px; word-break: break-all; }
  #gt7-name { position: fixed; inset: 0; z-index: 10000; display: grid;
    place-items: center; background: rgba(8, 11, 16, 0.88); padding: 16px;
    font-family: system-ui, "Segoe UI", sans-serif; color: #e6edf3; }
  #gt7-name[hidden] { display: none; }
  #gt7-name form { width: min(420px, 100%); background: #161b22;
    border: 1px solid #2b3542; border-radius: 12px; padding: 20px; }
  #gt7-name h3 { margin: 0 0 4px; font-size: 17px; }
  #gt7-name p { margin: 0 0 12px; font-size: 13px; color: #8b949e; }
  #gt7-name .gt7-picks { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
  #gt7-name button { font: inherit; font-size: 14px; font-weight: 700; border-radius: 7px;
    padding: 9px 14px; cursor: pointer; border: 1px solid #2b3542;
    color: #2ad4e8; background: transparent; }
  #gt7-name button[type=submit] { color: #06111a; background: #2ad4e8; border-color: #2ad4e8; }
  #gt7-name button:disabled { background: #46525f; color: #98a4b0; border-color: #46525f; }
  #gt7-name input { width: 100%; box-sizing: border-box; font: inherit; font-size: 16px;
    padding: 10px 12px; margin-bottom: 14px; border-radius: 7px;
    border: 1px solid #2b3542; background: #0d1117; color: #e6edf3; }
  #gt7-name .gt7-actions { display: flex; gap: 8px; justify-content: flex-end; }
  #gt7-name .gt7-error { color: #f87171; margin: 10px 0 0; }
  @media (max-width: 640px) {
    /* Whoever is reading this is already holding the phone. The bar spans the
       bottom edge instead of floating over the cards, and the page gets room
       underneath so the last card is not hidden behind it. */
    #gt7-resume { left: 0; right: 0; bottom: 0; border-radius: 0;
      justify-content: space-between; border-width: 1px 0 0;
      padding: 10px 16px calc(10px + env(safe-area-inset-bottom)); }
    #gt7-resume .gt7-send { display: none; }
    #gt7-resume { gap: 8px; flex-wrap: wrap; }
    #gt7-resume a, #gt7-resume button { white-space: nowrap; }
    #gt7-resume button { padding: 8px 10px; }
    body { padding-bottom: 72px; }
  }
</style>
"""

REPORT_BAR_SCRIPT = """
<script>
(function () {
  var bar = document.getElementById("gt7-resume");
  var resume = bar.querySelector(".gt7-resume");
  if (resume) {
    resume.addEventListener("click", function () {
      resume.disabled = true;
      resume.textContent = "準備しています…";
      fetch("/resume", { method: "POST" })
        .then(function () { window.location.href = "/"; })
        .catch(function () {
          resume.disabled = false;
          resume.textContent = "続けて記録する";
        });
    });
  }
  var rebuild = bar.querySelector(".gt7-rebuild");
  if (rebuild) {
    rebuild.addEventListener("click", function () {
      rebuild.disabled = true;
      rebuild.textContent = "作り直しています…";
      fetch("/rebuild?path=" + encodeURIComponent(window.location.pathname), { method: "POST" })
        .then(function (response) {
          if (!response.ok) throw new Error();
          window.location.reload();
        })
        .catch(function () {
          rebuild.disabled = false;
          rebuild.textContent = "作り直せませんでした";
        });
    });
  }
  var model = bar.querySelector(".gt7-model");
  if (model) {
    model.addEventListener("click", function () {
      var on = model.getAttribute("data-on") !== "1";
      model.disabled = true;
      fetch("/model?path=" + encodeURIComponent(window.location.pathname) + "&on=" + (on ? "1" : "0"),
            { method: "POST" })
        .then(function (response) {
          if (!response.ok) throw new Error();
          model.setAttribute("data-on", on ? "1" : "0");
          // The reports that use it are being built again in the background.
          model.textContent = on ? "お手本にしました（お手本をやめる）" : "お手本をやめました（お手本にする）";
          model.disabled = false;
        })
        .catch(function () {
          model.disabled = false;
          model.textContent = "変えられませんでした";
        });
    });
  }
  var naming = document.getElementById("gt7-name");
  var nameOpen = bar.querySelector(".gt7-name-open");
  if (naming && nameOpen) {
    var form = naming.querySelector("form");
    var field = form.querySelector("input");
    var error = form.querySelector(".gt7-error");
    nameOpen.addEventListener("click", function () {
      naming.hidden = false;
      field.focus();
    });
    form.querySelector(".gt7-cancel").addEventListener("click", function () { naming.hidden = true; });
    Array.prototype.forEach.call(form.querySelectorAll(".gt7-picks button"), function (pick) {
      pick.addEventListener("click", function () {
        field.value = pick.textContent;
        field.focus();
      });
    });
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var name = field.value.trim();
      if (!name) return;
      var save = form.querySelector("button[type=submit]");
      save.disabled = true;
      save.textContent = "保存しています…";
      error.textContent = "";
      fetch("/name-track?path=" + encodeURIComponent(window.location.pathname) +
            "&name=" + encodeURIComponent(name), { method: "POST" })
        .then(function (response) { return response.json().then(function (body) {
          if (!response.ok) throw new Error(body.error || "");
          window.location.href = body.url;
        }); })
        .catch(function (problem) {
          save.disabled = false;
          save.textContent = "保存";
          error.textContent = problem.message || "保存できませんでした";
        });
    });
  }
  var send = bar.querySelector(".gt7-send");
  if (!send) return;
  var panel = document.getElementById("gt7-phone");
  var path = send.getAttribute("data-path");
  // The button only appears once there is an address a phone could reach.
  fetch("/lan").then(function (response) { return response.json(); }).then(function (lan) {
    if (!lan.url) return;
    panel.querySelector(".gt7-url").textContent = lan.url.replace(/[/]$/, "") + path;
    send.hidden = false;
  }).catch(function () {});
  send.addEventListener("click", function () {
    var code = panel.querySelector("img");
    if (!code.getAttribute("src")) code.setAttribute("src", "/qr?path=" + encodeURIComponent(path));
    panel.hidden = false;
  });
  panel.addEventListener("click", function () { panel.hidden = true; });
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") panel.hidden = true;
  });
})();
</script>
"""


def _report_bar(
    *,
    resume: bool,
    phone_path: str | None,
    rebuild: bool = False,
    name_picks: list[str] | None = None,
    model: bool | None = None,
) -> str:
    parts = ['<div id="gt7-resume">', '  <a href="/sessions">過去の記録</a>']
    if model is not None:
        parts.append(
            f'  <button type="button" class="gt7-model gt7-quiet" data-on="{"1" if model else "0"}">'
            + ("お手本をやめる" if model else "お手本にする")
            + "</button>"
        )
    if name_picks is not None:
        parts.append('  <button type="button" class="gt7-name-open gt7-quiet">コース名を付ける</button>')
    if phone_path:
        parts.append(
            f'  <button type="button" class="gt7-send gt7-quiet" data-path="{html_escape(phone_path)}" hidden>'
            "スマホで開く</button>"
        )
    if rebuild:
        parts.append('  <button type="button" class="gt7-rebuild gt7-quiet">新しい版で作り直す</button>')
    if resume:
        parts.append('  <button type="button" class="gt7-resume">続けて記録する</button>')
    parts.append("</div>")
    if phone_path:
        parts.append(
            '<div id="gt7-phone" hidden>\n  <div>\n'
            '    <img alt="このレポートのアドレスのQRコード">\n'
            "    <p>スマホのカメラで読み取ると、このレポートが開きます</p>\n"
            '    <p class="gt7-url"></p>\n'
            "    <p>同じWi-Fiにつないだ端末から開けます</p>\n  </div>\n</div>"
        )
    if name_picks is not None:
        parts.append(_naming_panel(name_picks))
    return "\n".join(parts) + REPORT_BAR_STYLE + REPORT_BAR_SCRIPT


def _rebuild_all(root: Path, reports: list[Path]) -> None:
    from telemetry import rebuild

    seen = set()
    for report in reports:
        directory = report if report.is_dir() else report.parent
        if directory in seen:
            continue
        seen.add(directory)
        try:
            rebuild.rebuild(root, directory)
        except Exception:  # noqa: BLE001 - one report that will not build must not stop the rest
            continue


def _model_state(report: Path) -> bool | None:
    """Whether a report's session is the model; None where it cannot be marked."""
    from telemetry import sessions

    meta = sessions.read_meta(report.parent)
    return None if meta is None else meta.model


def _naming_panel(picks: list[str]) -> str:
    # Published lengths only narrow it down - Suzuka measures nearer Daytona's -
    # so they are offered as buttons to press, never filled in on their own.
    choices = ""
    if picks:
        choices = (
            "    <p>1周の距離が近いコース（形までは確かめていないので、違うこともあります）</p>\n"
            '    <div class="gt7-picks">'
            + "".join(f'<button type="button">{html_escape(pick)}</button>' for pick in picks)
            + "</div>\n"
        )
    return (
        '<div id="gt7-name" hidden>\n  <form>\n'
        "    <h3>このコースの名前</h3>\n"
        "    <p>付けた名前は形と一緒に覚えるので、次からは自動で出ます。</p>\n"
        + choices
        + '    <input name="name" maxlength="60" placeholder="コース名" autocomplete="off">\n'
        '    <div class="gt7-actions"><button type="button" class="gt7-cancel">やめる</button>'
        '<button type="submit">保存</button></div>\n'
        '    <p class="gt7-error"></p>\n  </form>\n</div>'
    )


def _name_picks(report: Path) -> list[str] | None:
    """Candidate names for a report whose circuit has none yet, else None."""
    from telemetry import sessions, tracks

    meta = sessions.read_meta(Path(report).parent)
    if meta is None or not tracks.is_placeholder(meta.track):
        return None
    if not meta.lap_distance_m:
        return []
    probe = tracks.Fingerprint(length_m=meta.lap_distance_m, width_m=0.0, depth_m=0.0, height_m=0.0)
    return [name for name, _km in tracks.suggest_names(probe)]


def _with_report_bar(
    body: bytes,
    *,
    resume: bool = True,
    phone_path: str | None = None,
    rebuild: bool = False,
    name_picks: list[str] | None = None,
    model: bool | None = None,
) -> bytes:
    """Puts the report bar just before the report's closing body tag."""
    bar = _report_bar(
        resume=resume, phone_path=phone_path, rebuild=rebuild, name_picks=name_picks, model=model
    ).encode("utf-8")
    marker = b"</body>"
    index = body.rfind(marker)
    if index == -1:
        return body + bar
    return body[:index] + bar + body[index:]


# The name the tests and older callers know it by.
_with_resume_bar = _with_report_bar


def _sessions_link(server: Any, report: Path) -> str:
    """The lasting address of a report, for a phone to open.

    `/report` follows whatever the latest capture produced, so a code drawn
    from it would show a different session once the next one finishes. The
    copy under the sessions folder stays put.
    """
    root = getattr(server, "sessions_root", None)
    if root is not None:
        try:
            relative = Path(report).resolve().relative_to(Path(root).resolve())
            return "/sessions/" + quote(relative.as_posix())
        except (ValueError, OSError):
            pass
    return "/report"


# How many ports past the requested one to try before giving up.
PORT_SEARCH_RANGE = 20


class _ExclusiveServer(ThreadingHTTPServer):
    """A server that refuses to share its port.

    HTTPServer sets SO_REUSEADDR, and on Windows that lets a second process bind
    a port another one is already listening on. Both then accept connections and
    the browser reaches whichever the OS happens to pick - so leaving yesterday's
    capture window open made a fresh recording show stale numbers, with nothing
    on screen to say why.

    Dropping SO_REUSEADDR is not enough once this binds 0.0.0.0: on Windows a
    wildcard bind and a specific-address bind of the same port coexist happily,
    so an old capture window holding 127.0.0.1 and a new one holding 0.0.0.0
    both answer - and the browser at 127.0.0.1 reaches the old one. Verified
    both ways on this machine; SO_EXCLUSIVEADDRUSE closes both directions, and
    a port someone else already holds fails the bind so the search moves on.
    """

    allow_reuse_address = False

    def server_bind(self) -> None:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    def handle_error(self, request, client_address) -> None:
        # A browser that drops a connection mid-request - leaving the live view
        # for the report, closing a tab - raises one of these in the handler
        # thread. Nothing is wrong, but the default prints a full traceback in
        # the middle of the recording, which reads as a crash.
        if isinstance(sys.exc_info()[1], (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)):
            return
        super().handle_error(request, client_address)


def lan_address() -> str | None:
    """This machine's address on the local network, or None if it has none.

    Asking the routing table which interface would carry a packet outwards is
    the only reliable way to pick the right address on a machine with several -
    a wired link, a wireless one, and whatever a VPN or virtual machine has
    added. Nothing is sent: a connected UDP socket only fixes the route.
    """
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 53))
        address = probe.getsockname()[0]
    except OSError:
        address = None
    finally:
        probe.close()
    if address and not address.startswith("127."):
        return address
    # No route to the internet does not mean no network: the PlayStation link
    # needs only the LAN. Fall back to whatever addresses the hostname carries.
    try:
        for candidate in socket.gethostbyname_ex(socket.gethostname())[2]:
            if candidate and not candidate.startswith("127."):
                return candidate
    except OSError:
        pass
    return None


def _bind(handler, port: int, *, host: str) -> tuple[ThreadingHTTPServer, int]:
    """Binds the first free port at or after `port`, and says which it took."""
    last_error: OSError | None = None
    for candidate in range(port, port + PORT_SEARCH_RANGE):
        try:
            return _ExclusiveServer((host, candidate), handler), candidate
        except OSError as error:
            last_error = error
    raise OSError(
        f"{port}番から{PORT_SEARCH_RANGE}個のポートがすべて使用中です。"
        "前回の記録ウィンドウが残っていないか確認してください。"
    ) from last_error


class LiveServer:
    """Runs the live view in a background thread alongside the capture loop.

    The view can also stop the capture, so a session can be run start to finish
    from the browser without touching the console window.
    """

    def __init__(
        self,
        state_provider: Callable[[], dict[str, Any]],
        *,
        port: int = DEFAULT_PORT,
        on_stop: Callable[[], None] | None = None,
        on_resume: Callable[[], None] | None = None,
        local_only: bool = False,
    ) -> None:
        self.requested_port = port
        # Open to the local network unless told otherwise, so the delta can be
        # watched on a phone propped against the wheel. Anyone on the same
        # network can then see lap times and past reports; `local_only` is there
        # for whoever would rather they could not.
        self.local_only = local_only
        # Set once a capture has been turned into a report, so the page can
        # send the driver straight to it. `report_error` covers the cases where
        # no report is coming, so the page can say why instead of waiting.
        self.report_path: Path | None = None
        self.report_error: str | None = None
        # Where every session lives, so the listing page and the reports under
        # it can be reached from the browser rather than from the file system.
        self.sessions_root: Path | None = None
        # Filled on the first page load: one network call per run is plenty.
        self.update_info: dict[str, Any] | None = None
        self.update_lock = threading.Lock()
        # Made on first use, so a driver without VOICEVOX never touches it.
        self.voice: Any = None
        handler = type(
            "BoundHandler",
            (_Handler,),
            {
                "state_provider": staticmethod(state_provider),
                "on_stop": staticmethod(on_stop) if on_stop else None,
                "on_resume": staticmethod(on_resume) if on_resume else None,
                "server_ref": self,
            },
        )
        self._server, self.port = _bind(
            handler, port, host="127.0.0.1" if local_only else "0.0.0.0"
        )
        self._server.daemon_threads = True
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        """The address for the browser on this machine."""
        return f"http://127.0.0.1:{self.port}/"

    @property
    def lan_url(self) -> str | None:
        """The address a phone on the same network would use, if there is one."""
        if self.local_only:
            return None
        address = lan_address()
        return f"http://{address}:{self.port}/" if address else None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)
