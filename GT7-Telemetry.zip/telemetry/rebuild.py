"""Rebuilds the reports of sessions already on disk with the current code.

A report is a finished HTML file: once written, it keeps the analysis and the
wording of the version that made it. After an update, the laps recorded last
week would go on showing last week's advice. Everything a report needs is still
in its session folder, so it can simply be built again.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from telemetry import sessions


def rebuild(root: Path, directory: Path) -> Path:
    """Builds one session's report (and its per-car reports) again, in place.

    `root` is the sessions folder, where each circuit keeps its corner names and
    the earlier sessions the history ghost is drawn from.
    """
    meta = sessions.read_meta(directory)
    if meta is None or not (directory / sessions.SESSION_FILENAME).exists():
        raise ValueError(f"{directory} は走行記録のフォルダではありません")

    backfill_tcs(directory)

    # Imported here: only rebuilding needs the report builder and its numpy.
    import build_report

    segments = root / meta.track_slug / sessions.SEGMENTS_FILENAME
    common = {
        "data_dir": directory,
        # The corner names were saved by the first build; reading them back
        # keeps every report of this circuit naming the corners the same way.
        "segments": segments if segments.exists() else None,
        "auto_segments": not segments.exists(),
        "track_slug": meta.track_slug,
        "track_name": meta.track,
        "history_root": root,
    }
    outcome = build_report.build(
        out=directory / sessions.REPORT_FILENAME, save_segments=segments, **common
    )
    for car in meta.cars:
        if car.id is None or not car.report or car.report == sessions.REPORT_FILENAME:
            continue
        build_report.build(out=directory / car.report, car_id=car.id, **common)
    return outcome.path


def backfill_tcs(directory: Path) -> bool:
    """Adds the traction-control channel to a session saved before it existed.

    The flag was always in the packets, so sessions kept with raw.bin can be
    replayed to recover it. Only the one channel is added: the laps already in
    session.json stay exactly as they were. A lap the replay does not reproduce
    (older versions kept the partial first lap the current code drops) gets
    null, so the next rebuild does not decrypt the whole session again.
    Returns True when the file was rewritten.
    """
    session_path = directory / sessions.SESSION_FILENAME
    raw_path = directory / sessions.RAW_FILENAME
    if not raw_path.exists():
        return False
    # Imported here: decrypting a whole session is only needed this once.
    import analyze_gt7
    from telemetry import packet, receiver
    from telemetry.session import SessionRecorder

    original = session_path.read_bytes()
    laps = json.loads(analyze_gt7.read_session_bytes(session_path))
    if not laps or all("data_tcs" in lap for lap in laps):
        return False

    recorder = SessionRecorder()
    for datagram in receiver.read_raw_capture(raw_path):
        try:
            recorder.feed(packet.decode(datagram))
        except packet.PacketError:
            continue
    replayed = {
        (lap.number, len(lap.samples)): [1 if s.tcs_active else 0 for s in lap.samples]
        for lap in recorder.laps
    }
    for lap in laps:
        lap["data_tcs"] = replayed.get((lap.get("number"), lap.get("lap_ticks")))
    body = json.dumps(laps, ensure_ascii=False).encode("utf-8")
    # Written back the way it was found, compressed or not.
    if original[:2] == analyze_gt7.GZIP_MAGIC:
        body = gzip.compress(body, 6)
    session_path.write_bytes(body)
    return True


def rebuild_all(root: Path) -> tuple[int, list[str]]:
    """Rebuilds every session under `root`. Returns the count and any failures.

    One broken session must not stop the rest, so each failure is collected and
    reported instead of raised.
    """
    rebuilt = 0
    failures: list[str] = []
    for meta in sessions.collect(root):
        try:
            rebuild(root, meta.directory)
            rebuilt += 1
        except Exception as error:  # noqa: BLE001 - keep going with the others
            failures.append(f"{meta.directory.relative_to(root)}: {error}")
    sessions.write_index(root)
    return rebuilt, failures
