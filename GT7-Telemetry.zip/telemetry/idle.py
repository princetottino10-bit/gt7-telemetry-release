"""Notices when the console has stopped sending, and for how long.

GT7 streams only while the car is on track: go back to the menu and the packets
simply stop. That is also what a driving session ending looks like, so a long
enough silence is a reasonable moment to close the recording and build the
report - which saves walking back to the PC to press a button.

The catch is that a pause looks exactly the same from here, so the wait has to
be long enough that stopping to answer the door does not end the session. It is
also gated on having something worth reporting: a tool started too early and
left sitting at the menu should keep waiting, not stop itself and announce that
no laps were recorded.
"""

from __future__ import annotations

import time
from collections.abc import Callable

# Long enough to sit out a pause, short enough that the report is waiting by the
# time the driver gets back to the machine.
DEFAULT_IDLE_STOP_S = 90.0


class IdleWatcher:
    """Tracks the gap since the last packet and says when it has gone on too long."""

    def __init__(
        self,
        timeout_s: float = DEFAULT_IDLE_STOP_S,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.timeout_s = timeout_s
        self._clock = clock
        self._last_packet_at: float | None = None

    @property
    def enabled(self) -> bool:
        return self.timeout_s > 0

    def note_packet(self) -> None:
        self._last_packet_at = self._clock()

    @property
    def silent_for_s(self) -> float:
        """How long since the last packet; zero before any has arrived."""
        if self._last_packet_at is None:
            return 0.0
        return self._clock() - self._last_packet_at

    def expired(self, *, worth_reporting: bool) -> bool:
        """True once the console has been quiet long enough to call it a day.

        Never before the first packet: at that point the console has not been
        found yet, and ending the session would only report that nothing was
        recorded. `worth_reporting` holds it off for the same reason.
        """
        if not self.enabled or self._last_packet_at is None or not worth_reporting:
            return False
        return self.silent_for_s >= self.timeout_s
