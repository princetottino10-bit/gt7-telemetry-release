"""Letting a phone on the same Wi-Fi reach the live view through Windows Firewall.

Telemetry from the PlayStation gets through on its own: it answers the
heartbeat this machine sends, and the firewall lets replies in. A phone opening
the page is a new connection from outside, which Windows blocks unless a rule
allows it. Windows offers to make that rule the first time Python listens, but
the offer is easy to miss or dismiss, and then the phone just fails to load
with nothing on the PC saying why (seen on the author's PC, 2026-10-24: no
rule at all). So the tool checks for its own rule and, if it is missing, asks
Windows for it once, through the usual administrator prompt.
"""

from __future__ import annotations

import subprocess
import sys

RULE_NAME = "GT7 Telemetry live view"
# The live view moves up from 8770 when the port is taken (a window left open),
# and the demo uses the next one, so the rule covers the whole range it tries.
PORTS = "8770-8789"


def applies() -> bool:
    return sys.platform == "win32"


def is_open() -> bool | None:
    """Whether the rule is there; None where there is no Windows Firewall to ask."""
    if not applies():
        return None
    try:
        # Reading the rules needs no administrator rights; netsh exits 1 when
        # no rule has the name.
        done = subprocess.run(
            ["netsh", "advfirewall", "firewall", "show", "rule", f"name={RULE_NAME}"],
            capture_output=True,
            timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return done.returncode == 0


def add_rule_arguments() -> str:
    # Home network (Private) only, and only from the same subnet: the page is
    # meant for the phone by the wheel, not for anyone on a café's Wi-Fi.
    return (
        f'advfirewall firewall add rule name="{RULE_NAME}" dir=in action=allow '
        f"protocol=TCP localport={PORTS} profile=private remoteip=localsubnet"
    )


def ask_to_open() -> bool:
    """Shows Windows' administrator prompt to add the rule. True if it was shown.

    Whether the driver said yes is not known here; is_open() tells afterwards.
    """
    if not applies():
        return False
    try:
        import ctypes

        result = ctypes.windll.shell32.ShellExecuteW(None, "runas", "netsh", add_rule_arguments(), None, 0)
    except (OSError, AttributeError):
        return False
    # ShellExecute returns a value above 32 on success; a refused prompt is 5.
    return int(result) > 32
