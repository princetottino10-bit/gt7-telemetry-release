"""Reads the live view's lines aloud in Zundamon's voice, through VOICEVOX.

VOICEVOX is a free speech engine the driver runs on the PC; it answers on
localhost only. The live view may be open on a phone, which cannot reach the
PC's localhost and could not call it across origins anyway, so the live server
passes the request on and hands back the WAV. Nothing is installed or bundled
here. When VOICEVOX is not running, its engine is looked for in the usual places
and started, since a driver who once installed it should not have to remember
to open it; if it is nowhere to be found the view simply stays silent.

VOICEVOX's terms ask for the credit "VOICEVOX:ずんだもん" wherever the voice is
used; the live view shows it beside the switch.
"""

from __future__ import annotations

import json
import os
import string
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.error import URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ENGINE_URL = "http://127.0.0.1:50021"
CHARACTER = "ずんだもん"
STYLE = "ノーマル"
# A corner's line is a few words; anything long is not one of ours.
MAX_TEXT = 80
TIMEOUT_S = 10
_CACHE_LIMIT = 200
# Loading the voice models takes a while on a CPU; seen at about 15s.
START_WAIT_S = 40


# Searching every drive took 23s on the driver's PC, so the engine found once is
# remembered beside the tool and tried first from then on.
REMEMBERED = Path(__file__).resolve().parents[1] / "voicevox_path.txt"


def _remembered() -> Path | None:
    try:
        path = Path(REMEMBERED.read_text(encoding="utf-8").strip())
    except OSError:
        return None
    return path if path.is_file() else None


def engine_candidates() -> list[Path]:
    """Where a VOICEVOX engine (run.exe) may sit on this PC, most likely first.

    The installer puts it under the app's folder; the engine-only download is a
    folder unpacked wherever the driver chose, seen as
    E:\\AI-Pipeline\\tools\\VOICEVOX\\windows-cpu\\run.exe, so each drive is
    searched a few folders deep for a VOICEVOX folder holding one.
    """
    found: list[Path] = []
    configured = os.environ.get("VOICEVOX_ENGINE")
    if configured:
        found.append(Path(configured))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        found += [Path(local, "Programs", "VOICEVOX", "vv-engine", "run.exe"), Path(local, "Programs", "VOICEVOX", "run.exe")]
    if sys.platform == "win32":
        for letter in string.ascii_uppercase:
            root = Path(f"{letter}:\\")
            if not root.exists():
                continue
            for pattern in ("VOICEVOX/run.exe", "VOICEVOX/*/run.exe", "*/VOICEVOX/*/run.exe", "*/*/VOICEVOX/*/run.exe", "*/*/*/VOICEVOX/*/run.exe"):
                try:
                    found += sorted(root.glob(pattern))
                except OSError:
                    continue
    return [path for path in found if path.is_file()]


class Voice:
    """One VOICEVOX engine, its Zundamon style id, and the lines already spoken."""

    def __init__(self, engine_url: str = ENGINE_URL) -> None:
        self.engine_url = engine_url
        self._lock = threading.Lock()
        self._speaker: int | None = None
        self._cache: dict[str, bytes] = {}

    def _call(self, path: str, body: bytes | None = None, *, post: bool = False) -> bytes:
        request = Request(
            self.engine_url + path,
            data=(body or b"") if post else None,
            headers={"Content-Type": "application/json"},
            method="POST" if post else "GET",
        )
        with urlopen(request, timeout=TIMEOUT_S) as response:
            return response.read()

    def speaker(self) -> int | None:
        """Zundamon's normal style, looked up by name since ids can move between versions."""
        with self._lock:
            if self._speaker is not None:
                return self._speaker
        try:
            speakers = json.loads(self._call("/speakers"))
        except (URLError, OSError, ValueError):
            return None
        found = None
        for speaker in speakers:
            if speaker.get("name") != CHARACTER:
                continue
            styles = speaker.get("styles") or []
            chosen = next((style for style in styles if style.get("name") == STYLE), styles[0] if styles else None)
            if chosen is not None:
                found = int(chosen["id"])
                break
        with self._lock:
            self._speaker = found
        return found

    def available(self) -> bool:
        return self.speaker() is not None

    def start(self) -> bool:
        """Starts the engine if it is not running, and waits for it. True once it answers."""
        if self.available():
            return True
        engine = _remembered()
        if engine is None:
            engines = engine_candidates()
            if not engines:
                return False
            engine = engines[0]
            try:
                REMEMBERED.write_text(str(engine), encoding="utf-8")
            except OSError:
                pass
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            subprocess.Popen([str(engine)], cwd=str(engine.parent), creationflags=flags,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            return False
        deadline = time.monotonic() + START_WAIT_S
        while time.monotonic() < deadline:
            time.sleep(1)
            if self.available():
                return True
        return False

    def say(self, text: str) -> bytes | None:
        """The WAV for one line, or None when VOICEVOX is not there to make it."""
        text = text.strip()[:MAX_TEXT]
        if not text:
            return None
        with self._lock:
            cached = self._cache.get(text)
        if cached is not None:
            return cached
        speaker = self.speaker()
        if speaker is None:
            return None
        try:
            query = self._call(f"/audio_query?text={quote(text)}&speaker={speaker}", post=True)
            wav = self._call(f"/synthesis?speaker={speaker}", query, post=True)
        except (URLError, OSError):
            # VOICEVOX was closed after the id was found; look it up afresh next time.
            with self._lock:
                self._speaker = None
            return None
        with self._lock:
            if len(self._cache) >= _CACHE_LIMIT:
                self._cache.clear()
            self._cache[text] = wav
        return wav
