"""Salsa20 stream cipher, as specified by Bernstein.

GT7 encrypts its telemetry packets with Salsa20, so decoding them needs exactly
one primitive. Implementing it here keeps the capture tool dependency-free; the
test suite checks it against pycryptodome when that library is available.
"""

from __future__ import annotations

import struct

SIGMA = b"expand 32-byte k"
_MASK = 0xFFFFFFFF
BLOCK_SIZE = 64
ROUNDS = 20


def _rotate(value: int, shift: int) -> int:
    return ((value << shift) | (value >> (32 - shift))) & _MASK


def _quarter_round(state: list[int], a: int, b: int, c: int, d: int) -> None:
    """The Salsa20 quarterround, applied in place to four state words."""
    state[b] ^= _rotate((state[a] + state[d]) & _MASK, 7)
    state[c] ^= _rotate((state[b] + state[a]) & _MASK, 9)
    state[d] ^= _rotate((state[c] + state[b]) & _MASK, 13)
    state[a] ^= _rotate((state[d] + state[c]) & _MASK, 18)


def _double_round(state: list[int]) -> None:
    # Column round.
    _quarter_round(state, 0, 4, 8, 12)
    _quarter_round(state, 5, 9, 13, 1)
    _quarter_round(state, 10, 14, 2, 6)
    _quarter_round(state, 15, 3, 7, 11)
    # Row round.
    _quarter_round(state, 0, 1, 2, 3)
    _quarter_round(state, 5, 6, 7, 4)
    _quarter_round(state, 10, 11, 8, 9)
    _quarter_round(state, 15, 12, 13, 14)


def _initial_state(key: bytes, nonce: bytes, counter: int) -> list[int]:
    """Lays out the 16 word state: constants, key, nonce and block counter."""
    if len(key) != 32:
        raise ValueError(f"Salsa20 needs a 32 byte key, got {len(key)}")
    if len(nonce) != 8:
        raise ValueError(f"Salsa20 needs an 8 byte nonce, got {len(nonce)}")

    constants = struct.unpack("<4I", SIGMA)
    key_words = struct.unpack("<8I", key)
    nonce_words = struct.unpack("<2I", nonce)

    return [
        constants[0], key_words[0], key_words[1], key_words[2],
        key_words[3], constants[1], nonce_words[0], nonce_words[1],
        counter & _MASK, (counter >> 32) & _MASK, constants[2], key_words[4],
        key_words[5], key_words[6], key_words[7], constants[3],
    ]


def block(key: bytes, nonce: bytes, counter: int) -> bytes:
    """Generates one 64 byte block of key stream."""
    state = _initial_state(key, nonce, counter)
    working = list(state)
    for _ in range(ROUNDS // 2):
        _double_round(working)
    mixed = [(working[i] + state[i]) & _MASK for i in range(16)]
    return struct.pack("<16I", *mixed)


def key_stream(key: bytes, nonce: bytes, length: int, counter: int = 0) -> bytes:
    """Generates `length` bytes of key stream from the given block counter."""
    output = bytearray()
    while len(output) < length:
        output += block(key, nonce, counter)
        counter += 1
    return bytes(output[:length])


def crypt(data: bytes, key: bytes, nonce: bytes, counter: int = 0) -> bytes:
    """XORs data with the key stream. Encryption and decryption are identical."""
    stream = key_stream(key, nonce, len(data), counter)
    return bytes(a ^ b for a, b in zip(data, stream))
