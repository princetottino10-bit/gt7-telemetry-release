"""Tells whether a newer version of the tool has been published.

Friends get the tool as a ZIP from a fixed link and have no other way to know
it changed. The download repository carries a version file next to the ZIP;
comparing it with the one this copy shipped with is enough to say so on the
live page. Any failure - no network, a slow answer - simply means "no news".
"""

from __future__ import annotations

import urllib.request
from pathlib import Path

VERSION_FILE = Path(__file__).resolve().parent.parent / "VERSION"
LATEST_URL = "https://raw.githubusercontent.com/princetottino10-bit/gt7-telemetry-release/main/version.txt"
DOWNLOAD_URL = "https://github.com/princetottino10-bit/gt7-telemetry-release/raw/main/GT7-Telemetry.zip"
TIMEOUT_S = 3.0


def _parse(text: str) -> tuple[int, ...] | None:
    try:
        return tuple(int(part) for part in text.strip().split("."))
    except ValueError:
        return None


def current_version() -> str | None:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def latest_version(url: str = LATEST_URL, timeout_s: float = TIMEOUT_S) -> str | None:
    try:
        with urllib.request.urlopen(url, timeout=timeout_s) as response:
            return response.read(64).decode("utf-8").strip() or None
    except Exception:  # noqa: BLE001 - offline is the normal case, not an error
        return None


def is_newer(latest: str | None, current: str | None) -> bool:
    """True only when both versions read and the published one is later."""
    a, b = _parse(latest or ""), _parse(current or "")
    return a is not None and b is not None and a > b


def check(url: str = LATEST_URL) -> dict:
    current = current_version()
    latest = latest_version(url)
    return {
        "current": current,
        "latest": latest,
        "newer": is_newer(latest, current),
        "download": DOWNLOAD_URL,
    }
