"""Writes captured laps in the GT7 Dashboard JSON shape, plus extra channels.

Keeping the original field names means every existing tool in this repo — the
report builder, the Markdown analysis, the 27 laps already recorded — keeps
working unchanged. The channels GT7 Dashboard never stored are added alongside,
under names the old files simply do not have.
"""

from __future__ import annotations

import gzip
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from telemetry.session import Lap

# Thresholds for the summary counters GT7 Dashboard keeps.
FULL_THROTTLE_PCT = 99.0
FULL_BRAKE_PCT = 99.0
PEDAL_ON_PCT = 1.0
# A wheel turning this much faster than the car is spinning.
SPIN_SLIP_RATIO = 1.1
# Racing slicks past this are past their window.
OVERHEAT_C = 110.0


def _timestamp(moment: datetime | None) -> str:
    return (moment or datetime.now()).strftime("%Y-%m-%d %H:%M:%S.%f")


def format_lap_time(seconds: float) -> str:
    minutes = int(seconds // 60)
    rest = seconds - minutes * 60
    return f"{minutes}:{rest:06.3f}"


def lap_to_dashboard_dict(lap: Lap, *, is_manual: bool = True) -> dict[str, Any]:
    """Renders one lap in the JSON layout GT7 Dashboard produces."""
    samples = lap.samples
    throttle = [sample.throttle_pct for sample in samples]
    braking = [sample.brake_pct for sample in samples]
    speed = [sample.speed_kmh for sample in samples]
    slip = [max(sample.tire_slip) for sample in samples]
    temps = [max(sample.tire_temps) for sample in samples]

    coasting = [
        1 if throttle_value < PEDAL_ON_PCT and brake_value < PEDAL_ON_PCT else 0
        for throttle_value, brake_value in zip(throttle, braking)
    ]

    both_pedals = sum(
        1
        for throttle_value, brake_value in zip(throttle, braking)
        if throttle_value >= PEDAL_ON_PCT and brake_value >= PEDAL_ON_PCT
    )

    fuel_start = samples[0].fuel_level if samples else 0.0
    fuel_end = samples[-1].fuel_level if samples else 0.0

    return {
        # ---- GT7 Dashboard compatible fields ----
        "title": format_lap_time(lap.lap_time_s),
        "lap_ticks": len(samples),
        "lap_finish_time": lap.finish_time_ms,
        "lap_live_time": lap.lap_time_s,
        "total_laps": 0,
        "number": lap.number,
        "throttle_and_brake_ticks": both_pedals,
        "no_throttle_and_no_brake_ticks": sum(coasting),
        "full_brake_ticks": sum(1 for value in braking if value >= FULL_BRAKE_PCT),
        "full_throttle_ticks": sum(1 for value in throttle if value >= FULL_THROTTLE_PCT),
        "tires_overheated_ticks": sum(1 for value in temps if value >= OVERHEAT_C),
        "tires_spinning_ticks": sum(1 for value in slip if value >= SPIN_SLIP_RATIO),
        "data_throttle": throttle,
        "data_braking": braking,
        "data_coasting": coasting,
        "data_speed": speed,
        "data_time": [sample.time_s for sample in samples],
        "data_rpm": [sample.rpm for sample in samples],
        "data_gear": [sample.gear for sample in samples],
        # GT7 Dashboard's own data_tires is undocumented; this fills the slot with
        # a defined quantity: the highest slip ratio across the four wheels.
        "data_tires": slip,
        "data_position_x": [sample.position[0] for sample in samples],
        "data_position_y": [sample.position[1] for sample in samples],
        "data_position_z": [sample.position[2] for sample in samples],
        "fuel_at_start": fuel_start,
        "fuel_at_end": fuel_end,
        "fuel_consumed": fuel_start - fuel_end,
        "data_boost": [sample.boost for sample in samples],
        "data_rotation_yaw": [sample.yaw for sample in samples],
        "data_absolute_yaw_rate_per_second": _yaw_rate(samples),
        "car_id": lap.car_code,
        "is_replay": False,
        "is_manual": is_manual,
        "lap_start_timestamp": _timestamp(lap.started_at),
        "lap_end_timestamp": _timestamp(lap.ended_at),
        "EstimatedTopSpeed": int(round(max(speed))) if speed else 0,
        # ---- channels GT7 Dashboard does not record ----
        "capture_source": "gt7-direct",
        "capture_version": 1,
        "data_tire_temp_fl": [sample.tire_temps[0] for sample in samples],
        "data_tire_temp_fr": [sample.tire_temps[1] for sample in samples],
        "data_tire_temp_rl": [sample.tire_temps[2] for sample in samples],
        "data_tire_temp_rr": [sample.tire_temps[3] for sample in samples],
        "data_tire_slip_fl": [sample.tire_slip[0] for sample in samples],
        "data_tire_slip_fr": [sample.tire_slip[1] for sample in samples],
        "data_tire_slip_rl": [sample.tire_slip[2] for sample in samples],
        "data_tire_slip_rr": [sample.tire_slip[3] for sample in samples],
        "data_suspension_fl": [sample.suspension_travel[0] for sample in samples],
        "data_suspension_fr": [sample.suspension_travel[1] for sample in samples],
        "data_suspension_rl": [sample.suspension_travel[2] for sample in samples],
        "data_suspension_rr": [sample.suspension_travel[3] for sample in samples],
        "data_slide_angle_deg": [sample.slide_angle_deg for sample in samples],
        "data_water_temp": [sample.water_temp for sample in samples],
        "data_oil_temp": [sample.oil_temp for sample in samples],
        "data_clutch": [sample.clutch_pedal for sample in samples],
        "data_distance_m": [sample.distance_m for sample in samples],
        "data_tcs": [1 if sample.tcs_active else 0 for sample in samples],
    }


def _yaw_rate(samples) -> list[float]:
    """Absolute rate of heading change per second, matching the original field."""
    if len(samples) < 2:
        return [0.0] * len(samples)

    rates = [0.0]
    for previous, current in zip(samples[:-1], samples[1:]):
        step = current.time_s - previous.time_s
        if step <= 0:
            rates.append(0.0)
            continue
        difference = current.yaw - previous.yaw
        # Unwrap across the +/-pi seam.
        while difference > 3.141592653589793:
            difference -= 6.283185307179586
        while difference < -3.141592653589793:
            difference += 6.283185307179586
        rates.append(abs(difference) / step)
    return rates


def session_filename(laps: list[Lap], *, started_at: datetime | None = None) -> str:
    """Mirrors GT7 Dashboard's naming so captures sort alongside older files."""
    moment = started_at or (laps[0].started_at if laps else datetime.now())
    car_code = laps[0].car_code if laps else 0
    return f"{moment.strftime('%Y-%m-%d_%H_%M_%S')}_CAR-ID-{car_code}.json"


def write_session(
    laps: list[Lap], directory: Path, *, filename: str | None = None, compress: bool = True
) -> Path:
    """Writes a session file containing every usable lap.

    Compressed by default: a five lap session is 12 MB of JSON and 4 MB gzipped,
    and someone recording twice a week fills a couple of gigabytes a year. The
    name keeps its .json suffix and the loader sniffs the gzip magic, so a file
    written either way reads back the same.
    """
    directory.mkdir(parents=True, exist_ok=True)
    payload = [lap_to_dashboard_dict(lap) for lap in laps]
    path = directory / (filename or session_filename(laps))
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    path.write_bytes(gzip.compress(body, 6) if compress else body)
    return path
