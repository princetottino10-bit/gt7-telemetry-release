"""Generates a segment definition for a circuit from its telemetry.

Detects corners from the median speed profile so a new track can be analysed
without hand-tuning fractions. Review the output and rename the segments to the
real corner names before using it.

Example:
    .venv\\Scripts\\python.exe make_segments.py --data-dir data_suzuka \\
        --track "Suzuka Circuit" --out suzuka_auto_segments.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import analyze_gt7 as core
from webreport import autoseg, loader, resample


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, default=core.DEFAULT_DATA_DIR, help="Folder holding GT7 Dashboard session JSON files.")
    parser.add_argument("--cars-csv", type=Path, default=core.DEFAULT_CARS_CSV, help="GT7 Dashboard car name table.")
    parser.add_argument("--track", default="Unknown Circuit", help="Track name written into the definition.")
    parser.add_argument("--out", type=Path, required=True, help="Destination JSON file.")
    parser.add_argument("--car-id", type=int, default=None, help="Restrict detection to one car ID.")
    parser.add_argument("--grid-points", type=int, default=resample.DEFAULT_GRID_POINTS, help="Samples per lap used for detection.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    laps = loader.load_laps(args.data_dir, args.cars_csv)
    selection = loader.select_laps(laps, car_id=args.car_id)
    grid = resample.build_grid(selection.laps, points=args.grid_points)
    traces = resample.build_traces(selection.laps, grid, selection.reference.uid)

    detected = autoseg.detect(traces, grid)
    definition = autoseg.to_definition(detected, grid, args.track)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(definition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    corners = sum(1 for segment in detected if segment.is_corner)
    straights = len(detected) - corners
    print(f"Wrote {args.out}")
    print(f"  laps analysed : {len(selection.laps)}")
    print(f"  segments      : {len(detected)} ({corners} corners, {straights} straights)")
    print()
    print(f"  {'segment':<14}{'from':>8}{'to':>8}{'length':>9}{'min km/h':>10}{'max km/h':>10}")
    for entry, segment in zip(definition["segments"], detected):
        start_m = entry["start_fraction"] * grid.lap_distance_m
        end_m = entry["end_fraction"] * grid.lap_distance_m
        print(
            f"  {entry['id']:<14}{start_m:>8.0f}{end_m:>8.0f}{end_m - start_m:>9.0f}"
            f"{segment.min_speed_kmh:>10.0f}{segment.max_speed_kmh:>10.0f}"
        )


if __name__ == "__main__":
    main()
