"""The icon set both pages share, and the tab icon that goes with it.

The listing page and the report are built by two packages that do not import
each other, so this sits beside them both rather than inside either - a second
copy would drift, and an icon meaning one thing on one page and something else
on the other is worse than no icon at all. Both import it defensively, so a
copy of either package moved somewhere without this file still builds, just
without decoration.

Everything is inlined into the page it is used on. These files are opened
straight off the disk and served on a home network, so nothing here may depend
on reaching the internet.
"""

from __future__ import annotations

import base64
from functools import lru_cache
from pathlib import Path

ASSETS = Path(__file__).parent / "assets"
SPRITE_FILE = ASSETS / "icons.svg"
# The app icon and the header art, both drawn in Canva. Inlined as data URIs so
# a report sent to someone else keeps them with no folder around it.
FAVICON_FILE = ASSETS / "favicon-64.png"
HERO_FILE = ASSETS / "hero.jpg"

# The previous tab icon, a checkered flag drawn in SVG. Kept as the fallback for
# a copy of the tool that has lost the PNG.
_FALLBACK_FAVICON = (
    '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 '
    "viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%227%22 "
    "fill=%22%230d1117%22/%3E%3Cg fill=%22%232ad4e8%22%3E%3Crect x=%227%22 y=%227%22 "
    "width=%224.5%22 height=%224.5%22/%3E%3Crect x=%2216%22 y=%227%22 width=%224.5%22 "
    "height=%224.5%22/%3E%3Crect x=%2211.5%22 y=%2211.5%22 width=%224.5%22 height=%224.5%22/%3E"
    "%3Crect x=%2220.5%22 y=%2211.5%22 width=%224.5%22 height=%224.5%22/%3E%3Crect x=%227%22 "
    'y=%2216%22 width=%224.5%22 height=%224.5%22/%3E%3Crect x=%2216%22 y=%2216%22 '
    'width=%224.5%22 height=%224.5%22/%3E%3C/g%3E%3C/svg%3E">'
)



def _data_uri(path: Path, mime: str) -> str | None:
    try:
        return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")
    except OSError:
        return None


@lru_cache(maxsize=1)
def favicon_uri() -> str | None:
    """The app icon as a data URI, or None when the file is missing."""
    return _data_uri(FAVICON_FILE, "image/png")


@lru_cache(maxsize=1)
def hero_uri() -> str | None:
    """The header art as a data URI, or None when the file is missing."""
    return _data_uri(HERO_FILE, "image/jpeg")


def favicon_link() -> str:
    uri = favicon_uri()
    return f'<link rel="icon" type="image/png" href="{uri}">' if uri else _FALLBACK_FAVICON


def hero_style() -> str:
    """CSS custom properties carrying the art, for a page's stylesheet.

    Set as variables rather than written into each rule so a page can place the
    art however its layout wants, and a missing file leaves the variables unset
    - the rules that use them fall back to plain colour instead of breaking.
    """
    rules = []
    hero = hero_uri()
    if hero:
        rules.append(f"--hero-art: url({hero});")
    mark = favicon_uri()
    if mark:
        rules.append(f"--app-mark: url({mark});")
    return ":root { " + " ".join(rules) + " }" if rules else ""


# Shared by both pages so an icon keeps the weight of the text beside it.
STYLES = """
.ic { fill: none; stroke: currentColor; stroke-width: 1.7; vertical-align: -0.13em;
      flex: none; }
.ic--sm { width: 15px; height: 15px; margin-right: 6px; }
.ic--h2 { width: 19px; height: 19px; margin-right: 9px; }
"""


@lru_cache(maxsize=1)
def sprite() -> str:
    """The hidden sheet of symbols, to drop in at the top of a page body.

    Missing is not fatal: the pages read perfectly well without their icons,
    and a build that fails over a decoration would be the worse outcome.
    """
    try:
        return SPRITE_FILE.read_text(encoding="utf-8")
    except OSError:
        return ""


def icon(name: str, *, size: str = "sm", extra: str = "") -> str:
    """One icon, referencing a symbol from the sprite."""
    classes = f"ic ic--{size}" + (f" {extra}" if extra else "")
    return f'<svg class="{classes}"><use href="#{name}"/></svg>'
