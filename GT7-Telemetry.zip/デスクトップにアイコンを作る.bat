@echo off
rem Puts a shortcut on the desktop so a session starts with one double-click.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

set "TARGET=%~dp0GT7を記録する.bat"
set "ICON=%~dp0assets\icon.ico"
set "NAME=GT7テレメトリ"

if not exist "%TARGET%" (
    echo 起動用のバッチが見つかりません: %TARGET%
    pause
    exit /b 1
)

powershell -NoProfile -Command ^
  "$desktop = [Environment]::GetFolderPath('Desktop');" ^
  "$link = Join-Path $desktop '%NAME%.lnk';" ^
  "$shell = New-Object -ComObject WScript.Shell;" ^
  "$s = $shell.CreateShortcut($link);" ^
  "$s.TargetPath = '%TARGET%';" ^
  "$s.WorkingDirectory = '%~dp0';" ^
  "$s.Description = 'GT7のテレメトリを記録してレポートを作成します';" ^
  "if (Test-Path '%ICON%') { $s.IconLocation = '%ICON%' };" ^
  "$s.Save();" ^
  "Write-Host ('作成しました: ' + $link);" ^
  "$viewer = '%~dp0走行記録を開く.bat';" ^
  "if (Test-Path $viewer) {" ^
  "  $link2 = Join-Path $desktop '%NAME%（記録一覧）.lnk';" ^
  "  $v = $shell.CreateShortcut($link2);" ^
  "  $v.TargetPath = $viewer;" ^
  "  $v.WorkingDirectory = '%~dp0';" ^
  "  $v.Description = 'これまでの走行記録とベストタイムの推移を開きます';" ^
  "  if (Test-Path '%ICON%') { $v.IconLocation = '%ICON%' };" ^
  "  $v.Save();" ^
  "  Write-Host ('作成しました: ' + $link2)" ^
  "}"

if errorlevel 1 (
    echo ショートカットの作成に失敗しました。
    pause
    exit /b 1
)

echo.
echo デスクトップの「%NAME%」をダブルクリックすると記録が始まります。
echo.
pause
