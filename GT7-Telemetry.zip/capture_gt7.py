"""Captures GT7 telemetry straight from the console, with a live delta view.

Replaces GT7 Dashboard as the recorder: it receives the console's UDP stream,
decrypts it, cuts it into laps, writes session files in the same JSON shape the
rest of this project already reads, and builds the report when you stop.

Run it with no arguments. The console is found automatically.

    .venv\\Scripts\\python.exe capture_gt7.py

Other modes:

    # Check the packet layout against a running session before trusting it
    .venv\\Scripts\\python.exe capture_gt7.py --verify

    # Replay a raw capture (no console needed)
    .venv\\Scripts\\python.exe capture_gt7.py --replay capture.bin --out data_replay
"""

from __future__ import annotations

import argparse
import sys
import threading
import time
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any

from dataclasses import dataclass

from telemetry import (
    discovery,
    export,
    focus,
    idle as idle_module,
    live,
    packet as packet_module,
    receiver as receiver_module,
    probe as probe_module,
    cars as cars_module,
    sessions as sessions_module,
    stint as stint_module,
    tracks,
)
from telemetry.session import SessionRecorder


@dataclass
class Stint:
    """One circuit's worth of a recording, banked when the track changes."""

    recorder: SessionRecorder
    started_at: datetime
    raw_start: int
    raw_end: int

CONSOLE_NOT_FOUND = (
    "PlayStationが見つかりませんでした。次を確認してください:\n"
    "  1. PS5とこのPCが同じWi-Fi / ルーターに繋がっている\n"
    "  2. GT7が起動していて、コース上にいる（メニュー画面では配信されません）\n"
    "  3. 初回はファイアウォールの確認ダイアログで「アクセスを許可する」を選ぶ\n"
    "  4. それでも駄目なら --host でIPアドレスを直接指定する"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--host", default=None, help="IP address of the PlayStation. Found automatically when omitted.")
    parser.add_argument(
        "--idle-stop",
        type=float,
        default=idle_module.DEFAULT_IDLE_STOP_S,
        metavar="SECONDS",
        help="Finish the session and build the report after this long with no telemetry (0 disables).",
    )
    parser.add_argument(
        "--local-only",
        action="store_true",
        help="Keep the live view on this machine only, off the local network.",
    )
    parser.add_argument("--discover-timeout", type=float, default=discovery.DEFAULT_TIMEOUT_S, help="Seconds to spend looking for the console.")
    parser.add_argument("--out", type=Path, default=Path("sessions"), help="Folder that holds every recorded session.")
    parser.add_argument("--track-name", default=None, help="Circuit name. Recognised automatically once it has been given here.")
    # Off by default: a prompt at the end of a session holds the report back
    # until someone comes to the keyboard, and the shape is recognised either way.
    parser.add_argument("--ask-names", action="store_true", help="Prompt for the name of an unrecognised circuit or car.")
    # Kept so existing shortcuts that pass it still start; not asking is the default now.
    parser.add_argument("--no-ask-track", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--no-report", action="store_true", help="Do not build a report when the capture stops.")
    parser.add_argument("--verify", action="store_true", help="Print decoded packets and check the layout, without recording.")
    parser.add_argument("--probe", action="store_true", help="Ask the console for its other packet formats and report what they hold.")
    parser.add_argument("--verify-packets", type=int, default=120, help="How many packets to inspect in --verify mode.")
    parser.add_argument("--record-raw", type=Path, default=None, help="Also save the raw encrypted datagrams here.")
    # On by default: every decoding bug found so far was fixed by re-running a
    # corrected decoder over the raw packets, instead of asking whoever recorded
    # the session to drive it again. Ten megabytes for five laps is worth that.
    parser.add_argument("--no-keep-raw", dest="keep_raw", action="store_false", help="Do not keep the raw packets alongside the session.")
    parser.set_defaults(keep_raw=True)
    parser.add_argument("--replay", type=Path, default=None, help="Replay a raw capture instead of connecting to a console.")
    parser.add_argument("--replay-realtime", action="store_true", help="Replay at 60 Hz instead of as fast as possible.")
    parser.add_argument("--duration", type=float, default=None, help="Stop after this many seconds.")
    parser.add_argument("--no-live", action="store_true", help="Do not start the live view.")
    parser.add_argument("--port", type=int, default=live.DEFAULT_PORT, help="Port for the live view.")
    parser.add_argument("--no-browser", action="store_true", help="Do not open a browser window.")
    return parser.parse_args()


def open_source(args: argparse.Namespace):
    """Chooses between a live console and a replayed capture."""
    if args.replay is not None:
        if not args.replay.exists():
            raise SystemExit(f"再生ファイルが見つかりません: {args.replay}")
        datagrams = receiver_module.read_raw_capture(args.replay)
        if not datagrams:
            raise SystemExit(f"{args.replay} にパケットが入っていません。")
        print(f"再生: {args.replay} から {len(datagrams)} パケット")
        return receiver_module.ReplaySource(datagrams, realtime=args.replay_realtime)

    host = args.host
    if not host:
        result = wait_for_console(args.discover_timeout)
        host = result.host
        print(f"GT7を {host} で見つけました（{result.elapsed_s:.1f}秒）")
    print(f"接続中: {host}")
    return receiver_module.GT7Receiver(host)


# After this many empty searches the checklist is shown, in case the console is
# not on the network at all rather than still in a menu.
SEARCHES_BEFORE_HELP = 10


def wait_for_console(timeout_s: float, *, resolve=None, limit: int | None = None):
    """Keeps looking for the console until GT7 starts streaming.

    GT7 only streams on track, so a single search made the driver get onto the
    track first and then press a key here. Searching until it answers lets the
    window be opened at any point and the recording start by itself.
    """
    resolve = resolve or discovery.resolve_host
    print("ネットワーク上のPlayStationを探しています...")
    attempts = 0
    while True:
        try:
            result = resolve(None, timeout_s=timeout_s)
        except KeyboardInterrupt:
            raise SystemExit("中止しました。") from None
        if result.found:
            return result
        attempts += 1
        if attempts == 1:
            print("GT7でコースに出ると、自動で記録が始まります。（やめるときはこのウィンドウを閉じてください）")
        if attempts == SEARCHES_BEFORE_HELP:
            searched = ", ".join(result.subnets) or "不明"
            print(f"{CONSOLE_NOT_FOUND}\n     (探索範囲: {searched})")
            print("このまま探し続けます。")
        if limit is not None and attempts >= limit:
            raise SystemExit(CONSOLE_NOT_FOUND)


def run_probe(args: argparse.Namespace) -> int:
    """Reports what the console's other packet formats contain."""
    host = args.host
    if not host:
        print("ネットワーク上のPlayStationを探しています...")
        result = discovery.resolve_host(None, timeout_s=args.discover_timeout)
        if not result.found:
            raise SystemExit(CONSOLE_NOT_FOUND)
        host = result.host
        print(f"GT7を {host} で見つけました")

    print()
    print("パケット形式を調べています（GT7をコース上にした状態で実行してください）")
    for result in probe_module.run(host):
        print(result.describe())
    print()
    print("標準パケットにコース名やコースIDは入っていません（実データで全域を確認済み）。")
    print("拡張形式に新しい値があれば、上に位置が出ます。")
    return 0


def run_verify(args: argparse.Namespace) -> int:
    """Decodes a handful of packets and reports whether the layout looks right."""
    problems: dict[str, int] = {}
    inspected = 0
    first_shown = False

    with open_source(args) as source:
        for decoded in source.packets(stop_after_s=args.duration or 20.0):
            inspected += 1
            if not first_shown:
                print()
                print(packet_module.describe(decoded))
                print()
                first_shown = True
            for issue in packet_module.implausible_fields(decoded):
                key = issue.split("=")[0]
                problems[key] = problems.get(key, 0) + 1
            if inspected >= args.verify_packets:
                break

    print(f"{inspected} パケットを確認しました。")
    if not inspected:
        print("パケットを受信できませんでした。GT7がコース上にあるか確認してください。")
        return 1
    if problems:
        print("値が想定範囲から外れています（パケット構造が変わった可能性があります）:")
        for name, count in sorted(problems.items(), key=lambda item: -item[1]):
            print(f"  {name}: {count}/{inspected} パケット")
        return 1
    print("確認した項目はすべて妥当な範囲にあります。")
    print("直線を走ってスライド角がゼロ付近になることも確認してください。")
    return 0


FIREWALL_ASKED = Path(__file__).resolve().parent / "firewall_asked.txt"


def offer_firewall_rule() -> None:
    """Asks Windows, once, to let the phone through to the live view.

    Asked at most once per install, so a driver who said no is not asked at
    every start; the live view's スマホで見る panel can ask again.
    """
    from telemetry import firewall

    if firewall.is_open() is not False:
        return
    if FIREWALL_ASKED.exists():
        print("  スマホからはまだ繋がりません（Windowsのファイアウォール）。画面の「スマホで見る」から許可できます。")
        return
    print("  スマホから繋がるように、Windowsの確認画面が出ます。「はい」を押してください。")
    try:
        FIREWALL_ASKED.write_text("asked\n", encoding="utf-8")
    except OSError:
        pass
    firewall.ask_to_open()


def run_capture(args: argparse.Namespace) -> int:
    recorder = SessionRecorder()
    server: live.LiveServer | None = None
    stop_requested = threading.Event()
    # Set by the button on the report: the driver wants another session without
    # going back to the desktop and starting the tool again.
    resume_requested = threading.Event()
    # The console the last session was recorded from, so the wait between
    # sessions can notice the driver going out again without a fresh search.
    last_host: str | None = None

    # The live page greets the driver by car name when the console connects;
    # resolved once per car id, since the lookup opens the bundled CSV.
    known_car_names: dict[int, str | None] = {}
    # The one line from the last report on this circuit, for the driver to
    # glance at on the live view.
    live_focus = focus.LiveFocus(args.out, lambda: tracks.Registry(registry_path()))

    def state_with_report() -> dict[str, Any]:
        """The live state, plus how the report is coming along."""
        state = recorder.live_state()
        car_id = state.get("carId")
        if car_id is not None:
            if car_id not in known_car_names:
                known_car_names[car_id] = car_name_for(car_id)
            state["carName"] = known_car_names[car_id]
        state["reportReady"] = server is not None and server.report_path is not None
        state["reportError"] = server.report_error if server is not None else None
        state["stopping"] = stop_requested.is_set()
        live_focus.observe(state)
        state["focus"] = live_focus.current(recorder)
        place = live_focus.where(state)
        state["trackAtM"], state["trackLapM"] = place if place else (None, None)
        state["targetsReport"] = live_focus.report(recorder)
        state["model"] = live_focus.model(recorder)
        return state

    def wait_for_the_browser(code: int) -> int | None:
        """Keeps serving after the capture ends, so the page can show the result.

        Returns None when the driver pressed the report's own button asking for
        another session; the caller then goes round again with the same server
        and the same browser tab.
        """
        if server is None:
            return code
        # The driver reads the report while driving the next laps, so the next
        # session starts on its own as soon as the car moves; the button is
        # only for starting before that.
        watcher_done = threading.Event()
        watcher: threading.Thread | None = None
        if last_host is not None:
            watcher = threading.Thread(
                target=resume_when_driving,
                args=(last_host, resume_requested, watcher_done),
                daemon=True,
            )
            watcher.start()
            print("GT7で走り出すと、自動で次の記録を始めます（レポートは開いたままで大丈夫です）。")
        else:
            print("続けて記録するなら、レポートの「続けて記録する」を押してください。")
        print("終了するには、このウィンドウを閉じるか Ctrl+C を押してください。")
        try:
            while not resume_requested.is_set():
                time.sleep(0.2)
            return None
        except KeyboardInterrupt:
            pass
        finally:
            watcher_done.set()
            if watcher is not None:
                # It holds the receive port; the next session binds the same
                # one, and on Windows both would bind and split the packets.
                watcher.join(timeout=3)
            if not resume_requested.is_set():
                server.stop()
        return code

    if not args.no_live:
        server = live.LiveServer(
            state_with_report,
            port=args.port,
            on_stop=stop_requested.set,
            on_resume=resume_requested.set,
            local_only=args.local_only,
        )
        server.start()
        # The pages link to the listing, so past sessions are one click away
        # rather than a trip through the file system.
        server.sessions_root = args.out
        print(f"ライブ表示: {server.url}")
        if server.lan_url:
            # Worth saying out loud: this is the address to put in a phone, and
            # it also means anyone on the same network can open the page.
            print(f"スマホ・タブレットから: {server.lan_url}  （画面の「スマホで見る」にQRコードが出ます）")
            offer_firewall_rule()
        if server.port != server.requested_port:
            # Almost always a capture window left open from last time. Say so,
            # rather than letting the driver stare at a page of stale numbers.
            print(
                f"  （{server.requested_port}番は使用中でした。"
                "前回の記録ウィンドウが残っているなら閉じてください）"
            )
        if not args.no_browser:
            webbrowser.open(server.url)

    def record_one_session() -> int | None:
        """Records, saves and reports one session.

        Returns the exit code, or None when the driver asked for another go:
        the report has a button for that, so a second session never means
        going back to the desktop and starting the tool again.
        """
        nonlocal recorder, last_host

        raw_log: list[bytes] = []
        started_at = datetime.now()

        print("記録中。ブラウザの「記録を終了してレポートへ」または Ctrl+C で停止します。")
        # Moving to another circuit mid-recording banks the laps so far as their own
        # session and carries straight on; nothing on disk happens until the end, so
        # the split costs no packets and asks no questions while the car is moving.
        watcher = stint_module.TrackChangeWatcher()
        # Going back to the menu stops the stream, which is as good a sign as
        # any that the driving is over. See telemetry/idle.py for why it waits.
        quiet = idle_module.IdleWatcher(args.idle_stop)
        if quiet.enabled:
            print(
                f"  （コースを降りて{quiet.timeout_s:.0f}秒たつと、自動でレポートにします）"
            )

        def worth_reporting() -> bool:
            return any(lap.is_usable for lap in recorder.laps)

        def should_stop() -> bool:
            return stop_requested.is_set() or quiet.expired(worth_reporting=worth_reporting())

        stints: list[Stint] = []
        raw_mark = 0
        source = open_source(args)
        if isinstance(source, receiver_module.GT7Receiver):
            last_host = source.host
        try:
            with source:
                # The stop flag goes into the receiver as well as being checked per
                # packet: GT7 stops streaming in menus and while paused, so a stop
                # pressed then would otherwise wait for the driver to go back out.
                if (args.record_raw is not None or args.keep_raw) and hasattr(source, "raw_datagrams"):
                    stream = _packets_recording_raw(
                        source, raw_log, args.duration, should_stop
                    )
                else:
                    stream = source.packets(
                        stop_after_s=args.duration, should_stop=should_stop
                    )
                announced = False
                for decoded in stream:
                    quiet.note_packet()
                    if not announced:
                        # Nothing else is printed until a lap is finished, so
                        # without this line the window sat on "接続中" for a
                        # whole lap and looked frozen while it was recording.
                        print("GT7からデータが届きました。記録しています（1周ごとにここに表示します）")
                        announced = True
                    if stop_requested.is_set():
                        break
                    if watcher.note(decoded):
                        if recorder.laps:
                            stints.append(Stint(recorder, started_at, raw_mark, len(raw_log)))
                            print(
                                f"  コースが変わりました。ここまでの{len(recorder.laps)}周を"
                                "1つのセッションとして区切り、記録を続けます。"
                            )
                        # Half a lap on the old circuit is not worth keeping either way.
                        recorder = SessionRecorder()
                        started_at = datetime.now()
                        raw_mark = len(raw_log)
                    finished = recorder.feed(decoded)
                    if finished is not None:
                        marker = "（ベスト）" if recorder.best_lap is finished else ""
                        print(
                            f"  {finished.number}周目: {export.format_lap_time(finished.lap_time_s)}"
                            f"  {finished.distance_m:.0f} m{marker}"
                        )
        except KeyboardInterrupt:
            stop_requested.set()

        if not stop_requested.is_set() and quiet.expired(worth_reporting=True):
            print(
                f"コースを降りて{quiet.timeout_s:.0f}秒たったので、記録を終了します。"
            )
        print("記録を終了しました。")
        stats = getattr(source, "stats", None)
        if stats is not None:
            print(stats.summary())

        if recorder.laps:
            stints.append(Stint(recorder, started_at, raw_mark, len(raw_log)))

        if not stints:
            message = "完走したラップがありません。1周してから終了してください。"
            print(message)
            if server is not None:
                server.report_error = message
            return wait_for_the_browser(1)

        if args.record_raw is not None and raw_log:
            receiver_module.write_raw_capture(args.record_raw, raw_log)
            print(f"生パケット: {args.record_raw} ({len(raw_log)} 個)")

        last_outcome = None
        last_error: str | None = None
        for position, banked in enumerate(stints):
            if len(stints) > 1:
                print()
                print(f"--- セッション {position + 1}/{len(stints)} ---")
            # An explicit --track-name can only describe the circuit the recording
            # began on; later stints are on something else by definition.
            outcome, error = process_stint(
                banked, args, raw_log, explicit_name=args.track_name if position == 0 else None
            )
            if outcome is not None:
                last_outcome = outcome
            if error is not None:
                last_error = error

        # The registry lets the listing name anything recorded before its
        # circuit was identified.
        index = sessions_module.write_index(
            args.out, tracks.Registry(registry_path())
        )
        print(f"走行記録の一覧: {index}")

        if last_error is not None and server is not None:
            server.report_error = last_error
        if last_outcome is None:
            return wait_for_the_browser(1 if last_error else 0)
        outcome = last_outcome

        if server is not None:
            # The live page polls for this and navigates to the report itself.
            server.report_path = outcome.path
            print()
            print("ブラウザにレポートを表示しました。")
            return wait_for_the_browser(0)

        if not args.no_browser:
            webbrowser.open(outcome.path.resolve().as_uri())
        return 0

    while True:
        # Everything a session owns is rebuilt here, so nothing from the last
        # one leaks into the next: the laps, the raw packets, the stop flag,
        # and whatever the page was last told about a report.
        stop_requested.clear()
        resume_requested.clear()
        recorder = SessionRecorder()
        if server is not None:
            server.report_path = None
            server.report_error = None
        code = record_one_session()
        if code is not None:
            return code
        print()
        print("新しいセッションを記録します。")



# How long the car has to keep moving before the wait between sessions counts
# it as driving again: a second of packets, so a car nudged on the grid or a
# replay flickering past does not start a session.
DRIVING_PACKETS = 60
DRIVING_KMH = 10.0


def wait_until_driving(packets, *, needed: int = DRIVING_PACKETS) -> bool:
    """True once the car has been moving for `needed` packets in a row."""
    moving = 0
    for decoded in packets:
        if not decoded.is_paused and decoded.speed_kmh > DRIVING_KMH:
            moving += 1
            if moving >= needed:
                return True
        else:
            moving = 0
    return False


def resume_when_driving(host: str, resume: threading.Event, done: threading.Event) -> None:
    """Asks for the next session once GT7 streams a moving car again."""
    try:
        with receiver_module.GT7Receiver(host) as watch:
            stream = watch.packets(should_stop=lambda: done.is_set() or resume.is_set())
            if wait_until_driving(stream):
                print("走り出したので、次の記録を始めます。")
                resume.set()
    except OSError:
        # The port is shared with the recording itself; if it cannot be had,
        # the button on the report still works.
        pass


def process_stint(
    banked: Stint, args, raw_log: list[bytes], *, explicit_name: str | None
):
    """Saves one stint to disk and builds its report.

    Returns (outcome, error_message); either may be None. A failure here never
    raises, because the stints after this one still deserve their turn.
    """
    recorder = banked.recorder
    # Before the report is built, so the name reaches the header, the lap list
    # and the index rather than a row of CAR-ID-3395.
    name_the_cars(recorder, args)
    track_name, fingerprint = identify_track(
        recorder, explicit_name, ask=args.ask_names and not args.no_ask_track
    )
    session_dir = sessions_module.session_directory(args.out, track_name, banked.started_at)

    path = export.write_session(
        recorder.laps, session_dir, filename=sessions_module.SESSION_FILENAME
    )
    print(f"保存: {path} ({path.stat().st_size / 1e6:.1f} MB / {len(recorder.laps)}周)")

    raw_slice = raw_log[banked.raw_start : banked.raw_end]
    if args.keep_raw and raw_slice:
        # Worth the disk: a decoding bug found later can be re-run over this
        # drive instead of asking whoever recorded it to go out and repeat it.
        raw_path = session_dir / sessions_module.RAW_FILENAME
        receiver_module.write_raw_capture(raw_path, raw_slice)
        print(f"生パケット: {raw_path} ({raw_path.stat().st_size / 1e6:.1f} MB)")

    best = recorder.best_lap
    if best is not None:
        print(f"ベストラップ: {export.format_lap_time(best.lap_time_s)}")

    if args.no_report:
        write_session_meta(session_dir, recorder, track_name, fingerprint, banked.started_at, None)
        return None, None

    print()
    print("レポートを作成しています...")
    try:
        # Imported here rather than at module scope: a capture does not need it
        # until a report is actually being built.
        import build_report

        # Corner names live with the circuit, not the session: name them once and
        # every later report on this track reads them back.
        track_segments = args.out / tracks.slug(track_name) / sessions_module.SEGMENTS_FILENAME
        outcome = build_report.build(
            # Only this stint's own laps: a folder holding two circuits would
            # produce a report that quietly averages both.
            data_dir=session_dir,
            out=session_dir / sessions_module.REPORT_FILENAME,
            segments=track_segments if track_segments.exists() else None,
            auto_segments=not track_segments.exists(),
            save_segments=track_segments,
            track_slug=tracks.slug(track_name),
            track_name=track_name,
            # Earlier sessions on this circuit live beside this one. The fastest
            # lap among them joins the report, so the comparison is against the
            # best ever driven here and not just against today.
            history_root=args.out,
        )
    except Exception as error:  # noqa: BLE001 - the capture is already safe on disk
        message = f"レポートの作成に失敗しました: {error}"
        print(message)
        print(f"データは {path} に保存済みです。build_report.py で後から作成できます。")
        write_session_meta(session_dir, recorder, track_name, fingerprint, banked.started_at, None)
        return None, message

    print(f"レポート: {outcome.path}")
    print(f"  {outcome.segment_count}区間を自動検出 / 理論ベスト {export.format_lap_time(outcome.theoretical_s)}")
    if outcome.history_lap:
        print(f"  過去の走行から {outcome.history_lap} を比較対象に追加しました")
    if outcome.flagged_count:
        print(f"  スピンやコースアウトと判定した {outcome.flagged_count} 区間を理論ベストから除外しました")

    car_reports = build_car_reports(recorder, session_dir, args, track_name, track_segments)

    write_session_meta(
        session_dir,
        recorder,
        track_name,
        fingerprint,
        banked.started_at,
        outcome,
        car_reports=car_reports,
    )

    segments_file = args.out / tracks.slug(track_name) / sessions_module.SEGMENTS_FILENAME
    if segments_file.exists():
        print(f"  コーナー名は {segments_file} で変更できます（name_ja を書き換えるだけ）")
    return outcome, None


def cars_driven(recorder: SessionRecorder) -> list[tuple[int, list]]:
    """The cars this stint was driven in, first seen first, with their laps."""
    grouped: dict[int, list] = {}
    for lap in recorder.laps:
        grouped.setdefault(lap.car_code, []).append(lap)
    return list(grouped.items())


def build_car_reports(
    recorder: SessionRecorder,
    session_dir: Path,
    args,
    track_name: str,
    track_segments: Path,
) -> dict[int, str]:
    """One extra report per car, when more than one was driven in this session.

    Swapping cars in the pits does not start a new session - it is the same
    circuit, so the recording carries on and report.html can compare across the
    two, which is worth having. But a car's own pace, its own history ghost and
    its own advice all get buried in a mixed report, so each car also gets one of
    its own. A session driven in a single car gets no extra file: it would hold
    exactly what report.html already holds.

    Returns the filename written for each car, so meta.json can point at them.
    """
    import build_report

    cars = cars_driven(recorder)
    if len(cars) < 2:
        return {}

    print()
    print(f"{len(cars)}車種で走っています。車ごとのレポートも作成します。")
    reports: dict[int, str] = {}
    for car_id, laps in cars:
        car_name = car_name_for(car_id)
        name = car_name or str(car_id)
        filename = sessions_module.car_report_filename(car_id, car_name)
        try:
            outcome = build_report.build(
                data_dir=session_dir,
                out=session_dir / filename,
                # The mixed report has already detected and saved the corners, so
                # every report of this session names them the same way.
                segments=track_segments if track_segments.exists() else None,
                auto_segments=not track_segments.exists(),
                track_slug=tracks.slug(track_name),
                track_name=track_name,
                # Restricting to one car is all it takes: the history ghost then
                # comes from this car's own past laps, since webreport/history.py
                # only ever matches the reference lap's car.
                car_id=car_id,
                history_root=args.out,
            )
        except Exception as error:  # noqa: BLE001 - one car must not cost the rest
            print(f"  {name}: レポートを作成できませんでした（{error}）")
            continue
        reports[car_id] = filename
        print(
            f"  {name}（{len(laps)}周）: {outcome.path}"
            f" / ベスト {export.format_lap_time(outcome.best_lap_s)}"
        )
        if outcome.history_lap:
            print(f"    過去の走行から {outcome.history_lap} を比較対象に追加しました")
    return reports


def registry_path() -> Path:
    """Where learned circuit shapes are kept: beside the tool, so it travels with it."""
    return Path(__file__).resolve().parent / tracks.REGISTRY_FILENAME


def ask_track_name(fingerprint: tracks.Fingerprint) -> str | None:
    """Asks which circuit this was, when nothing on file matches its shape."""
    if not sys.stdin or not sys.stdin.isatty():
        return None
    print()
    print(
        f"このコースは初めてです（1周 {fingerprint.length_m / 1000:.3f} km"
        f" / 高低差 {fingerprint.height_m:.0f} m）。"
    )

    # Distance narrows it down a long way, but the published figures these come
    # from are not measured from the game, so they are offered and never assumed.
    candidates = tracks.suggest_names(fingerprint)
    if candidates:
        print("距離が近いのはこのあたりです（合っていれば番号、違えば名前を入力）:")
        for position, (name, km) in enumerate(candidates, start=1):
            gap = fingerprint.length_m / 1000 - km
            print(f"  {position}. {name}  （公称 {km:.3f} km / 差 {gap:+.3f} km）")

    print("入力すると、次回からは形状で自動判別します。")
    try:
        answer = input("コース名（空欄のままEnterでも構いません）: ").strip()
    except (EOFError, KeyboardInterrupt):
        return None
    if not answer:
        return None
    if answer.isdigit() and candidates:
        choice = int(answer)
        if 1 <= choice <= len(candidates):
            return candidates[choice - 1][0]
    return answer


def identify_track(
    recorder: SessionRecorder, explicit_name: str | None, *, ask: bool
) -> tuple[str, tracks.Fingerprint]:
    """Works out which circuit was driven, learning the answer for next time."""
    reference = recorder.best_lap or recorder.laps[-1]
    fingerprint = tracks.fingerprint_from_lap(reference)
    registry = tracks.Registry(registry_path())

    if explicit_name:
        registry.remember(explicit_name, fingerprint)
        registry.save()
        return explicit_name, fingerprint

    known = registry.identify(fingerprint)
    if known is not None:
        print(f"コース: {known}（形状から判別 / 1周 {fingerprint.length_m / 1000:.3f} km）")
        return known, fingerprint

    answer = ask_track_name(fingerprint) if ask else None
    if answer:
        registry.remember(answer, fingerprint)
        registry.save()
        return answer, fingerprint

    # Better an honest placeholder than someone else's circuit name: the folder
    # can be renamed later and the shape re-learned with --track-name. The
    # placeholder is remembered too, or the next session's slightly different
    # lap length would file the same circuit under a new folder and lose its
    # corner names and history.
    placeholder = tracks.placeholder_name(fingerprint.length_m)
    registry.remember(placeholder, fingerprint)
    registry.save()
    return placeholder, fingerprint


def write_session_meta(
    directory: Path,
    recorder: SessionRecorder,
    track_name: str,
    fingerprint: tracks.Fingerprint,
    started_at: datetime,
    outcome,
    *,
    car_reports: dict[int, str] | None = None,
) -> None:
    """Writes the small file the index page reads, so it need not open the laps."""
    best = recorder.best_lap
    car_id = best.car_code if best is not None else None
    reports = car_reports or {}
    session_report = sessions_module.REPORT_FILENAME if outcome is not None else None

    # `carId` / `carName` stay singular and keep naming the car of the best lap,
    # so anything reading an older sidecar still finds what it expects. `cars`
    # is the honest list, and it is written even for a single car so a reader
    # never has to decide which of the two shapes it is looking at.
    cars = [
        {
            "id": entry_id,
            "name": car_name_for(entry_id),
            "laps": len(laps),
            "bestLapS": min(lap.lap_time_s for lap in laps),
            "report": reports.get(entry_id, session_report if not reports else None),
        }
        for entry_id, laps in cars_driven(recorder)
    ]

    sessions_module.write_meta(
        directory,
        {
            "track": track_name,
            "trackSlug": tracks.slug(track_name),
            "recordedAt": started_at.isoformat(timespec="seconds"),
            "laps": len(recorder.laps),
            "bestLapS": best.lap_time_s if best is not None else None,
            # This session's own laps only. The report's own figure includes the
            # ghost carried in from an earlier session, which is right there and
            # wrong in a column headed with this session's date.
            "theoreticalS": getattr(outcome, "theoretical_this_session_s", None)
            or getattr(outcome, "theoretical_s", None),
            "carId": car_id,
            "carName": car_name_for(car_id),
            "cars": cars,
            "lapDistanceM": fingerprint.length_m,
            "report": session_report,
            "session": sessions_module.SESSION_FILENAME,
        },
    )


def car_name_for(car_id: int | None) -> str | None:
    """Turns a car code into its name, if the tables know it."""
    if car_id is None:
        return None
    try:
        import analyze_gt7

        return analyze_gt7.load_car_names(analyze_gt7.DEFAULT_CARS_CSV).get(car_id)
    except Exception:  # noqa: BLE001 - a missing name must not cost the session
        return None


def ask_car_name(car_id: int) -> str | None:
    """Asks what this car is called, when the bundled table predates it.

    The table stops at 569 cars and GT7 keeps adding them, so a recent car has
    no name anywhere on this machine to find. Asked once, then remembered.
    """
    if not sys.stdin or not sys.stdin.isatty():
        return None
    print()
    print(f"この車（ID {car_id}）の名前が表にありません。")
    print("入力すると、次回からこの名前でレポートに出ます。")
    try:
        answer = input("車名（空欄のままEnterでも構いません）: ").strip()
    except (EOFError, KeyboardInterrupt):
        return None
    if not answer:
        return None
    cars_module.remember(car_id, answer)
    return answer


def name_the_cars(recorder: SessionRecorder, args) -> None:
    """Makes sure every car in this session has a name before the report is built."""
    if not getattr(args, "ask_names", False) or getattr(args, "no_ask_track", False):
        return
    seen: list[int] = []
    for lap in recorder.laps:
        if lap.car_code not in seen:
            seen.append(lap.car_code)
    for car_id in seen:
        if car_name_for(car_id) is None:
            ask_car_name(car_id)


def _packets_recording_raw(
    source, raw_log: list[bytes], duration: float | None, should_stop=None
):
    """Yields decoded packets while keeping the encrypted originals."""
    for datagram in source.raw_datagrams(stop_after_s=duration, should_stop=should_stop):
        raw_log.append(datagram)
        try:
            decoded = packet_module.decode(datagram)
        except packet_module.PacketError:
            source.stats.undecodable += 1
            continue
        source.stats.decoded += 1
        source.stats.note_packet_id(decoded.packet_id)
        yield decoded


def main() -> int:
    # A Japanese Windows console defaults to cp932, which cannot represent every
    # character used in these messages. Without this, printing a status line can
    # take the whole capture down.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError):
            pass

    args = parse_args()
    if args.probe:
        return run_probe(args)
    if args.verify:
        return run_verify(args)
    return run_capture(args)


if __name__ == "__main__":
    sys.exit(main())
