@echo off
rem First run: makes sure there is a Python to work with, then puts the icons on
rem the desktop. Runs the download only when neither a bundled runtime nor an
rem installed Python is present, so the same file works for every way of getting
rem this folder.
setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul

set "PYVER=3.12.7"
set "RUNTIME=%~dp0runtime"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-embed-amd64.zip"
set "PIPURL=https://bootstrap.pypa.io/get-pip.py"

echo ====================================
echo  GT7 テレメトリ 初回セットアップ
echo ====================================
echo.

if exist "%RUNTIME%\python.exe" (
    echo Python は同梱済みです。ダウンロードは不要です。
    goto :shortcuts
)

where python >nul 2>&1
if not errorlevel 1 (
    echo このPCの Python を使います。
    goto :shortcuts
)

echo このPCに Python が無いので、必要な分だけ取得します。
echo インターネット接続が必要です。2〜3分かかります。
echo.

mkdir "%RUNTIME%" 2>nul

echo [1/4] Python %PYVER% をダウンロードしています...
powershell -NoProfile -Command ^
  "$ProgressPreference='SilentlyContinue';" ^
  "try { Invoke-WebRequest -Uri '%PYURL%' -OutFile '%TEMP%\gt7-python.zip' -UseBasicParsing } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 goto :failed

echo [2/4] 展開しています...
powershell -NoProfile -Command ^
  "Expand-Archive -Path '%TEMP%\gt7-python.zip' -DestinationPath '%RUNTIME%' -Force"
if errorlevel 1 goto :failed
del "%TEMP%\gt7-python.zip" >nul 2>&1

rem The embeddable build disables site-packages by default; pip needs it back,
rem and '..' puts this folder on the path so `telemetry` and `webreport` import.
echo [3/4] 準備しています...
powershell -NoProfile -Command ^
  "$pth = Get-ChildItem '%RUNTIME%\python*._pth' | Select-Object -First 1;" ^
  "if (-not $pth) { Write-Host '._pth が見つかりません'; exit 1 };" ^
  "(Get-Content $pth.FullName) -replace '^#\s*import site', 'import site' | Set-Content $pth.FullName;" ^
  "if (-not (Select-String -Path $pth.FullName -Pattern '^import site' -Quiet)) { Add-Content $pth.FullName 'import site' };" ^
  "if (-not (Select-String -Path $pth.FullName -Pattern '^\.\.$' -Quiet)) { Add-Content $pth.FullName '..' }"
if errorlevel 1 goto :failed

powershell -NoProfile -Command ^
  "$ProgressPreference='SilentlyContinue';" ^
  "try { Invoke-WebRequest -Uri '%PIPURL%' -OutFile '%RUNTIME%\get-pip.py' -UseBasicParsing } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 goto :failed
"%RUNTIME%\python.exe" "%RUNTIME%\get-pip.py" --no-warn-script-location -q
if errorlevel 1 goto :failed
del "%RUNTIME%\get-pip.py" >nul 2>&1

echo [4/4] numpy を入れています...
"%RUNTIME%\python.exe" -m pip install --no-warn-script-location -q -r requirements.txt
if errorlevel 1 goto :failed
"%RUNTIME%\python.exe" -m pip uninstall -y pip -q >nul 2>&1
for /d /r "%RUNTIME%" %%C in (__pycache__) do if exist "%%C" rmdir /s /q "%%C"

echo.
echo 準備ができました。
echo.

:shortcuts
call "%~dp0デスクトップにアイコンを作る.bat"
exit /b 0

:failed
echo.
echo セットアップに失敗しました。インターネット接続を確認してもう一度実行してください。
echo どうしても駄目な場合は、https://www.python.org/downloads/ から Python を
echo インストールしてください（「Add Python to PATH」に必ずチェック）。
echo その後、このファイルをもう一度実行すれば使えます。
pause
exit /b 1
