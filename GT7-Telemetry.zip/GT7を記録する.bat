@echo off
rem GT7 telemetry capture, for people who would rather not open a terminal.
rem Double-click this file. It finds whichever Python this folder was set up with.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ====================================
echo  GT7 テレメトリ記録
echo ====================================
echo.

rem Three ways this folder can have a Python, in the order they are preferred:
rem the runtime bundled or fetched beside it, a virtual environment made here,
rem then whatever is installed on the machine.
set "PY="
if exist "%~dp0runtime\python.exe" set "PY=%~dp0runtime\python.exe"
if not defined PY if exist "%~dp0.venv\Scripts\python.exe" set "PY=%~dp0.venv\Scripts\python.exe"

if not defined PY (
    where python >nul 2>&1
    if errorlevel 1 (
        echo Python の準備ができていません。
        echo.
        echo   同じフォルダの「はじめに実行してください.bat」を先に実行してください。
        echo.
        pause
        exit /b 1
    )
    echo 初回セットアップを行います。数分かかります。
    echo.
    python -m venv .venv
    if errorlevel 1 (
        echo 仮想環境の作成に失敗しました。
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip -q
    ".venv\Scripts\python.exe" -m pip install -q -r requirements.txt
    if errorlevel 1 (
        echo 必要なライブラリのインストールに失敗しました。
        pause
        exit /b 1
    )
    set "PY=%~dp0.venv\Scripts\python.exe"
    echo セットアップが完了しました。
    echo.
)

echo GT7でコースに出ると、自動で記録が始まります。
echo （先にこのウィンドウを開いておいても大丈夫です）
echo.

"%PY%" -X utf8 capture_gt7.py %*

echo.
echo 終了しました。ウィンドウを閉じて構いません。
pause
