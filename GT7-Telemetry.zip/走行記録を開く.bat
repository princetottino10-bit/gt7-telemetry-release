@echo off
rem Opens the list of every recorded session. Rebuilds it first, so a folder
rem copied in by hand or a report made later still shows up.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=runtime\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" -c "import sys; sys.path.insert(0,'.'); from pathlib import Path; from telemetry import sessions; print(sessions.write_index(Path('sessions')))" >nul 2>&1

if not exist "sessions\index.html" (
    echo まだ走行記録がありません。
    echo 「GT7を記録する」から1周走ってください。
    echo.
    pause
    exit /b 1
)

start "" "sessions\index.html"
