"""Plays a recorded lap back through the live view, to try it without driving.

The live view, its "next corner" box and the Zundamon read-out can only be
seen on track otherwise. This replays the fastest lap of the newest session
that has a report, at real speed and round and round, with that report as the
source of the target speeds (the Daily Race week rule is skipped here: the
point is to see and hear the view, not to pick a fair target).
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any

from analyze_gt7 import read_session_bytes
from telemetry import focus, live, sessions

ROOT = Path(__file__).resolve().parent


def newest_session(root: Path) -> Path | None:
    """The newest session folder with a report beside its laps.

    The driver's own: a model's laps are someone else's, and the driver's report
    is the one that carries the model as targets.
    """
    reports = sorted(root.glob(f"*/*/{sessions.REPORT_FILENAME}"), key=lambda path: path.parent.name, reverse=True)
    found = [report.parent for report in reports if (report.parent / "session.json").exists()]
    own = [folder for folder in found if not sessions.is_model(folder)]
    return (own or found or [None])[0]


def fastest_lap(folder: Path) -> dict[str, Any] | None:
    laps = json.loads(read_session_bytes(folder / "session.json"))
    usable = [lap for lap in laps if lap.get("data_distance_m") and lap.get("lap_finish_time", 0) > 0]
    return min(usable, key=lambda lap: lap["lap_finish_time"]) if usable else None


class Replay:
    """The live state at the current moment of the lap being replayed."""

    def __init__(self, lap: dict[str, Any], report_url: str, model: dict[str, Any] | None = None) -> None:
        self.lap = lap
        self.report_url = report_url
        self.model = model
        self.times = lap["data_time"]
        self.length = float(lap["data_distance_m"][-1])
        self.lap_s = lap["lap_finish_time"] / 1000.0
        self.start = time.monotonic()
        step = max(1, len(lap["data_position_x"]) // 400)
        self.path = [[round(x, 1), round(z, 1)] for x, z in zip(lap["data_position_x"][::step], lap["data_position_z"][::step])]

    def state(self) -> dict[str, Any]:
        elapsed = time.monotonic() - self.start
        loops, into = divmod(elapsed, self.lap_s)
        i = self._index(into)
        lap = self.lap
        return {
            "connected": True,
            "carId": lap["car_id"],
            "carName": None,
            "onTrack": True,
            "paused": False,
            "lapNumber": int(loops) + 2,
            "lapTimeS": into,
            "distanceM": lap["data_distance_m"][i],
            "deltaS": 0.0,
            "speedKmh": lap["data_speed"][i],
            "gear": lap["data_gear"][i],
            "rpm": lap["data_rpm"][i],
            "rpmAlertMin": 7000,
            "rpmAlertMax": 7500,
            "throttlePct": lap["data_throttle"][i],
            "brakePct": lap["data_braking"][i],
            "position": [lap["data_position_x"][i], lap["data_position_z"][i]],
            "tireTemps": [70, 70, 70, 70],
            "tireSlip": [0, 0, 0, 0],
            "slideAngleDeg": 0,
            "bestLapS": self.lap_s,
            "lastLapS": self.lap_s,
            "completedLaps": int(loops) + 1,
            "referenceDistanceM": self.length,
            "deltaSparkline": [],
            "sectors": None,
            "trackPath": self.path,
            "focus": None,
            "targetsReport": self.report_url,
            "model": self.model,
            "reportReady": False,
            "stopping": False,
        }

    def _index(self, seconds: float) -> int:
        # The samples are in time order, so a binary search finds the moment.
        lo, hi = 0, len(self.times) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if self.times[mid] < seconds:
                lo = mid + 1
            else:
                hi = mid
        return lo


def main() -> int:
    parser = argparse.ArgumentParser(description="ライブ画面のデモ（録った周を流し直す）")
    parser.add_argument("--sessions", type=Path, default=ROOT / "sessions")
    parser.add_argument("--port", type=int, default=live.DEFAULT_PORT + 1)
    args = parser.parse_args()

    folder = newest_session(args.sessions)
    lap = fastest_lap(folder) if folder else None
    if folder is None or lap is None:
        print("デモに使える走行記録がありません。先に1回記録してレポートを作ってください。")
        return 1
    report = folder / sessions.REPORT_FILENAME
    if not focus.has_targets(report):
        print("レポートが古い版で作られているので、今の版で作り直しています（1〜2分）...")
        if not focus.bring_up_to_date(args.sessions, report):
            print("作り直せませんでした。目標の数字と読み上げなしで流します。")
    report_url = "/sessions/" + (folder / sessions.REPORT_FILENAME).relative_to(args.sessions).as_posix()
    # The model of the week the replayed session was driven in.
    replay = Replay(lap, report_url, focus.latest_model(args.sessions, folder.parent.name, focus._week_of(folder)))
    server = live.LiveServer(replay.state, port=args.port)
    server.sessions_root = args.sessions
    server.start()
    print(f"デモ: {folder.parent.name} {folder.name} のベスト {lap['lap_finish_time'] / 1000:.3f} 秒を流しています")
    print("画面上の「読み上げ」を押すと、ずんだもんが次のコーナーの最低速度を読みます。")
    print("終わるときはこのウィンドウを閉じてください。")
    webbrowser.open(server.url)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
