"""Brings the all-time best lap of a circuit into today's report.

A report is built from one session folder on purpose: mixing folders would
average two different circuits together. That also means a report can only ever
compare a driver with themselves on the day, and the one lap most worth chasing
- the fastest they have ever driven here - is sitting in a folder next door.

This picks that lap out of the earlier sessions on the same circuit and hands it
back as an ordinary lap, labelled with the date it was set, so the ghost player,
the segment table and the delta traces all work on it unchanged.
"""

from __future__ import annotations

import dataclasses
import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

import analyze_gt7 as core
from webreport import loader

PreparedLap = core.PreparedLap

# Named here rather than imported so the report side never has to pull in the
# recorder. telemetry/sessions.py is where these are written, and the two have to
# agree; both are also listed in analyze_gt7.SIDECAR_FILENAMES.
SESSION_FILENAME = "session.json"
META_FILENAME = "meta.json"

# How far a past lap's reconstructed distance may sit from today's field before
# it is treated as a different layout rather than the same corner sequence.
DISTANCE_TOLERANCE = 0.05


def session_directories(root: Path, track_slug: str, *, exclude: Path | None = None) -> list[Path]:
    """Every earlier session recorded on this circuit, newest first."""
    folder = root / track_slug
    if not folder.exists():
        return []
    skip = exclude.resolve() if exclude is not None else None
    found = [
        path.parent
        for path in sorted(folder.glob("*/" + SESSION_FILENAME))
        if skip is None or path.parent.resolve() != skip
    ]
    found.sort(key=lambda path: path.name, reverse=True)
    return found


def recorded_on(directory: Path, lap: PreparedLap | None = None) -> str:
    """The day a session was driven, as `8/13`, or "" when nothing says."""
    stamp = _meta_recorded_at(directory)
    if not stamp and lap is not None:
        stamp = lap.start_timestamp
    if not stamp:
        return ""
    for text in (stamp, stamp.replace(" ", "T")):
        try:
            moment = datetime.fromisoformat(text)
        except ValueError:
            continue
        return f"{moment.month}/{moment.day}"
    return ""


def _meta(directory: Path) -> dict:
    path = directory / META_FILENAME
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        # A session whose sidecar was hand-edited into invalid JSON still has
        # perfectly good laps; fall back to the timestamp on the lap itself.
        return {}
    return payload if isinstance(payload, dict) else {}


def _meta_recorded_at(directory: Path) -> str:
    return str(_meta(directory).get("recordedAt") or "")


def is_model(directory: Path) -> bool:
    """Whether the driver marked this session as the model to chase.

    A model is recorded like any session, usually while GT7 plays back a faster
    driver's replay (the console sends telemetry during replays too), so only
    the mark tells it apart from the driver's own laps.
    """
    return bool(_meta(directory).get("model"))


def _recorded_moment(directory: Path) -> datetime | None:
    """When a session was driven: the sidecar, else the folder's own name."""
    stamp = _meta_recorded_at(directory)
    for text in (stamp, stamp.replace(" ", "T")):
        if not text:
            continue
        try:
            return datetime.fromisoformat(text)
        except ValueError:
            continue
    # capture_gt7.py names each folder after the minute it started.
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})_(\d{2})(\d{2})", directory.name)
    if match:
        try:
            return datetime(*(int(part) for part in match.groups()))
        except ValueError:
            return None
    return None


def daily_week(directory: Path) -> date | None:
    """The Monday that starts the week a session was driven in.

    GT7's Daily Races change week by week, and a race fixes the car's tyres. A
    week's laps in one car on one circuit are practice for the same race on the
    same tyres; a best from another week may have been on another compound,
    which the telemetry does not record, so it is no fair target. The exact hour
    the races change over is not published anywhere the tool can read, so the
    week starts at midnight on Monday.
    """
    moment = _recorded_moment(directory)
    if moment is None:
        return None
    day = moment.date()
    return day - timedelta(days=day.weekday())


def label(lap: PreparedLap, directory: Path) -> PreparedLap:
    """Renames a past lap so the report says when it was driven."""
    day = recorded_on(directory, lap)
    time = core.format_time(lap.lap_time_s)
    title = f"{day}のベスト {time}" if day else f"過去のベスト {time}"
    return dataclasses.replace(lap, title=title, is_history=True)


def load_candidates(directories: list[Path], cars_csv: Path) -> list[PreparedLap]:
    """Reads the usable laps out of earlier sessions, already labelled."""
    candidates: list[PreparedLap] = []
    for directory in directories:
        try:
            laps = loader.load_laps(directory, cars_csv)
        except (OSError, ValueError, FileNotFoundError, json.JSONDecodeError):
            # One unreadable old session must never cost today's report.
            continue
        candidates.extend(
            label(lap, directory) for lap in laps if lap.validity == "included"
        )
    return candidates


def _comparable(lap: PreparedLap, selection: loader.LapSelection, *, any_car: bool = False) -> bool:
    """Whether a past lap can sit alongside today's without distorting them."""
    current = selection.laps
    # Same lap, read twice: today's session file is also the newest history file
    # once a second report is built over the same folder.
    if any(lap.uid == existing.uid for existing in current):
        return False
    if not any_car and lap.car_id != selection.reference.car_id:
        return False
    # A behaviour channel missing from one lap is missing from the whole report,
    # since only channels every lap carries can be compared.
    shared = set(current[0].extended)
    for existing in current[1:]:
        shared &= set(existing.extended)
    if not shared <= set(lap.extended):
        return False
    reference = float(selection.reference.distance_m[-1])
    if reference <= 0:
        return False
    gap = abs(float(lap.distance_m[-1]) - reference) / reference
    return gap <= DISTANCE_TOLERANCE


def pick_best(candidates: list[PreparedLap], selection: loader.LapSelection) -> PreparedLap | None:
    """The fastest past lap worth showing beside today's, if there is one."""
    usable = [lap for lap in candidates if _comparable(lap, selection)]
    if not usable:
        return None
    return min(usable, key=lambda lap: lap.lap_time_s)


def model_lap(directories: list[Path], cars_csv: Path, selection: loader.LapSelection) -> PreparedLap | None:
    """The fastest lap of the newest model session, labelled as the model.

    Any car: a replay worth copying may be in another car than the driver's.
    The layout still has to match, and so do the recorded channels.
    """
    for directory in directories:
        if not is_model(directory):
            continue
        try:
            laps = [lap for lap in loader.load_laps(directory, cars_csv) if lap.validity == "included"]
        except (OSError, ValueError, FileNotFoundError, json.JSONDecodeError):
            continue
        usable = [lap for lap in laps if _comparable(lap, selection, any_car=True)]
        if not usable:
            continue
        best = min(usable, key=lambda lap: lap.lap_time_s)
        day = recorded_on(directory, best)
        title = f"お手本 {core.format_time(best.lap_time_s)}" + (f"（{day}）" if day else "")
        return dataclasses.replace(best, title=title, is_history=True, is_model=True)
    return None


def merge(selection: loader.LapSelection, lap: PreparedLap | None) -> loader.LapSelection:
    """Adds a past lap to the selection, letting it take the reference if faster.

    The pace cutoff and the lap cap are deliberately not applied here. Both exist
    to drop cool-down laps from a session; a lap that has already been chosen as
    the best a driver has ever managed on this circuit is not one of those, and
    running it through the same filters would throw it away exactly when today's
    pace was poor and the comparison mattered most.
    """
    if lap is None:
        return selection
    laps = sorted([*selection.laps, lap], key=lambda entry: entry.lap_time_s)
    # The model is there to be chased, never to stand in for the driver's own best.
    own = [entry for entry in laps if not entry.is_model]
    return loader.LapSelection(laps=laps, excluded=selection.excluded, reference=own[0])


def attach(
    selection: loader.LapSelection,
    *,
    root: Path | None,
    track_slug: str,
    exclude: Path | None,
    cars_csv: Path,
) -> loader.LapSelection:
    """Finds the circuit's best lap this Daily Race week and folds it in.

    The newest model of the week comes in too, as its own lap. A model's own
    report takes in neither: its laps are someone else's driving.
    """
    if root is None:
        return selection
    if exclude is not None and is_model(exclude):
        return selection
    directories = session_directories(root, track_slug, exclude=exclude)
    week = daily_week(exclude) if exclude is not None else None
    if week is not None:
        directories = [directory for directory in directories if daily_week(directory) == week]
    if not directories:
        return selection
    own = [directory for directory in directories if not is_model(directory)]
    merged = merge(selection, pick_best(load_candidates(own, cars_csv), selection))
    return merge(merged, model_lap(directories, cars_csv, merged))
