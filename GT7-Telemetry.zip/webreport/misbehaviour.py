"""Decides whether one lap's run through one segment can be believed.

The segment table, the theoretical best and the advice panel all rest on the
same assumption: a quick time through a corner is a time the driver drove. A
spin, a wall or a trip across the grass breaks that assumption, and a single
contaminated segment is enough to produce a theoretical best nobody can reach
and advice pointing at a lap that never happened.

This looks at the raw 60 Hz samples rather than the resampled trace, because a
car that stops covers almost no distance: on a distance grid the whole incident
collapses into a handful of points, while in time it is seconds long.

Thresholds come from first_session.bin (Watkins Glen Long, 296 GTB '22, five
laps, four of them clean). The numbers below are the widest gap between what the
clean laps did and what the ruined one did:

    metric                     clean laps (worst)   lap 5 (crashed)
    time under 20 km/h              0.00 s              2.37 s
    peak speed step             1146 km/h/s         4911 km/h/s
    time past 20 deg of slide        0.95 s             0.50 s
    peak slide angle                38.1 deg           27.7 deg
    peak tyre slip                   1.95               1.38

Slide angle and tyre slip therefore do not separate a ruined lap from a ragged
one on this circuit, so their thresholds are set where the physics stops being
ambiguous instead: a car past 45 degrees for over half a second is no longer
following its nose, and a tyre at 2.5 is spinning rather than gripping. Both sit
far above anything the clean laps produced, so they cost nothing here and still
catch the spin this session happens not to contain.
"""

from __future__ import annotations

from typing import Any

import numpy as np

# Below this, and for this long, the car is not cornering: it has stopped.
# Even the slowest hairpin in the game is taken at more than double this.
STOPPED_KMH = 20.0
STOPPED_HOLD_S = 0.5

# No brake can take this much speed out of a car in one 60 Hz sample. At
# 2500 km/h/s the car is shedding about 70 g, which is a wall or a reset.
IMPACT_KMH_PER_S = 2500.0

# Past this angle the car is travelling sideways rather than steering.
SPIN_ANGLE_DEG = 45.0
SPIN_HOLD_S = 0.6

# Slip is clamped at 3.0 by the decoder; 1.0 is a rolling wheel.
WHEELSPIN_SLIP = 2.5
WHEELSPIN_HOLD_S = 0.4

SLIDE_CHANNEL = "data_slide_angle_deg"
SLIP_CHANNELS = (
    "data_tire_slip_fl",
    "data_tire_slip_fr",
    "data_tire_slip_rl",
    "data_tire_slip_rr",
)

# Fewer samples than this and the window is too short to say anything.
MIN_SAMPLES = 4


def has_channels(lap: Any) -> bool:
    """Whether this lap carries the channels the checks need.

    GT7 Dashboard sessions do not, so they keep the behaviour they always had:
    every segment time is believed.
    """
    extended = getattr(lap, "extended", None)
    return bool(extended) and SLIDE_CHANNEL in extended


def segment_mask(lap: Any, segment: dict[str, Any]) -> np.ndarray:
    """The raw samples that fall inside a segment's stretch of the lap."""
    start = float(segment["start_fraction"])
    end = float(segment["end_fraction"])
    return (lap.progress >= start) & (lap.progress <= end)


def longest_hold_s(mask: np.ndarray, time_s: np.ndarray) -> float:
    """Duration of the longest unbroken stretch where `mask` is true."""
    longest = 0.0
    start: int | None = None
    for index, flagged in enumerate(mask):
        if flagged and start is None:
            start = index
        elif not flagged and start is not None:
            longest = max(longest, float(time_s[index - 1] - time_s[start]))
            start = None
    if start is not None:
        longest = max(longest, float(time_s[-1] - time_s[start]))
    return longest


def _speed_step(speed_kmh: np.ndarray, time_s: np.ndarray) -> tuple[float, float]:
    """Sharpest speed change in the window, as (km/h per second, km/h)."""
    if len(speed_kmh) < 2:
        return 0.0, 0.0
    drop = np.abs(np.diff(speed_kmh))
    # A repeated timestamp would divide by zero; a sample can never be shorter
    # than a millisecond in practice.
    elapsed = np.maximum(np.diff(time_s), 1e-3)
    rate = drop / elapsed
    peak = int(np.argmax(rate))
    return float(rate[peak]), float(drop[peak])


def inspect(lap: Any, segment: dict[str, Any]) -> str:
    """Why this lap's run through this segment cannot be trusted, or "" if it can.

    The text is shown to the driver as the tooltip on the flagged row, so it says
    what happened rather than which threshold fired.
    """
    if not has_channels(lap):
        return ""
    mask = segment_mask(lap, segment)
    if int(mask.sum()) < MIN_SAMPLES:
        return ""

    time_s = lap.time_s[mask]
    speed_kmh = lap.speed_kmh[mask]

    rate, drop = _speed_step(speed_kmh, time_s)
    if rate >= IMPACT_KMH_PER_S:
        return f"速度が一瞬で {drop:.0f}km/h 落ちています（衝突かリセット）"

    stopped = longest_hold_s(speed_kmh < STOPPED_KMH, time_s)
    if stopped >= STOPPED_HOLD_S:
        return f"{stopped:.1f}秒 ほぼ停止しています（スピンかコースアウト）"

    slide = np.abs(lap.extended[SLIDE_CHANNEL][mask])
    spinning = longest_hold_s(slide > SPIN_ANGLE_DEG, time_s)
    if spinning >= SPIN_HOLD_S:
        return f"{spinning:.1f}秒 横を向いたままです（スピン）"

    slips = [lap.extended[name][mask] for name in SLIP_CHANNELS if name in lap.extended]
    if slips:
        peak = np.maximum.reduce(slips)
        wheelspin = longest_hold_s(peak >= WHEELSPIN_SLIP, time_s)
        if wheelspin >= WHEELSPIN_HOLD_S:
            return f"{wheelspin:.1f}秒 タイヤが空転しています（スリップ比 {float(peak.max()):.1f}）"

    return ""
