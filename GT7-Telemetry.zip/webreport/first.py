"""The report's "first thing to do", worked out in Python for the live view.

The report works this out in the browser (templates/js/47-theme.js and
49-first.js) so it can follow whichever reference lap is picked. The live view
has no report open, so the same figure for the default reference lap is
computed here at build time and saved next to the report; the capture window
reads it back and shows it as one line while the driver is on track.

Since 2026.11.11 the live view asks the report page itself for its headline
(the panel of targets decides it there, which this module does not repeat), so
what is saved here is where the line belongs on the lap and the wording to
fall back on when that page cannot be read. The factors, floors and wording
below mirror the older theme in the JS.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

FILENAME_SUFFIX = ".first.json"

# Same floors as the cards (47-actions.js).
MIN_GAIN_S = 0.03
MIN_SPEED_DIFF_KMH = 2.5
MIN_POINT_DIFF_M = 8

# In the order a corner is driven; a corner is credited to the first that
# differs (THEME_FACTORS in 47-theme.js).
_FACTORS = (
    ("brake", "brakePointM", -1, "m"),
    ("minSpeed", "minSpeedKmh", -1, "km/h"),
    ("throttle", "fullThrottleM", 1, "m"),
    ("exit", "exitSpeedKmh", -1, "km/h"),
)

# FIRST_THING in 49-first.js.
_WORDING = {
    "brake": (
        lambda ref, best: f"ブレーキング開始を {best - ref:.0f}m 奥へ",
        "動かない目印を1つ決め、そこまで我慢してから踏む",
    ),
    "minSpeed": (
        lambda ref, best: f"最低速度 {best:.0f} km/h",
        "ブレーキの後半を早めに緩める",
    ),
    "throttle": (
        lambda ref, best: f"全開を {ref - best:.0f}m 手前で",
        "向きを変え切ったら、1回で全開まで踏んで戻さない",
    ),
    "exit": (
        lambda ref, best: f"出口 {best:.0f} km/h",
        "クリップを少し奥にとり、出口でコース幅を使い切る",
    ),
}


def _value(entry: dict[str, Any], field: str, index: int) -> float | None:
    values = entry.get(field) or []
    return values[index] if index < len(values) else None


def _flagged(entry: dict[str, Any], index: int) -> bool:
    return bool(_value(entry, "flagged", index))


def _fastest(entry: dict[str, Any], pool: list[int]) -> int | None:
    """fastestLapForSegment: spins and offs are not evidence unless every lap was one."""
    times = entry["timeS"]
    for include_flagged in (False, True):
        best = None
        for i in pool:
            if times[i] is None or (not include_flagged and _flagged(entry, i)):
                continue
            if best is None or times[i] < times[best]:
                best = i
        if best is not None:
            return best
    return None


def first_thing(payload: dict[str, Any]) -> dict[str, Any] | None:
    """The theme's top corner for the report's default reference lap, or None."""
    laps = payload["laps"]
    ref = next((lap["index"] for lap in laps if lap.get("isReference")), None)
    if ref is None:
        return None
    car = laps[ref].get("carId")
    pool = [lap["index"] for lap in laps if lap.get("carId") == car]
    segments = payload["segments"]
    by_id = {entry["id"]: entry for entry in payload["sectors"]}
    credit: dict[str, dict[str, Any]] = {key: {"seconds": 0.0, "corners": {}} for key, *_ in _FACTORS}

    for position, segment in enumerate(segments):
        entry = by_id.get(segment["id"])
        if entry is None or entry["timeS"][ref] is None or _flagged(entry, ref):
            continue
        best = _fastest(entry, pool)
        if best is None or best == ref or _flagged(entry, best):
            continue
        loss = entry["timeS"][ref] - entry["timeS"][best]
        if not loss > MIN_GAIN_S:
            continue
        # Time lost on a straight was lost in the corner before it.
        source = segments[position - 1] if segment["id"].startswith("straight") else segment
        source_entry = by_id.get(source["id"])
        if source_entry is None:
            continue
        for key, field, sign, unit in _FACTORS:
            ref_value = _value(source_entry, field, ref)
            best_value = _value(source_entry, field, best)
            if ref_value is None or best_value is None:
                continue
            floor = MIN_SPEED_DIFF_KMH if unit == "km/h" else MIN_POINT_DIFF_M
            if sign * (ref_value - best_value) < floor:
                continue
            credit[key]["seconds"] += loss
            corner = credit[key]["corners"].setdefault(
                source["id"], {"segment": source, "loss": 0.0, "ref": ref_value, "best": best_value}
            )
            corner["loss"] += loss
            break

    ranked = sorted(
        ((key, item) for key, item in credit.items() if item["seconds"] > 0),
        key=lambda pair: -pair[1]["seconds"],
    )
    if not ranked:
        return None
    key, item = ranked[0]
    corner = max(item["corners"].values(), key=lambda corner: corner["loss"])
    target, action = _WORDING[key]
    segment = corner["segment"]
    return {
        "track": payload.get("meta", {}).get("trackName"),
        "factor": key,
        "corner": segment.get("name_ja") or segment.get("name") or segment["id"],
        "segmentId": segment["id"],
        "startFraction": segment.get("start_fraction"),
        "endFraction": segment.get("end_fraction"),
        "target": target(corner["ref"], corner["best"]),
        "action": action,
        "lossS": round(corner["loss"], 3),
    }


def path_for(report: Path) -> Path:
    return report.with_name(report.stem + FILENAME_SUFFIX)


def write(report: Path, payload: dict[str, Any]) -> Path | None:
    """Saves the line beside the report, or removes a stale one."""
    target = path_for(report)
    first = first_thing(payload)
    if first is None:
        target.unlink(missing_ok=True)
        return None
    target.write_text(json.dumps(first, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return target


def read(path: Path) -> dict[str, Any] | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
