"""Per-corner timing and driving-style metrics for each lap."""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

import numpy as np

import analyze_gt7 as core
from webreport import misbehaviour, trailbrake
from webreport.resample import ROTATION_CHANNEL, Grid, LapTrace

# A brake or throttle input has to hold for this many grid samples before it
# counts, so a momentary stab does not register as the braking point.
SUSTAIN_SAMPLES = 6
BRAKE_THRESHOLD_PCT = 8.0
FULL_THROTTLE_PCT = 98.0
TCS_CHANNEL = "data_tcs"
# GT7 streams at 60 Hz; one saved sample is one tick.
TICK_HZ = 60.0


@dataclass(frozen=True)
class SectorResult:
    """One lap's numbers through one segment of the circuit."""

    segment_id: str
    lap_uid: str
    time_s: float
    entry_speed_kmh: float
    min_speed_kmh: float
    exit_speed_kmh: float
    max_speed_kmh: float
    brake_point_m: float | None
    full_throttle_m: float | None
    delta_gain_s: float
    # Empty when the run through the segment looks like driving. Otherwise the
    # reason it does not, in the words shown to the driver.
    flag_reason: str = ""
    # Share of this corner's braking effort applied while the car was already
    # turning, 0..1. None where the segment is not a braked corner, and on
    # sessions whose laps carry no usable yaw rate.
    trail_brake_share: float | None = None
    # Seconds traction control spent cutting power in this segment. None on
    # sessions recorded before the flag was saved.
    tcs_s: float | None = None

    @property
    def is_flagged(self) -> bool:
        return bool(self.flag_reason)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def segment_bounds(grid: Grid, segment: dict[str, Any]) -> tuple[int, int]:
    """Maps a segment's fractional bounds onto grid indices."""
    last = grid.points - 1
    start = int(round(float(segment["start_fraction"]) * last))
    end = int(round(float(segment["end_fraction"]) * last))
    return start, min(max(end, start + 1), last)


def _sustained_distance(
    values: np.ndarray, distance: np.ndarray, threshold: float, above: bool
) -> float | None:
    """Distance at which an input first crosses a threshold and stays there."""
    index = core.first_sustained_index(values, threshold, above, run=SUSTAIN_SAMPLES)
    return None if index is None else float(distance[index])


def tcs_seconds(lap: Any, segment: dict[str, Any]) -> float | None:
    """Time traction control was intervening inside a segment, from raw samples.

    Counted in time on the 60 Hz samples rather than on the distance grid: the
    flag flickers on and off within a few samples, which resampling would blur.
    """
    extended = getattr(lap, "extended", None) or {}
    flags = extended.get(TCS_CHANNEL)
    if flags is None:
        return None
    mask = misbehaviour.segment_mask(lap, segment)
    return float(np.count_nonzero(np.asarray(flags)[mask] > 0.5)) / TICK_HZ


def compute_sector(
    trace: LapTrace, grid: Grid, segment: dict[str, Any]
) -> SectorResult:
    """Derives timing and input metrics for one lap through one segment."""
    start, end = segment_bounds(grid, segment)
    window = slice(start, end + 1)
    elapsed = trace.channel("time_s")
    speed = trace.channel("speed_kmh")[window]
    distance = grid.distance_m[window]
    rotation = trace.channels.get(ROTATION_CHANNEL)

    return SectorResult(
        segment_id=str(segment["id"]),
        lap_uid=trace.uid,
        time_s=float(elapsed[end] - elapsed[start]),
        entry_speed_kmh=float(speed[0]),
        min_speed_kmh=float(speed.min()),
        exit_speed_kmh=float(speed[-1]),
        max_speed_kmh=float(speed.max()),
        brake_point_m=_sustained_distance(
            trace.channel("brake_pct")[window], distance, BRAKE_THRESHOLD_PCT, above=True
        ),
        full_throttle_m=_sustained_distance(
            trace.channel("throttle_pct")[window], distance, FULL_THROTTLE_PCT, above=True
        ),
        delta_gain_s=float(trace.delta_s[end] - trace.delta_s[start]),
        flag_reason=misbehaviour.inspect(trace.lap, segment),
        trail_brake_share=None
        if rotation is None
        else trailbrake.share(
            trace.channel("brake_pct"),
            trace.channel("speed_kmh"),
            rotation,
            grid.distance_m,
            (start, end),
        ),
        tcs_s=tcs_seconds(trace.lap, segment),
    )


def compute_all(
    traces: list[LapTrace], grid: Grid, segments: list[dict[str, Any]]
) -> list[SectorResult]:
    """Runs `compute_sector` for every lap and segment combination."""
    return [
        compute_sector(trace, grid, segment)
        for trace in traces
        for segment in segments
    ]


def fastest_by_segment(
    results: list[SectorResult], *, include_flagged: bool = False
) -> dict[str, SectorResult]:
    """Finds the quickest lap through each segment, regardless of overall time.

    Runs that misbehaved are skipped by default: a corner cut after a spin can
    post a time no clean lap can match, and every number built on top of it then
    describes an incident rather than a driver. A segment where every lap
    misbehaved falls back to its own fastest, since dropping it entirely would
    quietly shorten the theoretical lap.
    """
    best: dict[str, SectorResult] = {}
    for result in results:
        if not include_flagged and result.is_flagged:
            continue
        current = best.get(result.segment_id)
        if current is None or result.time_s < current.time_s:
            best[result.segment_id] = result

    if not include_flagged:
        missing = {result.segment_id for result in results} - set(best)
        for result in results:
            if result.segment_id not in missing:
                continue
            current = best.get(result.segment_id)
            if current is None or result.time_s < current.time_s:
                best[result.segment_id] = result
    return best


def flagged_results(results: list[SectorResult]) -> list[SectorResult]:
    """Every run that failed the behaviour checks."""
    return [result for result in results if result.is_flagged]


def theoretical_best_s(results: list[SectorResult]) -> float:
    """Sums the fastest believable segment times: what the field actually showed."""
    return float(sum(result.time_s for result in fastest_by_segment(results).values()))
