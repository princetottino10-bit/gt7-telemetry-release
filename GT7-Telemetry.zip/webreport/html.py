"""Assembles the self-contained HTML report from templates and payload."""

from __future__ import annotations

import base64
import json
import mimetypes
from pathlib import Path

try:
    import icons
except ImportError:  # pragma: no cover - the report reads fine without them
    icons = None
from typing import Any

TEMPLATE_DIR = Path(__file__).parent / "templates"
SUPPORTED_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp", ".svg", ".gif")


def find_track_image(assets_dir: Path, slug: str) -> Path | None:
    """Looks for a background course diagram named after the track slug."""
    for suffix in SUPPORTED_IMAGE_SUFFIXES:
        candidate = assets_dir / f"{slug}{suffix}"
        if candidate.exists():
            return candidate
    return None


def encode_image(path: Path) -> str:
    """Inlines an image as a data URL so the report stays a single file."""
    mime, _ = mimetypes.guess_type(path.name)
    if mime is None:
        mime = "image/png"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def load_scripts() -> str:
    """Concatenates the JS modules in filename order."""
    parts = [path.read_text(encoding="utf-8") for path in sorted((TEMPLATE_DIR / "js").glob("*.js"))]
    return "\n\n".join(parts)


def _embed_json(payload: dict[str, Any]) -> str:
    """Serialises the payload so it cannot terminate the surrounding script tag."""
    text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    return text.replace("</", "<\\/")


def render(payload: dict[str, Any], title: str) -> str:
    """Substitutes styles, scripts and data into the page template."""
    template = (TEMPLATE_DIR / "index.html").read_text(encoding="utf-8")
    styles = (TEMPLATE_DIR / "app.css").read_text(encoding="utf-8")
    return (
        template.replace("__TITLE__", title)
        .replace("__STYLES__", styles)
        .replace("__SCRIPTS__", load_scripts())
        .replace("__PAYLOAD__", _embed_json(payload))
        .replace("__SPRITE__", icons.sprite() if icons else "")
        .replace("__FAVICON__", icons.favicon_link() if icons else "")
        .replace("__ICON_STYLES__", icons.STYLES if icons else "")
        .replace("__HERO_STYLE__", icons.hero_style() if icons else "")
    )
