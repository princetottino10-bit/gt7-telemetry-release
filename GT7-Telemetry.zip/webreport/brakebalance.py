"""How hard each axle works under braking, and where the fronts run out of grip.

GT7 sends neither the brake balance setting nor the ABS level, so the report
cannot say "you are on -2". What it can measure is the result: how much each
tyre slips when the driver brakes. A rear axle that slips far less than the front
under full braking still has grip to give, which is the case for moving the
balance rearward; a rear that slips as much as the front is the case for moving
it forward. That direction is all this module claims. How many clicks, and
whether the setting is already at its end stop, only the driver knows.

Slip
----
`data_tire_slip_*` is wheel surface speed over car speed (telemetry/session.py),
so 1.0 is rolling and below 1.0 is a wheel turning slower than the car - braking
slip. Each wheel's ratio is divided by its own median while cruising, because
the radius GT7 reports does not match the rolling radius exactly: on every
session recorded so far the rears cruise at 1.016-1.031, the fronts at 1.000.
Slip here is therefore `1 - normalised ratio`, in percent.

The axle figure is taken only under straight-line full braking (pedal past
`FULL_BRAKE_PCT`, above `MIN_SPEED_KMH`, rotation below trailbrake's
`ROTATION_FLOOR`), where both axles are asked for the same thing and the split
between them is down to the balance, not to cornering. Medians per lap on the
latest session of each circuit recorded by 2026-10-19:

    session                     front  rear
    Autopolis Short              5.9    4.7
    Spa (GR Supra RC)            9.0    5.7
    Laguna Seca (Honda VGT)     11.1    6.6
    Watkins Glen (M6 GT3)       10.9    5.2
    Suzuka (Genesis Gr.3)        9.9    6.0

Across all eleven sessions (61 laps, eight cars) the rear never slipped more
than the front, and almost all of those laps were driven at balance 0. The one
lap the driver ran at rear 5 (the Spa best) read 8.8 / 5.6, against 9.5 / 6.0
and 9.0 / 5.7 at 0 - so a balance change is not visible in this figure lap by
lap, and it is reported as a picture of the session, never as a reading of the
setting.

`REAR_ROOM_RATIO` is where the report starts saying the rear has grip to spare.
It is a judgement, not a measurement: the sessions above run from 1.2 to 2.6
times, and 1.5 splits the near-even ones (Autopolis, the first Watkins Glen
session at 1.3) from the clearly front-heavy rest.

Where the fronts run out
------------------------
Under straight-line full braking ABS holds the front tyres at a slip that is the
limit of this car on these tyres; its median over the session is the
`reference`. Brake while already turning and the tyre has to give some of that
grip to cornering, so a front slipping *at least as much* as it does at full
straight-line braking, while the car is rotating, has nothing left for the turn.
Those moments are the `events`. Calibrating against the session's own straight
braking keeps the line honest across cars: the reference ran from 6.4% to 13.9%
slip across the eleven sessions, so no single fixed number would have meant the
same thing on all of them.

Per lap this finds 1-9 events (median 4), and it is steady within a session -
3 laps at Spa gave 7, 7 and 7; 12 at Laguna Seca 2-5. Events closer than
`BRIDGE_SAMPLES` are one event, and a run shorter than `MIN_EVENT_SAMPLES` is a
kerb or a bump, not braking.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from webreport import trailbrake
from webreport.loader import PreparedLap

SLIP_CHANNELS = ("data_tire_slip_fl", "data_tire_slip_fr", "data_tire_slip_rl", "data_tire_slip_rr")

# Cruising: off the brake, on the throttle, fast enough for the ratio to settle.
CRUISE_THROTTLE_PCT = 20.0
CRUISE_BRAKE_PCT = 1.0

# Straight-line full braking, where the axle split is measured.
FULL_BRAKE_PCT = 95.0
MIN_SPEED_KMH = 80.0
# Fewer samples than this (half a second at 60 Hz) is not enough braking to
# quote a figure for a lap.
MIN_FULL_BRAKE_SAMPLES = 30

# Front slip at least this many times the rear's means the rear has grip to
# spare. See the module docstring; the browser reads it from the payload.
REAR_ROOM_RATIO = 1.5

# An event is braking that matters while the car is turning.
EVENT_BRAKE_PCT = 20.0
EVENT_MIN_SPEED_KMH = 50.0
BRIDGE_SAMPLES = 12
MIN_EVENT_SAMPLES = 3


@dataclass(frozen=True)
class LapBraking:
    """One lap's braking split and where its fronts ran out of grip."""

    uid: str
    front_slip_pct: float | None
    rear_slip_pct: float | None
    # Lap progress (0..1) at the deepest point of each event.
    events: list[float] = field(default_factory=list)


def has_slip(lap: PreparedLap) -> bool:
    return all(name in lap.extended for name in SLIP_CHANNELS)


def normalised_slip(lap: PreparedLap) -> dict[str, np.ndarray]:
    """Each wheel's slip ratio divided by its own cruising median."""
    cruise = (
        (lap.brake_pct < CRUISE_BRAKE_PCT)
        & (lap.throttle_pct > CRUISE_THROTTLE_PCT)
        & (lap.speed_kmh > MIN_SPEED_KMH)
    )
    out: dict[str, np.ndarray] = {}
    for name in SLIP_CHANNELS:
        values = np.asarray(lap.extended[name], dtype=float)
        base = float(np.median(values[cruise])) if cruise.any() else 1.0
        out[name] = values / (base if base > 0 else 1.0)
    return out


def _straight_full_brake(lap: PreparedLap, rotation: np.ndarray) -> np.ndarray:
    return (
        (lap.brake_pct >= FULL_BRAKE_PCT)
        & (lap.speed_kmh > MIN_SPEED_KMH)
        & (rotation < trailbrake.ROTATION_FLOOR)
    )


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    """Index ranges where `mask` holds, bridging short gaps, dropping blips."""
    runs: list[tuple[int, int]] = []
    start: int | None = None
    gap = 0
    for index, value in enumerate(mask):
        if value:
            if start is None:
                start = index
            gap = 0
        elif start is not None:
            gap += 1
            if gap > BRIDGE_SAMPLES:
                runs.append((start, index - gap))
                start = None
                gap = 0
    if start is not None:
        runs.append((start, len(mask) - 1 - gap))
    return [run for run in runs if run[1] - run[0] + 1 >= MIN_EVENT_SAMPLES]


def reference_slip(laps: list[PreparedLap]) -> float | None:
    """The front's normalised ratio under straight-line full braking.

    The median over all the given laps, so one lap's odd stop cannot move it.
    """
    pooled: list[np.ndarray] = []
    for lap in laps:
        if not has_slip(lap):
            continue
        slip = normalised_slip(lap)
        rotation = trailbrake.rotation_rate(lap.yaw_rate)
        front = np.minimum(slip["data_tire_slip_fl"], slip["data_tire_slip_fr"])
        pooled.append(front[_straight_full_brake(lap, rotation)])
    values = np.concatenate(pooled) if pooled else np.array([])
    if len(values) < MIN_FULL_BRAKE_SAMPLES:
        return None
    return float(np.median(values))


def analyse_lap(lap: PreparedLap, reference: float | None) -> LapBraking:
    """Axle slip under straight full braking, and the lap's front-limit events."""
    if not has_slip(lap):
        return LapBraking(lap.uid, None, None, [])
    slip = normalised_slip(lap)
    rotation = trailbrake.rotation_rate(lap.yaw_rate)
    straight = _straight_full_brake(lap, rotation)

    front_pct = rear_pct = None
    if int(straight.sum()) >= MIN_FULL_BRAKE_SAMPLES:
        front = (slip["data_tire_slip_fl"] + slip["data_tire_slip_fr"]) / 2
        rear = (slip["data_tire_slip_rl"] + slip["data_tire_slip_rr"]) / 2
        front_pct = (1.0 - float(np.median(front[straight]))) * 100.0
        rear_pct = (1.0 - float(np.median(rear[straight]))) * 100.0

    events: list[float] = []
    if reference is not None:
        worst = np.minimum(slip["data_tire_slip_fl"], slip["data_tire_slip_fr"])
        mask = (
            (lap.brake_pct > EVENT_BRAKE_PCT)
            & (lap.speed_kmh > EVENT_MIN_SPEED_KMH)
            & (rotation >= trailbrake.ROTATION_FLOOR)
            & (worst < reference)
        )
        for first, last in _runs(mask):
            deepest = first + int(np.argmin(worst[first : last + 1]))
            events.append(float(lap.progress[deepest]))
    return LapBraking(lap.uid, front_pct, rear_pct, events)


def analyse(laps: list[PreparedLap]) -> dict:
    """The browser payload: one entry per lap, in the order given.

    The reference is computed per car, since two cars on one circuit have two
    different limits.
    """
    by_car: dict[int, list[PreparedLap]] = {}
    for lap in laps:
        by_car.setdefault(lap.car_id, []).append(lap)
    references = {car: reference_slip(group) for car, group in by_car.items()}

    entries = []
    for lap in laps:
        result = analyse_lap(lap, references[lap.car_id])
        entries.append(
            {
                "frontSlipPct": None if result.front_slip_pct is None else round(result.front_slip_pct, 2),
                "rearSlipPct": None if result.rear_slip_pct is None else round(result.rear_slip_pct, 2),
                "events": [round(p, 5) for p in result.events],
            }
        )
    reference_pct = {
        str(car): None if value is None else round((1.0 - value) * 100.0, 2)
        for car, value in references.items()
    }
    return {"laps": entries, "referenceSlipPct": reference_pct, "rearRoomRatio": REAR_ROOM_RATIO}
