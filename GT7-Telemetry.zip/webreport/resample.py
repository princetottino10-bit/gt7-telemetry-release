"""Puts every lap on a shared distance grid so they can be compared directly."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from webreport import trailbrake
from webreport.loader import PreparedLap

# Roughly 2.9 m per sample on a 5.8 km circuit: fine enough for a smooth track
# map and for locating braking points, without bloating the embedded payload.
DEFAULT_GRID_POINTS = 2000

# Channels interpolated onto the grid. `time_s` drives the delta calculation,
# `x`/`z` drive the track map, the rest are the driver inputs we plot.
CHANNELS = ("time_s", "speed_kmh", "throttle_pct", "brake_pct", "gear", "rpm", "x", "z")

# Derived on the way through rather than read off the lap: the raw yaw rate is
# too noisy to use a sample at a time, and smoothing has to happen in the time
# domain, before the lap is stretched onto a distance axis. Not packed into the
# payload - only the per-corner numbers computed from it are.
ROTATION_CHANNEL = "rotation_rate"


@dataclass(frozen=True)
class LapTrace:
    """One lap resampled onto the shared grid, with its delta to the reference."""

    uid: str
    lap: PreparedLap
    channels: dict[str, np.ndarray]
    delta_s: np.ndarray

    def channel(self, name: str) -> np.ndarray:
        return self.channels[name]


@dataclass(frozen=True)
class Grid:
    """The common distance axis shared by every trace in a report."""

    progress: np.ndarray
    distance_m: np.ndarray
    lap_distance_m: float

    @property
    def points(self) -> int:
        return len(self.progress)


def build_grid(laps: list[PreparedLap], points: int = DEFAULT_GRID_POINTS) -> Grid:
    """Builds a 0..1 progress axis scaled by the field's median lap distance."""
    totals = np.array([float(lap.distance_m[-1]) for lap in laps], dtype=float)
    lap_distance = float(np.median(totals))
    progress = np.linspace(0.0, 1.0, points)
    return Grid(progress=progress, distance_m=progress * lap_distance, lap_distance_m=lap_distance)


def _interp(source_progress: np.ndarray, values: np.ndarray, grid: np.ndarray) -> np.ndarray:
    """Interpolates onto the grid after collapsing duplicate progress samples."""
    unique_progress, indices = np.unique(source_progress, return_index=True)
    return np.interp(grid, unique_progress, values[indices])


def common_extended_channels(laps: list[PreparedLap]) -> list[str]:
    """Extended channels that every lap carries.

    A session can mix files recorded by GT7 Dashboard with ones from the direct
    capture tool. Only channels present on all of them can be compared, so a
    mixed selection reports none rather than half-empty traces.
    """
    if not laps:
        return []
    shared = set(laps[0].extended)
    for lap in laps[1:]:
        shared &= set(lap.extended)
    return sorted(shared)


def resample_lap(lap: PreparedLap, grid: Grid, extended: list[str] | None = None) -> dict[str, np.ndarray]:
    """Interpolates every analysed channel of one lap onto the shared grid."""
    resampled: dict[str, np.ndarray] = {}
    for name in CHANNELS:
        resampled[name] = _interp(lap.progress, getattr(lap, name), grid.progress)
    for name in extended or []:
        resampled[name] = _interp(lap.progress, lap.extended[name], grid.progress)
    resampled[ROTATION_CHANNEL] = _interp(
        lap.progress, trailbrake.rotation_rate(lap.yaw_rate), grid.progress
    )
    # Rescale the interpolated clock so the lap still ends on its official time;
    # interpolation of a non-uniform sample rate can drift by a few milliseconds.
    elapsed = resampled["time_s"]
    if elapsed[-1] > 0:
        resampled["time_s"] = elapsed * (lap.lap_time_s / elapsed[-1])
    return resampled


def build_traces(
    laps: list[PreparedLap], grid: Grid, reference_uid: str
) -> list[LapTrace]:
    """Resamples all laps and computes each one's running delta to the reference."""
    extended = common_extended_channels(laps)
    resampled = {lap.uid: resample_lap(lap, grid, extended) for lap in laps}
    if reference_uid not in resampled:
        raise KeyError(f"Reference lap {reference_uid} is not in the selection")
    reference_time = resampled[reference_uid]["time_s"]

    traces: list[LapTrace] = []
    for lap in laps:
        channels = resampled[lap.uid]
        traces.append(
            LapTrace(
                uid=lap.uid,
                lap=lap,
                channels=channels,
                delta_s=channels["time_s"] - reference_time,
            )
        )
    return traces


def ideal_line(traces: list[LapTrace]) -> dict[str, np.ndarray]:
    """Averages the track map coordinates so the map survives a single noisy lap."""
    xs = np.vstack([trace.channel("x") for trace in traces])
    zs = np.vstack([trace.channel("z") for trace in traces])
    return {"x": np.median(xs, axis=0), "z": np.median(zs, axis=0)}
