"""Loads GT7 Dashboard sessions and selects the laps worth comparing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

import analyze_gt7 as core

PreparedLap = core.PreparedLap

# A lap slower than the best by more than this ratio is treated as a cool-down
# or traffic lap rather than a genuine attempt.
DEFAULT_PACE_CUTOFF = 1.08


@dataclass(frozen=True)
class LapSelection:
    """The laps that made it into the report plus the reasons for exclusions."""

    laps: list[PreparedLap]
    excluded: list[tuple[PreparedLap, str]]
    reference: PreparedLap

    @property
    def car_ids(self) -> list[int]:
        seen: dict[int, None] = {}
        for lap in self.laps:
            seen.setdefault(lap.car_id, None)
        return list(seen)


def load_laps(data_dir: Path, cars_csv: Path) -> list[PreparedLap]:
    """Reads every session JSON in `data_dir` and returns deduplicated laps."""
    sessions, _inventory = core.load_sessions(data_dir)
    car_names = core.load_car_names(cars_csv)
    return core.deduplicate_laps(sessions, car_names)


def _distance_outlier_bounds(laps: list[PreparedLap]) -> tuple[float, float]:
    """Rejects laps whose reconstructed distance disagrees with the field."""
    distances = np.array([lap.distance_m[-1] for lap in laps], dtype=float)
    median = float(np.median(distances))
    return median * 0.9, median * 1.1


def select_laps(
    laps: list[PreparedLap],
    *,
    car_id: int | None = None,
    max_laps: int | None = None,
    pace_cutoff: float = DEFAULT_PACE_CUTOFF,
) -> LapSelection:
    """Keeps complete, representative laps and picks the fastest as reference."""
    excluded: list[tuple[PreparedLap, str]] = []
    candidates: list[PreparedLap] = []
    for lap in laps:
        if lap.validity != "included":
            excluded.append((lap, lap.exclusion_reason or "invalid"))
        elif car_id is not None and lap.car_id != car_id:
            excluded.append((lap, "other_car"))
        else:
            candidates.append(lap)

    if not candidates:
        raise ValueError("No usable laps were found in the telemetry")

    low, high = _distance_outlier_bounds(candidates)
    on_distance: list[PreparedLap] = []
    for lap in candidates:
        total = float(lap.distance_m[-1])
        if low <= total <= high:
            on_distance.append(lap)
        else:
            excluded.append((lap, "distance_outlier"))

    if not on_distance:
        raise ValueError("Every lap failed the distance sanity check")

    # One cutoff per car, not one for the session. A driver who swaps cars
    # mid-session is still on the same circuit, so the laps stay comparable and
    # belong in the same report - but a car two seconds a lap slower is not
    # driving cool-down laps, and judging it against another car's best would
    # throw away every lap it ever set. With a single car in the session this is
    # the old behaviour exactly: there is only one group to take a best from.
    best_by_car: dict[int, float] = {}
    for lap in on_distance:
        previous = best_by_car.get(lap.car_id)
        if previous is None or lap.lap_time_s < previous:
            best_by_car[lap.car_id] = lap.lap_time_s

    kept: list[PreparedLap] = []
    for lap in on_distance:
        if lap.lap_time_s <= best_by_car[lap.car_id] * pace_cutoff:
            kept.append(lap)
        else:
            excluded.append((lap, "off_pace"))

    kept.sort(key=lambda lap: lap.lap_time_s)
    if max_laps is not None and len(kept) > max_laps:
        for lap in kept[max_laps:]:
            excluded.append((lap, "beyond_max_laps"))
        kept = kept[:max_laps]

    return LapSelection(laps=kept, excluded=excluded, reference=kept[0])
