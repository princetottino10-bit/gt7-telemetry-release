"use strict";

/* Wires the payload, state and views together. */

(function main() {
  const payload = JSON.parse(document.getElementById("payload").textContent);
  const data = buildDataset(payload);
  addSessionAverage(data);

  const el = {
    trackName: document.getElementById("trackName"),
    sessionMeta: document.getElementById("sessionMeta"),
    statStrip: document.getElementById("statStrip"),
    refSelect: document.getElementById("refSelect"),
    cmpSelect: document.getElementById("cmpSelect"),
    verdict: document.getElementById("verdict"),
    mapStage: document.getElementById("mapStage"),
    trackCanvas: document.getElementById("trackCanvas"),
    mapLegend: document.getElementById("mapLegend"),
    mapModeToggle: document.getElementById("mapModeToggle"),
    calibrate: document.getElementById("calibrate"),
    calibControls: document.getElementById("calibControls"),
    calibReset: document.getElementById("calibReset"),
    calibExport: document.getElementById("calibExport"),
    calibRemove: document.getElementById("calibRemove"),
    calibHint: document.getElementById("calibHint"),
    theoryList: document.getElementById("theoryList"),
    theorySummary: document.getElementById("theorySummary"),
    theoryMap: document.getElementById("theoryMap"),
    theorySave: document.getElementById("theorySave"),
    actionsList: document.getElementById("actionsList"),
    actionsSummary: document.getElementById("actionsSummary"),
    actionsTheme: document.getElementById("actionsTheme"),
    firstThing: document.getElementById("firstThing"),
    gapBars: document.getElementById("gapBars"),
    gapCaption: document.getElementById("gapCaption"),
    charts: document.getElementById("charts"),
    cursorReadout: document.getElementById("cursorReadout"),
    sectorTable: document.getElementById("sectorTable"),
    lapTable: document.getElementById("lapTable"),
    blockBars: document.getElementById("blockBars"),
    blocksNote: document.getElementById("blocksNote"),
    consistencyTable: document.getElementById("consistencyTable"),
    consistencySummary: document.getElementById("consistencySummary"),
    behaviourNote: document.getElementById("behaviourNote"),
    tyreNote: document.getElementById("tyreNote"),
    brakingPanel: document.getElementById("brakingPanel"),
    brakingSplit: document.getElementById("brakingSplit"),
    brakingCorners: document.getElementById("brakingCorners"),
    brakingMemo: document.getElementById("brakingMemo"),
    ghostPlay: document.getElementById("ghostPlay"),
    ghostSeek: document.getElementById("ghostSeek"),
    ghostRate: document.getElementById("ghostRate"),
    ghostReadout: document.getElementById("ghostReadout"),
    colophon: document.getElementById("colophon")
  };

  const refIndex = data.laps.findIndex((lap) => lap.isReference);
  // Compare against a median-pace lap by default: the gap is large enough to
  // read, and it represents what the driver actually repeats.
  const byTime = data.laps.filter((lap) => !lap.isAverage).sort((a, b) => a.lapTimeS - b.lapTimeS);
  const median = byTime[Math.floor(byTime.length / 2)];
  // With a model in the report, it is what the laps are set against.
  const model = modelLapIndex(data);
  const cmpIndex =
    model !== null ? model : median.index === refIndex && byTime.length > 1 ? byTime[1].index : median.index;

  const initialDelta = computeDelta(data, refIndex, cmpIndex);
  const state = createState({
    refIndex,
    cmpIndex,
    delta: initialDelta,
    deltaRate: computeDeltaRate(initialDelta, data.distance),
    lateral: computeLateralOffset(data, refIndex, cmpIndex),
    mapMode: "delta",
    mapRotationDeg: 0,
    cursor: null,
    zoom: [0, data.points - 1],
    selection: null,
    activeSegment: null,
    sectorSort: { key: "gap", desc: true },
    ghostTime: 0,
    ghostPlaying: false,
    ghostRate: 1
  });

  let ghostControls = { stop: () => {} };

  function selectLaps(nextRef, nextCmp) {
    if (state.get().ghostPlaying) ghostControls.stop();
    const delta = computeDelta(data, nextRef, nextCmp);
    state.set({
      refIndex: nextRef,
      cmpIndex: nextCmp,
      delta,
      deltaRate: computeDeltaRate(delta, data.distance),
      lateral: computeLateralOffset(data, nextRef, nextCmp)
    });
  }

  /* ---------- static header ---------- */

  if (el.theorySave) el.theorySave.addEventListener("click", () => saveTheoryImage());
  el.trackName.textContent = payload.meta.trackName;
  el.sessionMeta.textContent = payload.meta.sessionSummary;
  el.colophon.textContent = payload.meta.colophon;
  /* "損失/利得" is pit-wall vocabulary. Say which lap was quicker instead: the
     panel answers "where did this lap lose time", so answer it in those words. */
  el.gapCaption.textContent = "各区間で、比較ラップが基準ラップより 右（赤）= 遅い / 左（緑）= 速い";

  function fillSelect(select, selectedIndex) {
    // The average first: it is the one entry that is not a lap, and a driver
    // looking for it should not have to scroll past every lap to find it.
    select.innerHTML = [...data.laps]
      .sort((a, b) => Number(Boolean(b.isAverage)) - Number(Boolean(a.isAverage)))
      .map(
        (lap) =>
          `<option value="${lap.index}"${lap.index === selectedIndex ? " selected" : ""}>` +
          `${lapLabel(lap)}</option>`
      )
      .join("");
  }

  fillSelect(el.refSelect, refIndex);
  fillSelect(el.cmpSelect, cmpIndex);

  el.refSelect.addEventListener("change", () => {
    selectLaps(Number(el.refSelect.value), state.get().cmpIndex);
  });
  el.cmpSelect.addEventListener("change", () => {
    selectLaps(state.get().refIndex, Number(el.cmpSelect.value));
  });

  if (!data.hasExtended) {
    // GT7 Dashboard sessions have no behaviour channels; drop the controls that
    // would render nothing rather than showing an empty view.
    el.mapModeToggle.querySelectorAll('[data-requires="extended"]').forEach((node) => node.remove());
  }

  el.mapModeToggle.querySelectorAll("button").forEach((button) => {
    button.addEventListener("click", () => {
      state.set({ mapMode: button.dataset.mode });
      el.mapModeToggle.querySelectorAll("button").forEach((other) => {
        other.classList.toggle("is-active", other === button);
      });
    });
  });

  /* ---------- views ---------- */

  const trackMap = createTrackMap(data, state, {
    canvas: el.trackCanvas,
    stage: el.mapStage,
    legend: el.mapLegend
  });

  const charts = createCharts(data, state, el.charts);

  ghostControls = createGhostPlayer(data, state, {
    play: el.ghostPlay,
    seek: el.ghostSeek,
    rate: el.ghostRate,
    readout: el.ghostReadout
  });

  createCalibration(data, state, trackMap, {
    stage: el.mapStage,
    controls: el.calibControls,
    reset: el.calibReset,
    exportButton: el.calibExport,
    remove: el.calibRemove,
    hint: el.calibHint
  });

  function toggleSegment(segmentId) {
    const s = state.get();
    if (s.activeSegment === segmentId) {
      state.set({ activeSegment: null, zoom: [0, data.points - 1] });
      if (ghostControls) {
        ghostControls.playWholeLap();
        ghostControls.stop();
      }
      return;
    }
    const segment = data.segments.find((entry) => entry.id === segmentId);
    if (!segment) return;
    const pad = Math.round((segment.end - segment.start) * 0.15);
    state.set({
      activeSegment: segmentId,
      zoom: [
        Math.max(0, segment.start - pad),
        Math.min(data.points - 1, segment.end + pad)
      ]
    });
    // The map has just zoomed onto this corner; run the two cars round it so the
    // difference between the laps can be watched rather than read off a chart.
    if (ghostControls) ghostControls.playSegment(segmentId);
  }

  function renderTables() {
    renderStats(data, state, el.statStrip);
    renderTheory(data, state, { list: el.theoryList, summary: el.theorySummary, map: el.theoryMap }, toggleSegment);
    // After the panel: the line at the top is that panel's first corner.
    renderFirstThing(data, state, el.firstThing, toggleSegment);
    renderTheme(data, state, el.actionsTheme, toggleSegment);
    renderActions(data, state, { list: el.actionsList, summary: el.actionsSummary }, toggleSegment);
    renderVerdict(data, state, el.verdict);
    renderGapBars(data, state, el.gapBars, toggleSegment);
    renderSectorTable(data, state, el.sectorTable, toggleSegment);
    renderConsistency(data, state, {
      blocks: el.blockBars,
      blocksNote: el.blocksNote,
      table: el.consistencyTable,
      summary: el.consistencySummary,
      behaviour: el.behaviourNote,
      tyres: el.tyreNote
    }, toggleSegment);
    renderBraking(data, state, {
      panel: el.brakingPanel,
      split: el.brakingSplit,
      corners: el.brakingCorners,
      memo: el.brakingMemo
    }, toggleSegment);
    renderLapTable(data, state, el.lapTable, (index) => {
      selectLaps(state.get().refIndex, index);
      el.cmpSelect.value = String(index);
    });
  }

  function renderCanvases() {
    trackMap.render();
    charts.render();
  }

  /* Only the cursor moves on most events, so keep the heavy work off that path. */
  let previous = { ...state.get() };
  let frame = null;

  state.subscribe((s) => {
    const structural =
      s.refIndex !== previous.refIndex ||
      s.cmpIndex !== previous.cmpIndex ||
      s.activeSegment !== previous.activeSegment ||
      s.sectorSort !== previous.sectorSort ||
      // The corner pictures on the cards turn with the big map.
      s.mapRotationDeg !== previous.mapRotationDeg;
    previous = { ...s };
    if (frame) cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      frame = null;
      if (structural) renderTables();
      renderCanvases();
      renderCursor(data, state, el.cursorReadout);
    });
  });

  window.addEventListener("resize", () => renderCanvases());

  /* Keyboard control. The charts are canvases, so without this there is no way
     to move the cursor or drive playback except with a pointer. */
  document.addEventListener("keydown", (event) => {
    const tag = event.target.tagName;
    if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;

    const s = state.get();
    const stride = event.shiftKey ? 25 : 5;
    const from = s.cursor === null ? s.zoom[0] : s.cursor;
    const clamp = (index) => Math.max(s.zoom[0], Math.min(s.zoom[1], index));

    switch (event.key) {
      case "ArrowRight":
        state.set({ cursor: clamp(from + stride) });
        break;
      case "ArrowLeft":
        state.set({ cursor: clamp(from - stride) });
        break;
      case "Home":
        state.set({ cursor: s.zoom[0] });
        break;
      case "End":
        state.set({ cursor: s.zoom[1] });
        break;
      case " ":
        el.ghostPlay.click();
        break;
      case "Escape":
        ghostControls.playWholeLap();
        ghostControls.stop();
        state.set({ zoom: [0, data.points - 1], activeSegment: null, cursor: null });
        break;
      default:
        return;
    }
    event.preventDefault();
  });

  renderTables();
  renderCanvases();
  renderCursor(data, state, el.cursorReadout);

  // Handle for the browser console: inspect the decoded telemetry, or drive the
  // report from a script (gt7.state.set({ cmpIndex: 4 })).
  window.gt7 = { data, state, selectLaps, render: renderCanvases };
})();
