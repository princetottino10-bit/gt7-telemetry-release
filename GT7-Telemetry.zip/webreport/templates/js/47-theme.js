"use strict";

/* The one habit to work on, measured against the reference lap.
 *
 * The cards below name three corners. This steps back and asks which kind of
 * difference the reference lap's lost time shares across every corner, so the
 * answer to "what do I practise" is one thing rather than three.
 *
 * It compares exactly what the cards compare: the reference lap against the
 * driver's own fastest clean run through each corner, in the same car. Each
 * corner's gap is credited to every candidate - minimum speed, exit speed,
 * full-throttle point, braking start - on which the reference lap was worse
 * than that faster run by at least the floors the cards use
 * (MIN_SPEED_DIFF_KMH, MIN_POINT_DIFF_M) - the first such one in driving
 * order, see THEME_FACTORS. The candidate with the most seconds behind it is
 * the theme.
 *
 * On the reports recorded by 2026-10-19 (credited / total seconds):
 *
 *     session                   reference = best lap     reference = session average
 *     Laguna Seca (Honda VGT)   full throttle 0.27/0.66  minimum speed 2.02/2.53
 *     Watkins Glen (M6 GT3)     minimum speed 0.61/0.86  minimum speed 1.17/1.78
 *     Suzuka (Genesis Gr.3)     minimum speed 0.52/0.88  minimum speed 1.15/2.07
 *     Spa (GR Supra RC, 3 laps) minimum speed 0.26/0.48  full throttle 0.61/1.09
 *
 * Braking start was credited nowhere: where the reference lap braked 8 m or
 * more earlier than the faster run, the corner was not one it lost time in.
 *
 * The best lap's theme is what that one lap still left; the average's is the
 * habit, which is why the session average can be picked as the reference.
 *
 * An earlier version compared the median lap instead. That read as a second
 * kind of "usual lap" beside the reference lap the rest of the page uses, and
 * needed four laps before it said anything; against the reference lap there is
 * one baseline, and two laps are enough to have a faster run to point at.
 */

/* In the order a corner is driven. A corner is credited to the first of these
   that differs, not to all of them: a lap that braked early and so carried
   less speed, reached full throttle late and left slowly made one mistake, at
   the brake, and the three after it are what that mistake looks like further
   on (gt7-driving-knowledge: the cause comes before its results). */
const THEME_FACTORS = [
  {
    key: "brake",
    field: "brakePointM",
    // sign makes "reference worse than the faster run" come out positive.
    sign: -1,
    title: "ブレーキング開始を奥にする",
    because: "ブレーキング開始が速かった周より早い",
    unit: "m",
    technique: "brakeEarly",
    goal: (corner) => `ブレーキング開始をあと ${(corner.best - corner.ref).toFixed(0)}m 奥で`
  },
  {
    key: "minSpeed",
    field: "minSpeedKmh",
    sign: -1,
    title: "コーナーで速度を落としすぎない",
    because: "最低速度が速かった周より低い",
    unit: "km/h",
    technique: "minSpeed",
    goal: (corner) => `最低速度を ${corner.best.toFixed(0)}km/h まで残す（いまは ${corner.ref.toFixed(0)}km/h）`
  },
  {
    key: "throttle",
    field: "fullThrottleM",
    sign: 1,
    title: "全開を早くする",
    because: "全開が速かった周より遅い",
    unit: "m",
    technique: "throttle",
    goal: (corner) => `全開をあと ${(corner.ref - corner.best).toFixed(0)}m 手前で`
  },
  {
    key: "exit",
    field: "exitSpeedKmh",
    sign: -1,
    title: "立ち上がりの速度を上げる",
    because: "出口の速度が速かった周より低い",
    unit: "km/h",
    technique: "throttle",
    goal: (corner) => `出口の速度を ${corner.best.toFixed(0)}km/h まで上げる（いまは ${corner.ref.toFixed(0)}km/h）`
  }
];

/* The theme for the reference lap, or null when nothing repeats. `totalLoss`
   is the same figure the cards' summary gives as the time on the table. */
function sessionTheme(data, refIndex) {
  // Same evidence as the cards: a lap in another car cannot show what this
  // one could have done.
  const evidence = sameCarLapIndexes(data, refIndex);
  const credit = Object.fromEntries(THEME_FACTORS.map((factor) => [factor.key, { seconds: 0, corners: [] }]));
  let totalLoss = 0;

  for (const segment of data.segments) {
    const entry = data.sectorsById[segment.id];
    if (entry.timeS[refIndex] === null || sectorFlag(data, segment.id, refIndex)) continue;
    const bestLap = fastestLapForSegment(data, segment.id, { lapIndexes: evidence });
    if (bestLap === null || bestLap === refIndex || sectorFlag(data, segment.id, bestLap)) continue;
    const loss = entry.timeS[refIndex] - entry.timeS[bestLap];
    if (!(loss > 0)) continue;
    totalLoss += loss;
    if (loss <= MIN_GAIN_S) continue;

    // Time lost on a straight was lost in the corner before it, so it is
    // judged on that corner's figures and credited to that corner.
    const straight = segment.id.startsWith("straight");
    const source = straight ? previousSegment(data, segment.id) : segment;
    const sourceEntry = data.sectorsById[source.id];
    for (const factor of THEME_FACTORS) {
      const ref = sourceEntry[factor.field][refIndex];
      const best = sourceEntry[factor.field][bestLap];
      if (ref === null || ref === undefined || best === null || best === undefined) continue;
      // Same floors as the cards, so the two never disagree on what counts as
      // a difference a driver can act on.
      const gap = factor.sign * (ref - best);
      if (gap < (factor.unit === "km/h" ? MIN_SPEED_DIFF_KMH : MIN_POINT_DIFF_M)) continue;
      credit[factor.key].seconds += loss;
      const known = credit[factor.key].corners.find((corner) => corner.segment.id === source.id);
      if (known) known.loss += loss;
      else credit[factor.key].corners.push({ segment: source, loss, ref, best, bestLap });
      break;
    }
  }

  const ranked = THEME_FACTORS.map((factor) => ({ factor, ...credit[factor.key] }))
    .filter((item) => item.seconds > 0)
    .sort((a, b) => b.seconds - a.seconds);
  if (!ranked.length) return { factor: null, totalLoss };
  const top = ranked[0];
  top.corners.sort((a, b) => b.loss - a.loss);
  return { ...top, totalLoss, others: ranked.slice(1) };
}

function themeValue(factor, value) {
  return factor.unit === "km/h" ? `${value.toFixed(0)} km/h` : `${value.toFixed(0)} m地点`;
}

function renderTheme(data, state, element, onSelect) {
  if (!element) return;
  const refIndex = state.get().refIndex;
  const theme = sessionTheme(data, refIndex);
  const refTitle = data.laps[refIndex].title;
  element.hidden = false;
  if (!theme.factor) {
    element.innerHTML =
      '<p class="theme__label">基準ラップのテーマ</p>' +
      (theme.totalLoss > MIN_GAIN_S
        ? `<p class="theme__why">基準ラップ <b>${refTitle}</b> の遅れに、共通する理由は見つかりませんでした。下のカードから試してください。</p>`
        : `<p class="theme__why">基準ラップ <b>${refTitle}</b> より速く走れたコーナーがありません。もっと走って比較対象を増やしてください。</p>`);
    return;
  }
  const { factor } = theme;
  const corners = theme.corners.slice(0, 3);
  const note = techniqueNote(factor.technique);

  element.innerHTML =
    '<p class="theme__label">基準ラップのテーマ</p>' +
    `<h3 class="theme__title">${factor.title}</h3>` +
    `<p class="theme__why">基準ラップ <b>${refTitle}</b> は、コーナーごとの自己ベストより合計 <b>${theme.totalLoss.toFixed(1)}秒</b> 遅れています。` +
    `そのうち <b>${theme.seconds.toFixed(1)}秒</b> は「${factor.because}」コーナーの分で、ほかの理由より大きい差です。</p>` +
    '<div class="theme__corners">' +
    corners
      .map(
        (corner) =>
          `<div class="theme__corner" data-segment="${corner.segment.id}">` +
          cornerMap(data, corner.segment.id, state.get().mapRotationDeg) +
          `<span class="theme__name">${corner.segment.name}</span>` +
          `<span>基準 ${themeValue(factor, corner.ref)} → 速かった周 <b>${themeValue(factor, corner.best)}</b></span>` +
          `<span class="theme__loss">−${corner.loss.toFixed(2)}秒</span>` +
          "</div>"
      )
      .join("") +
    "</div>" +
    // A target the driver can check on the next run, then how to practise it.
    `<p class="theme__todo"><b>やること</b> まずは ${corners[0].segment.name} だけで、${factor.goal(corners[0])}。</p>` +
    (note ? `<p class="theme__todo"><b>練習</b> ${note.drill}。</p>` : "") +
    (note && note.source ? `<p class="theme__source"><b>根拠</b> ${note.source}</p>` : "");

  element.querySelectorAll(".theme__corner").forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
  });
}
