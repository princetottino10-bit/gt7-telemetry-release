"use strict";

/* The reference lap against the theoretical best, corner by corner.
 *
 * The theoretical best is the driver's own fastest run through each corner,
 * strung together. Every corner where the reference lap is slower gets a card
 * with the two numbers a driver can check on track - minimum speed and exit
 * speed - and the reason read straight off the pedal traces: braking started
 * earlier, full throttle came later, the throttle was held part-open where the
 * faster run was flat out, or the car arrived too fast.
 *
 * A corner here runs from its braking point to the next corner's braking point.
 * The segment table cuts corners where the car starts turning, which leaves the
 * braking zone in the straight before; that split hid the braking point (every
 * lap "started braking" on the segment's first sample) and put the loss on the
 * straight after a slow exit in a different row from the exit that caused it.
 *
 * Measured on Interlagos, GR Supra RC, 2026-10-21/22 (14 laps): the 1:37.243
 * reference lost 0.86 s to the theoretical best through the Senna S, with the
 * same minimum speed (88 vs 85 km/h) but 60-65% throttle between T1 and T2
 * where the faster lap was flat out. That is the case the "part throttle"
 * reason exists for: neither the minimum speed nor the full-throttle point,
 * which both came out the same, could show it.
 */

// Braking zones are bounded this far before the earliest lap's braking point,
// so a lap that braked a little earlier still has its whole zone inside.
const THEORY_BRAKE_LEAD_M = 20;
// GT7 reports zero throttle for a moment at every upshift. A dip shorter than
// this between two stretches of full throttle is a gear change, not a lift.
const THEORY_SHIFT_GAP_M = 15;
const THEORY_FULL_PCT = 95;
// The reference counts as holding back where it was this many points under
// the faster run (the cards' MIN_THROTTLE_DIFF_PCT).
const THEORY_PARTIAL_DIFF_PCT = 10;
// Shorter stretches of part throttle are a hand settling, not a habit.
const THEORY_PARTIAL_MIN_M = 20;
// A phase (into the corner / out of it) has to lose this much to be explained.
const THEORY_PHASE_MIN_S = 0.05;
// Cards that lose at least this much are drawn larger, at most two of them.
const THEORY_HIGHLIGHT_S = 0.15;
const THEORY_HIGHLIGHT_COUNT = 2;
// The minimum-speed point counts as moved deeper past this distance.
const THEORY_APEX_SHIFT_M = 8;

function theoryCorners(data) {
  return data.segments.filter((segment) => segment.id.startsWith("corner"));
}

/* A report segment can hold two corners: Interlagos' "ターン4" is T8 and T9.
   Its minimum speed is then the first corner's while the time may go in the
   second, so such a segment is split where the track changes direction
   between the two.

   Read from the track's shape, not the laps' speed: a split decided from the
   speed traces came and went from one session to the next. Curvature on the
   Interlagos sessions (radians per km): the S-bends T1/T2 and T8/T9 peak at
   14-35 on each side of the turn, while the fast kinks T3 and T11 that should
   stay part of their neighbour peak at 8-10. */
const THEORY_SPLIT_CURVE = 12;
const THEORY_CURVE_WINDOW_M = 10;

function trackCurvature(data) {
  const lapIndex = Math.max(0, data.laps.findIndex((lap) => lap.isReference));
  const xs = data.channels.x ? data.channels.x[lapIndex] : null;
  const zs = xs ? data.channels.z[lapIndex] : null;
  if (!xs || !zs) return null;
  const n = xs.length;
  const step = data.lapDistanceM / (n - 1);
  const w = Math.max(1, Math.round(THEORY_CURVE_WINDOW_M / step));
  const heading = Array.from(xs, (_, i) => {
    const a = Math.max(0, i - w);
    const c = Math.min(n - 1, i + w);
    return Math.atan2(zs[c] - zs[a], xs[c] - xs[a]);
  });
  return heading.map((_, i) => {
    const a = Math.max(0, i - w);
    const c = Math.min(n - 1, i + w);
    let turn = heading[c] - heading[a];
    while (turn > Math.PI) turn -= 2 * Math.PI;
    while (turn < -Math.PI) turn += 2 * Math.PI;
    return (turn / ((c - a) * step)) * 1000;
  });
}

/* The corners the theoretical best is timed over: the report's segments, with
   an S-bend segment split in two. A split part keeps the report segment's id
   as `parentId`, for zooming and the sector flags. */
function theoryParts(data, pool) {
  const curve = trackCurvature(data);
  const out = [];
  for (const corner of theoryCorners(data)) {
    let split = null;
    if (curve) {
      // The tightest point, then the tightest point the other way after it.
      let first = corner.start;
      for (let i = corner.start; i <= corner.end; i += 1) if (Math.abs(curve[i]) > Math.abs(curve[first])) first = i;
      const sign = Math.sign(curve[first]);
      let second = null;
      for (let i = first; i <= corner.end; i += 1) {
        if (Math.sign(curve[i]) === -sign && (second === null || Math.abs(curve[i]) > Math.abs(curve[second]))) second = i;
      }
      // The same the other way: the tighter half may be the second one.
      let before = null;
      for (let i = corner.start; i <= first; i += 1) {
        if (Math.sign(curve[i]) === -sign && (before === null || Math.abs(curve[i]) > Math.abs(curve[before]))) before = i;
      }
      const pair =
        Math.abs(curve[first]) >= THEORY_SPLIT_CURVE && second !== null && Math.abs(curve[second]) >= THEORY_SPLIT_CURVE
          ? [first, second]
          : Math.abs(curve[first]) >= THEORY_SPLIT_CURVE && before !== null && Math.abs(curve[before]) >= THEORY_SPLIT_CURVE
          ? [before, first]
          : null;
      if (pair) {
        // Where the direction changes between the two.
        for (let i = pair[0]; i <= pair[1]; i += 1) {
          if (Math.sign(curve[i]) !== Math.sign(curve[pair[0]])) {
            split = i;
            break;
          }
        }
      }
    }
    // A second half the laps only speed up through (the Senna S' T2, taken
    // on the throttle) has no minimum speed to aim at, so it stays whole.
    if (split !== null && pool.length) {
      const second = { ...corner, start: split };
      const climbing = pool.filter((lap) => apexIndex(data, lap, second) - split <= 2).length;
      if (climbing * 2 >= pool.length) split = null;
    }
    if (split === null || split <= corner.start || split >= corner.end) {
      out.push({ ...corner, parentId: corner.id });
      continue;
    }
    const head = { ...corner, id: `${corner.id}-1`, end: split, parentId: corner.id };
    const tail = { ...corner, id: `${corner.id}-2`, start: split, parentId: corner.id };
    head.name = cornerNumberLabel(data, head.start, head.end) || `${corner.name}-1`;
    tail.name = cornerNumberLabel(data, tail.start, tail.end) || `${corner.name}-2`;
    out.push(head, tail);
  }
  return out;
}

/* The circuit's own corner numbers for grid points [start, end], where the
   report knows them (webreport/corners.py, which names whole segments the same
   way): the two halves of Interlagos' T8-9 are T8 and T9, not "-1" and "-2". */
function cornerNumberLabel(data, start, end) {
  const table = data.payload && data.payload.meta && data.payload.meta.cornerNumbers;
  if (!table) return null;
  const from = start / (data.points - 1);
  const to = end / (data.points - 1);
  const inside = table.corners.filter((corner) => corner.at >= from && corner.at <= to);
  const major = inside.filter((corner) => !corner.minor);
  const numbers = (major.length ? major : inside).map((corner) => corner.n);
  if (!numbers.length) return null;
  const key = numbers.length === 1 ? `${numbers[0]}` : `${numbers[0]}-${numbers[numbers.length - 1]}`;
  const name = (table.names || {})[key];
  return `T${key}${name ? ` ${name}` : ""}`;
}

/* First index in [from, to] where `test` holds for SUSTAIN_SAMPLES samples. */
/* Where a corner's exit speed is read: where the track itself stops turning,
   so the point is the same for every lap and every session on the track (the
   driver remembers one number for one place), instead of moving with whichever
   laps are compared. Walking out from the last tight point of the corner, the
   exit is the first spot the line runs straight for a while, or where it starts
   turning the other way. On Interlagos this lands within 40m of the exits the
   driver picked by eye (Senna S 500m, T4-5 1675m, T6-7 2200m, T8-9 2525m, T10
   2800m, T12 3400m). The long flat-out bends after some corners (Curva do Sol,
   T11) turn at 5-10 rad/km and would otherwise push the exit 200-300m on. */
const THEORY_STRAIGHT_CURVE = 4;
const THEORY_STRAIGHT_M = 20;

function theoryExitIndex(data, curve, corners, k) {
  const corner = corners[k];
  const next = corners[k + 1];
  // The first half of a split S-bend ends where the direction changes.
  if (next && next.parentId === corner.parentId) return corner.end;
  if (!curve) return null;
  const limit = next ? next.start : data.points - 1;
  const step = data.lapDistanceM / (data.points - 1);
  const run = Math.max(1, Math.round(THEORY_STRAIGHT_M / step));
  let from = corner.start;
  for (let i = corner.start; i <= corner.end; i += 1) if (Math.abs(curve[i]) > Math.abs(curve[from])) from = i;
  // A segment that never turns has no shape to read (positions missing or flat).
  if (Math.abs(curve[from]) < THEORY_STRAIGHT_CURVE) return null;
  for (let i = from; i <= corner.end; i += 1) if (Math.abs(curve[i]) >= THEORY_SPLIT_CURVE) from = i;
  const sign = Math.sign(curve[from]);
  let flip = null;
  for (let i = from; i <= limit; i += 1) {
    if (Math.sign(curve[i]) === -sign) {
      if (flip === null) flip = i;
      if (Math.abs(curve[i]) >= THEORY_STRAIGHT_CURVE) return flip;
    } else {
      flip = null;
    }
    let straight = i + run <= limit + 1;
    for (let j = i; straight && j < i + run; j += 1) if (Math.abs(curve[j]) >= THEORY_STRAIGHT_CURVE) straight = false;
    if (straight) return i;
  }
  return null;
}

function firstSustainedIndex(values, from, to, test) {
  for (let i = from; i <= to - SUSTAIN_SAMPLES + 1; i += 1) {
    let held = true;
    for (let k = 0; k < SUSTAIN_SAMPLES; k += 1) {
      if (!test(values[i + k])) {
        held = false;
        break;
      }
    }
    if (held) return i;
  }
  return null;
}

/* Throttle with the gear-change dips filled in, over [from, to]. */
function throttleWithoutShifts(data, lapIndex, from, to) {
  const raw = data.channels.throttle_pct[lapIndex];
  const step = data.lapDistanceM / (data.points - 1);
  const maxGap = Math.max(1, Math.round(THEORY_SHIFT_GAP_M / step));
  const out = Float32Array.from(raw.subarray(from, to + 1));
  let lastFull = null;
  for (let i = 0; i < out.length; i += 1) {
    if (out[i] < THEORY_FULL_PCT) continue;
    if (lastFull !== null && i - lastFull > 1 && i - lastFull - 1 <= maxGap) {
      for (let k = lastFull + 1; k < i; k += 1) out[k] = 100;
    }
    lastFull = i;
  }
  return out;
}

/* Where each lap starts braking for a corner, searched from the end of the
   corner before so a late lift on the previous exit is not read as braking. */
function brakeStartIndex(data, lapIndex, searchFrom, apex) {
  const brake = data.channels.brake_pct[lapIndex];
  return firstSustainedIndex(brake, searchFrom, apex, (value) => value >= BRAKE_ON_PCT);
}

function apexIndex(data, lapIndex, segment) {
  const speed = data.channels.speed_kmh[lapIndex];
  let apex = segment.start;
  for (let i = segment.start; i <= segment.end; i += 1) {
    if (speed[i] < speed[apex]) apex = i;
  }
  return apex;
}

/* Grid index where each corner's stretch begins: just before the earliest
   braking point any lap in `pool` used, or the corner's own start where
   nobody braked. */
function theoryBoundaries(data, corners, pool) {
  return corners.map((corner, k) => {
    const searchFrom = k === 0 ? 0 : corners[k - 1].end;
    let earliest = null;
    for (const lap of pool) {
      const start = brakeStartIndex(data, lap, searchFrom, apexIndex(data, lap, corner));
      if (start !== null && (earliest === null || start < earliest)) earliest = start;
    }
    if (earliest === null) return corner.start;
    const step = data.lapDistanceM / (data.points - 1);
    return Math.max(searchFrom, Math.min(corner.start, earliest - Math.round(THEORY_BRAKE_LEAD_M / step)));
  });
}

/* One lap's figures through one corner stretch [from, to]. */
function theoryFigures(data, lapIndex, corner, from, to) {
  const speed = data.channels.speed_kmh[lapIndex];
  const apex = apexIndex(data, lapIndex, corner);
  const brakeAt = brakeStartIndex(data, lapIndex, from, apex);
  // Where the last long run of full throttle in the stretch begins: a lap that
  // touches 100% between two parts of an S and lifts again has not finished
  // the corner yet. The run need not reach the end of the stretch, because the
  // stretch ends inside the next corner's braking (seen on the 10/21 Beetle
  // laps, where every lap was on the brakes at the end and the exit speed fell
  // back to a point where both laps were braking).
  const throttle = throttleWithoutShifts(data, lapIndex, apex, to);
  const step = data.lapDistanceM / (data.points - 1);
  const minRun = Math.max(1, Math.round(THEORY_PARTIAL_MIN_M / step));
  let fullAt = null;
  let i = throttle.length - 1;
  while (i >= 0 && fullAt === null) {
    while (i >= 0 && throttle[i] < THEORY_FULL_PCT) i -= 1;
    const runEnd = i;
    while (i >= 0 && throttle[i] >= THEORY_FULL_PCT) i -= 1;
    if (runEnd >= 0 && runEnd - i >= minRun) fullAt = apex + i + 1;
  }
  // The first time the lap went flat out, and where it then backed off again
  // before the point it was finally held from. A late "held" point is two
  // different habits: never getting there, or getting there and lifting.
  const firstFull = firstSustainedIndex(throttle, 0, throttle.length - 1, (value) => value >= THEORY_FULL_PCT);
  let liftAt = null;
  if (firstFull !== null && fullAt !== null && apex + firstFull < fullAt) {
    const lift = firstSustainedIndex(throttle, firstFull, fullAt - apex, (value) => value < THEORY_FULL_PCT);
    if (lift !== null) liftAt = apex + lift;
  }
  let lock = null;
  if (data.hasExtended && data.extended.slipFront && brakeAt !== null) {
    const slip = data.extended.slipFront[lapIndex];
    lock = Infinity;
    for (let i = brakeAt; i <= apex; i += 1) lock = Math.min(lock, slip[i]);
  }
  return {
    apex,
    apexM: data.distance[apex],
    minSpeedKmh: speed[apex],
    brakeAt,
    brakeM: brakeAt === null ? null : data.distance[brakeAt],
    fullAt,
    fullM: fullAt === null ? null : data.distance[fullAt],
    firstFullM: firstFull === null ? null : data.distance[apex + firstFull],
    liftM: liftAt === null ? null : data.distance[liftAt],
    lock
  };
}

/* Distance over which the reference held less throttle than the faster lap,
   between the faster lap's apex and the end of the stretch. Both the straight
   part-throttle case (60% where the other was flat) and a gentler ramp out of
   the apex (40-70% where the other was already at 85%) count. */
function partialThrottle(data, refIndex, bestIndex, from, to) {
  if (from >= to) return null;
  const ref = throttleWithoutShifts(data, refIndex, from, to);
  const best = throttleWithoutShifts(data, bestIndex, from, to);
  const brake = data.channels.brake_pct[refIndex];
  const step = data.lapDistanceM / (data.points - 1);
  let count = 0;
  let sum = 0;
  let sumBest = 0;
  for (let i = 0; i < ref.length; i += 1) {
    if (best[i] - ref[i] >= THEORY_PARTIAL_DIFF_PCT && brake[from + i] < BRAKE_OFF_PCT) {
      count += 1;
      sum += ref[i];
      sumBest += best[i];
    }
  }
  return count ? { metres: count * step, meanPct: sum / count, bestPct: sumBest / count } : null;
}

function lapTime(data, lapIndex, from, to) {
  const time = data.channels.time_s[lapIndex];
  return time[to] - time[from];
}

/* Reasons, each measured directly against the faster run, in driving order.
   A reason for the way out is only given when the way in did not already
   explain the corner: a lap that arrived too fast also leaves slowly, and
   that slow exit is the same mistake. */
function theoryReasons(ref, best, entryLoss, exitLoss, partial) {
  const reasons = [];
  const brakeGap = ref.brakeM !== null && best.brakeM !== null ? ref.brakeM - best.brakeM : null;
  const exitDown = best.exitSpeedKmh - ref.exitSpeedKmh;
  const apexDeeper = ref.apexM - best.apexM >= THEORY_APEX_SHIFT_M;
  const locked = ref.lock !== null && ref.lock < LOCK_SLIP && (best.lock === null || best.lock >= LOCK_SLIP);

  if (brakeGap !== null && brakeGap >= MIN_POINT_DIFF_M && exitDown >= MIN_SPEED_DIFF_KMH && (apexDeeper || locked)) {
    const proof = [apexDeeper ? `最低速度の地点が ${(ref.apexM - best.apexM).toFixed(0)}m 奥` : "", locked ? "前輪がロック気味" : ""]
      .filter(Boolean)
      .join("、");
    reasons.push({
      key: "overspeed",
      tag: "突っ込みすぎ",
      text: `ブレーキング開始が ${brakeGap.toFixed(0)}m 遅く（${proof}）、脱出速度が ${exitDown.toFixed(0)}km/h 低い。踏み始めを手前にしてクリップに着ける`
    });
    return reasons;
  }

  if (entryLoss >= THEORY_PHASE_MIN_S) {
    if (brakeGap !== null && brakeGap <= -MIN_POINT_DIFF_M) {
      reasons.push({
        key: "brakeEarly",
        tag: "ブレーキングが早い",
        text: `踏み始めが ${(-brakeGap).toFixed(0)}m 手前（${ref.brakeM.toFixed(0)}m地点、速い周は ${best.brakeM.toFixed(0)}m地点）`
      });
    } else if (best.minSpeedKmh - ref.minSpeedKmh >= MIN_SPEED_DIFF_KMH) {
      reasons.push({
        key: "minSpeed",
        tag: "落としすぎ",
        text: `最低速度が ${(best.minSpeedKmh - ref.minSpeedKmh).toFixed(0)}km/h 低い（ブレーキング開始の差は ${brakeGap === null ? "—" : `${Math.abs(brakeGap).toFixed(0)}m`}）`
      });
    }
  }

  if (exitLoss >= THEORY_PHASE_MIN_S) {
    const fullGap = ref.fullM !== null && best.fullM !== null ? ref.fullM - best.fullM : null;
    // Lifting after going flat also shows up as part throttle over the same
    // metres; it is reported once, as the lift.
    const lifted =
      fullGap !== null &&
      fullGap >= MIN_POINT_DIFF_M &&
      ref.liftM !== null &&
      ref.firstFullM !== null &&
      ref.firstFullM - best.fullM < MIN_POINT_DIFF_M;
    if (lifted) {
      reasons.push({
        key: "lift",
        tag: "出口で戻している",
        text: `一度全開にしたあと ${ref.liftM.toFixed(0)}m地点で戻し、${ref.fullM.toFixed(0)}m地点まで全開に戻っていない（速い周は ${best.fullM.toFixed(0)}m地点から全開のまま）`
      });
    } else {
      if (partial && partial.metres >= THEORY_PARTIAL_MIN_M) {
        reasons.push({
          key: "partial",
          tag: "アクセル開度が低い",
          text: `${partial.metres.toFixed(0)}m のあいだ速い周より踏めていない（平均 ${partial.meanPct.toFixed(0)}%、速い周は ${partial.bestPct.toFixed(0)}%）`
        });
      }
      if (fullGap !== null && fullGap >= MIN_POINT_DIFF_M) {
        reasons.push({
          key: "throttle",
          tag: "全開が遅い",
          text: `全開が ${fullGap.toFixed(0)}m 遅い（${ref.fullM.toFixed(0)}m地点、速い周は ${best.fullM.toFixed(0)}m地点）`
        });
      }
    }
  }
  return reasons;
}

/* The theoretical best and one entry per corner for the reference lap. */
/* Laps the driver has taken out of the theoretical best by hand: the packets
   do not say which tyres a lap was on, so a lap on another compound inside the
   same week can only be told apart by the one who drove it. */
const theoryExcluded = new Set();

function theoryComparison(data, refIndex, excluded = theoryExcluded) {
  const pool = sameCarLapIndexes(data, refIndex).filter((lap) => lap === refIndex || !excluded.has(lap));
  if (!pool.length || !data.channels.time_s) return null;
  const corners = theoryParts(data, pool);
  if (!corners.length) return null;
  const bounds = theoryBoundaries(data, corners, pool);
  const last = data.points - 1;

  // The part before the first corner's braking zone is timed too, so the
  // theoretical lap covers the whole lap.
  const parts = [{ from: 0, to: bounds[0], corner: null, flagSegment: null }];
  const curve = trackCurvature(data);
  corners.forEach((corner, k) => {
    parts.push({
      from: bounds[k],
      to: k + 1 < corners.length ? bounds[k + 1] : last,
      corner,
      flagSegment: corner.parentId,
      exitAt: theoryExitIndex(data, curve, corners, k)
    });
  });

  let theoretical = 0;
  let refTotal = 0;
  const entries = [];
  for (const part of parts) {
    if (part.to <= part.from) continue;
    const usable = pool.filter((lap) => !part.flagSegment || !sectorFlag(data, part.flagSegment, lap));
    const candidates = usable.length ? usable : pool;
    let bestLap = candidates[0];
    for (const lap of candidates) {
      if (lapTime(data, lap, part.from, part.to) < lapTime(data, bestLap, part.from, part.to)) bestLap = lap;
    }
    const bestTime = lapTime(data, bestLap, part.from, part.to);
    const refTime = lapTime(data, refIndex, part.from, part.to);
    theoretical += bestTime;
    refTotal += refTime;
    if (!part.corner) continue;

    const loss = refTime - bestTime;
    const ref = theoryFigures(data, refIndex, part.corner, part.from, part.to);
    const best = theoryFigures(data, bestLap, part.corner, part.from, part.to);
    // Exit speed is read at one place for both laps. Without the track's shape
    // (no positions recorded), where the later of the two went flat out for
    // good, so both have finished the corner there.
    const fullPoints = [ref.fullAt, best.fullAt].filter((value) => value !== null);
    const exitAt =
      part.exitAt ?? (fullPoints.length ? Math.max(...fullPoints) : part.corner.end);
    ref.exitSpeedKmh = data.channels.speed_kmh[refIndex][exitAt];
    best.exitSpeedKmh = data.channels.speed_kmh[bestLap][exitAt];
    // Split at the faster run's minimum-speed point: before it is braking and
    // turning in, after it is the way out and the straight that follows.
    const timeRef = data.channels.time_s[refIndex];
    const timeBest = data.channels.time_s[bestLap];
    const entryLoss = timeRef[best.apex] - timeRef[part.from] - (timeBest[best.apex] - timeBest[part.from]);
    const exitLoss = loss - entryLoss;
    const partial = bestLap === refIndex ? null : partialThrottle(data, refIndex, bestLap, best.apex, part.to);
    entries.push({
      segment: part.corner,
      exitM: data.distance[exitAt],
      exitAt,
      from: part.from,
      to: part.to,
      bestLap,
      loss,
      entryLoss,
      exitLoss,
      ref,
      best,
      reasons: bestLap === refIndex ? [] : theoryReasons(ref, best, entryLoss, exitLoss, partial)
    });
  }

  // The reference's own time over the same parts, so the gap and the lap time
  // agree even where the grid's last sample is not quite the timing line.
  const refLapTime = data.laps[refIndex].lapTimeS;
  const theoreticalS = refLapTime - (refTotal - theoretical);
  const ranked = entries.filter((entry) => entry.loss >= THEORY_HIGHLIGHT_S).sort((a, b) => b.loss - a.loss);
  for (const entry of ranked.slice(0, THEORY_HIGHLIGHT_COUNT)) entry.highlight = true;
  return { theoreticalS, refLapTime, entries };
}

function theorySpeed(refValue, bestValue) {
  const gap = refValue - bestValue;
  const cls = gap <= -MIN_SPEED_DIFF_KMH ? "is-loss" : gap >= MIN_SPEED_DIFF_KMH ? "is-gain" : "";
  const shown = Math.abs(gap) < MIN_SPEED_DIFF_KMH ? "±0" : `${gap > 0 ? "+" : "−"}${Math.abs(gap).toFixed(0)}`;
  // Shown at full weight even where this lap was already faster: the driver
  // brakes to the bottom speed, so it is the reference for every corner.
  return (
    // The driver steers by the number to hit, so that is the large one; what
    // the reference lap did sits under it.
    `<span class="theory__now">${bestValue.toFixed(0)}</span>` +
    `<span class="theory__best">今回 ${refValue.toFixed(0)} <b class="${cls}">(${shown})</b></span>`
  );
}

/* The one reason a row is labelled with: from the side, entry or exit, where
   most of the time went, so the label agrees with the numbers beside it. */
const THEORY_ENTRY_KEYS = ["overspeed", "brakeEarly", "minSpeed"];
function theoryMainReason(entry) {
  if (!entry.reasons.length) return null;
  const entrySide = entry.entryLoss >= entry.exitLoss;
  return (
    entry.reasons.find((reason) => THEORY_ENTRY_KEYS.includes(reason.key) === entrySide) || entry.reasons[0]
  );
}

/* The whole track, large, with each losing corner drawn in and labelled with
   its loss, so the cards beside it read as "where" first and "why" second. */
function theoryTrackMap(data, entries, rotationDeg = 0) {
  const lapIndex = Math.max(0, data.laps.findIndex((lap) => lap.isReference));
  const xs = data.channels && data.channels.x ? data.channels.x[lapIndex] : null;
  const zs = xs ? data.channels.z[lapIndex] : null;
  if (!xs || !zs) return "";
  // Turned so the circuit lies wide, as the frame beside the cards is wide.
  // Of the two turns that do that, the one nearer the big map's is taken.
  const sampleStep = Math.max(1, Math.floor(xs.length / 200));
  const spans = (deg) => {
    const r = (deg * Math.PI) / 180;
    let uLo = Infinity, uHi = -Infinity, vLo = Infinity, vHi = -Infinity;
    for (let i = 0; i < xs.length; i += sampleStep) {
      const u = xs[i] * Math.cos(r) - zs[i] * Math.sin(r);
      const v = xs[i] * Math.sin(r) + zs[i] * Math.cos(r);
      uLo = Math.min(uLo, u); uHi = Math.max(uHi, u);
      vLo = Math.min(vLo, v); vHi = Math.max(vHi, v);
    }
    return (uHi - uLo) / Math.max(vHi - vLo, 1);
  };
  let turn = rotationDeg;
  let best = -Infinity;
  for (let deg = 0; deg < 180; deg += 5) {
    const ratio = spans(deg);
    if (ratio > best + 1e-6) {
      best = ratio;
      turn = deg;
    }
  }
  const away180 = (deg) => Math.abs(((deg - rotationDeg + 540) % 360) - 180);
  if (away180(turn + 180) < away180(turn)) turn += 180;
  const radians = (turn * Math.PI) / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  const rotated = Array.from(xs, (x, i) => [x * cos - zs[i] * sin, x * sin + zs[i] * cos]);
  const us = rotated.map((point) => point[0]);
  const vs = rotated.map((point) => point[1]);
  const uMin = Math.min(...us);
  const vMin = Math.min(...vs);
  const uSpan = Math.max(Math.max(...us) - uMin, 1);
  const vSpan = Math.max(Math.max(...vs) - vMin, 1);
  // Room around the track for the labels, which sit outside it.
  const pad = 58;
  const width = 640;
  const height = 400;
  const scale = Math.min((width - pad * 2) / uSpan, (height - pad * 2) / vSpan);
  const offsetX = (width - uSpan * scale) / 2;
  const offsetY = (height - vSpan * scale) / 2;
  // World +Z runs down the screen, as on the big map (see computeView).
  const point = (i) => [(rotated[i][0] - uMin) * scale + offsetX, (rotated[i][1] - vMin) * scale + offsetY];
  const at = (i) => point(i).map((value) => value.toFixed(1)).join(",");
  const path = (from, to, step) => {
    const parts = [];
    for (let i = from; i < to; i += step) parts.push(at(i));
    parts.push(at(to));
    return "M" + parts.join("L");
  };
  const step = Math.max(1, Math.floor(xs.length / 400));
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < xs.length; i += step) {
    const [px, py] = point(i);
    cx += px;
    cy += py;
  }
  const samples = Math.ceil(xs.length / step);
  cx /= samples;
  cy /= samples;

  // The start line across the track, and an arrow a little way on for the
  // direction of travel.
  const [sx, sy] = point(0);
  const ahead = Math.min(xs.length - 1, Math.round(xs.length * 0.025));
  const [ax, ay] = point(ahead);
  const [bx, by] = point(Math.max(0, ahead - 3));
  const dirLen = Math.hypot(ax - bx, ay - by) || 1;
  const dx = (ax - bx) / dirLen;
  const dy = (ay - by) / dirLen;
  const [s1x, s1y] = point(Math.min(xs.length - 1, 3));
  const tLen = Math.hypot(s1x - sx, s1y - sy) || 1;
  const nx = -(s1y - sy) / tLen;
  const ny = (s1x - sx) / tLen;
  const arrow =
    `M${(ax + dx * 9).toFixed(1)},${(ay + dy * 9).toFixed(1)}` +
    `L${(ax - dx * 6 + nx * 7).toFixed(1)},${(ay - dy * 6 + ny * 7).toFixed(1)}` +
    `L${(ax - dx * 6 - nx * 7).toFixed(1)},${(ay - dy * 6 - ny * 7).toFixed(1)}Z`;

  const theoryTick = (i, colour, rank) => {
    const [px, py] = point(i);
    const [ax2, ay2] = point(Math.max(0, i - 2));
    const [bx2, by2] = point(Math.min(xs.length - 1, i + 2));
    const len = Math.hypot(bx2 - ax2, by2 - ay2) || 1;
    const ux = -(by2 - ay2) / len;
    const uy = (bx2 - ax2) / len;
    return (
      [["#0a0d12", 8], [colour, 4]]
        .map(
          ([stroke, width]) =>
            `<line x1="${(px + ux * 12).toFixed(1)}" y1="${(py + uy * 12).toFixed(1)}" x2="${(px - ux * 12).toFixed(1)}" y2="${(py - uy * 12).toFixed(1)}" ` +
            `stroke="${stroke}" stroke-width="${width}" stroke-linecap="round"/>`
        )
        .join("") +
      // The corner's number beside its tick: two red corners side by side
      // otherwise leave it unclear whose exit a tick is.
      `<text x="${(px + ux * 24).toFixed(1)}" y="${(py + uy * 24 + 5).toFixed(1)}" text-anchor="middle" class="theory-map__tick" fill="${colour}">${rank}</text>`
    );
  };
  const labels = [];
  // Each label goes where it is clearest of the track and of the labels
  // already placed, tried around its ring at a few distances, biggest loss
  // first. Pushing every label straight out from the centre put two corners'
  // labels on top of each other where corners sit close together.
  const trackPoints = [];
  for (let i = 0; i < xs.length; i += step) trackPoints.push(point(i));
  const placed = new Map();
  for (const entry of [...entries].sort((a, b) => a.rank - b.rank)) {
    const [mx, my] = point(entry.best.apex);
    const outward = Math.atan2(my - cy, mx - cx);
    let best = null;
    for (const reach of [55, 75, 100]) {
      for (let k = 0; k < 12; k += 1) {
        const angle = outward + (k * Math.PI) / 6;
        const lx = mx + Math.cos(angle) * reach;
        const ly = my + Math.sin(angle) * reach;
        if (lx < 40 || lx > width - 40 || ly < 30 || ly > height - 34) continue;
        let room = Infinity;
        for (const [px, py] of trackPoints) room = Math.min(room, Math.hypot((px - lx) * 0.8, py - (ly + 3)) - 24);
        for (const [qx, qy] of labels) room = Math.min(room, Math.hypot((qx - lx) * 0.7, qy - ly) - 40);
        // Nearer and more outward wins when the room is about the same.
        const score = Math.min(room, 30) - reach * 0.05 - Math.min(k, 12 - k) * 1.5;
        if (!best || score > best.score) best = { lx, ly, score };
      }
    }
    if (!best) best = { lx: mx, ly: my - 40 };
    labels.push([best.lx, best.ly]);
    placed.set(entry.segment.id, best);
  }
  const corners = entries
    .map((entry) => {
      const { segment } = entry;
      const colour = entry.highlight ? COLORS.loss : COLORS.cmp;
      // The label hangs off the minimum-speed ring, so the number, the ring
      // and the tick of one corner read as one group.
      const [mx, my] = point(entry.best.apex);
      const { lx, ly } = placed.get(segment.id);
      // The leader stops short of the label so it does not run through the text.
      const reach = Math.hypot(lx - mx, ly - my);
      const short = reach > 1 ? Math.max(0, reach - 28) / reach : 0;
      const tipX = mx + (lx - mx) * short;
      const tipY = my + (ly - my) * short;
      return (
        `<g class="theory-map__corner${entry.highlight ? " is-key" : ""}" data-segment="${segment.id}" data-zoom="${segment.parentId}">` +
        `<path d="${path(segment.start, segment.end, 1)}" fill="none" stroke="${colour}" stroke-width="${entry.highlight ? 9 : 6}" stroke-linecap="round" stroke-linejoin="round"/>` +
        // Where the two speeds are read: the target lap's minimum and the
        // fixed exit point, as ring and tick.
        theoryTick(entry.exitAt, colour, entry.rank) +
        `<circle cx="${point(entry.best.apex)[0].toFixed(1)}" cy="${point(entry.best.apex)[1].toFixed(1)}" r="7" fill="#0a0d12" stroke="${colour}" stroke-width="3.5"/>` +
        `<line x1="${mx.toFixed(1)}" y1="${my.toFixed(1)}" x2="${tipX.toFixed(1)}" y2="${tipY.toFixed(1)}" stroke="${colour}" stroke-width="1" opacity="0.6"/>` +
        `<circle cx="${lx.toFixed(1)}" cy="${(ly - 12).toFixed(1)}" r="13" fill="${colour}"/>` +
        `<text x="${lx.toFixed(1)}" y="${(ly - 7).toFixed(1)}" text-anchor="middle" class="theory-map__rank">${entry.rank}</text>` +
        `<text x="${lx.toFixed(1)}" y="${(ly + 18).toFixed(1)}" text-anchor="middle" class="theory-map__loss" fill="${colour}">+${entry.loss.toFixed(2)}</text>` +
        "</g>"
      );
    })
    .join("");

  // "スタート" goes on whichever side of the line is clearer of the corner labels.
  const clearance = (x, y) =>
    Math.min(Infinity, ...labels.flatMap(([lx, ly]) => [Math.hypot(lx - x, ly - 12 - y), Math.hypot(lx - x, ly + 14 - y)]));
  const sides = [];
  for (const reach of [30, 50, 70]) {
    sides.push([sx + nx * reach, sy + ny * reach], [sx - nx * reach, sy - ny * reach]);
  }
  // A nearer spot wins unless a farther one is clearly clearer.
  const clear = (x, y) => Math.min(60, clearance(x, y));
  const [startX, startY] = sides.reduce((best, side) => (clear(...side) > clear(...best) ? side : best));
  return (
    `<svg class="theory-map" viewBox="0 0 ${width} ${height}" role="img" aria-label="負けているコーナーの場所">` +
    `<path d="${path(0, xs.length - 1, step)}" fill="none" stroke="${COLORS.neutral}" stroke-width="4" stroke-linejoin="round"/>` +
    `<line x1="${(sx + nx * 12).toFixed(1)}" y1="${(sy + ny * 12).toFixed(1)}" x2="${(sx - nx * 12).toFixed(1)}" y2="${(sy - ny * 12).toFixed(1)}" stroke="${COLORS.text}" stroke-width="3"/>` +
    `<path d="${arrow}" fill="${COLORS.text}"/>` +
    `<text x="${startX.toFixed(1)}" y="${(startY + 4).toFixed(1)}" text-anchor="middle" class="theory-map__start">スタート</text>` +
    corners +
    `<g class="theory-map__legend"><circle cx="16" cy="${height - 16}" r="6" fill="#0a0d12" stroke="${COLORS.text}" stroke-width="3"/>` +
    `<text x="27" y="${height - 11}">最低速度の地点</text>` +
    `<line x1="146" y1="${height - 25}" x2="146" y2="${height - 7}" stroke="${COLORS.text}" stroke-width="4" stroke-linecap="round"/>` +
    `<text x="157" y="${height - 11}">脱出速度を測る地点</text></g>` +
    "</svg>"
  );
}

// What the panel last showed, for the image export to draw the same page.
let theoryLast = null;

/* The laps the theoretical best is built from, each with a box to leave it out.
   The reference lap is what everything is measured against, so it stays in. */
function theoryLapPicker(data, refIndex) {
  const laps = sameCarLapIndexes(data, refIndex);
  const used = laps.filter((lap) => lap === refIndex || !theoryExcluded.has(lap)).length;
  const rows = laps
    .map((lap) => {
      const isRef = lap === refIndex;
      const on = isRef || !theoryExcluded.has(lap);
      return (
        `<label class="theory-laps__lap${on ? "" : " is-off"}">` +
        `<input type="checkbox" id="theory-lap-${lap}" value="${lap}"${on ? " checked" : ""}${isRef ? " disabled" : ""}>` +
        `<span>${data.laps[lap].title}${isRef ? "（基準ラップ）" : ""}</span></label>`
      );
    })
    .join("");
  return (
    '<details class="theory-laps"><summary>' +
    `比べる周 ${used}/${laps.length}周（違うタイヤで走った周は外してください）</summary>` +
    `<div class="theory-laps__list">${rows}</div></details>`
  );
}
/* A corner losing less than this gets no row of its own, only a name on the
   "no difference" line: a few hundredths is lap-to-lap noise to the driver,
   and every extra row pushes the ones worth working on further apart. The
   theoretical time still counts them. */
const THEORY_ROW_MIN_S = 0.1;

function renderTheory(data, state, elements, onSelect) {
  if (!elements.list) return;
  const s = state.get();
  const result = theoryComparison(data, s.refIndex);
  if (!result) {
    elements.list.innerHTML = "";
    elements.summary.textContent = "";
    if (elements.map) elements.map.innerHTML = "";
    theoryLast = null;
    return;
  }
  const refTitle = data.laps[s.refIndex].title;
  const gap = result.refLapTime - result.theoreticalS;
  // Biggest loss first, numbered, and the same number on the map: the order
  // to read in is the order to work in.
  const losing = result.entries
    .filter((entry) => entry.loss >= THEORY_ROW_MIN_S)
    .sort((a, b) => b.loss - a.loss)
    .map((entry, i) => ({ ...entry, rank: i + 1 }));
  const even = result.entries.filter((entry) => entry.loss < THEORY_ROW_MIN_S);

  const carName = data.laps[s.refIndex].carName;
  const trackName = (data.payload.meta && data.payload.meta.trackName) || "";
  const when = ((data.payload.meta && data.payload.meta.sessionSummary) || "").split(" / ")[0];
  theoryLast = { data, losing, even, gap, refTitle, theoreticalS: result.theoreticalS, carName, trackName, when, map: elements.map };
  elements.summary.innerHTML =
    `<span class="theory-sum__what">${[trackName, carName, when].filter(Boolean).join(" ／ ")}</span>` +
    `<span class="theory-sum__label">理論ベストまで</span><span class="theory-sum__value">+${gap.toFixed(2)}<small>秒</small></span>` +
    `<span class="theory-sum__times">基準ラップ ${refTitle} ／ 理論ベスト ${formatLapTime(result.theoreticalS)}` +
    (hasSeveralCars(data) ? `（${data.laps[s.refIndex].carName} の周だけ）` : "") +
    "</span>" +
    theoryLapPicker(data, s.refIndex);
  elements.summary.querySelectorAll(".theory-laps input").forEach((box) => {
    box.addEventListener("change", () => {
      const lap = Number(box.value);
      if (box.checked) theoryExcluded.delete(lap);
      else theoryExcluded.add(lap);
      renderTheory(data, state, elements, onSelect);
      const picker = elements.summary.querySelector(".theory-laps");
      if (picker) picker.open = true;
    });
  });

  // One row a corner: the verdict in a word, the two speeds, the time. The
  // sentences behind the verdict are folded away until asked for.
  elements.list.innerHTML =
    (losing.length
      ? '<div class="theory-cols" aria-hidden="true"><span></span><span>最低速度の目標</span><span>脱出速度の目標</span><span>負け</span></div>'
      : "") +
    losing
      .map((entry) => {
        const bestTitle = data.laps[entry.bestLap].title;
        const main = theoryMainReason(entry);
        const reasons = entry.reasons.length
          ? entry.reasons
              .map((reason) => `<li><span class="theory__tag">${reason.tag}</span>${reason.text}</li>`)
              .join("")
          : "<li>ブレーキとアクセルにははっきりした差がありません。走行ラインを比べてください</li>";
        return (
          `<article class="theory${entry.highlight ? " theory--key" : ""}" data-segment="${entry.segment.id}" data-zoom="${entry.segment.parentId}">` +
          '<div class="theory__row">' +
          '<div class="theory__name">' +
          `<span class="theory__rank">${entry.rank}</span>` +
          `<div><h3>${entry.segment.name}</h3><p class="theory__verdict">${main ? main.tag : "要確認"}</p></div>` +
          "</div>" +
          `<div class="theory__speed" data-label="最低速度の目標">${theorySpeed(entry.ref.minSpeedKmh, entry.best.minSpeedKmh)}</div>` +
          `<div class="theory__speed" data-label="脱出速度の目標">${theorySpeed(entry.ref.exitSpeedKmh, entry.best.exitSpeedKmh)}</div>` +
          `<div class="theory__loss">+${entry.loss.toFixed(2)}<small>秒</small></div>` +
          "</div>" +
          '<details class="theory__more"><summary>詳しく</summary>' +
          `<ul class="theory__reasons">${reasons}</ul>` +
          `<p class="theory__from">入口 ${formatDelta(entry.entryLoss, 2)} ／ 出口 ${formatDelta(entry.exitLoss, 2)}（最低速度の地点で分けた負け）。` +
          `脱出速度は ${entry.exitM.toFixed(0)}m地点。理論側の周: ${bestTitle}</p>` +
          "</details>" +
          "</article>"
        );
      })
      .join("") +
    (even.length
      ? `<p class="subtle theory__even">差なし（0.1秒未満）: ${even.map((entry) => entry.segment.name).join("、")}</p>`
      : "");
  // Opening the details is reading, not choosing the corner to zoom to.
  elements.list.querySelectorAll(".theory__more").forEach((node) => {
    node.addEventListener("click", (event) => event.stopPropagation());
  });

  if (elements.map) elements.map.innerHTML = theoryTrackMap(data, losing, s.mapRotationDeg);
  // Pointing at a card lights its corner on the map, and the other way round.
  const mark = (segmentId, on) => {
    const root = elements.list.closest(".panel") || elements.list;
    root.querySelectorAll(`[data-segment="${segmentId}"]`).forEach((node) => node.classList.toggle("is-hover", on));
  };
  const nodes = [...elements.list.querySelectorAll(".theory")];
  if (elements.map) nodes.push(...elements.map.querySelectorAll(".theory-map__corner"));
  nodes.forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.zoom || node.dataset.segment));
    node.addEventListener("mouseenter", () => mark(node.dataset.segment, true));
    node.addEventListener("mouseleave", () => mark(node.dataset.segment, false));
  });
}

/* ---------- the panel as one picture ----------

   Drawn on a canvas rather than captured, since a page with no outside
   references has no screenshot library to call on. The map is the panel's own
   SVG, given its colours inline because a picture made from it sees no CSS. */

const THEORY_IMAGE_W = 1600;
const THEORY_IMAGE_H = 1000;

function theoryMapImage(svg, numFont) {
  const copy = svg.cloneNode(true);
  copy.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  copy.setAttribute("width", svg.viewBox.baseVal.width);
  copy.setAttribute("height", svg.viewBox.baseVal.height);
  const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
  style.textContent =
    `text{font-family:${numFont};}` +
    `.theory-map__loss{font-size:18px;font-weight:700;paint-order:stroke;stroke:#0a0d12;stroke-width:5px;stroke-linejoin:round;}` +
    `.theory-map__rank{fill:#0a0d12;font-size:15px;font-weight:800;}` +
    `.theory-map__tick{font-size:14px;font-weight:800;paint-order:stroke;stroke:#0a0d12;stroke-width:4px;}` +
    `.theory-map__start,.theory-map__legend text{fill:${COLORS.textDim};font-family:sans-serif;font-size:13px;}`;
  copy.insertBefore(style, copy.firstChild);
  const source = new XMLSerializer().serializeToString(copy);
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(source);
  });
}

async function theoryImage() {
  const last = theoryLast;
  if (!last) return null;
  const scale = 2;
  const canvas = document.createElement("canvas");
  canvas.width = THEORY_IMAGE_W * scale;
  canvas.height = THEORY_IMAGE_H * scale;
  const ctx = canvas.getContext("2d");
  ctx.scale(scale, scale);
  const sans = getComputedStyle(document.body).fontFamily;
  const probe = document.querySelector(".theory__loss") || document.body;
  const num = getComputedStyle(probe).fontFamily;
  const font = (size, weight = 400, family = sans) => `${weight} ${size}px ${family}`;

  ctx.fillStyle = "#0b0f15";
  ctx.fillRect(0, 0, THEORY_IMAGE_W, THEORY_IMAGE_H);

  // Title: where and in what, then the gap.
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = COLORS.text;
  ctx.font = font(40, 600);
  ctx.fillText(`${last.trackName} 理論ベストとの差`, 48, 76);
  ctx.font = font(22, 400);
  ctx.fillStyle = COLORS.textDim;
  ctx.fillText([last.carName, last.when].filter(Boolean).join(" ／ "), 48, 114);
  ctx.font = font(18, 400, num);
  ctx.fillText(`基準ラップ ${last.refTitle} ／ 理論ベスト ${formatLapTime(last.theoreticalS)}`, 48, 146);
  ctx.textAlign = "right";
  ctx.fillStyle = COLORS.textDim;
  ctx.font = font(20, 400);
  ctx.fillText("理論ベストまで", THEORY_IMAGE_W - 48, 62);
  ctx.fillStyle = COLORS.loss;
  ctx.font = font(64, 700, num);
  ctx.fillText(`+${last.gap.toFixed(2)}秒`, THEORY_IMAGE_W - 48, 130);
  ctx.textAlign = "left";

  // The map on the left.
  const svg = last.map && last.map.querySelector("svg");
  const mapBox = { x: 32, y: 190, w: 800, h: 760 };
  ctx.fillStyle = "#0a0d12";
  ctx.fillRect(mapBox.x, mapBox.y, mapBox.w, mapBox.h);
  if (svg) {
    const image = await theoryMapImage(svg, num);
    const fit = Math.min(mapBox.w / image.width, mapBox.h / image.height);
    const w = image.width * fit;
    const h = image.height * fit;
    ctx.drawImage(image, mapBox.x + (mapBox.w - w) / 2, mapBox.y + (mapBox.h - h) / 2, w, h);
  }

  // One row a corner on the right, as on the page.
  const left = 860;
  const right = THEORY_IMAGE_W - 32;
  const colMin = left + 400;
  const colExit = left + 540;
  ctx.font = font(15, 400);
  ctx.fillStyle = COLORS.textDim;
  ctx.textAlign = "right";
  ctx.fillText("最低速度の目標", colMin, 214);
  ctx.fillText("脱出速度の目標", colExit, 214);
  ctx.fillText("負け", right - 16, 214);
  ctx.textAlign = "left";
  const top = 230;
  const gapY = 10;
  const rowH = Math.min(118, (THEORY_IMAGE_H - 70 - top - gapY * (last.losing.length - 1)) / Math.max(last.losing.length, 1));
  last.losing.forEach((entry, i) => {
    const y = top + i * (rowH + gapY);
    const colour = entry.highlight ? COLORS.loss : COLORS.cmp;
    ctx.fillStyle = entry.highlight ? "rgba(255, 90, 95, 0.08)" : "#0f141c";
    ctx.fillRect(left, y, right - left, rowH);
    ctx.strokeStyle = entry.highlight ? COLORS.loss : "#222c3a";
    ctx.lineWidth = entry.highlight ? 2 : 1;
    ctx.strokeRect(left + 0.5, y + 0.5, right - left - 1, rowH - 1);
    ctx.fillStyle = colour;
    ctx.fillRect(left, y, 5, rowH);
    const mid = y + rowH / 2;
    ctx.beginPath();
    ctx.arc(left + 36, mid, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#0a0d12";
    ctx.font = font(17, 800, num);
    ctx.textAlign = "center";
    ctx.fillText(String(entry.rank), left + 36, mid + 6);
    ctx.textAlign = "left";
    ctx.fillStyle = COLORS.text;
    ctx.font = font(24, 600);
    ctx.fillText(entry.segment.name, left + 66, mid - 6);
    const main = theoryMainReason(entry);
    ctx.fillStyle = colour;
    ctx.font = font(18, 600);
    ctx.fillText(main ? main.tag : "要確認", left + 66, mid + 24);
    const speed = (x, target, now) => {
      const diff = now - target;
      const met = diff >= MIN_SPEED_DIFF_KMH;
      ctx.textAlign = "right";
      ctx.fillStyle = COLORS.text;
      ctx.font = font(34, 600, num);
      ctx.fillText(target.toFixed(0), x, mid + 4);
      const shown = Math.abs(diff) < MIN_SPEED_DIFF_KMH ? "±0" : `${diff > 0 ? "+" : "−"}${Math.abs(diff).toFixed(0)}`;
      ctx.font = font(15, 600, num);
      ctx.fillStyle = diff <= -MIN_SPEED_DIFF_KMH ? COLORS.loss : met ? COLORS.gain : COLORS.textDim;
      ctx.fillText(`(${shown})`, x, mid + 30);
      const width = ctx.measureText(`(${shown})`).width;
      ctx.fillStyle = COLORS.textDim;
      ctx.font = font(15, 400, num);
      ctx.fillText(`今回 ${now.toFixed(0)} `, x - width, mid + 30);
      ctx.textAlign = "left";
    };
    speed(colMin, entry.best.minSpeedKmh, entry.ref.minSpeedKmh);
    speed(colExit, entry.best.exitSpeedKmh, entry.ref.exitSpeedKmh);
    ctx.textAlign = "right";
    ctx.fillStyle = colour;
    ctx.font = font(entry.highlight ? 32 : 28, 700, num);
    ctx.fillText(`+${entry.loss.toFixed(2)}秒`, right - 16, mid + 12);
    ctx.textAlign = "left";
  });
  if (last.even.length) {
    ctx.fillStyle = COLORS.textDim;
    ctx.font = font(17, 400);
    // Wrapped by hand: a long track's list runs past the picture's edge.
    let y = top + last.losing.length * (rowH + gapY) + 18;
    let line = "差なし（0.1秒未満）: ";
    last.even.forEach((entry, i) => {
      const word = entry.segment.name + (i + 1 < last.even.length ? "、" : "");
      if (ctx.measureText(line + word).width > right - left - 8) {
        ctx.fillText(line, left + 4, y);
        line = "";
        y += 26;
      }
      line += word;
    });
    ctx.fillText(line, left + 4, y);
  }
  return canvas;
}

async function saveTheoryImage() {
  const canvas = await theoryImage();
  if (!canvas) return;
  const last = theoryLast;
  // ASCII only: Chromium was seen to drop a Japanese file name and save the
  // picture as a bare "download" with no extension.
  const day = (last.when.match(/\d{4}-\d{2}-\d{2}/g) || []).pop() || "";
  const car = last.carName.replace(/[^A-Za-z0-9 ._-]/g, "").trim().replace(/\s+/g, "-");
  const name = ["GT7-theory", day, car].filter(Boolean).join("_") + ".png";
  // A data URL rather than a blob: a report opened from disk has no origin, and
  // browsers drop the file name of a blob link from such a page.
  const link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = name;
  document.body.appendChild(link);
  link.click();
  link.remove();
}
