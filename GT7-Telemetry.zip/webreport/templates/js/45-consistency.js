"use strict";

/* Consistency analysis: separates "always slow here" from "sometimes slow here",
   and replaces the naive theoretical best with one that has to keep runs of
   consecutive segments from the same lap. */

function median(values) {
  if (!values.length) return NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function standardDeviation(values) {
  if (values.length < 2) return 0;
  const mean = values.reduce((total, value) => total + value, 0) / values.length;
  const variance =
    values.reduce((total, value) => total + (value - mean) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

/* Believable segment times for one segment: nulls and incidents dropped.
   A spin makes a corner both slower and more variable than the driving did, so
   leaving it in would label a corner "ばらつく" for something that happened once
   and was not a technique at all. Falls back to the raw times when every lap
   through the segment was flagged, so the row still says something. */
function believableTimes(data, segmentId, lapIndexes = null) {
  const entry = data.sectorsById[segmentId];
  const present = entry.timeS
    .map((value, index) => ({ value, index }))
    .filter((item) => item.value !== null)
    .filter((item) => lapIndexes === null || lapIndexes.includes(item.index));
  const clean = present.filter((item) => !sectorFlag(data, segmentId, item.index));
  return (clean.length ? clean : present).map((item) => item.value);
}

/* Per-segment timing statistics across the laps in the report.

   `lapIndexes` narrows it to one car. Spread is the reason: two cars through
   the same corner differ by seconds, and pooling them would label every corner
   on the circuit "ばらつく" for a reason that has nothing to do with driving. */
function segmentStats(data, lapIndexes = null) {
  return data.segments.map((segment) => {
    const times = believableTimes(data, segment.id, lapIndexes);
    const best = Math.min(...times);
    const mid = median(times);
    return {
      id: segment.id,
      name: segment.name,
      times,
      best,
      median: mid,
      sd: standardDeviation(times),
      // What the driver gives away on a typical lap versus their own best here.
      habitualLoss: mid - best,
      spread: Math.max(...times) - best
    };
  });
}

/* Classifies a segment by how its spread compares with the rest of the lap.
   Both thresholds are relative to this driver's own numbers, so the labels stay
   meaningful whether the session was ragged or tidy. */
function classifySegments(stats) {
  const spreadReference = median(stats.map((entry) => entry.sd)) || 1e-6;
  const lossReference = median(stats.map((entry) => entry.habitualLoss)) || 1e-6;

  return stats.map((entry) => {
    const erratic = entry.sd > spreadReference * 1.3;
    const costly = entry.habitualLoss > lossReference * 1.3;
    let label;
    let hint;
    if (erratic && costly) {
      label = "ばらつく・損失大";
      hint = "毎周違うことをしていて、しかも遅い。まず操作を一つに固定する";
    } else if (erratic) {
      label = "ばらつく";
      hint = "速い時は速い。ベスト周のやり方を再現できれば取り返せる";
    } else if (costly) {
      label = "安定して遅い";
      hint = "毎周同じように遅い。ラインかブレーキング開始地点そのものを変える必要がある";
    } else {
      label = "安定";
      hint = "ここは仕上がっている";
    }
    return { ...entry, label, erratic, costly, hint };
  });
}

/* Fastest lap achievable while keeping runs of at least `minBlock` consecutive
   segments from one lap. minBlock of 1 is the usual (over-optimistic)
   theoretical best; minBlock of every segment is simply the best lap. */
function realisticBest(data, minBlock, lapIndexes = null) {
  const segments = data.segments;
  const count = segments.length;
  const block = Math.max(1, Math.min(minBlock, count));
  const pool = lapIndexes || data.laps.map((_lap, index) => index);

  // An incident is not a run that can be strung together with others, so it is
  // blanked out here. A segment where every lap went wrong keeps its times:
  // blanking the whole row would leave no way through and no answer at all.
  const times = segments.map((segment) => {
    const row = data.sectorsById[segment.id].timeS;
    const anyClean = row.some((value, lap) => value !== null && !sectorFlag(data, segment.id, lap));
    if (!anyClean) return row;
    return row.map((value, lap) => (sectorFlag(data, segment.id, lap) ? null : value));
  });
  const best = new Array(count + 1).fill(Infinity);
  best[0] = 0;

  for (let end = block; end <= count; end += 1) {
    for (let length = block; length <= end; length += 1) {
      const start = end - length;
      if (!isFinite(best[start])) continue;
      for (const lap of pool) {
        let total = 0;
        let usable = true;
        for (let segment = start; segment < end; segment += 1) {
          const value = times[segment][lap];
          if (value === null) {
            usable = false;
            break;
          }
          total += value;
        }
        if (usable && best[start] + total < best[end]) best[end] = best[start] + total;
      }
    }
  }
  // No run of this length survived the flags anywhere. The driver's own best
  // lap is then the honest answer: slower than the ideal, never faster.
  if (!isFinite(best[count])) {
    return Math.min(...pool.map((lap) => data.laps[lap].lapTimeS));
  }
  return best[count];
}

/* With fewer laps the spread of a segment is the difference between two or
   three runs: a standard deviation of two numbers, and a "median" that is one
   of them. The labels below ("ばらつく", "安定して遅い") describe a habit, and
   a habit needs laps to show. Five is the count gt7-driving-knowledge 9.3
   uses for judging a change (the median of five valid laps). */
const CONSISTENCY_MIN_LAPS = 5;

function renderConsistency(data, state, elements, onSelect) {
  // This whole panel ends in an instruction, so it is built from the reference
  // lap's own car. With one car that is every lap in the report.
  const s = state.get();
  const pool = sameCarLapIndexes(data, s.refIndex);
  const stats = classifySegments(segmentStats(data, pool));
  const actualBest = Math.min(...pool.map((index) => data.laps[index].lapTimeS));
  const fewLaps = pool.filter((index) => !data.laps[index].isAverage).length < CONSISTENCY_MIN_LAPS;

  /* ---- how realistic is the theoretical best ---- */

  const blockSizes = [1, 2, 3, 4, 6, 8, data.segments.length];
  const rows = blockSizes.map((size) => ({ size, time: realisticBest(data, size, pool) }));
  const naive = rows[0].time;
  const range = Math.max(actualBest - naive, 1e-6);

  elements.blocks.innerHTML = rows
    .map((row) => {
      const remaining = (actualBest - row.time) / range;
      const width = Math.max(2, remaining * 100);
      const label =
        row.size === 1
          ? "区間ごと"
          : row.size >= data.segments.length
          ? "1周まるごと"
          : `${row.size}区間ずつ`;
      return (
        '<div class="gap-row" title="同じ周から連続する区間をまとめて使った場合の最速">' +
        `<span class="gap-row__name">${label}</span>` +
        '<span class="gap-row__track">' +
        `<span class="gap-row__fill" style="left:0;width:${width}%;background:${
          row.size === 1 ? COLORS.textFaint : COLORS.ref
        }"></span></span>` +
        `<span class="gap-row__value">${formatLapTime(row.time)}</span>` +
        "</div>"
      );
    })
    .join("");

  const practical = rows.find((row) => row.size === 3);
  elements.blocksNote.textContent =
    `区間最速の単純合算は ${formatLapTime(naive)} ですが、区間のつながりを無視しています。` +
    `3区間続けて再現できた実績で組むと ${formatLapTime(practical.time)}、` +
    `実ベストとの差は ${formatDelta(actualBest - practical.time)}秒です。`;

  /* ---- per-segment consistency ---- */

  const head = ["区間", "最速", "中央値", "常時損失", "ばらつき σ", "判定"]
    .map((label) => `<th>${label}</th>`)
    .join("");

  const sorted = [...stats].sort((a, b) => b.habitualLoss + b.sd - (a.habitualLoss + a.sd));
  const activeSegment = state.get().activeSegment;

  const body = sorted
    .map((entry) => {
      const active = entry.id === activeSegment ? ' class="is-active"' : "";
      const badge = entry.erratic || entry.costly ? "cell-loss" : "cell-dim";
      return (
        `<tr data-segment="${entry.id}"${active} title="${entry.hint}">` +
        `<td>${entry.name}</td>` +
        `<td>${formatSeconds(entry.best)}</td>` +
        `<td>${formatSeconds(entry.median)}</td>` +
        `<td class="${entry.costly ? "cell-loss" : "cell-dim"}">${formatDelta(entry.habitualLoss)}</td>` +
        `<td class="${entry.erratic ? "cell-loss" : "cell-dim"}">${entry.sd.toFixed(3)}</td>` +
        `<td class="${fewLaps ? "cell-dim" : badge}" style="text-align:left">${fewLaps ? "—" : entry.label}</td>` +
        "</tr>"
      );
    })
    .join("");

  elements.table.innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body}</tbody>`;
  elements.table.querySelectorAll("tbody tr").forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
  });

  if (elements.behaviour) {
    elements.behaviour.innerHTML = behaviourFinding(data, state);
  }

  // Temperatures describe the session rather than the selected pair of laps, so
  // they get their own line instead of being folded into the behaviour sentence.
  if (elements.tyres) {
    elements.tyres.innerHTML = temperatureFinding(data, pool);
  }

  /* Not "the first thing to fix": that is said once, at the top of the page,
     and this table sorts by something else (median loss plus spread). Calling
     both "first" pointed at two corners on every one of the ten sessions
     inspected on 2026-11-11. This line says what was measured. */
  const worst = sorted[0];
  const lapCount = pool.filter((index) => !data.laps[index].isAverage).length;
  elements.summary.innerHTML =
    lapCount < CONSISTENCY_MIN_LAPS
      ? `ばらつきの判定は ${CONSISTENCY_MIN_LAPS}周以上で出します（いまは ${lapCount}周）。下の表は参考です。`
      : `周ごとのばらつきと損失が一番大きいのは <b>${worst.name}</b>（${worst.label}）。${worst.hint}。` +
        `全区間の常時損失を足すと ${formatDelta(stats.reduce((total, entry) => total + entry.habitualLoss, 0))}秒です。` +
        "直す順番は一番上の「次の走行はまずここ」です。";
}


/* Reads the behaviour channels and says, in words, what the car is doing where.
   Only meaningful for sessions captured by capture_gt7.py. */
function behaviourFinding(data, state) {
  if (!data.hasExtended) return "";

  // Slide angle and slip come out of the car as much as out of the driver, so
  // across two cars this sentence would blame a driver for a chassis. Say which
  // two cars are being held side by side and stop there.
  const picked = state.get();
  const reference = data.laps[picked.refIndex];
  const comparison = data.laps[picked.cmpIndex];
  if (reference && comparison && reference.carId !== comparison.carId) {
    return (
      `挙動: 比較の周は <b>${comparison.carName}</b>、基準は <b>${reference.carName}</b> です。` +
      "滑りや空転の差には車の違いが混ざるため、運転の助言の根拠にはしていません。"
    );
  }

  const rows = buildSectorRows(data, state);
  if (!rows.length) return "";

  const pick = (compare) => rows.reduce((worst, row) => (compare(row, worst) ? row : worst), rows[0]);
  const candidates = [
    {
      row: pick((row, worst) => row.slideGap > worst.slideGap),
      applies: (row) => row.slideGap > 0.5,
      phrase: (row) => `基準より ${row.slideGap.toFixed(1)}° 多く流れ`
    },
    {
      row: pick((row, worst) => row.maxRearSlip > worst.maxRearSlip),
      applies: (row) => row.maxRearSlip > 1.05,
      phrase: (row) => `リアが ${row.maxRearSlip.toFixed(2)} まで空転し`
    },
    {
      row: pick((row, worst) => row.minFrontSlip < worst.minFrontSlip),
      applies: (row) => row.minFrontSlip < 0.95,
      phrase: (row) => `フロントが ${row.minFrontSlip.toFixed(2)} までロックし`
    }
  ].filter((entry) => entry.applies(entry.row));

  if (!candidates.length) return "挙動チャンネル上、目立つ滑りや空転はありません。";

  // The same corner often wins on several counts; say its name once.
  const bySegment = new Map();
  for (const entry of candidates) {
    const existing = bySegment.get(entry.row.id) || { row: entry.row, phrases: [] };
    existing.phrases.push(entry.phrase(entry.row));
    bySegment.set(entry.row.id, existing);
  }

  const sentences = [...bySegment.values()].map(({ row, phrases }) => {
    const joined = phrases.join("、");
    return `<b>${row.name}</b> は${joined}ています（この区間で ${formatDelta(row.gap)}s）`;
  });
  return "挙動: " + sentences.join(" · ") + "。";
}
