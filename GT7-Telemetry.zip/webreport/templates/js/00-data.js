"use strict";

/* Payload decoding, shared state and formatting helpers. */

const TYPED_ARRAYS = { u8: Uint8Array, u16: Uint16Array, u32: Uint32Array };

const COLORS = {
  ref: "#2ad4e8",
  cmp: "#f5a524",
  gain: "#35d07f",
  loss: "#ff5a5f",
  neutral: "#6c7a8d",
  grid: "#1f2836",
  gridStrong: "#2a3543",
  text: "#e8edf4",
  textDim: "#9aa8bb",
  textFaint: "#6c7a8d",
  ghost: "rgba(154, 168, 187, 0.18)"
};

function base64ToBytes(encoded) {
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

/* Expands a quantised channel into one Float32Array per lap, in real units. */
function decodeChannel(spec, lapCount, points) {
  const bytes = base64ToBytes(spec.data);
  const raw = new TYPED_ARRAYS[spec.dtype](bytes.buffer, bytes.byteOffset, lapCount * points);
  const perLap = [];
  for (let lap = 0; lap < lapCount; lap += 1) {
    const out = new Float32Array(points);
    const base = lap * points;
    for (let i = 0; i < points; i += 1) out[i] = raw[base + i] / spec.scale + spec.offset;
    perLap.push(out);
  }
  return perLap;
}

function buildDataset(payload) {
  const points = payload.grid.points;
  const lapCount = payload.laps.length;
  const channels = {};
  for (const [name, spec] of Object.entries(payload.channels)) {
    channels[name] = decodeChannel(spec, lapCount, points);
  }
  channels.x = decodeChannel(payload.track.x, lapCount, points);
  channels.z = decodeChannel(payload.track.z, lapCount, points);

  const distance = new Float32Array(points);
  const step = payload.grid.lapDistanceM / (points - 1);
  for (let i = 0; i < points; i += 1) distance[i] = i * step;

  const segmentBounds = payload.segments.map((segment) => ({
    id: segment.id,
    name: segment.name_ja || segment.name || segment.id,
    nameEn: segment.name || segment.id,
    note: segment.description_ja || "",
    start: Math.round(segment.start_fraction * (points - 1)),
    end: Math.round(segment.end_fraction * (points - 1))
  }));

  const sectorsById = {};
  for (const entry of payload.sectors) sectorsById[entry.id] = entry;

  // Channels only capture_gt7.py records. Sessions from GT7 Dashboard have none
  // of these, so everything that uses them has to check `hasExtended` first.
  const extended = {};
  for (const [name, spec] of Object.entries(payload.extended || {})) {
    extended[name] = decodeChannel(spec, lapCount, points);
  }
  const hasExtended = Object.keys(extended).length > 0;
  if (hasExtended) {
    // Axle averages are what a driver actually reasons about: the rear spinning
    // up, or the fronts locking.
    extended.slipFront = [];
    extended.slipRear = [];
    extended.tempFront = [];
    extended.tempRear = [];
    for (let lap = 0; lap < lapCount; lap += 1) {
      const front = new Float32Array(points);
      const rear = new Float32Array(points);
      const tempF = new Float32Array(points);
      const tempR = new Float32Array(points);
      for (let i = 0; i < points; i += 1) {
        front[i] = (extended.slipFL[lap][i] + extended.slipFR[lap][i]) / 2;
        rear[i] = (extended.slipRL[lap][i] + extended.slipRR[lap][i]) / 2;
        tempF[i] = (extended.tempFL[lap][i] + extended.tempFR[lap][i]) / 2;
        tempR[i] = (extended.tempRL[lap][i] + extended.tempRR[lap][i]) / 2;
      }
      extended.slipFront.push(front);
      extended.slipRear.push(rear);
      extended.tempFront.push(tempF);
      extended.tempRear.push(tempR);
    }
  }

  // Traction-control time is only known for sessions recorded (or rebuilt from
  // raw.bin) after the flag started being saved.
  const hasTcs = payload.sectors.some((entry) => (entry.tcsS || []).some((value) => value !== null));

  return {
    extended,
    hasExtended,
    hasTcs,
    payload,
    points,
    lapCount,
    channels,
    distance,
    lapDistanceM: payload.grid.lapDistanceM,
    laps: payload.laps,
    segments: segmentBounds,
    sectorsById,
    bounds: payload.track.bounds
  };
}

/* ---------- session average ---------- */

function meanOf(values) {
  const present = values.filter((value) => value !== null && value !== undefined && Number.isFinite(value));
  return present.length ? present.reduce((sum, value) => sum + value, 0) / present.length : null;
}

function meanTrace(traces) {
  const out = new Float32Array(traces[0].length);
  for (let i = 0; i < out.length; i += 1) {
    let sum = 0;
    for (const trace of traces) sum += trace[i];
    out[i] = sum / traces.length;
  }
  return out;
}

/* Adds one lap that is the mean of this session's laps in the reference car, so
   it can be picked as the reference: "where does my usual pace lose time"
   rather than "where does one lap". Every channel is averaged point by point on
   the distance grid, so its time trace is the mean time to each point and its
   lap time the mean lap time; the corner figures are the mean of each lap's.

   It is a comparison baseline, never evidence: sameCarLapIndexes leaves it out,
   so no advice ever quotes the average as "a lap you drove". Laps carried in
   from another day are not averaged, and spins stay in, because an average
   that quietly dropped the bad laps would no longer be the session's.

   Returns the new lap's index, or null with fewer than two laps to average. */
function addSessionAverage(data) {
  const reference = data.laps.find((lap) => lap.isReference) || data.laps[0];
  if (!reference) return null;
  const source = data.laps
    .filter((lap) => !lap.isHistory && !lap.isAverage && lap.carId === reference.carId)
    .map((lap) => lap.index);
  if (source.length < 2) return null;

  const index = data.laps.length;
  const lapTimeS = meanOf(source.map((i) => data.laps[i].lapTimeS));
  data.laps = [
    ...data.laps,
    {
      index,
      uid: "session-average",
      title: `セッション平均（${formatLapTime(lapTimeS)}）`,
      lapTimeS,
      number: null,
      carId: reference.carId,
      carName: reference.carName,
      sourceFile: "",
      isReference: false,
      isHistory: false,
      isAverage: true,
      averageOf: source.length,
      topSpeedKmh: meanOf(source.map((i) => data.laps[i].topSpeedKmh))
    }
  ];
  for (const name of Object.keys(data.channels)) {
    data.channels[name].push(meanTrace(source.map((i) => data.channels[name][i])));
  }
  for (const name of Object.keys(data.extended)) {
    data.extended[name].push(meanTrace(source.map((i) => data.extended[name][i])));
  }
  for (const entry of Object.values(data.sectorsById)) {
    for (const [field, values] of Object.entries(entry)) {
      if (!Array.isArray(values)) continue;
      // An average run is not a run that can go wrong.
      values.push(field === "flagged" ? null : meanOf(source.map((i) => values[i])));
    }
  }
  // The braking panel lines its per-lap list up with data.laps. The average
  // has no events of its own: an averaged slip trace smooths every one away.
  const braking = data.payload.braking;
  if (braking && braking.laps) {
    data.payload = {
      ...data.payload,
      braking: { ...braking, laps: [...braking.laps, { frontSlipPct: null, rearSlipPct: null, events: [] }] }
    };
  }
  data.lapCount = data.laps.length;
  return index;
}

/* Running time difference between two laps across the whole distance grid. */
function computeDelta(data, refIndex, cmpIndex) {
  const refTime = data.channels.time_s[refIndex];
  const cmpTime = data.channels.time_s[cmpIndex];
  const delta = new Float32Array(data.points);
  for (let i = 0; i < data.points; i += 1) delta[i] = cmpTime[i] - refTime[i];
  return delta;
}

/* Local rate of time loss in s/100m, smoothed so single samples cannot spike it. */
function computeDeltaRate(delta, distance, window = 12) {
  const points = delta.length;
  const rate = new Float32Array(points);
  for (let i = 0; i < points; i += 1) {
    const lo = Math.max(0, i - window);
    const hi = Math.min(points - 1, i + window);
    const span = distance[hi] - distance[lo];
    rate[i] = span > 0 ? ((delta[hi] - delta[lo]) / span) * 100 : 0;
  }
  return rate;
}

/* ---------- formatting ---------- */

function formatLapTime(seconds) {
  if (!isFinite(seconds)) return "—";
  const sign = seconds < 0 ? "-" : "";
  const total = Math.abs(seconds);
  const minutes = Math.floor(total / 60);
  const rest = total - minutes * 60;
  return `${sign}${minutes}:${rest.toFixed(3).padStart(6, "0")}`;
}

function formatDelta(seconds, digits = 3) {
  if (seconds === null || seconds === undefined || !isFinite(seconds)) return "—";
  const value = seconds.toFixed(digits);
  return seconds >= 0 ? `+${value}` : value;
}

function formatSeconds(seconds, digits = 3) {
  return isFinite(seconds) ? seconds.toFixed(digits) : "—";
}

function deltaClass(value) {
  if (value === null || !isFinite(value) || Math.abs(value) < 0.0005) return "";
  return value > 0 ? "is-loss" : "is-gain";
}

function deltaCellClass(value) {
  if (value === null || !isFinite(value) || Math.abs(value) < 0.0005) return "cell-dim";
  return value > 0 ? "cell-loss" : "cell-gain";
}

/* Past laps carry the date in their title already; the marker says at a glance
   that the row is not from today, wherever the label is reused. */
function lapLabel(lap) {
  if (lap.isAverage) return `${lap.title}  ·  ${lap.averageOf}周`;
  const prefix = lap.isHistory ? "★ " : "";
  return `${prefix}${lap.title}  ·  ${lap.carName}`;
}

/* ---------- cars ---------- */

/* Every car that appears in the report, in the order the laps were packed. */
function carIdsInReport(data) {
  const seen = [];
  for (const lap of data.laps) {
    if (!seen.includes(lap.carId)) seen.push(lap.carId);
  }
  return seen;
}

function hasSeveralCars(data) {
  return carIdsInReport(data).length > 1;
}

/* The laps that may stand as evidence for advice about `lapIndex`: the ones
   driven in the same car.

   A session can hold two cars, because swapping in the pits does not start a
   new recording. Comparing them is worth having and the charts, the ghost and
   the segment table all keep doing it. Advice is different: "brake later here"
   is not something another car's lap can prove, and a corner is not erratic
   because two different cars drove it. Anything that turns into an instruction
   is built from this list instead of from every lap in the report. */
function sameCarLapIndexes(data, lapIndex) {
  const reference = data.laps[lapIndex];
  const carId = reference === undefined ? undefined : reference.carId;
  const indexes = [];
  for (let i = 0; i < data.laps.length; i += 1) {
    // The session average is a baseline to compare against, not a lap driven.
    if (data.laps[i].carId === carId && !data.laps[i].isAverage) indexes.push(i);
  }
  return indexes;
}

/* Red for time lost, green for time gained, grey where the laps agree. */
function rateColor(rate, fullScale = 0.12) {
  const t = Math.max(-1, Math.min(1, rate / fullScale));
  const magnitude = Math.abs(t);
  const target = t > 0 ? [255, 90, 95] : [53, 208, 127];
  const base = [108, 122, 141];
  const eased = Math.pow(magnitude, 0.7);
  const mix = base.map((channel, i) => Math.round(channel + (target[i] - channel) * eased));
  return `rgb(${mix[0]}, ${mix[1]}, ${mix[2]})`;
}

/* Blue-to-yellow ramp for the speed view of the track map. */
function speedColor(speed, min, max) {
  const t = max > min ? (speed - min) / (max - min) : 0;
  const clamped = Math.max(0, Math.min(1, t));
  const stops = [
    [40, 90, 180],
    [42, 212, 232],
    [53, 208, 127],
    [245, 165, 36],
    [255, 232, 120]
  ];
  const scaled = clamped * (stops.length - 1);
  const index = Math.min(stops.length - 2, Math.floor(scaled));
  const local = scaled - index;
  const a = stops[index];
  const b = stops[index + 1];
  const mix = a.map((channel, i) => Math.round(channel + (b[i] - channel) * local));
  return `rgb(${mix[0]}, ${mix[1]}, ${mix[2]})`;
}

/* ---------- state ---------- */

function createState(initial) {
  const listeners = new Set();
  const state = { ...initial };
  return {
    get: () => state,
    set(patch) {
      let changed = false;
      for (const [key, value] of Object.entries(patch)) {
        if (state[key] !== value) {
          state[key] = value;
          changed = true;
        }
      }
      if (changed) listeners.forEach((listener) => listener(state));
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

/* Canvas sizing that stays sharp on high-DPI displays. */
function fitCanvas(canvas, cssHeight) {
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth;
  const height = cssHeight !== undefined ? cssHeight : canvas.clientHeight;
  if (height === 0 || width === 0) return null;
  if (cssHeight !== undefined) canvas.style.height = `${cssHeight}px`;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, width, height);
  return { ctx, width, height };
}

/* ---------- racing line ---------- */

/* Signed distance from the reference lap's racing line, in metres.
   Positive is left of the reference car's direction of travel, negative right.
   The nearest point is searched in a window around the same lap progress, which
   keeps it honest through hairpins where the line doubles back on itself. */
function computeLateralOffset(data, refIndex, cmpIndex, window = 40) {
  const refX = data.channels.x[refIndex];
  const refZ = data.channels.z[refIndex];
  const cmpX = data.channels.x[cmpIndex];
  const cmpZ = data.channels.z[cmpIndex];
  const points = data.points;
  const offset = new Float32Array(points);

  // The polyline wraps around the start/finish line, but if the seam is far
  // longer than a normal step the lap has a gap there. Projecting onto that
  // stretch would measure against a path the car never took, and because it
  // points backwards it flips the sign. Skip anything that far out of scale.
  const typicalStep = data.lapDistanceM / (points - 1);
  const maxStepSq = (typicalStep * 20) ** 2;

  for (let i = 0; i < points; i += 1) {
    const px = cmpX[i];
    const pz = cmpZ[i];
    let bestDistance = Infinity;
    let nearestX = px;
    let nearestZ = pz;
    let tangentX = 1;
    let tangentZ = 0;

    for (let k = -window; k < window; k += 1) {
      const a = (i + k + points) % points;
      const b = (a + 1) % points;
      const ax = refX[a];
      const az = refZ[a];
      const edgeX = refX[b] - ax;
      const edgeZ = refZ[b] - az;
      const lengthSq = edgeX * edgeX + edgeZ * edgeZ;
      if (lengthSq === 0 || lengthSq > maxStepSq) continue;

      let t = ((px - ax) * edgeX + (pz - az) * edgeZ) / lengthSq;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const qx = ax + edgeX * t;
      const qz = az + edgeZ * t;
      const dx = px - qx;
      const dz = pz - qz;
      const distance = dx * dx + dz * dz;
      if (distance < bestDistance) {
        bestDistance = distance;
        nearestX = qx;
        nearestZ = qz;
        tangentX = edgeX;
        tangentZ = edgeZ;
      }
    }

    const length = Math.hypot(tangentX, tangentZ) || 1;
    const normalX = -tangentZ / length;
    const normalZ = tangentX / length;
    offset[i] = (px - nearestX) * normalX + (pz - nearestZ) * normalZ;
  }
  return offset;
}

/* Percentile of |values| over a range. The first lap of a stint starts on the
   pit-exit line, which puts an 11 m outlier on the main straight; scaling the
   colour ramp to a percentile keeps the rest of the lap readable. */
function percentileAbs(values, from, to, ratio) {
  const slice = [];
  for (let i = from; i <= to; i += 1) slice.push(Math.abs(values[i]));
  if (!slice.length) return 0;
  slice.sort((a, b) => a - b);
  return slice[Math.min(slice.length - 1, Math.floor(slice.length * ratio))];
}

/* Purple to the left of the reference line, blue to the right: distinct from the
   red/green delta ramp and the cyan/amber lap colours. */
function offsetColor(metres, fullScale = 2.5) {
  const t = Math.max(-1, Math.min(1, metres / fullScale));
  const magnitude = Math.pow(Math.abs(t), 0.7);
  const target = t > 0 ? [167, 139, 250] : [56, 189, 248];
  const base = [108, 122, 141];
  const mix = base.map((channel, i) => Math.round(channel + (target[i] - channel) * magnitude));
  return `rgb(${mix[0]}, ${mix[1]}, ${mix[2]})`;
}


/* ---------- car behaviour ---------- */

/* Slide angle: neutral while the car follows its nose, warming to amber and red
   as it starts running wide of its own heading. */
function slideColor(degrees, fullScale = 8) {
  const magnitude = Math.min(1, Math.abs(degrees) / fullScale);
  const eased = Math.pow(magnitude, 0.7);
  const base = [108, 122, 141];
  const target = [255, 138, 40];
  const mix = base.map((channel, i) => Math.round(channel + (target[i] - channel) * eased));
  return `rgb(${mix[0]}, ${mix[1]}, ${mix[2]})`;
}

/* Slip ratio: 1.0 is a rolling wheel. Above is wheelspin (red), below is a
   locking wheel (blue). */
function slipColor(ratio, fullScale = 0.15) {
  const deviation = ratio - 1;
  const t = Math.max(-1, Math.min(1, deviation / fullScale));
  const magnitude = Math.pow(Math.abs(t), 0.7);
  const target = t > 0 ? [255, 90, 95] : [56, 189, 248];
  const base = [108, 122, 141];
  const mix = base.map((channel, i) => Math.round(channel + (target[i] - channel) * magnitude));
  return `rgb(${mix[0]}, ${mix[1]}, ${mix[2]})`;
}
