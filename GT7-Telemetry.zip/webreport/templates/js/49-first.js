"use strict";

/* One line at the top of the page: the first thing to do next time out.
 *
 * The theme and the cards below explain themselves at length, which is right
 * for reading after a run and wrong for the moment before one: a driver about
 * to go out reads one corner, one number and one action, and nothing else. So
 * this takes the theme's top corner (the corner worth the most seconds on the
 * habit that costs the most) and states only its target.
 *
 * The number is always the driver's own faster run through that corner, the
 * same evidence as the theme, and the action is the outward result to aim for
 * rather than how to move a foot (gt7-driving-knowledge 1.5). */

const FIRST_THING = {
  brake: {
    target: (corner) => `ブレーキング開始を ${(corner.best - corner.ref).toFixed(0)}m 奥へ`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)}m地点、速かった周は ${corner.best.toFixed(0)}m地点`,
    action: "動かない目印を1つ決め、そこまで我慢してから踏む"
  },
  minSpeed: {
    target: (corner) => `最低速度 ${corner.best.toFixed(0)} km/h`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)} km/h`,
    action: "ブレーキの後半を早めに緩める"
  },
  throttle: {
    target: (corner) => `全開を ${(corner.ref - corner.best).toFixed(0)}m 手前で`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)}m地点、速かった周は ${corner.best.toFixed(0)}m地点`,
    action: "向きを変え切ったら、1回で全開まで踏んで戻さない"
  },
  exit: {
    target: (corner) => `出口 ${corner.best.toFixed(0)} km/h`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)} km/h`,
    action: "クリップを少し奥にとり、出口でコース幅を使い切る"
  }
};

/* What to show, or null when the reference lap has nothing to make up. */
function firstThing(data, refIndex) {
  const theme = sessionTheme(data, refIndex);
  if (!theme.factor || !theme.corners.length) return null;
  const corner = theme.corners[0];
  const wording = FIRST_THING[theme.factor.key];
  return {
    segment: corner.segment,
    loss: corner.loss,
    target: wording.target(corner),
    now: wording.now(corner),
    action: wording.action,
    bestLap: corner.bestLap
  };
}

/* The same "first" from the panel of targets below, when it has one: the
   corner losing most to the model (or the theoretical best) and the speed
   its main reason is about. Two different "first" corners at the top of one
   page left the driver to pick between them. */
function firstFromTheory() {
  const last = theoryLast;
  if (!last || !last.losing.length) return null;
  const entry = last.losing[0];
  // The panel's own verdict, so the line and the row below it cannot differ.
  const reason = entry.verdict === undefined ? theoryMainReason(entry) : entry.verdict;
  const speed = (label, key) => ({ label, target: entry.best[key], now: entry.ref[key] });
  const min = speed("最低速度", "minSpeedKmh");
  const exit = speed("脱出速度", "exitSpeedKmh");
  /* The large number is the speed the reason moves. Arriving too fast is
     named among the entry reasons, but what it costs shows at the exit: the
     minimum speed is often the same (SUGO 2026-10-26, turn 8: 116 against
     119 km/h at the apex, 123 against 142 at the exit), and a target the
     driver already meets says nothing. The same holds wherever the reason's
     own speed is within the floor and the other is not. */
  let exitSide = reason ? !["brakeEarly", "minSpeed"].includes(reason.key) : entry.exitLoss > entry.entryLoss;
  const short = (item) => item.target - item.now >= MIN_SPEED_DIFF_KMH;
  const flat = Boolean(entry.ref.flat || entry.best.flat);
  if (flat) exitSide = true;
  else if (exitSide && !short(exit) && short(min)) exitSide = false;
  else if (!exitSide && !short(min) && short(exit)) exitSide = true;
  return {
    entry,
    reason,
    main: exitSide ? exit : min,
    // No bottom speed in a corner taken without slowing: say nothing of it.
    other: flat ? null : exitSide ? min : exit,
    target: last.target
  };
}

/* The gap as the two numbers beside it show it. Inside the floor it is still
   printed, uncoloured: "目標 119 / 今回 116 / ±0" read as a misprint. */
function speedGap(now, target) {
  const diff = Math.round(now) - Math.round(target);
  const text = diff === 0 ? "±0" : `${diff > 0 ? "+" : "−"}${Math.abs(diff)}`;
  if (Math.abs(now - target) < MIN_SPEED_DIFF_KMH) return { text, cls: "" };
  return { text, cls: diff < 0 ? "is-loss" : "is-gain" };
}

// The last call, so the line can follow the panel when only the panel redraws.
let firstThingArgs = null;
function refreshFirstThing() {
  if (firstThingArgs) renderFirstThing(...firstThingArgs);
}

function renderFirstThing(data, state, element, onSelect) {
  if (!element) return;
  firstThingArgs = [data, state, element, onSelect];
  const rotation = state.get().mapRotationDeg;
  const hero = firstFromTheory();
  if (hero) {
    const { entry, reason, main, other } = hero;
    const mainGap = speedGap(main.now, main.target);
    const otherGap = other ? speedGap(other.now, other.target) : null;
    element.hidden = false;
    element.classList.add("first--hero");
    element.innerHTML =
      `<div class="first__map">${cornerMap(data, entry.segment.parentId || entry.segment.id, rotation)}</div>` +
      '<div class="first__body">' +
      `<p class="first__label">次の走行はまずここ</p>` +
      `<p class="first__corner">${entry.segment.name}</p>` +
      `<p class="first__why">${reason ? reason.tag : "要確認（操作の差は小さい）・ゴースト再生で見比べる"}` +
      `<span class="first__loss">${hero.target}より +${entry.loss.toFixed(2)}秒</span></p>` +
      (reason && reason.goal ? `<p class="first__do">${reason.goal}</p>` : "") +
      "</div>" +
      '<div class="first__goal">' +
      `<p class="first__goal-label">${main.label}の目標</p>` +
      `<p class="first__goal-value">${main.target.toFixed(0)}<small>km/h</small></p>` +
      `<p class="first__goal-now">今回 ${main.now.toFixed(0)} <b class="${mainGap.cls}">${mainGap.text}</b></p>` +
      (other
        ? `<p class="first__goal-other">${other.label}の目標 ${other.target.toFixed(0)}（今回 ${other.now.toFixed(0)} ` +
          `<b class="${otherGap.cls}">${otherGap.text}</b>）</p>`
        : "") +
      "</div>";
    element.onclick = () => onSelect(entry.segment.parentId || entry.segment.id);
    return;
  }
  element.classList.remove("first--hero");
  const refIndex = state.get().refIndex;
  const first = firstThing(data, refIndex);
  if (!first) {
    element.hidden = true;
    element.innerHTML = "";
    return;
  }
  element.hidden = false;
  element.innerHTML =
    `<div class="first__map">${cornerMap(data, first.segment.id, rotation)}</div>` +
    '<div class="first__body">' +
    `<p class="first__label">次の走行はまずこれだけ</p>` +
    `<p class="first__line"><span class="first__corner">${first.segment.name}</span>` +
    `<span class="first__target">${first.target}</span></p>` +
    `<p class="first__action">${first.action}</p>` +
    `<p class="first__note">${first.now}。基準ラップ ${data.laps[refIndex].title} はここで ` +
    `<b>−${first.loss.toFixed(2)}秒</b>（速かった周 ${data.laps[first.bestLap].title}）</p>` +
    "</div>";
  element.onclick = () => onSelect(first.segment.id);
}
