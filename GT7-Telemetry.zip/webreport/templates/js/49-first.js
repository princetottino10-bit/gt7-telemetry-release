"use strict";

/* One line at the top of the page: the first thing to do next time out.
 *
 * The theme and the cards below explain themselves at length, which is right
 * for reading after a run and wrong for the moment before one: a driver about
 * to go out reads one corner, one number and one action, and nothing else. So
 * this takes the theme's top corner (the corner worth the most seconds on the
 * habit that costs the most) and states only its target.
 *
 * The number is always the driver's own faster run through that corner, the
 * same evidence as the theme, and the action is the outward result to aim for
 * rather than how to move a foot (gt7-driving-knowledge 1.5). */

const FIRST_THING = {
  brake: {
    target: (corner) => `ブレーキング開始を ${(corner.best - corner.ref).toFixed(0)}m 奥へ`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)}m地点、速かった周は ${corner.best.toFixed(0)}m地点`,
    action: "動かない目印を1つ決め、そこまで我慢してから踏む"
  },
  minSpeed: {
    target: (corner) => `最低速度 ${corner.best.toFixed(0)} km/h`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)} km/h`,
    action: "ブレーキの後半を早めに緩める"
  },
  throttle: {
    target: (corner) => `全開を ${(corner.ref - corner.best).toFixed(0)}m 手前で`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)}m地点、速かった周は ${corner.best.toFixed(0)}m地点`,
    action: "向きを変え切ったら、1回で全開まで踏んで戻さない"
  },
  exit: {
    target: (corner) => `出口 ${corner.best.toFixed(0)} km/h`,
    now: (corner) => `いまは ${corner.ref.toFixed(0)} km/h`,
    action: "クリップを少し奥にとり、出口でコース幅を使い切る"
  }
};

/* What to show, or null when the reference lap has nothing to make up. */
function firstThing(data, refIndex) {
  const theme = sessionTheme(data, refIndex);
  if (!theme.factor || !theme.corners.length) return null;
  const corner = theme.corners[0];
  const wording = FIRST_THING[theme.factor.key];
  return {
    segment: corner.segment,
    loss: corner.loss,
    target: wording.target(corner),
    now: wording.now(corner),
    action: wording.action,
    bestLap: corner.bestLap
  };
}

/* The same "first" from the panel of targets below, when it has one: the
   corner losing most to the model (or the theoretical best) and the speed
   its main reason is about. Two different "first" corners at the top of one
   page left the driver to pick between them. */
function firstFromTheory() {
  const last = theoryLast;
  if (!last || !last.losing.length) return null;
  const entry = last.losing[0];
  const reason = theoryMainReason(entry);
  const exitSide = reason ? !THEORY_ENTRY_KEYS.includes(reason.key) : entry.exitLoss > entry.entryLoss;
  const speed = (label, key) => ({ label, target: entry.best[key], now: entry.ref[key] });
  const min = speed("最低速度", "minSpeedKmh");
  const exit = speed("脱出速度", "exitSpeedKmh");
  return {
    entry,
    reason,
    main: exitSide ? exit : min,
    other: exitSide ? min : exit,
    target: last.target
  };
}

function speedGap(now, target) {
  const diff = Math.round(now - target);
  if (Math.abs(now - target) < MIN_SPEED_DIFF_KMH) return { text: "±0", cls: "" };
  return { text: `${diff > 0 ? "+" : "−"}${Math.abs(diff)}`, cls: diff < 0 ? "is-loss" : "is-gain" };
}

// The last call, so the line can follow the panel when only the panel redraws.
let firstThingArgs = null;
function refreshFirstThing() {
  if (firstThingArgs) renderFirstThing(...firstThingArgs);
}

function renderFirstThing(data, state, element, onSelect) {
  if (!element) return;
  firstThingArgs = [data, state, element, onSelect];
  const rotation = state.get().mapRotationDeg;
  const hero = firstFromTheory();
  if (hero) {
    const { entry, reason, main, other } = hero;
    const mainGap = speedGap(main.now, main.target);
    const otherGap = speedGap(other.now, other.target);
    element.hidden = false;
    element.classList.add("first--hero");
    element.innerHTML =
      `<div class="first__map">${cornerMap(data, entry.segment.parentId || entry.segment.id, rotation)}</div>` +
      '<div class="first__body">' +
      `<p class="first__label">次の走行はまずここ</p>` +
      `<p class="first__corner">${entry.segment.name}</p>` +
      `<p class="first__why">${reason ? reason.tag : "ブレーキとアクセルに差なし・走行ラインを確認"}` +
      `<span class="first__loss">${hero.target}より +${entry.loss.toFixed(2)}秒</span></p>` +
      "</div>" +
      '<div class="first__goal">' +
      `<p class="first__goal-label">${main.label}の目標</p>` +
      `<p class="first__goal-value">${main.target.toFixed(0)}<small>km/h</small></p>` +
      `<p class="first__goal-now">今回 ${main.now.toFixed(0)} <b class="${mainGap.cls}">${mainGap.text}</b></p>` +
      `<p class="first__goal-other">${other.label}の目標 ${other.target.toFixed(0)}（今回 ${other.now.toFixed(0)} ` +
      `<b class="${otherGap.cls}">${otherGap.text}</b>）</p>` +
      "</div>";
    element.onclick = () => onSelect(entry.segment.parentId || entry.segment.id);
    return;
  }
  element.classList.remove("first--hero");
  const refIndex = state.get().refIndex;
  const first = firstThing(data, refIndex);
  if (!first) {
    element.hidden = true;
    element.innerHTML = "";
    return;
  }
  element.hidden = false;
  element.innerHTML =
    `<div class="first__map">${cornerMap(data, first.segment.id, rotation)}</div>` +
    '<div class="first__body">' +
    `<p class="first__label">次の走行はまずこれだけ</p>` +
    `<p class="first__line"><span class="first__corner">${first.segment.name}</span>` +
    `<span class="first__target">${first.target}</span></p>` +
    `<p class="first__action">${first.action}</p>` +
    `<p class="first__note">${first.now}。基準ラップ ${data.laps[refIndex].title} はここで ` +
    `<b>−${first.loss.toFixed(2)}秒</b>（速かった周 ${data.laps[first.bestLap].title}）</p>` +
    "</div>";
  element.onclick = () => onSelect(first.segment.id);
}
