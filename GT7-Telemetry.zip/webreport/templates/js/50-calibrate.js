"use strict";

/* View alignment: rotate the telemetry map, and drop in a course diagram to
   sit behind it. Both settings persist in localStorage per track. */

function storageKey(slug, suffix) {
  return `gt7report:${slug}:${suffix}`;
}

function defaultCalibration(bounds) {
  return {
    mapRotationDeg: 0,
    centerX: (bounds.xMin + bounds.xMax) / 2,
    centerZ: (bounds.zMin + bounds.zMax) / 2,
    widthM: (bounds.xMax - bounds.xMin) * 1.12,
    rotationDeg: 0,
    opacity: 0.55,
    flipX: false,
    flipY: false
  };
}

function readStored(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

function writeStored(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    /* Private-mode or quota failures are not worth interrupting the user for. */
  }
}

function createCalibration(data, state, trackMap, elements) {
  const slug = data.payload.meta.trackSlug;
  const bounds = data.bounds;
  const span = Math.max(bounds.xMax - bounds.xMin, bounds.zMax - bounds.zMin);
  const buildTime = data.payload.meta.calibration || {};
  let params = {
    ...defaultCalibration(bounds),
    ...buildTime,
    ...readStored(storageKey(slug, "calib"), {})
  };
  let imageSource = null;

  const MAP_CONTROLS = [
    { key: "mapRotationDeg", label: "マップの向き", min: -180, max: 180, step: 0.5, unit: "°", digits: 1 }
  ];

  const IMAGE_CONTROLS = [
    { key: "centerX", label: "画像 左右位置", min: bounds.xMin - span, max: bounds.xMax + span, step: 1, unit: "m", digits: 0 },
    { key: "centerZ", label: "画像 上下位置", min: bounds.zMin - span, max: bounds.zMax + span, step: 1, unit: "m", digits: 0 },
    { key: "widthM", label: "画像 拡大縮小", min: span * 0.25, max: span * 3, step: 1, unit: "m", digits: 0 },
    { key: "rotationDeg", label: "画像 回転", min: -180, max: 180, step: 0.5, unit: "°", digits: 1 },
    { key: "opacity", label: "画像 不透明度", min: 0.05, max: 1, step: 0.01, unit: "", digits: 2 }
  ];

  function makeSlider(control) {
    const wrapper = document.createElement("label");
    wrapper.className = "slider";
    wrapper.innerHTML =
      `<span class="slider__top"><span>${control.label}</span><output></output></span>` +
      `<input type="range" min="${control.min}" max="${control.max}" step="${control.step}">`;
    const input = wrapper.querySelector("input");
    const output = wrapper.querySelector("output");
    const show = (value) => {
      output.textContent = `${Number(value).toFixed(control.digits)}${control.unit}`;
    };
    input.value = params[control.key];
    show(params[control.key]);
    input.addEventListener("input", () => {
      params = { ...params, [control.key]: Number(input.value) };
      show(input.value);
      apply();
    });
    return wrapper;
  }

  function makeCheckbox(key, label) {
    const wrapper = document.createElement("label");
    wrapper.className = "checkbox";
    wrapper.innerHTML = `<input type="checkbox"><span>${label}</span>`;
    const input = wrapper.querySelector("input");
    input.checked = Boolean(params[key]);
    input.addEventListener("change", () => {
      params = { ...params, [key]: input.checked };
      apply();
    });
    return wrapper;
  }

  function buildControls() {
    elements.controls.innerHTML = "";
    MAP_CONTROLS.forEach((control) => elements.controls.append(makeSlider(control)));
    if (!imageSource) return;
    IMAGE_CONTROLS.forEach((control) => elements.controls.append(makeSlider(control)));
    elements.controls.append(makeCheckbox("flipX", "画像 左右反転"));
    elements.controls.append(makeCheckbox("flipY", "画像 上下反転"));
  }

  function apply() {
    writeStored(storageKey(slug, "calib"), params);
    state.set({ mapRotationDeg: params.mapRotationDeg });
    trackMap.updateBackgroundParams(params);
  }

  function setImageActions(enabled) {
    elements.remove.disabled = !enabled;
    elements.remove.style.opacity = enabled ? "1" : "0.4";
    elements.hint.textContent = enabled
      ? "スライダーで背景コース図をテレメトリに重ねます。調整内容はこのブラウザに保存されます。"
      : "コース図の画像をマップにドラッグ&ドロップすると背景に敷けます。";
  }

  function loadImage(source, options = {}) {
    const image = new Image();
    image.onload = () => {
      imageSource = source;
      if (options.resetImageParams) {
        const defaults = { ...defaultCalibration(bounds), ...buildTime };
        params = {
          ...params,
          centerX: defaults.centerX,
          centerZ: defaults.centerZ,
          widthM: defaults.widthM,
          rotationDeg: defaults.rotationDeg,
          opacity: defaults.opacity,
          flipX: defaults.flipX,
          flipY: defaults.flipY
        };
        writeStored(storageKey(slug, "calib"), params);
      }
      if (options.persist !== false) writeStored(storageKey(slug, "image"), source);
      buildControls();
      setImageActions(true);
      trackMap.setBackground(image, params);
    };
    image.onerror = () => window.alert("画像を読み込めませんでした。");
    image.src = source;
  }

  function readFile(file) {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => loadImage(String(reader.result), { resetImageParams: true });
    reader.readAsDataURL(file);
  }

  /* ---------- drag and drop ---------- */

  const stage = elements.stage;
  ["dragenter", "dragover"].forEach((type) =>
    stage.addEventListener(type, (event) => {
      event.preventDefault();
      stage.classList.add("is-dragover");
    })
  );
  ["dragleave", "drop"].forEach((type) =>
    stage.addEventListener(type, (event) => {
      event.preventDefault();
      if (type === "dragleave" && stage.contains(event.relatedTarget)) return;
      stage.classList.remove("is-dragover");
    })
  );
  stage.addEventListener("drop", (event) => {
    readFile(event.dataTransfer && event.dataTransfer.files[0]);
  });

  /* ---------- actions ---------- */

  elements.reset.addEventListener("click", () => {
    params = { ...defaultCalibration(bounds), ...buildTime };
    writeStored(storageKey(slug, "calib"), params);
    buildControls();
    apply();
  });

  elements.remove.addEventListener("click", () => {
    imageSource = null;
    window.localStorage.removeItem(storageKey(slug, "image"));
    buildControls();
    setImageActions(false);
    trackMap.setBackground(null, params);
  });

  elements.exportButton.addEventListener("click", () => {
    const snippet = JSON.stringify({ [slug]: { calibration: params } }, null, 2);
    const fallback = () => window.prompt("この内容を tracks.json にコピーしてください", snippet);
    if (navigator.clipboard) {
      navigator.clipboard
        .writeText(snippet)
        .then(() => window.alert("位置合わせ設定をクリップボードにコピーしました。\n\n" + snippet), fallback);
    } else {
      fallback();
    }
  });

  buildControls();
  setImageActions(false);
  state.set({ mapRotationDeg: params.mapRotationDeg });

  /* A previously dropped image wins over the build-time one, since it is the
     more recent expression of what the user wants to see. */
  const stored = readStored(storageKey(slug, "image"), null);
  const embedded = data.payload.meta.trackImage;
  if (stored) loadImage(stored, { persist: false });
  else if (embedded) loadImage(embedded, { persist: false });
}
