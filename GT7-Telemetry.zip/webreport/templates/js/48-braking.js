"use strict";

/* How hard each axle works under braking, and where the fronts ran out of grip.
 *
 * The numbers are measured in webreport/brakebalance.py on the raw 60 Hz laps;
 * see that module for how and on what data. This file only words them.
 *
 * GT7 never sends the brake balance or ABS setting, so nothing here may read as
 * a statement about the setting. The panel keeps three kinds of figure apart:
 * what was measured, what was judged against a line (and which line), and what
 * the driver typed in themselves. */

const BRAKE_MEMO_PREFIX = "gt7-brake-memo:";

function hasBraking(data) {
  const braking = data.payload && data.payload.braking;
  return Boolean(braking && braking.laps && braking.laps.length === data.laps.length);
}

function medianOf(values) {
  const sorted = values.filter((value) => value !== null && Number.isFinite(value)).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

/* This session's laps in the reference lap's car. Laps carried in from another
   day are left out: they may have been driven on another setting. */
function brakingPool(data, refIndex) {
  return sameCarLapIndexes(data, refIndex).filter((index) => !data.laps[index].isHistory);
}

/* Session medians of the axle slip under straight-line full braking. */
function brakingSplit(data, lapIndexes) {
  if (!hasBraking(data)) return null;
  const entries = lapIndexes.map((index) => data.payload.braking.laps[index]);
  const front = medianOf(entries.map((entry) => entry.frontSlipPct));
  const rear = medianOf(entries.map((entry) => entry.rearSlipPct));
  if (front === null || rear === null) return null;
  return { front, rear, laps: entries.filter((entry) => entry.frontSlipPct !== null).length };
}

/* Which way the measurements point. Direction only: the setting is unknown, so
   "how many clicks" and "already at the end stop" are the driver's to judge. */
function balanceDirection(split, ratio) {
  if (!split) return null;
  if (split.rear >= split.front) return "forward";
  if (split.rear <= 0 || split.front / split.rear >= ratio) return "rearward";
  return "even";
}

function balanceSentence(direction) {
  if (direction === "rearward") {
    return (
      "後輪にまだ余裕があります。いまの設定より<b>後ろ寄り</b>を試す価値があります。" +
      "もう後ろいっぱいなら、曲がりながらのブレーキを早めに緩めるほうで詰めてください。"
    );
  }
  if (direction === "forward") {
    return "後輪が前輪と同じかそれ以上に滑っています。いまの設定より<b>前寄り</b>を試す価値があります。";
  }
  if (direction === "even") {
    return "前後はおおむね釣り合っています。バランスより、ブレーキの踏み方と緩め方で詰めるところです。";
  }
  return "";
}

/* Grid index for a lap progress fraction. */
function progressIndex(data, progress) {
  return Math.max(0, Math.min(data.points - 1, Math.round(progress * (data.points - 1))));
}

function segmentAtIndex(data, index) {
  return data.segments.find((segment) => index >= segment.start && index <= segment.end) || null;
}

/* Front-limit events per corner across the given laps, busiest first. */
function frontLimitByCorner(data, lapIndexes) {
  if (!hasBraking(data)) return [];
  const counts = new Map();
  for (const lapIndex of lapIndexes) {
    for (const progress of data.payload.braking.laps[lapIndex].events) {
      const segment = segmentAtIndex(data, progressIndex(data, progress));
      if (!segment) continue;
      counts.set(segment.id, (counts.get(segment.id) || 0) + 1);
    }
  }
  return data.segments
    .filter((segment) => counts.has(segment.id))
    .map((segment) => ({ segment, count: counts.get(segment.id), perLap: counts.get(segment.id) / lapIndexes.length }))
    .sort((a, b) => b.count - a.count);
}

/* Grid indexes of one lap's events, for the track map. */
function frontLimitIndexes(data, lapIndex) {
  if (!hasBraking(data)) return [];
  return data.payload.braking.laps[lapIndex].events.map((progress) => progressIndex(data, progress));
}

function brakeMemoKey(data) {
  const meta = data.payload.meta || {};
  return BRAKE_MEMO_PREFIX + (meta.trackSlug || "") + "|" + (meta.sessionSummary || "");
}

function readBrakeMemo(data) {
  try {
    return localStorage.getItem(brakeMemoKey(data)) || "";
  } catch (error) {
    return "";
  }
}

function writeBrakeMemo(data, text) {
  try {
    if (text) localStorage.setItem(brakeMemoKey(data), text);
    else localStorage.removeItem(brakeMemoKey(data));
  } catch (error) {
    // Private windows and locked-down browsers refuse storage; the memo is a
    // convenience, so it simply does not persist there.
  }
}

function splitBar(label, value, scale, color) {
  const width = Math.max(2, Math.min(100, (value / scale) * 100));
  return (
    '<div class="brake-bar">' +
    `<span class="brake-bar__label">${label}</span>` +
    `<span class="brake-bar__track"><span class="brake-bar__fill" style="width:${width}%;background:${color}"></span></span>` +
    `<span class="brake-bar__value">${value.toFixed(1)}%</span>` +
    "</div>"
  );
}

function renderBraking(data, state, elements, onSelect) {
  if (!elements.panel) return;
  if (!data.hasExtended || !hasBraking(data)) {
    elements.panel.hidden = true;
    return;
  }
  elements.panel.hidden = false;

  const s = state.get();
  const pool = brakingPool(data, s.refIndex);
  const braking = data.payload.braking;
  const split = brakingSplit(data, pool);
  const carId = data.laps[s.refIndex].carId;
  const referencePct = braking.referenceSlipPct ? braking.referenceSlipPct[String(carId)] : null;

  if (split) {
    const scale = Math.max(split.front, split.rear) * 1.15;
    const direction = balanceDirection(split, braking.rearRoomRatio);
    elements.split.innerHTML =
      '<p class="brake-kind brake-kind--measured">測定値</p>' +
      '<p class="subtle">まっすぐ全開でブレーキしている間の、タイヤの滑り（このセッション ' +
      `${split.laps}周の中央値）。大きいほど限界に近い。</p>` +
      splitBar("前輪", split.front, scale, COLORS.loss) +
      splitBar("後輪", split.rear, scale, COLORS.ref) +
      `<p class="brake-verdict">前は後ろの <b>${(split.front / Math.max(split.rear, 0.01)).toFixed(1)}倍</b> 滑っています。` +
      balanceSentence(direction) +
      "</p>" +
      `<p class="subtle">後ろ寄りを勧める境目は「前が後ろの${braking.rearRoomRatio}倍以上」。` +
      "設定の値はゲームから送られてこないので、ここで分かるのは動かす向きまでです。</p>";
  } else {
    elements.split.innerHTML =
      '<p class="subtle">まっすぐ全開でブレーキした区間が短く、前後の滑りを比べられませんでした。</p>';
  }

  const corners = frontLimitByCorner(data, pool);
  const head =
    '<p class="brake-kind brake-kind--judged">判定（境目あり）</p>' +
    '<p class="subtle">曲がりながらのブレーキで、前輪（左右で滑りが大きい側）が「まっすぐ全開ブレーキの時」' +
    (referencePct === null || referencePct === undefined ? "" : `（${referencePct.toFixed(1)}%）`) +
    "以上に滑った所。そこでは曲がるためのグリップが残っていません。マップの「前輪の限界」で場所を見られます。</p>";
  if (corners.length) {
    const total = corners.reduce((sum, entry) => sum + entry.count, 0);
    elements.corners.innerHTML =
      head +
      `<p class="brake-verdict">${pool.length}周で <b>${total}回</b>（1周あたり ${(total / pool.length).toFixed(1)}回）。` +
      `一番多いのは <b>${corners[0].segment.name}</b> です。</p>` +
      '<div class="brake-corners">' +
      corners
        .map(
          (entry) =>
            `<div class="brake-corner" data-segment="${entry.segment.id}">` +
            `<span>${entry.segment.name}</span><span>${entry.count}回</span>` +
            `<span class="subtle">1周 ${entry.perLap.toFixed(1)}回</span></div>`
        )
        .join("") +
      "</div>";
    elements.corners.querySelectorAll(".brake-corner").forEach((node) => {
      node.addEventListener("click", () => onSelect(node.dataset.segment));
    });
  } else {
    elements.corners.innerHTML =
      head + '<p class="brake-verdict">このセッションでは一度もありませんでした。</p>';
  }

  if (elements.memo && !elements.memo.dataset.bound) {
    elements.memo.dataset.bound = "1";
    elements.memo.value = readBrakeMemo(data);
    elements.memo.addEventListener("input", () => writeBrakeMemo(data, elements.memo.value.trim()));
  }
}
