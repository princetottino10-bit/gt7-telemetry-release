"use strict";

/* Distance-axis telemetry charts: delta, speed, pedals and gear. */

const PLOT = { left: 48, right: 12, top: 10, bottom: 6 };
const AXIS_HEIGHT = 18;

function createCharts(data, state, container) {
  const charts = [];

  function addChart(config) {
    const wrapper = document.createElement("div");
    wrapper.className = "chart";
    const canvas = document.createElement("canvas");
    const label = document.createElement("span");
    label.className = "chart__label";
    label.textContent = config.label;
    wrapper.append(canvas, label);
    container.append(wrapper);
    const chart = { ...config, canvas, wrapper };
    charts.push(chart);
    attachPointer(chart);
    return chart;
  }

  function xForIndex(index, width, zoom) {
    const span = Math.max(1, zoom[1] - zoom[0]);
    return PLOT.left + ((index - zoom[0]) / span) * (width - PLOT.left - PLOT.right);
  }

  function indexForX(px, width, zoom) {
    const span = Math.max(1, zoom[1] - zoom[0]);
    const inner = width - PLOT.left - PLOT.right;
    const ratio = (px - PLOT.left) / inner;
    return Math.round(zoom[0] + Math.max(0, Math.min(1, ratio)) * span);
  }

  function drawFrame(ctx, width, height, chart, s) {
    const plotBottom = height - PLOT.bottom - (chart.axis ? AXIS_HEIGHT : 0);
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;

    for (const segment of data.segments) {
      if (segment.start < s.zoom[0] || segment.start > s.zoom[1]) continue;
      const x = Math.round(xForIndex(segment.start, width, s.zoom)) + 0.5;
      const active = segment.id === s.activeSegment;
      ctx.strokeStyle = active ? "rgba(42, 212, 232, 0.55)" : COLORS.gridStrong;
      ctx.beginPath();
      ctx.moveTo(x, PLOT.top);
      ctx.lineTo(x, plotBottom);
      ctx.stroke();
    }

    ctx.strokeStyle = COLORS.gridStrong;
    ctx.beginPath();
    ctx.moveTo(PLOT.left, plotBottom + 0.5);
    ctx.lineTo(width - PLOT.right, plotBottom + 0.5);
    ctx.stroke();

    if (chart.axis) {
      ctx.fillStyle = COLORS.textFaint;
      ctx.font = "10px ui-monospace, monospace";
      ctx.textBaseline = "top";
      const ticks = 6;
      for (let t = 0; t <= ticks; t += 1) {
        const index = Math.round(s.zoom[0] + ((s.zoom[1] - s.zoom[0]) * t) / ticks);
        const x = xForIndex(index, width, s.zoom);
        ctx.textAlign = t === 0 ? "left" : t === ticks ? "right" : "center";
        ctx.fillText(`${Math.round(data.distance[index])}m`, x, plotBottom + 4);
      }
    }
    return plotBottom;
  }

  function drawYAxis(ctx, values, yFor, format) {
    const label = format || ((value) => String(value));
    ctx.fillStyle = COLORS.textFaint;
    ctx.font = "10px ui-monospace, monospace";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    for (const value of values) {
      ctx.fillText(label(value), PLOT.left - 6, yFor(value));
    }
  }

  function drawGridLines(ctx, values, yFor, width) {
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    for (const value of values) {
      const y = Math.round(yFor(value)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(PLOT.left, y);
      ctx.lineTo(width - PLOT.right, y);
      ctx.stroke();
    }
  }

  function drawSeries(ctx, series, yFor, width, zoom, style) {
    ctx.beginPath();
    for (let i = zoom[0]; i <= zoom[1]; i += 1) {
      const x = xForIndex(i, width, zoom);
      const y = yFor(series[i]);
      if (i === zoom[0]) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = style.color;
    ctx.lineWidth = style.width || 1.6;
    ctx.setLineDash(style.dash || []);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  function fillBetween(ctx, series, baseline, yFor, width, zoom, color) {
    ctx.beginPath();
    ctx.moveTo(xForIndex(zoom[0], width, zoom), yFor(baseline));
    for (let i = zoom[0]; i <= zoom[1]; i += 1) {
      ctx.lineTo(xForIndex(i, width, zoom), yFor(series[i]));
    }
    ctx.lineTo(xForIndex(zoom[1], width, zoom), yFor(baseline));
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }

  function drawCursorLine(ctx, s, width, plotBottom) {
    if (s.cursor === null || s.cursor < s.zoom[0] || s.cursor > s.zoom[1]) return;
    const x = Math.round(xForIndex(s.cursor, width, s.zoom)) + 0.5;
    ctx.strokeStyle = "rgba(232, 237, 244, 0.55)";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(x, PLOT.top);
    ctx.lineTo(x, plotBottom);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  function drawSelection(ctx, s, width, plotBottom) {
    if (!s.selection) return;
    const [a, b] = s.selection;
    const x1 = xForIndex(Math.min(a, b), width, s.zoom);
    const x2 = xForIndex(Math.max(a, b), width, s.zoom);
    ctx.fillStyle = "rgba(42, 212, 232, 0.16)";
    ctx.fillRect(x1, PLOT.top, x2 - x1, plotBottom - PLOT.top);
  }

  /* ---------- individual charts ---------- */

  const deltaChart = addChart({
    label: "デルタタイム (s)",
    height: 158,
    render(ctx, width, height, s) {
      const plotBottom = drawFrame(ctx, width, height, this, s);
      const delta = s.delta;
      // Always keep the zero line in view; otherwise follow the data.
      let low = 0;
      let high = 0;
      for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
        if (delta[i] < low) low = delta[i];
        if (delta[i] > high) high = delta[i];
      }
      const pad = Math.max(0.02, (high - low) * 0.14);
      const lo = low - pad;
      const hi = high + pad;
      const yFor = (value) => plotBottom - ((value - lo) / (hi - lo)) * (plotBottom - PLOT.top);

      const stepCandidates = [0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5];
      const step = stepCandidates.find((candidate) => (hi - lo) / candidate <= 7) || 10;
      const ticks = [];
      for (let value = Math.ceil(lo / step) * step; value <= hi; value += step) {
        ticks.push(Number(value.toFixed(3)));
      }
      drawGridLines(ctx, ticks, yFor, width);
      drawYAxis(ctx, ticks, yFor, (value) => (value > 0 ? `+${value.toFixed(2)}` : value.toFixed(2)));

      // Split the fill at the zero line: above is time lost, below is time gained.
      ctx.save();
      ctx.beginPath();
      ctx.rect(PLOT.left, PLOT.top, width - PLOT.left - PLOT.right, yFor(0) - PLOT.top);
      ctx.clip();
      fillBetween(ctx, delta, 0, yFor, width, s.zoom, "rgba(255, 90, 95, 0.28)");
      ctx.restore();

      ctx.save();
      ctx.beginPath();
      ctx.rect(PLOT.left, yFor(0), width - PLOT.left - PLOT.right, plotBottom - yFor(0));
      ctx.clip();
      fillBetween(ctx, delta, 0, yFor, width, s.zoom, "rgba(53, 208, 127, 0.28)");
      ctx.restore();

      ctx.strokeStyle = COLORS.gridStrong;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(PLOT.left, Math.round(yFor(0)) + 0.5);
      ctx.lineTo(width - PLOT.right, Math.round(yFor(0)) + 0.5);
      ctx.stroke();

      drawSeries(ctx, delta, yFor, width, s.zoom, { color: COLORS.cmp, width: 1.8 });
      drawSelection(ctx, s, width, plotBottom);
      drawCursorLine(ctx, s, width, plotBottom);
    }
  });

  const speedChart = addChart({
    label: "速度 (km/h)",
    height: 150,
    render(ctx, width, height, s) {
      const plotBottom = drawFrame(ctx, width, height, this, s);
      const ref = data.channels.speed_kmh[s.refIndex];
      const cmp = data.channels.speed_kmh[s.cmpIndex];
      let min = Infinity;
      let max = -Infinity;
      for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
        min = Math.min(min, ref[i], cmp[i]);
        max = Math.max(max, ref[i], cmp[i]);
      }
      const pad = Math.max(6, (max - min) * 0.1);
      const lo = Math.max(0, min - pad);
      const hi = max + pad;
      const yFor = (value) => plotBottom - ((value - lo) / (hi - lo)) * (plotBottom - PLOT.top);

      const step = hi - lo > 220 ? 50 : hi - lo > 90 ? 25 : 10;
      const ticks = [];
      for (let value = Math.ceil(lo / step) * step; value <= hi; value += step) ticks.push(value);
      drawGridLines(ctx, ticks, yFor, width);
      drawYAxis(ctx, ticks, yFor, "");

      drawSeries(ctx, ref, yFor, width, s.zoom, { color: COLORS.ref, width: 1.5 });
      drawSeries(ctx, cmp, yFor, width, s.zoom, { color: COLORS.cmp, width: 1.7 });
      drawSelection(ctx, s, width, plotBottom);
      drawCursorLine(ctx, s, width, plotBottom);
    }
  });

  function pedalChart(label, channel, refColor, cmpColor) {
    return addChart({
      label,
      height: 88,
      render(ctx, width, height, s) {
        const plotBottom = drawFrame(ctx, width, height, this, s);
        const ref = data.channels[channel][s.refIndex];
        const cmp = data.channels[channel][s.cmpIndex];
        const yFor = (value) => plotBottom - (value / 100) * (plotBottom - PLOT.top);
        drawGridLines(ctx, [50, 100], yFor, width);
        drawYAxis(ctx, [0, 50, 100], yFor, "");
        fillBetween(ctx, ref, 0, yFor, width, s.zoom, refColor);
        drawSeries(ctx, cmp, yFor, width, s.zoom, { color: cmpColor, width: 1.5 });
        drawSelection(ctx, s, width, plotBottom);
        drawCursorLine(ctx, s, width, plotBottom);
      }
    });
  }

  pedalChart("スロットル (%)", "throttle_pct", "rgba(42, 212, 232, 0.22)", COLORS.cmp);
  pedalChart("ブレーキ (%)", "brake_pct", "rgba(255, 90, 95, 0.2)", COLORS.cmp);

  addChart({
    label: "ライン差 (m) · 上=右 / 下=左",
    height: 96,
    render(ctx, width, height, s) {
      const plotBottom = drawFrame(ctx, width, height, this, s);
      const offset = s.lateral;
      const limit = Math.max(0.4, percentileAbs(offset, s.zoom[0], s.zoom[1], 0.97) * 1.2);
      const yFor = (value) =>
        PLOT.top + ((limit - value) / (limit * 2)) * (plotBottom - PLOT.top);

      const stepCandidates = [0.25, 0.5, 1, 2, 5, 10];
      const step = stepCandidates.find((candidate) => limit / candidate <= 3) || 20;
      const ticks = [];
      for (let value = -Math.floor(limit / step) * step; value <= limit; value += step) {
        ticks.push(Number(value.toFixed(2)));
      }
      drawGridLines(ctx, ticks, yFor, width);
      drawYAxis(ctx, ticks, yFor, (value) => value.toFixed(step < 1 ? 2 : 0));

      // Clip so a lap that runs off the scale stays inside its own panel.
      ctx.save();
      ctx.beginPath();
      ctx.rect(PLOT.left, PLOT.top, width - PLOT.left - PLOT.right, plotBottom - PLOT.top);
      ctx.clip();
      fillBetween(ctx, offset, 0, yFor, width, s.zoom, "rgba(167, 139, 250, 0.18)");
      drawSeries(ctx, offset, yFor, width, s.zoom, { color: "#a78bfa", width: 1.6 });
      ctx.restore();

      ctx.strokeStyle = COLORS.gridStrong;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(PLOT.left, Math.round(yFor(0)) + 0.5);
      ctx.lineTo(width - PLOT.right, Math.round(yFor(0)) + 0.5);
      ctx.stroke();

      drawSelection(ctx, s, width, plotBottom);
      drawCursorLine(ctx, s, width, plotBottom);
    }
  });

  // Only sessions captured by capture_gt7.py carry these.
  if (data.hasExtended) {
    addChart({
      label: "スライド角 (°) · 車体の向きと進行方向の差",
      height: 96,
      render(ctx, width, height, s) {
        const plotBottom = drawFrame(ctx, width, height, this, s);
        const ref = data.extended.slideAngle[s.refIndex];
        const cmp = data.extended.slideAngle[s.cmpIndex];
        let peak = 2;
        for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
          peak = Math.max(peak, Math.abs(ref[i]), Math.abs(cmp[i]));
        }
        const limit = peak * 1.15;
        const yFor = (value) =>
          PLOT.top + ((limit - value) / (limit * 2)) * (plotBottom - PLOT.top);

        const step = limit > 12 ? 10 : limit > 6 ? 5 : 2;
        const ticks = [];
        for (let value = -Math.floor(limit / step) * step; value <= limit; value += step) {
          ticks.push(value);
        }
        drawGridLines(ctx, ticks, yFor, width);
        drawYAxis(ctx, ticks, yFor, (value) => value.toFixed(0));

        ctx.save();
        ctx.beginPath();
        ctx.rect(PLOT.left, PLOT.top, width - PLOT.left - PLOT.right, plotBottom - PLOT.top);
        ctx.clip();
        fillBetween(ctx, cmp, 0, yFor, width, s.zoom, "rgba(255, 138, 40, 0.16)");
        drawSeries(ctx, ref, yFor, width, s.zoom, { color: COLORS.ref, width: 1.3 });
        drawSeries(ctx, cmp, yFor, width, s.zoom, { color: "#ff8a28", width: 1.7 });
        ctx.restore();

        drawSelection(ctx, s, width, plotBottom);
        drawCursorLine(ctx, s, width, plotBottom);
      }
    });

    addChart({
      label: "スリップ比 · 1.0=転がり / 上=空転 / 下=ロック",
      height: 96,
      render(ctx, width, height, s) {
        const plotBottom = drawFrame(ctx, width, height, this, s);
        const front = data.extended.slipFront[s.cmpIndex];
        const rear = data.extended.slipRear[s.cmpIndex];
        let spread = 0.05;
        for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
          spread = Math.max(spread, Math.abs(front[i] - 1), Math.abs(rear[i] - 1));
        }
        const limit = spread * 1.2;
        const yFor = (value) =>
          PLOT.top + ((1 + limit - value) / (limit * 2)) * (plotBottom - PLOT.top);

        const step = limit > 0.4 ? 0.25 : limit > 0.15 ? 0.1 : 0.05;
        const ticks = [];
        for (let offset = -Math.floor(limit / step) * step; offset <= limit; offset += step) {
          ticks.push(Number((1 + offset).toFixed(3)));
        }
        drawGridLines(ctx, ticks, yFor, width);
        drawYAxis(ctx, ticks, yFor, (value) => value.toFixed(2));

        ctx.strokeStyle = COLORS.gridStrong;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(PLOT.left, Math.round(yFor(1)) + 0.5);
        ctx.lineTo(width - PLOT.right, Math.round(yFor(1)) + 0.5);
        ctx.stroke();

        ctx.save();
        ctx.beginPath();
        ctx.rect(PLOT.left, PLOT.top, width - PLOT.left - PLOT.right, plotBottom - PLOT.top);
        ctx.clip();
        drawSeries(ctx, front, yFor, width, s.zoom, { color: "#38bdf8", width: 1.5 });
        drawSeries(ctx, rear, yFor, width, s.zoom, { color: "#ff5a5f", width: 1.5 });
        ctx.restore();

        drawSelection(ctx, s, width, plotBottom);
        drawCursorLine(ctx, s, width, plotBottom);
      }
    });
  }

  // Tyre temperature, one line per wheel, for the comparison lap. Read against
  // 46-tyres.js: the spread between the four lines is the story, not the level.
  if (hasTyreTemps(data)) {
    addChart({
      label: "タイヤ温度 (°C) · 比較ラップの4輪",
      height: 110,
      render(ctx, width, height, s) {
        const plotBottom = drawFrame(ctx, width, height, this, s);
        const series = TYRE_WHEELS.map((wheel) => data.extended[wheel.key][s.cmpIndex]);
        let min = Infinity;
        let max = -Infinity;
        for (const values of series) {
          for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
            if (values[i] < min) min = values[i];
            if (values[i] > max) max = values[i];
          }
        }
        const pad = Math.max(3, (max - min) * 0.1);
        const lo = min - pad;
        const hi = max + pad;
        const yFor = (value) => plotBottom - ((value - lo) / (hi - lo)) * (plotBottom - PLOT.top);

        const step = hi - lo > 120 ? 40 : hi - lo > 60 ? 20 : hi - lo > 25 ? 10 : 5;
        const ticks = [];
        for (let value = Math.ceil(lo / step) * step; value <= hi; value += step) ticks.push(value);
        drawGridLines(ctx, ticks, yFor, width);
        drawYAxis(ctx, ticks, yFor, (value) => value.toFixed(0));

        ctx.save();
        ctx.beginPath();
        ctx.rect(PLOT.left, PLOT.top, width - PLOT.left - PLOT.right, plotBottom - PLOT.top);
        ctx.clip();
        series.forEach((values, index) => {
          drawSeries(ctx, values, yFor, width, s.zoom, {
            color: TYRE_WHEELS[index].color,
            width: 1.4
          });
        });
        ctx.restore();

        // Without a key the four lines are unreadable; the chart is too short to
        // carry a separate legend element, so it is painted into the top right -
        // the chart's own caption already occupies the left.
        ctx.font = "10px ui-monospace, monospace";
        ctx.textAlign = "left";
        ctx.textBaseline = "top";
        const entries = TYRE_WHEELS.map((wheel) => ({
          wheel,
          span: 12 + ctx.measureText(wheel.label).width + 10
        }));
        let x = width - PLOT.right - entries.reduce((total, entry) => total + entry.span, 0);
        for (const entry of entries) {
          ctx.fillStyle = entry.wheel.color;
          ctx.fillRect(x, PLOT.top + 4, 8, 2);
          ctx.fillText(entry.wheel.label, x + 12, PLOT.top);
          x += entry.span;
        }

        drawSelection(ctx, s, width, plotBottom);
        drawCursorLine(ctx, s, width, plotBottom);
      }
    });
  }

  addChart({
    label: "ギア",
    height: 84,
    axis: true,
    render(ctx, width, height, s) {
      const plotBottom = drawFrame(ctx, width, height, this, s);
      const ref = data.channels.gear[s.refIndex];
      const cmp = data.channels.gear[s.cmpIndex];
      let max = 1;
      for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) max = Math.max(max, ref[i], cmp[i]);
      const lo = 0.5;
      const hi = max + 0.5;
      const yFor = (value) => plotBottom - ((value - lo) / (hi - lo)) * (plotBottom - PLOT.top);
      const ticks = [];
      for (let gear = 1; gear <= max; gear += 1) ticks.push(gear);
      drawGridLines(ctx, ticks, yFor, width);
      drawYAxis(ctx, ticks, yFor, "");

      for (const [series, style] of [
        [ref, { color: COLORS.ref, width: 1.4 }],
        [cmp, { color: COLORS.cmp, width: 1.6 }]
      ]) {
        ctx.beginPath();
        for (let i = s.zoom[0]; i <= s.zoom[1]; i += 1) {
          const x = xForIndex(i, width, s.zoom);
          const y = yFor(series[i]);
          if (i === s.zoom[0]) ctx.moveTo(x, y);
          else {
            ctx.lineTo(x, yFor(series[i - 1]));
            ctx.lineTo(x, y);
          }
        }
        ctx.strokeStyle = style.color;
        ctx.lineWidth = style.width;
        ctx.stroke();
      }
      drawSelection(ctx, s, width, plotBottom);
      drawCursorLine(ctx, s, width, plotBottom);
    }
  });

  /* ---------- interaction ---------- */

  function attachPointer(chart) {
    let dragStart = null;

    chart.canvas.addEventListener("pointermove", (event) => {
      const rect = chart.canvas.getBoundingClientRect();
      const index = indexForX(event.clientX - rect.left, rect.width, state.get().zoom);
      if (dragStart !== null) {
        state.set({ cursor: index, selection: [dragStart, index] });
      } else {
        state.set({ cursor: index });
      }
    });

    chart.canvas.addEventListener("pointerdown", (event) => {
      const rect = chart.canvas.getBoundingClientRect();
      dragStart = indexForX(event.clientX - rect.left, rect.width, state.get().zoom);
      chart.canvas.setPointerCapture(event.pointerId);
    });

    chart.canvas.addEventListener("pointerup", () => {
      const s = state.get();
      if (s.selection) {
        const [a, b] = s.selection;
        const lo = Math.min(a, b);
        const hi = Math.max(a, b);
        // Ignore accidental micro-drags; treat them as a plain click.
        if (hi - lo > 12) state.set({ zoom: [lo, hi], activeSegment: null });
      }
      dragStart = null;
      state.set({ selection: null });
    });

    chart.canvas.addEventListener("pointerleave", () => {
      if (dragStart === null) state.set({ cursor: null });
    });

    chart.canvas.addEventListener("dblclick", () => {
      state.set({ zoom: [0, data.points - 1], activeSegment: null, selection: null });
    });
  }

  function render() {
    const s = state.get();
    for (const chart of charts) {
      const fitted = fitCanvas(chart.canvas, chart.height);
      if (!fitted) continue;
      chart.render(fitted.ctx, fitted.width, fitted.height, s);
    }
  }

  return { render };
}
