"use strict";

/* Ghost playback: replays two laps against the same clock so the moment a gap
   opens is visible rather than inferred from a graph. */

const GHOST_RATES = [0.25, 0.5, 1, 2];

/* Fractional grid index a lap has reached at elapsed time `seconds`. */
function indexAtTime(data, lapIndex, seconds) {
  const elapsed = data.channels.time_s[lapIndex];
  const last = data.points - 1;
  if (seconds <= 0) return 0;
  if (seconds >= elapsed[last]) return last;

  let low = 0;
  let high = last;
  while (high - low > 1) {
    const middle = (low + high) >> 1;
    if (elapsed[middle] <= seconds) low = middle;
    else high = middle;
  }
  const span = elapsed[high] - elapsed[low];
  const t = span > 0 ? (seconds - elapsed[low]) / span : 0;
  return low + t;
}

/* World position of a lap at a fractional grid index. */
function positionAtIndex(data, lapIndex, index) {
  const xs = data.channels.x[lapIndex];
  const zs = data.channels.z[lapIndex];
  const low = Math.floor(index);
  const high = Math.min(data.points - 1, low + 1);
  const t = index - low;
  return {
    x: xs[low] + (xs[high] - xs[low]) * t,
    z: zs[low] + (zs[high] - zs[low]) * t,
    index
  };
}

function ghostDuration(data, state) {
  const s = state.get();
  return Math.max(data.laps[s.refIndex].lapTimeS, data.laps[s.cmpIndex].lapTimeS);
}

/* The stretch of the clock a segment occupies, taken from the reference lap.
   The two cars are played against one shared clock, so one lap has to define
   the window; the reference is the one every gap in the report is measured
   from. A little air either side, so the corner is entered rather than begun
   halfway through. */
function segmentWindowOf(data, state, segmentId) {
  const segment = data.segments.find((entry) => entry.id === segmentId);
  if (!segment) return null;
  const times = data.channels.time_s[state.get().refIndex];
  const start = times[segment.start];
  const end = times[segment.end];
  if (!isFinite(start) || !isFinite(end) || end <= start) return null;
  const pad = Math.min(1.2, (end - start) * 0.2);
  return { start: Math.max(0, start - pad), end: end + pad };
}

function createGhostPlayer(data, state, elements) {
  let rafId = null;
  let lastFrame = null;
  // While set, playback loops over one corner instead of running the whole lap.
  let window = null;

  function stop() {
    if (rafId !== null) cancelAnimationFrame(rafId);
    rafId = null;
    lastFrame = null;
    elements.play.textContent = "▶ 再生";
    state.set({ ghostPlaying: false });
  }

  function begin() {
    elements.play.textContent = "❚❚ 停止";
    state.set({ ghostPlaying: true });
    lastFrame = null;
    if (rafId === null) rafId = requestAnimationFrame(step);
  }

  /* Zooming into a corner starts the two cars round it, over and over. Watching
     the same corner repeat is how the difference between the laps becomes
     visible; having to find the play button and scrub to the right moment first
     is why nobody did it. */
  function playSegment(segmentId) {
    const found = segmentWindowOf(data, state, segmentId);
    if (!found) return;
    window = found;
    applyTime(window.start);
    begin();
  }

  function playWholeLap() {
    window = null;
  }

  function step(now) {
    const s = state.get();
    if (!s.ghostPlaying) return;
    const elapsed = lastFrame === null ? 0 : (now - lastFrame) / 1000;
    lastFrame = now;

    const duration = ghostDuration(data, state);
    let next = s.ghostTime + elapsed * s.ghostRate;
    if (window) {
      // Round and round one corner, rather than off down the rest of the lap.
      if (next >= window.end) next = window.start;
    } else if (next >= duration) {
      next = 0; // loop back to the start line
    }
    applyTime(next);
    rafId = requestAnimationFrame(step);
  }

  function applyTime(seconds) {
    const s = state.get();
    // Drive the shared cursor from the reference car so every chart follows.
    const cursor = Math.round(indexAtTime(data, s.refIndex, seconds));
    state.set({ ghostTime: seconds, cursor });
    updateReadout(seconds);
  }

  function updateReadout(seconds) {
    const s = state.get();
    const duration = ghostDuration(data, state);
    const refIndex = indexAtTime(data, s.refIndex, seconds);
    const cmpIndex = indexAtTime(data, s.cmpIndex, seconds);
    const refDistance = (refIndex / (data.points - 1)) * data.lapDistanceM;
    const cmpDistance = (cmpIndex / (data.points - 1)) * data.lapDistanceM;
    const metres = cmpDistance - refDistance;

    elements.seek.value = String(Math.round((seconds / duration) * 1000));
    elements.readout.innerHTML =
      `<b>${seconds.toFixed(2)}s</b> / ${duration.toFixed(2)}s · ` +
      `車間 <b class="${metres < 0 ? "v-cmp" : "v-ref"}">${Math.abs(metres).toFixed(1)}m</b> ` +
      (Math.abs(metres) < 0.5 ? "並走" : metres < 0 ? "基準がリード" : "比較がリード");
  }

  elements.play.addEventListener("click", () => {
    const s = state.get();
    if (s.ghostPlaying) {
      stop();
      return;
    }
    // Pressing play by hand means the whole lap, not the corner last looked at.
    playWholeLap();
    begin();
  });

  elements.seek.addEventListener("input", () => {
    playWholeLap();
    if (state.get().ghostPlaying) stop();
    const duration = ghostDuration(data, state);
    applyTime((Number(elements.seek.value) / 1000) * duration);
  });

  elements.rate.addEventListener("change", () => {
    state.set({ ghostRate: Number(elements.rate.value) });
  });

  elements.rate.innerHTML = GHOST_RATES.map(
    (rate) => `<option value="${rate}"${rate === 1 ? " selected" : ""}>${rate}x</option>`
  ).join("");

  updateReadout(0);
  return { stop, applyTime, playSegment, playWholeLap };
}
