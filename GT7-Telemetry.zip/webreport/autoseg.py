"""Derives circuit segments from the telemetry instead of hand-tuned fractions.

Corners show up as sustained speed minima. Each minimum is grown outwards until
the car has recovered most of the speed it lost, which gives the corner its own
segment; whatever is left between corners becomes a straight.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from webreport.peaks import find_peaks
from webreport.resample import Grid, LapTrace

# A dip has to drop this fraction of the lap's speed range below its surroundings
# before it counts as a corner rather than a lift or a bumpy patch.
MIN_PROMINENCE_RATIO = 0.04
# Apexes closer together than this belong to one complex (the esses, a chicane).
MIN_CORNER_SPACING_M = 45.0
# How much of the lost speed has to come back before the corner is over.
SPEED_RECOVERY_RATIO = 0.85
# Corners separated by less than this are merged; straights shorter than this are
# absorbed into the corner before them, since they cannot be timed meaningfully.
MIN_STRAIGHT_M = 110.0
# Smoothing window for the speed trace, in metres.
SMOOTHING_WINDOW_M = 25.0


@dataclass(frozen=True)
class DetectedSegment:
    """One detected stretch of circuit, in grid indices."""

    start: int
    end: int
    is_corner: bool
    min_speed_kmh: float
    max_speed_kmh: float


def _smooth(values: np.ndarray, window: int) -> np.ndarray:
    """Moving average that keeps the array length and respects the lap loop."""
    if window < 3:
        return values
    kernel = np.ones(window) / window
    padded = np.concatenate([values[-window:], values, values[:window]])
    smoothed = np.convolve(padded, kernel, mode="same")
    return smoothed[window : window + len(values)]


def reference_profile(traces: list[LapTrace], channel: str) -> np.ndarray:
    """Median of a channel across all laps: robust to one scrappy lap."""
    return np.median(np.vstack([trace.channel(channel) for trace in traces]), axis=0)


def smoothed_speed(traces: list[LapTrace], grid: Grid) -> np.ndarray:
    step_m = grid.lap_distance_m / (grid.points - 1)
    window = max(3, int(round(SMOOTHING_WINDOW_M / step_m)))
    return _smooth(reference_profile(traces, "speed_kmh"), window)


def find_apexes(speed: np.ndarray, grid: Grid) -> np.ndarray:
    """Returns grid indices of corner apexes, ordered by distance."""
    step_m = grid.lap_distance_m / (grid.points - 1)
    speed_range = float(speed.max() - speed.min())
    if speed_range <= 0:
        return np.asarray([], dtype=int)
    apexes = find_peaks(
        -speed,
        prominence=speed_range * MIN_PROMINENCE_RATIO,
        distance=max(1, int(round(MIN_CORNER_SPACING_M / step_m))),
    )
    return apexes.astype(int)


def _corner_extent(speed: np.ndarray, apex: int, low: int, high: int) -> tuple[int, int]:
    """Grows an apex outwards until most of the lost speed has been recovered."""
    apex_speed = float(speed[apex])
    peak_before = float(speed[low : apex + 1].max())
    peak_after = float(speed[apex : high + 1].max())
    entry_target = apex_speed + (peak_before - apex_speed) * SPEED_RECOVERY_RATIO
    exit_target = apex_speed + (peak_after - apex_speed) * SPEED_RECOVERY_RATIO

    start = apex
    while start > low and speed[start] < entry_target:
        start -= 1
    end = apex
    while end < high and speed[end] < exit_target:
        end += 1
    return start, end


def _corner_windows(speed: np.ndarray, apexes: np.ndarray, points: int) -> list[list[int]]:
    """Corner extents for every apex, merged where they touch."""
    windows: list[list[int]] = []
    for position, apex in enumerate(apexes):
        low = 0 if position == 0 else int(apexes[position - 1])
        high = points - 1 if position == len(apexes) - 1 else int(apexes[position + 1])
        start, end = _corner_extent(speed, int(apex), low, high)
        if windows and start <= windows[-1][1]:
            windows[-1][1] = max(windows[-1][1], end)
        else:
            windows.append([start, end])
    return windows


def _fill_gaps(windows: list[list[int]], points: int, min_gap: int) -> list[tuple[int, int, bool]]:
    """Turns corner windows into a continuous chain of corners and straights."""
    chain: list[tuple[int, int, bool]] = []
    cursor = 0
    for start, end in windows:
        if start > cursor:
            gap = start - cursor
            if gap < min_gap and chain:
                # Too short to time on its own: hand it to the previous corner.
                previous_start, _previous_end, was_corner = chain[-1]
                chain[-1] = (previous_start, start, was_corner)
            elif gap < min_gap:
                start = cursor
            else:
                chain.append((cursor, start, False))
        chain.append((start, end, True))
        cursor = end
    if cursor < points - 1:
        if (points - 1 - cursor) < min_gap and chain:
            previous_start, _previous_end, was_corner = chain[-1]
            chain[-1] = (previous_start, points - 1, was_corner)
        else:
            chain.append((cursor, points - 1, False))
    return chain


def detect(traces: list[LapTrace], grid: Grid) -> list[DetectedSegment]:
    """Splits the lap into corner and straight segments."""
    speed = smoothed_speed(traces, grid)
    apexes = find_apexes(speed, grid)
    step_m = grid.lap_distance_m / (grid.points - 1)
    min_gap = max(2, int(round(MIN_STRAIGHT_M / step_m)))

    if len(apexes) == 0:
        return [
            DetectedSegment(0, grid.points - 1, False, float(speed.min()), float(speed.max()))
        ]

    windows = _corner_windows(speed, apexes, grid.points)
    chain = _fill_gaps(windows, grid.points, min_gap)

    segments: list[DetectedSegment] = []
    for start, end, is_corner in chain:
        if end - start < 2:
            continue
        window = speed[start : end + 1]
        segments.append(
            DetectedSegment(
                start=start,
                end=end,
                is_corner=is_corner,
                min_speed_kmh=float(window.min()),
                max_speed_kmh=float(window.max()),
            )
        )
    return segments


def _name_segments(segments: list[DetectedSegment]) -> list[tuple[str, str, str]]:
    """Numbers corners and straights separately: (id, name, name_ja)."""
    names: list[tuple[str, str, str]] = []
    corner_index = 0
    straight_index = 0
    for segment in segments:
        if segment.is_corner:
            corner_index += 1
            names.append(
                # "Turn N", the way a circuit is talked about on a race broadcast.
                # Numbering is fixed the first time a circuit is driven and reused
                # after that, so "Turn 9" stays the same bend across sessions.
                (f"corner_{corner_index}", f"Turn {corner_index}", f"ターン{corner_index}")
            )
        else:
            straight_index += 1
            names.append(
                (f"straight_{straight_index}", f"Straight {straight_index}", f"ストレート{straight_index}")
            )
    return names


def to_definition(
    segments: list[DetectedSegment], grid: Grid, track_name: str
) -> dict[str, Any]:
    """Renders detected segments in the same shape as a hand-written definition."""
    last = grid.points - 1
    entries: list[dict[str, Any]] = []
    for (segment_id, name, name_ja), segment in zip(_name_segments(segments), segments):
        note = (
            f"最低速 {segment.min_speed_kmh:.0f}km/h"
            if segment.is_corner
            else f"最高速 {segment.max_speed_kmh:.0f}km/h"
        )
        entries.append(
            {
                "id": segment_id,
                "name": name,
                "name_ja": name_ja,
                "description_ja": f"自動検出 · {note}",
                "start_fraction": round(segment.start / last, 6),
                "end_fraction": round(segment.end / last, 6),
            }
        )
    # Rounding can leave hairline gaps; snap the chain back together.
    for previous, following in zip(entries[:-1], entries[1:]):
        following["start_fraction"] = previous["end_fraction"]
    if entries:
        entries[0]["start_fraction"] = 0.0
        entries[-1]["end_fraction"] = 1.0

    return {
        "track": track_name,
        "distance_basis": "fraction_of_reconstructed_lap_distance",
        "notes": [
            "Generated by make_segments.py from the median speed profile.",
            "Corners are speed minima grown out to where the speed recovers.",
            "Rename the segments to the real corner names to make the report readable.",
        ],
        "segments": entries,
    }
