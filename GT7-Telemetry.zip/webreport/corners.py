"""Gives a circuit's corners the numbers they go by, where those are known.

The report finds corners itself and counts them in order ("ターン1"...), which
matches nothing a driver reads or watches: at Interlagos the report's ターン4 is
what every guide calls T8 and T9. For a circuit listed in corner_numbers.json a
corner segment is named after the numbered corners inside it ("T8-9"); anywhere
else the counted names stay. The table goes into the page as well, so the
theory panel can name the halves of a segment it splits ("T8", "T9").
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

TABLE = Path(__file__).with_name("corner_numbers.json")


def load(slug: str) -> dict[str, Any] | None:
    try:
        table = json.loads(TABLE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    entry = table.get(slug)
    return entry if isinstance(entry, dict) and entry.get("corners") else None


def label(table: dict[str, Any], start: float, end: float) -> str | None:
    """The name for the stretch of lap [start, end] (fractions), or None."""
    inside = [corner for corner in table["corners"] if start <= corner["at"] <= end]
    major = [corner for corner in inside if not corner.get("minor")]
    numbers = [corner["n"] for corner in (major or inside)]
    if not numbers:
        return None
    key = str(numbers[0]) if len(numbers) == 1 else f"{numbers[0]}-{numbers[-1]}"
    name = table.get("names", {}).get(key)
    return f"T{key}" + (f" {name}" if name else "")


def apply(definition: dict[str, Any], slug: str) -> dict[str, Any] | None:
    """Renames the corner segments in place; returns the table for the page."""
    table = load(slug)
    if table is None:
        return None
    for segment in definition["segments"]:
        if not str(segment["id"]).startswith("corner_"):
            continue
        named = label(table, segment["start_fraction"], segment["end_fraction"])
        if named:
            segment["name"] = named
            segment["name_ja"] = named
    return table
