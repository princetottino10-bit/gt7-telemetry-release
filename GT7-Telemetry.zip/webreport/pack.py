"""Quantises the resampled telemetry into a compact, browser-readable payload."""

from __future__ import annotations

import base64
from typing import Any

import numpy as np

from webreport.resample import Grid, LapTrace
from webreport.sectors import SectorResult

# Per-channel quantisation. `scale` is the multiplier applied before rounding,
# so the stored resolution is 1/scale in the channel's own unit.
CHANNEL_CODECS: dict[str, dict[str, Any]] = {
    "time_s": {"dtype": "u32", "scale": 1000.0},
    "speed_kmh": {"dtype": "u16", "scale": 100.0},
    "throttle_pct": {"dtype": "u8", "scale": 2.55},
    "brake_pct": {"dtype": "u8", "scale": 2.55},
    "gear": {"dtype": "u8", "scale": 1.0},
    "rpm": {"dtype": "u16", "scale": 1.0},
}

NUMPY_DTYPES = {"u8": np.uint8, "u16": np.uint16, "u32": np.uint32}
DTYPE_MAX = {"u8": 255, "u16": 65535, "u32": 4294967295}

# Track coordinates share one offset and scale so the map keeps its aspect ratio.
COORDINATE_DTYPE = "u16"


def _encode(matrix: np.ndarray, dtype: str, scale: float, offset: float) -> dict[str, Any]:
    """Quantises a (laps x points) matrix into a base64 typed-array buffer."""
    scaled = np.rint((matrix - offset) * scale)
    clipped = np.clip(scaled, 0, DTYPE_MAX[dtype]).astype(NUMPY_DTYPES[dtype])
    return {
        "dtype": dtype,
        "scale": scale,
        "offset": offset,
        "data": base64.b64encode(clipped.tobytes()).decode("ascii"),
    }


def _stack(traces: list[LapTrace], channel: str) -> np.ndarray:
    return np.vstack([trace.channel(channel) for trace in traces])


def pack_channels(traces: list[LapTrace]) -> dict[str, Any]:
    """Encodes every scalar channel across all laps into one buffer per channel."""
    packed: dict[str, Any] = {}
    for name, codec in CHANNEL_CODECS.items():
        packed[name] = _encode(_stack(traces, name), codec["dtype"], codec["scale"], 0.0)
    return packed


def pack_coordinates(traces: list[LapTrace]) -> dict[str, Any]:
    """Encodes X/Z positions with a shared transform so the map stays undistorted."""
    xs = _stack(traces, "x")
    zs = _stack(traces, "z")
    x_min, x_max = float(xs.min()), float(xs.max())
    z_min, z_max = float(zs.min()), float(zs.max())
    span = max(x_max - x_min, z_max - z_min, 1.0)
    # Leave headroom so rounding at the extremes cannot overflow the range.
    scale = (DTYPE_MAX[COORDINATE_DTYPE] - 1) / span
    return {
        "bounds": {"xMin": x_min, "xMax": x_max, "zMin": z_min, "zMax": z_max},
        "x": _encode(xs, COORDINATE_DTYPE, scale, x_min),
        "z": _encode(zs, COORDINATE_DTYPE, scale, z_min),
    }


def lap_metadata(traces: list[LapTrace], reference_uid: str) -> list[dict[str, Any]]:
    """Describes each lap for the selector UI, in the order the buffers are packed."""
    entries: list[dict[str, Any]] = []
    for index, trace in enumerate(traces):
        lap = trace.lap
        entries.append(
            {
                "index": index,
                "uid": lap.uid,
                "title": lap.title,
                "lapTimeS": lap.lap_time_s,
                "number": lap.number,
                "carId": lap.car_id,
                "carName": lap.car_name,
                "sourceFile": lap.source_file,
                "startTimestamp": lap.start_timestamp,
                "isReference": lap.uid == reference_uid,
                # True for laps carried in from an earlier session on this track.
                "isHistory": bool(getattr(lap, "is_history", False)),
                # The lap to chase, from a session marked as the model.
                "isModel": bool(getattr(lap, "is_model", False)),
                "topSpeedKmh": float(trace.channel("speed_kmh").max()),
            }
        )
    return entries


# Extended channels, written only by capture_gt7.py. Names are shortened for the
# browser; the quantisation is chosen per family since their ranges differ.
EXTENDED_NAMES = {
    "data_slide_angle_deg": "slideAngle",
    "data_tire_slip_fl": "slipFL",
    "data_tire_slip_fr": "slipFR",
    "data_tire_slip_rl": "slipRL",
    "data_tire_slip_rr": "slipRR",
    "data_tire_temp_fl": "tempFL",
    "data_tire_temp_fr": "tempFR",
    "data_tire_temp_rl": "tempRL",
    "data_tire_temp_rr": "tempRR",
    "data_tcs": "tcs",
}


def _extended_codec(name: str) -> tuple[str, float, float]:
    """Returns (dtype, scale, offset) for one extended channel."""
    if name.startswith("data_tire_slip"):
        # Slip sits near 1.0; four decimal places is far more than needed but
        # still fits a lock-up or a big wheelspin inside 16 bits.
        return ("u16", 10000.0, 0.0)
    if name.startswith("data_tire_temp"):
        return ("u16", 100.0, 0.0)
    if name == "data_tcs":
        # 0/1 per sample; on the distance grid it becomes the share of samples
        # with traction control on, which a byte holds to the percent.
        return ("u8", 100.0, 0.0)
    if name == "data_slide_angle_deg":
        # Shifted so the whole +/-180 range is positive.
        return ("u16", 100.0, -180.0)
    return ("u16", 100.0, 0.0)


def extended_channel_names(traces: list[LapTrace]) -> list[str]:
    """The extended channels present on the resampled traces, if any."""
    if not traces:
        return []
    known = set(EXTENDED_NAMES)
    return sorted(name for name in traces[0].channels if name in known)


def pack_extended(traces: list[LapTrace]) -> dict[str, Any]:
    """Encodes the extended channels, keyed by their browser-side names."""
    packed: dict[str, Any] = {}
    for name in extended_channel_names(traces):
        dtype, scale, offset = _extended_codec(name)
        packed[EXTENDED_NAMES[name]] = _encode(_stack(traces, name), dtype, scale, offset)
    return packed


def pack_sectors(
    results: list[SectorResult], segments: list[dict[str, Any]], lap_order: list[str]
) -> list[dict[str, Any]]:
    """Groups sector metrics by segment, with one value per lap in packing order."""
    index_of = {uid: position for position, uid in enumerate(lap_order)}
    by_segment: dict[str, list[SectorResult | None]] = {
        str(segment["id"]): [None] * len(lap_order) for segment in segments
    }
    for result in results:
        bucket = by_segment.get(result.segment_id)
        if bucket is not None and result.lap_uid in index_of:
            bucket[index_of[result.lap_uid]] = result

    packed: list[dict[str, Any]] = []
    for segment in segments:
        segment_id = str(segment["id"])
        rows = by_segment[segment_id]
        packed.append(
            {
                "id": segment_id,
                "timeS": [None if row is None else round(row.time_s, 4) for row in rows],
                "minSpeedKmh": [None if row is None else round(row.min_speed_kmh, 2) for row in rows],
                "maxSpeedKmh": [None if row is None else round(row.max_speed_kmh, 2) for row in rows],
                "entrySpeedKmh": [None if row is None else round(row.entry_speed_kmh, 2) for row in rows],
                "exitSpeedKmh": [None if row is None else round(row.exit_speed_kmh, 2) for row in rows],
                "brakePointM": [None if row is None or row.brake_point_m is None else round(row.brake_point_m, 1) for row in rows],
                "fullThrottleM": [None if row is None or row.full_throttle_m is None else round(row.full_throttle_m, 1) for row in rows],
                # Null where the run looked like driving; otherwise the reason it
                # did not, which the browser shows and refuses to reason from.
                "flagged": [None if row is None or not row.flag_reason else row.flag_reason for row in rows],
                # 0..1 share of the corner's braking done while already turning.
                # Null on segments that are not braked corners, and throughout on
                # sessions with no usable yaw rate.
                "trailBrake": [
                    None if row is None or row.trail_brake_share is None else round(row.trail_brake_share, 4)
                    for row in rows
                ],
                # Seconds of traction-control intervention; null throughout on
                # sessions recorded before the flag was saved.
                "tcsS": [None if row is None or row.tcs_s is None else round(row.tcs_s, 3) for row in rows],
            }
        )
    return packed


def build_payload(
    traces: list[LapTrace],
    grid: Grid,
    segments: list[dict[str, Any]],
    sector_results: list[SectorResult],
    reference_uid: str,
    meta: dict[str, Any],
) -> dict[str, Any]:
    """Assembles the complete JSON payload embedded into the HTML report."""
    lap_order = [trace.uid for trace in traces]
    return {
        "meta": meta,
        "grid": {
            "points": grid.points,
            "lapDistanceM": grid.lap_distance_m,
        },
        "laps": lap_metadata(traces, reference_uid),
        "channels": pack_channels(traces),
        "track": pack_coordinates(traces),
        "segments": segments,
        "sectors": pack_sectors(sector_results, segments, lap_order),
        "extended": pack_extended(traces),
    }
