"""Peak detection, replacing the one function this project used SciPy for.

SciPy is 116 MB. `find_peaks` was the only thing taken from it, and the two
features actually used — prominence and a minimum spacing — are short to write.
Dropping the dependency is what makes it practical to ship Python alongside the
tool, so someone can run it without installing anything.

The behaviour matches `scipy.signal.find_peaks(values, prominence=..., distance=...)`;
`test_webreport.py` checks that against SciPy itself while it is still installed.
"""

from __future__ import annotations

import numpy as np


def _local_maxima(values: list[float]) -> list[int]:
    """Indices of local maxima, taking the middle sample of any flat top."""
    peaks: list[int] = []
    count = len(values)
    index = 1
    while index < count - 1:
        if values[index] <= values[index - 1]:
            index += 1
            continue
        # Walk to the end of a run of equal samples.
        ahead = index
        while ahead < count - 1 and values[ahead + 1] == values[index]:
            ahead += 1
        if ahead < count - 1 and values[ahead] > values[ahead + 1]:
            peaks.append((index + ahead) // 2)
        index = ahead + 1
    return peaks


def _prominence(values: list[float], peak: int) -> float:
    """How far a peak stands above the higher of the two saddles beside it.

    Walk outwards until the terrain rises above this peak (or the data runs
    out), tracking the lowest point on each side. The taller of those two
    lowest points is the base the peak is measured from.
    """
    height = values[peak]

    left_min = height
    index = peak
    while index > 0:
        index -= 1
        if values[index] > height:
            break
        if values[index] < left_min:
            left_min = values[index]

    right_min = height
    index = peak
    last = len(values) - 1
    while index < last:
        index += 1
        if values[index] > height:
            break
        if values[index] < right_min:
            right_min = values[index]

    return height - max(left_min, right_min)


def _enforce_spacing(peaks: list[int], heights: list[float], distance: float) -> list[int]:
    """Keeps the tallest peaks, dropping any that sit too close to a taller one."""
    if distance <= 1:
        return peaks

    keep = [True] * len(peaks)
    # Tallest first, so a peak is only ever removed in favour of a bigger one.
    # Ties go to the later peak, which is how SciPy's argsort ends up ordering
    # them; without this, equal-height peaks resolve to the wrong one.
    order = sorted(range(len(peaks)), key=lambda k: (heights[k], peaks[k]), reverse=True)
    for position in order:
        if not keep[position]:
            continue
        for other in range(len(peaks)):
            if other == position or not keep[other]:
                continue
            if abs(peaks[other] - peaks[position]) < distance:
                keep[other] = False
    return [peak for peak, kept in zip(peaks, keep) if kept]


def find_peaks(
    values: np.ndarray | list[float],
    *,
    prominence: float | None = None,
    distance: float | None = None,
) -> np.ndarray:
    """Locates peaks that stand out by `prominence` and are `distance` apart."""
    series = [float(value) for value in np.asarray(values, dtype=float)]
    if len(series) < 3:
        return np.asarray([], dtype=int)

    peaks = _local_maxima(series)
    # SciPy applies the spacing rule before the prominence one, and the order
    # matters: a peak removed for being too close never gets measured.
    if distance is not None and peaks:
        peaks = _enforce_spacing(peaks, [series[peak] for peak in peaks], distance)
    if prominence is not None:
        peaks = [peak for peak in peaks if _prominence(series, peak) >= prominence]
    return np.asarray(peaks, dtype=int)
