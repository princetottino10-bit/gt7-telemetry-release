"""How much of a corner's braking is done while the car is already turning.

The advice panel could already say "you are braking too much" or "you braked too
early". Neither distinguishes the two ways a corner entry goes wrong: stopping
the car in a straight line and then turning a stationary object, or dragging the
brakes so far into the corner that the front tyres never get to grip. This puts a
number on that split so the advice can name the technique instead of the symptom.

The measurement
---------------
For each corner the braking event it is entered on is located first: the run of
samples with the brake past `BRAKE_ON_PCT` whose *release* falls inside the
segment. Anchoring on the release rather than on the segment window matters,
because a driver who brakes earlier moves the start of the braking zone into the
previous segment, and a metric measured inside the window alone would then read a
change of technique where there was only a change of braking point.

Over that event, the share is the fraction of braking effort applied while the
car is rotating:

    share = sum(brake_pct where rotating) / sum(brake_pct)

Effort-weighting rather than plain time makes a light brush of the pedal at the
apex count for less than full pressure, which is what the driver feels. A share
near 0 means the car was stopped in a straight line and then turned; a share near
0.5 means half the braking was done with the car already rotating.

The rotation signal
-------------------
GT7 reports `data_absolute_yaw_rate_per_second`, an unsigned yaw rate. On
first_session.bin it oscillates strongly even on the main straight - at 275 km/h
it swings between 0.00 and 0.39 rad/s with a period of about half a second, so a
single sample says nothing about whether the car is cornering. Averaged over
`SMOOTH_SAMPLES` (0.68 s at 60 Hz) it separates cleanly: the 20th percentile over
a lap sits at 0.05 rad/s and corner peaks reach 0.9 rad/s.

Because the channel is unsigned there is no left/right information, which is
exactly what this measurement does not need: it only asks whether the car is
turning, not which way.

Thresholds, from first_session.bin
----------------------------------
Watkins Glen Long, 296 GTB '22, four usable laps out of five. Eight of the
fifteen segments carry a braking event big enough to measure. The parameters
below (0.68 s smoothing, rotation counted past half the corner's own peak or
0.25 rad/s, whichever is larger) were the combination that made the share most
repeatable between laps:

    pooled within-corner standard deviation across clean laps   0.088
    median within-corner standard deviation                     0.038

`MIN_SHARE_DIFF` is therefore set to 0.20, a little over twice the pooled
standard deviation: below that, two laps differ by no more than the driver's own
lap-to-lap scatter. On this session exactly one corner clears it - corner_9, where
the reference lap holds 0.35 more of its braking into the turn than the lap that
was quickest through there, which is four times the noise level.

Runs the behaviour checks flagged are never measured here; the caller passes them
in already flagged, and `webreport.sectors` drops them the same way it drops
flagged times.
"""

from __future__ import annotations

import numpy as np

# Pedal past this counts as braking. Matches sectors.BRAKE_THRESHOLD_PCT so the
# braking point and this share describe the same pedal application.
BRAKE_ON_PCT = 8.0

# A lift shorter than this many grid samples does not end a braking event: a
# driver modulating the pedal through a long zone is still on the brakes.
BRIDGE_SAMPLES = 6

# A braking event has to be a real one before its shape means anything. A stab of
# the pedal through a fast kink has no entry technique to describe.
MIN_PEAK_BRAKE_PCT = 40.0
MIN_SPEED_DROP_KMH = 50.0
MIN_LENGTH_M = 40.0

# The segment also has to be a corner. Straights carry braking events for the
# corner that follows them, and their own rotation never gets near this.
MIN_CORNER_ROTATION = 0.35

# Rotation is measured against the corner's own peak, so a slow hairpin and a
# fast sweeper are judged on the same scale, with a floor so a nearly straight
# segment cannot promote its own wobble into "turning".
ROTATION_SHARE = 0.5
ROTATION_FLOOR = 0.25

# Yaw rate is averaged over this many raw 60 Hz samples before use. See above.
SMOOTH_SAMPLES = 41

# Below this, two laps' shares are within the driver's own scatter.
MIN_SHARE_DIFF = 0.20


def smooth(values: np.ndarray, window: int) -> np.ndarray:
    """Moving average that holds its end values instead of fading to zero."""
    if window <= 1 or len(values) == 0:
        return np.asarray(values, dtype=float)
    kernel = np.ones(window) / window
    padded = np.concatenate(
        [np.full(window, values[0], dtype=float), np.asarray(values, dtype=float), np.full(window, values[-1], dtype=float)]
    )
    return np.convolve(padded, kernel, mode="same")[window : window + len(values)]


def rotation_rate(yaw_rate: np.ndarray) -> np.ndarray:
    """The conditioned "is the car turning" signal, in rad/s.

    The channel is already unsigned in GT7's packets, but taking the magnitude
    again costs nothing and keeps the function honest if that ever changes.
    """
    return smooth(np.abs(np.asarray(yaw_rate, dtype=float)), SMOOTH_SAMPLES)


def brake_events(brake_pct: np.ndarray, bridge: int = BRIDGE_SAMPLES) -> list[tuple[int, int]]:
    """Index ranges where the brake is applied, merging lifts shorter than `bridge`."""
    events: list[tuple[int, int]] = []
    on = np.asarray(brake_pct, dtype=float) >= BRAKE_ON_PCT
    start: int | None = None
    gap = 0
    for index, pressed in enumerate(on):
        if pressed:
            if start is None:
                start = index
            gap = 0
        elif start is not None:
            gap += 1
            if gap > bridge:
                events.append((start, index - gap))
                start = None
                gap = 0
    if start is not None:
        events.append((start, len(on) - 1 - gap))
    return events


def entry_event(
    brake_pct: np.ndarray, bounds: tuple[int, int]
) -> tuple[int, int] | None:
    """The braking event this corner is entered on, or None if there is not one.

    Chosen by which event releases inside the corner and spends the most pedal
    there, so a corner preceded by a separate dab further back is not confused
    with the application that actually slows the car for it.
    """
    start, end = bounds
    chosen: tuple[int, int] | None = None
    strongest = 0.0
    for first, last in brake_events(brake_pct):
        if not start <= last <= end:
            continue
        low, high = max(first, start), min(last, end)
        if high < low:
            continue
        effort = float(np.sum(brake_pct[low : high + 1]))
        if effort > strongest:
            strongest = effort
            chosen = (first, last)
    return chosen


def share(
    brake_pct: np.ndarray,
    speed_kmh: np.ndarray,
    rotation: np.ndarray,
    distance_m: np.ndarray,
    bounds: tuple[int, int],
) -> float | None:
    """Fraction of this corner's braking applied while the car was turning.

    None when the segment is not a braked corner: no rotation to speak of, no
    braking event releasing inside it, or an event too small to have a technique.
    All arrays are on the report's shared distance grid; `bounds` are the
    segment's indices into it.
    """
    start, end = bounds
    peak = float(np.max(rotation[start : end + 1]))
    if peak < MIN_CORNER_ROTATION:
        return None

    event = entry_event(brake_pct, bounds)
    if event is None:
        return None
    first, last = event

    pedal = np.asarray(brake_pct, dtype=float)[first : last + 1]
    speed = np.asarray(speed_kmh, dtype=float)[first : last + 1]
    total = float(pedal.sum())
    if total <= 0:
        return None
    if float(pedal.max()) < MIN_PEAK_BRAKE_PCT:
        return None
    if float(speed[0] - speed.min()) < MIN_SPEED_DROP_KMH:
        return None
    if float(distance_m[last] - distance_m[first]) < MIN_LENGTH_M:
        return None

    threshold = max(ROTATION_FLOOR, peak * ROTATION_SHARE)
    turning = rotation[first : last + 1] >= threshold
    return float(pedal[turning].sum()) / total
