"""Asks whether a telemetry channel is worth turning into driving advice.

The report already carries nine signals. Adding a tenth is only worth doing if
it separates a quick lap from a slow one by more than the driver's own lap-to-lap
scatter - otherwise the card it produces is confident and wrong, which is worse
than no card at all.

Three candidates were measured this way and all three were turned down:

    coasting      correlation with segment time was +0.17 across 32 segments,
                  and negative in a third of them. Coasting is often what a good
                  entry looks like: carry more speed in, release the brake
                  earlier, coast longer.
    gear          of 33 segments, only 2 had laps genuinely choosing a different
                  gear. 15 more differed only because a shift landed a few
                  metres either side of the segment boundary.
    suspension    compression rates run smoothly from road noise up to the
                  biggest hit, with no break to put a threshold in. The quickest
                  lap at Watkins Glen had the most events, because using kerbs
                  is what a quick lap does.

Those numbers came from four clean laps per session. Four is not enough to
settle a correlation, so this exists to be run again once there are twenty or
thirty, when the answers may well change.

    .venv\\Scripts\\python.exe evaluate_channels.py
    .venv\\Scripts\\python.exe evaluate_channels.py --track ワトキンズ・グレン-ロング
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

import analyze_gt7 as core
from telemetry import sessions as sessions_module
from webreport import loader, resample, sectors

# The bar a new signal has to clear, taken from the two that did clear it.
# webreport/trailbrake.py measured the driver's own within-corner scatter at
# 0.088 and set its threshold at 0.20 - a shade over twice it.
MIN_USEFUL_CORRELATION = 0.5
SCATTER_MULTIPLE = 2.0
# A channel that barely moves between laps has nothing to say either way.
MIN_VARIATION_RATIO = 0.02


@dataclass
class SegmentSample:
    """One segment of one lap: what the channel said, and what it cost."""

    track: str
    segment: str
    lap_uid: str
    value: float
    time_s: float


def track_dirs(root: Path, track: str | None) -> list[Path]:
    if not root.exists():
        return []
    return [
        entry
        for entry in sorted(root.iterdir())
        if entry.is_dir() and (track is None or entry.name == track)
    ]


def load_track(directory: Path) -> tuple[str, list, object] | None:
    """Every usable lap a circuit has, pooled across all its sessions.

    Pooling is the point: the answers here are limited by how many laps there
    are, and a circuit driven on five evenings has five times the evidence of
    one session.
    """
    definition_path = directory / sessions_module.SEGMENTS_FILENAME
    if not definition_path.exists():
        return None
    definition = json.loads(definition_path.read_text(encoding="utf-8"))

    laps = []
    for session in sorted(entry for entry in directory.iterdir() if entry.is_dir()):
        if not (session / sessions_module.SESSION_FILENAME).exists():
            continue
        try:
            laps.extend(loader.load_laps(session, core.DEFAULT_CARS_CSV))
        except (FileNotFoundError, ValueError):
            continue
    if not laps:
        return None

    try:
        selection = loader.select_laps(laps)
    except ValueError:
        return None
    grid = resample.build_grid(selection.laps)
    traces = resample.build_traces(selection.laps, grid, selection.reference.uid)
    return definition, traces, grid


def coasting_seconds(trace, start: int, end: int) -> float:
    """Time with neither pedal pressed, in one segment."""
    throttle = trace.channel("throttle_pct")[start : end + 1]
    brake = trace.channel("brake_pct")[start : end + 1]
    time_s = trace.channel("time_s")[start : end + 1]
    step = np.diff(time_s, prepend=time_s[0])
    return float(np.sum(step[(throttle < 3) & (brake < 3)]))


def dominant_gear(trace, start: int, end: int) -> tuple[float, float]:
    """The gear a segment is mostly driven in, and how much of it that covers.

    The share matters: a segment split evenly between two gears has not chosen a
    different gear, it has moved a shift by a few metres.
    """
    gears = trace.channel("gear")[start : end + 1].astype(int)
    values, counts = np.unique(gears, return_counts=True)
    best = int(np.argmax(counts))
    return float(values[best]), float(counts[best] / len(gears))


def suspension_rates(raw_lap: dict) -> np.ndarray:
    """Per-sample compression rates, in millimetres, across the four corners.

    Read out of the session file rather than a PreparedLap: suspension is one of
    the channels the loader does not carry, which is exactly the state of affairs
    this tool exists to re-examine. If it ever earns its place, it gets added to
    EXTENDED_ARRAY_FIELDS and this can read it like anything else.
    """
    rates = []
    for wheel in ("fl", "fr", "rl", "rr"):
        values = np.asarray(raw_lap.get(f"data_suspension_{wheel}", []), dtype=float)
        if values.size < 2:
            return np.asarray([], dtype=float)
        rates.append(-np.diff(values, prepend=values[0]))
    return np.max(np.vstack(rates), axis=0) * 1000.0


def raw_laps(directory: Path) -> list[dict]:
    """Every lap of every session on a circuit, straight from the JSON."""
    found: list[dict] = []
    for session in sorted(entry for entry in directory.iterdir() if entry.is_dir()):
        path = session / sessions_module.SESSION_FILENAME
        if not path.exists():
            continue
        try:
            # Through the shared reader: session files are gzipped now, and this
            # was still opening them as plain text.
            payload = json.loads(core.read_session_bytes(path).decode("utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if isinstance(payload, list):
            found.extend(entry for entry in payload if isinstance(entry, dict))
    return found


def correlation_report(samples: list[SegmentSample], label: str) -> None:
    """Does the channel predict a slower segment, or only differ between laps?"""
    by_segment: dict[tuple[str, str], list[SegmentSample]] = {}
    for sample in samples:
        by_segment.setdefault((sample.track, sample.segment), []).append(sample)

    correlations: list[float] = []
    scatters: list[float] = []
    for entries in by_segment.values():
        if len(entries) < 3:
            continue
        values = np.array([entry.value for entry in entries])
        times = np.array([entry.time_s for entry in entries])
        if values.std() < 1e-9 or times.std() < 1e-9:
            continue
        correlations.append(float(np.corrcoef(values, times)[0, 1]))
        scatters.append(float(values.std()))

    print(f"\n--- {label} ---")
    if not correlations:
        print("  比較できる区間がありません（同じ区間を3周以上走ったデータが要ります）")
        return

    correlations = np.array(correlations)
    agreeing = int(np.sum(correlations > MIN_USEFUL_CORRELATION))
    against = int(np.sum(correlations < -MIN_USEFUL_CORRELATION))
    print(f"  対象区間              : {len(correlations)}")
    print(f"  相関の中央値          : {np.median(correlations):+.2f}")
    print(f"  「大きいほど遅い」区間 : {agreeing}")
    print(f"  逆に出た区間          : {against}")
    print(f"  周ごとのばらつき中央値 : {np.median(scatters):.3f}")

    verdict = (
        "使えそう"
        if np.median(correlations) > MIN_USEFUL_CORRELATION and against == 0
        else "助言には使えない"
    )
    print(f"  判定                  : {verdict}")
    if against:
        print("    逆相関の区間があるうちは、速い走りを直せと言うカードが出ます。")


def audit(root: Path, track: str | None) -> int:
    directories = track_dirs(root, track)
    if not directories:
        print(f"{root} に走行記録が見つかりません。")
        return 1

    coasting: list[SegmentSample] = []
    gear_real = gear_boundary = gear_same = 0
    suspension_shape: list[tuple[str, float, float]] = []
    lap_total = 0

    for directory in directories:
        loaded = load_track(directory)
        if loaded is None:
            continue
        definition, traces, grid = loaded
        lap_total += len(traces)
        results = sectors.compute_all(traces, grid, definition["segments"])
        time_of = {(r.segment_id, r.lap_uid): r.time_s for r in results}

        for segment in definition["segments"]:
            start = int(segment["start_fraction"] * (grid.points - 1))
            end = int(segment["end_fraction"] * (grid.points - 1))
            name = segment.get("name_ja", segment["id"])

            gears = []
            for trace in traces:
                elapsed = time_of.get((segment["id"], trace.uid))
                if elapsed is None:
                    continue
                coasting.append(
                    SegmentSample(
                        track=directory.name,
                        segment=name,
                        lap_uid=trace.uid,
                        value=coasting_seconds(trace, start, end),
                        time_s=elapsed,
                    )
                )
                gears.append(dominant_gear(trace, start, end))

            chosen = {gear for gear, _share in gears}
            if len(chosen) <= 1:
                gear_same += 1
            elif min(share for _gear, share in gears) > 0.55:
                gear_real += 1
            else:
                gear_boundary += 1

        for raw_lap in raw_laps(directory):
            rates = suspension_rates(raw_lap)
            if rates.size:
                suspension_shape.append(
                    (directory.name, float(np.percentile(rates, 99.9)), float(rates.max()))
                )

    print(f"対象: {len(directories)}コース / {lap_total}周")

    correlation_report(coasting, "惰性（アクセルもブレーキも踏んでいない時間）")

    print("\n--- ギア選択 ---")
    total = gear_same + gear_real + gear_boundary
    print(f"  対象区間                    : {total}")
    print(f"  全周で同じギア              : {gear_same}")
    print(f"  シフト位置のずれだけ         : {gear_boundary}")
    print(f"  本当にギアが違う            : {gear_real}")
    print(
        "  判定                        : "
        + ("使えそう" if gear_real > total * 0.25 else "助言には使えない")
    )

    print("\n--- サスペンション（縁石・底付き） ---")
    if not suspension_shape:
        print("  サスペンションのチャンネルがありません（capture_gt7.py で録った記録が要ります）")
    else:
        ratios = [p999 / peak for _track, p999, peak in suspension_shape if peak > 0]
        print(f"  対象周                      : {len(suspension_shape)}")
        print(f"  p99.9 が最大値に占める割合   : {np.median(ratios):.2f}")
        isolated = np.median(ratios) < 0.5
        print(
            "  判定                        : "
            + (
                "使えそう（大きな衝撃が孤立している）"
                if isolated
                else "助言には使えない（路面と縁石を分ける段差がない）"
            )
        )

    print(
        "\n新しい信号を採用する条件: 周ごとのばらつきの"
        f"{SCATTER_MULTIPLE:.0f}倍以上の差が出て、相関が"
        f"{MIN_USEFUL_CORRELATION:+.1f}を超え、逆相関の区間が無いこと。"
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--sessions", type=Path, default=Path("sessions"))
    parser.add_argument("--track", default=None, help="1コースだけを見る（フォルダ名）")
    args = parser.parse_args()
    return audit(args.sessions, args.track)


if __name__ == "__main__":
    raise SystemExit(main())
