from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import dataclasses
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import numpy as np

# matplotlib and pandas are only used by this script's own PNG and CSV output.
# webreport imports this module purely for its data helpers, and pulling in
# ~100 MB of plotting and dataframe libraries to read a JSON file makes the
# capture tool slow to start and impossible to ship with Python bundled. They
# are bound in main() instead.
plt = None
pd = None


DEFAULT_DATA_DIR = Path.home() / "AppData/Local/Programs/GT7dashboard/data"
def _default_cars_csv() -> Path:
    """The car name table, preferring the copy shipped with this tool.

    It used to read GT7 Dashboard's copy directly, which meant anyone given the
    portable build saw car IDs instead of car names.
    """
    bundled = Path(__file__).resolve().parent / "assets" / "db" / "cars.csv"
    if bundled.exists():
        return bundled
    return Path.home() / "AppData/Local/Programs/GT7dashboard/_internal/db/cars.csv"


DEFAULT_CARS_CSV = _default_cars_csv()

# How far a lap's recorded duration may sit from the time the console reported
# for it. Laps captured end to end agree to about 0.015 %; a capture that began
# mid-lap is out by tens of percent.
PARTIAL_LAP_DRIFT = 0.02

# Files that live beside a session but describe it rather than hold laps.
SIDECAR_FILENAMES = frozenset({"meta.json", "segments.json", "run_metadata.json"})
# The line each report saves beside itself for the live view (webreport/first.py):
# report.first.json, report.<car>.first.json.
SIDECAR_SUFFIX = ".first.json"
PLOT_COLORS = ["#176B87", "#D99A25", "#D65A31", "#5B6870"]
PLOT_STYLES = ["-", "--", "-.", ":"]
ARRAY_FIELDS = [
    "data_throttle",
    "data_braking",
    "data_coasting",
    "data_speed",
    "data_time",
    "data_rpm",
    "data_gear",
    "data_tires",
    "data_position_x",
    "data_position_y",
    "data_position_z",
    "data_boost",
    "data_rotation_yaw",
    "data_absolute_yaw_rate_per_second",
]

# Channels only present in files written by capture_gt7.py. Older GT7 Dashboard
# sessions simply do not carry them, so every consumer has to treat them as
# optional.
EXTENDED_ARRAY_FIELDS = [
    "data_slide_angle_deg",
    "data_tire_slip_fl",
    "data_tire_slip_fr",
    "data_tire_slip_rl",
    "data_tire_slip_rr",
    "data_tire_temp_fl",
    "data_tire_temp_fr",
    "data_tire_temp_rl",
    "data_tire_temp_rr",
    # 1 while traction control is intervening. Sessions recorded before it was
    # saved lack it until rebuild backfills it from raw.bin.
    "data_tcs",
]


@dataclass
class PreparedLap:
    uid: str
    source_file: str
    title: str
    number: int
    finish_ms: int
    lap_time_s: float
    live_time_s: float
    car_id: int
    car_name: str
    is_replay: bool
    is_manual: bool
    start_timestamp: str
    end_timestamp: str
    distance_m: np.ndarray
    progress: np.ndarray
    time_s: np.ndarray
    speed_kmh: np.ndarray
    throttle_pct: np.ndarray
    brake_pct: np.ndarray
    coasting: np.ndarray
    gear: np.ndarray
    rpm: np.ndarray
    x: np.ndarray
    y: np.ndarray
    z: np.ndarray
    yaw: np.ndarray
    yaw_rate: np.ndarray
    fuel_start: float
    fuel_end: float
    validity: str
    exclusion_reason: str
    # Empty for GT7 Dashboard files; populated for direct captures.
    extended: dict[str, np.ndarray] = dataclasses.field(default_factory=dict)
    # Set only on laps carried in from an earlier session on the same circuit,
    # so the report can say which times were driven today and which were not.
    is_history: bool = False
    # Set on the one lap taken from a session marked as the model to chase (a
    # replay of a faster driver, recorded the same way); also is_history, since
    # it was not driven today either.
    is_model: bool = False

    @property
    def total_distance_m(self) -> float:
        return float(self.distance_m[-1])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze GT7 Dashboard telemetry JSON")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument(
        "--segments",
        type=Path,
        default=Path(__file__).with_name("spa_segments.json"),
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path(__file__).with_name("output")
    )
    parser.add_argument("--track", default="Spa-Francorchamps GP")
    parser.add_argument(
        "--focus-car-id",
        type=int,
        default=None,
        help="Car ID to use as the primary comparison target. Defaults to the overall fastest car.",
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_car_names(path: Path) -> dict[int, str]:
    """Car names, from the bundled table plus anything taught since.

    The bundled table came from GT7 Dashboard and predates a good many cars, so
    names learned during a capture are layered on top and win where they differ.
    """
    result: dict[int, str] = {}
    if path.exists():
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                try:
                    result[int(row["ID"])] = row["ShortName"]
                except (KeyError, TypeError, ValueError):
                    continue
    try:
        from telemetry import cars

        result.update(cars.load())
    except Exception:  # noqa: BLE001 - a missing name must not cost a report
        pass
    return result


# gzip's magic number. Session files keep their .json name whether or not they
# are compressed, so the contents are what decides how to read them.
GZIP_MAGIC = b"\x1f\x8b"


def read_session_bytes(path: Path) -> bytes:
    """The JSON of a session file, compressed or not."""
    raw = path.read_bytes()
    if raw[:2] == GZIP_MAGIC:
        import gzip

        return gzip.decompress(raw)
    return raw


def load_sessions(data_dir: Path) -> tuple[list[tuple[Path, list[dict[str, Any]]]], list[dict[str, Any]]]:
    # Sidecars share the folder with the laps but are not lap files; reading them
    # as sessions is what a rebuild used to die on.
    files = sorted(
        path
        for path in data_dir.glob("*.json")
        if path.name not in SIDECAR_FILENAMES and not path.name.endswith(SIDECAR_SUFFIX)
    )
    if not files:
        raise FileNotFoundError(f"No JSON files found in {data_dir}")

    inventory: list[dict[str, Any]] = []
    sessions: list[tuple[Path, list[dict[str, Any]]]] = []
    seen_hashes: dict[str, str] = {}
    for path in files:
        file_hash = sha256(path)
        duplicate_of = seen_hashes.get(file_hash, "")
        inventory.append(
            {
                "file": path.name,
                "bytes": path.stat().st_size,
                "sha256": file_hash,
                "is_exact_duplicate": bool(duplicate_of),
                "duplicate_of": duplicate_of,
                "modified_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
            }
        )
        if duplicate_of:
            continue
        seen_hashes[file_hash] = path.name
        payload = json.loads(read_session_bytes(path).decode("utf-8"))
        if not isinstance(payload, list):
            raise ValueError(f"Top-level JSON must be a list: {path}")
        sessions.append((path, payload))
    return sessions, inventory


def lap_uid(lap: dict[str, Any]) -> str:
    identity = "|".join(
        str(lap.get(key, ""))
        for key in (
            "car_id",
            "lap_start_timestamp",
            "lap_end_timestamp",
            "number",
            "lap_finish_time",
        )
    )
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]


def safe_array(lap: dict[str, Any], name: str, size: int, default: float = 0.0) -> np.ndarray:
    value = lap.get(name)
    if not isinstance(value, list):
        return np.full(size, default, dtype=float)
    array = np.asarray(value[:size], dtype=float)
    if len(array) < size:
        array = np.pad(array, (0, size - len(array)), constant_values=default)
    return array


def prepare_lap(
    lap: dict[str, Any], source_file: str, car_names: dict[int, str]
) -> PreparedLap:
    lengths = [len(lap.get(name, [])) for name in ARRAY_FIELDS if isinstance(lap.get(name), list)]
    size = min(lengths) if lengths else 0
    finish_ms = int(lap.get("lap_finish_time") or 0)
    validity = "included"
    exclusion_reason = ""
    if size < 600:
        validity, exclusion_reason = "excluded", "too_few_samples"
    elif finish_ms <= 0:
        validity, exclusion_reason = "excluded", "missing_lap_finish_time"

    time_s = safe_array(lap, "data_time", size)
    speed_kmh = safe_array(lap, "data_speed", size)
    if size:
        time_s = np.maximum.accumulate(time_s)
        time_s = time_s - time_s[0]
        official_lap_time_s = finish_ms / 1000.0
        if official_lap_time_s > 0 and time_s[-1] > 0:
            # The console reports the whole lap's time even when the recording
            # only caught part of it, so the two disagreeing means the capture
            # started after the start line. Stretching such a lap onto its
            # reported time would inflate every distance derived from it - one
            # real half lap came out claiming 2706 m of a 2980 m circuit, passed
            # every downstream check, and gave a session of 1:18 laps a
            # theoretical best of 1:05.
            #
            # Dropped packets do not trigger this: the timestamps come from the
            # console's own tick counter, so a patchy lap still ends at the right
            # time with fewer samples along the way. Laps recorded end to end
            # agree to about a part in seven thousand.
            drift = abs(time_s[-1] - official_lap_time_s) / official_lap_time_s
            if drift > PARTIAL_LAP_DRIFT:
                validity, exclusion_reason = "excluded", "partial_lap"
            else:
                time_s = time_s * (official_lap_time_s / time_s[-1])
        delta_t = np.diff(time_s, prepend=time_s[0])
        typical_dt = float(np.median(np.diff(time_s))) if size > 2 else 1 / 60
        delta_t[0] = typical_dt
        delta_t = np.clip(delta_t, 0.0, max(0.1, typical_dt * 3))
        speed_ms = speed_kmh / 3.6
        increments = np.zeros(size)
        if size > 1:
            increments[1:] = (
                (speed_ms[1:] + speed_ms[:-1]) * 0.5 * delta_t[1:]
            )
        distance_m = np.cumsum(increments)
        if distance_m[-1] <= 100:
            validity, exclusion_reason = "excluded", "implausible_distance"
        progress = distance_m / max(float(distance_m[-1]), 1.0)
    else:
        distance_m = np.asarray([], dtype=float)
        progress = np.asarray([], dtype=float)

    car_id = int(lap.get("car_id") or -1)
    return PreparedLap(
        uid=lap_uid(lap),
        source_file=source_file,
        title=str(lap.get("title") or "unknown"),
        number=int(lap.get("number") or 0),
        finish_ms=finish_ms,
        lap_time_s=finish_ms / 1000.0,
        live_time_s=float(lap.get("lap_live_time") or 0.0),
        car_id=car_id,
        car_name=car_names.get(car_id, f"CAR-ID-{car_id}"),
        is_replay=bool(lap.get("is_replay")),
        is_manual=bool(lap.get("is_manual")),
        start_timestamp=str(lap.get("lap_start_timestamp") or ""),
        end_timestamp=str(lap.get("lap_end_timestamp") or ""),
        distance_m=distance_m,
        progress=progress,
        time_s=time_s,
        speed_kmh=speed_kmh,
        throttle_pct=safe_array(lap, "data_throttle", size),
        brake_pct=safe_array(lap, "data_braking", size),
        coasting=safe_array(lap, "data_coasting", size),
        gear=safe_array(lap, "data_gear", size),
        rpm=safe_array(lap, "data_rpm", size),
        x=safe_array(lap, "data_position_x", size),
        y=safe_array(lap, "data_position_y", size),
        z=safe_array(lap, "data_position_z", size),
        yaw=safe_array(lap, "data_rotation_yaw", size),
        yaw_rate=safe_array(lap, "data_absolute_yaw_rate_per_second", size),
        fuel_start=float(lap.get("fuel_at_start") or 0.0),
        fuel_end=float(lap.get("fuel_at_end") or 0.0),
        validity=validity,
        exclusion_reason=exclusion_reason,
        extended={
            name: safe_array(lap, name, size)
            for name in EXTENDED_ARRAY_FIELDS
            if isinstance(lap.get(name), list)
        },
    )


def deduplicate_laps(sessions: list[tuple[Path, list[dict[str, Any]]]], car_names: dict[int, str]) -> list[PreparedLap]:
    laps: list[PreparedLap] = []
    seen: set[str] = set()
    for path, payload in sessions:
        for raw_lap in payload:
            uid = lap_uid(raw_lap)
            if uid in seen:
                continue
            seen.add(uid)
            laps.append(prepare_lap(raw_lap, path.name, car_names))
    return sorted(laps, key=lambda lap: (lap.start_timestamp, lap.lap_time_s))


def load_segments(path: Path) -> dict[str, Any]:
    definition = json.loads(path.read_text(encoding="utf-8"))
    segments = definition.get("segments", [])
    if not segments:
        raise ValueError("Segment definition contains no segments")
    expected = 0.0
    for segment in segments:
        start = float(segment["start_fraction"])
        end = float(segment["end_fraction"])
        if abs(start - expected) > 1e-4 or end <= start:
            raise ValueError(f"Segments must be continuous: {segment['id']}")
        expected = end
    if abs(expected - 1.0) > 1e-4:
        raise ValueError("Last segment must end at 1.0")
    return definition


def interp(lap: PreparedLap, values: np.ndarray, progress: np.ndarray) -> np.ndarray:
    unique_progress, indices = np.unique(lap.progress, return_index=True)
    return np.interp(progress, unique_progress, values[indices])


def first_sustained_index(values: np.ndarray, threshold: float, above: bool, run: int = 8) -> int | None:
    condition = values >= threshold if above else values <= threshold
    if len(condition) < run:
        return None
    hits = np.convolve(condition.astype(int), np.ones(run, dtype=int), mode="valid")
    indices = np.flatnonzero(hits == run)
    return int(indices[0]) if len(indices) else None


def sector_metrics(lap: PreparedLap, segment: dict[str, Any], best_lap: PreparedLap) -> dict[str, Any]:
    start = float(segment["start_fraction"])
    end = float(segment["end_fraction"])
    mask = (lap.progress >= start) & (lap.progress <= end)
    idx = np.flatnonzero(mask)
    if len(idx) < 3:
        raise ValueError(f"Not enough samples in {segment['id']} for {lap.uid}")
    a, b = int(idx[0]), int(idx[-1])
    local_progress = lap.progress[a : b + 1]
    local_distance = lap.distance_m[a : b + 1]
    local_speed = lap.speed_kmh[a : b + 1]
    local_throttle = lap.throttle_pct[a : b + 1]
    local_brake = lap.brake_pct[a : b + 1]
    local_gear = lap.gear[a : b + 1]
    local_yaw_rate = lap.yaw_rate[a : b + 1]
    min_local = int(np.argmin(local_speed))

    brake_idx = first_sustained_index(local_brake, 5.0, above=True, run=6)
    brake_release_idx: int | None = None
    if brake_idx is not None:
        released = first_sustained_index(local_brake[brake_idx:], 5.0, above=False, run=8)
        if released is not None:
            brake_release_idx = brake_idx + released

    throttle_idx_rel = first_sustained_index(local_throttle[min_local:], 10.0, above=True, run=6)
    full_idx_rel = first_sustained_index(local_throttle[min_local:], 95.0, above=True, run=10)
    throttle_idx = min_local + throttle_idx_rel if throttle_idx_rel is not None else None
    full_idx = min_local + full_idx_rel if full_idx_rel is not None else None

    delta_distance = np.diff(local_distance, prepend=local_distance[0])
    coast_mask = (local_throttle < 5.0) & (local_brake < 5.0)
    shifts = int(np.count_nonzero(np.diff(local_gear.astype(int)) != 0))
    gears = sorted({int(g) for g in local_gear if g > 0})

    line_progress = np.linspace(start, end, 101)
    bx = interp(best_lap, best_lap.x, line_progress)
    by = interp(best_lap, best_lap.y, line_progress)
    bz = interp(best_lap, best_lap.z, line_progress)
    lx = interp(lap, lap.x, line_progress)
    ly = interp(lap, lap.y, line_progress)
    lz = interp(lap, lap.z, line_progress)
    line_delta = np.sqrt((lx - bx) ** 2 + (ly - by) ** 2 + (lz - bz) ** 2)

    def position_at(local_index: int | None) -> float | None:
        return float(local_distance[local_index]) if local_index is not None else None

    return {
        "lap_uid": lap.uid,
        "lap_number": lap.number,
        "lap_time_s": lap.lap_time_s,
        "lap_title": lap.title,
        "car_id": lap.car_id,
        "car_name": lap.car_name,
        "segment_id": segment["id"],
        "segment_name": segment["name"],
        "segment_name_ja": segment["name_ja"],
        "start_m": float(lap.total_distance_m * start),
        "end_m": float(lap.total_distance_m * end),
        "sector_time_s": float(np.interp(end, lap.progress, lap.time_s) - np.interp(start, lap.progress, lap.time_s)),
        "entry_speed_kmh": float(local_speed[0]),
        "min_speed_kmh": float(np.min(local_speed)),
        "exit_speed_kmh": float(local_speed[-1]),
        "max_speed_kmh": float(np.max(local_speed)),
        "brake_start_m": position_at(brake_idx),
        "max_brake_pct": float(np.max(local_brake)),
        "brake_release_m": position_at(brake_release_idx),
        "throttle_start_m": position_at(throttle_idx),
        "full_throttle_m": position_at(full_idx),
        "coast_distance_m": float(np.sum(delta_distance[coast_mask])),
        "gears": "/".join(str(g) for g in gears),
        "shift_count": shifts,
        "mean_abs_yaw_rate": float(np.mean(np.abs(local_yaw_rate))),
        "max_abs_yaw_rate": float(np.max(np.abs(local_yaw_rate))),
        "mean_line_delta_to_best_m": float(np.mean(line_delta)),
        "max_line_delta_to_best_m": float(np.max(line_delta)),
    }


def format_time(seconds: float) -> str:
    minutes = int(seconds // 60)
    return f"{minutes}:{seconds - minutes * 60:06.3f}"


def clean_label(lap: PreparedLap, role: str) -> str:
    return f"{role}: {lap.car_name} L{lap.number} {lap.title}"


def choose_comparison_laps(
    laps: list[PreparedLap], focus_car_id: int
) -> list[tuple[str, PreparedLap]]:
    focus_laps = sorted(
        (lap for lap in laps if lap.car_id == focus_car_id),
        key=lambda lap: lap.lap_time_s,
    )
    selected: list[tuple[str, PreparedLap]] = [("Overall best", focus_laps[0])]

    other_cars = sorted(
        {lap.car_id for lap in laps if lap.car_id != focus_car_id},
        key=lambda car_id: min(
            lap.lap_time_s for lap in laps if lap.car_id == car_id
        ),
    )
    for car_id in other_cars:
        best_other = min(
            (lap for lap in laps if lap.car_id == car_id),
            key=lambda lap: lap.lap_time_s,
        )
        selected.append(("Car best", best_other))

    used = {lap.uid for _, lap in selected}
    for role, candidates in (
        ("Focus second", focus_laps[1:2]),
        ("Focus representative", focus_laps[2:]),
    ):
        if len(selected) >= 4:
            break
        available = [lap for lap in candidates if lap.uid not in used]
        if not available:
            continue
        if role == "Focus representative":
            median = statistics.median(lap.lap_time_s for lap in focus_laps)
            choice = min(available, key=lambda lap: abs(lap.lap_time_s - median))
        else:
            choice = available[0]
        selected.append((role, choice))
        used.add(choice.uid)
    return selected[:4]


def setup_plot() -> None:
    plt.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": "#5B6870",
            "axes.labelcolor": "#27343A",
            "text.color": "#27343A",
            "xtick.color": "#5B6870",
            "ytick.color": "#5B6870",
            "grid.color": "#DDE3E6",
            "grid.linewidth": 0.7,
            "font.size": 10,
        }
    )


def add_segment_guides(ax: plt.Axes, segments: list[dict[str, Any]], lap_distance: float) -> None:
    for segment in segments[1:]:
        ax.axvline(float(segment["start_fraction"]) * lap_distance, color="#C7CED2", lw=0.55, zorder=0)


def save_line_plot(
    path: Path,
    selected: list[tuple[str, PreparedLap]],
    segments: list[dict[str, Any]],
    field: str,
    title: str,
    ylabel: str,
    step: bool = False,
) -> None:
    fig, ax = plt.subplots(figsize=(14, 5.5), constrained_layout=True)
    reference_distance = selected[0][1].total_distance_m
    distance_grid = np.linspace(0.0, reference_distance, 1401)
    progress = distance_grid / reference_distance
    for i, (role, lap) in enumerate(selected):
        values = interp(lap, getattr(lap, field), progress)
        draw = ax.step if step else ax.plot
        kwargs = {
            "color": PLOT_COLORS[i % len(PLOT_COLORS)],
            "linestyle": PLOT_STYLES[i % len(PLOT_STYLES)],
            "linewidth": 1.5 if i == 0 else 1.1,
            "label": clean_label(lap, role),
        }
        if step:
            draw(distance_grid, values, where="post", **kwargs)
        else:
            draw(distance_grid, values, **kwargs)
    add_segment_guides(ax, segments, reference_distance)
    ax.set(title=title, xlabel="Reconstructed lap distance (m)", ylabel=ylabel)
    ax.grid(True, axis="both")
    ax.legend(
        ncol=2,
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.16),
    )
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def save_delta_plot(path: Path, selected: list[tuple[str, PreparedLap]], segments: list[dict[str, Any]]) -> None:
    fig, ax = plt.subplots(figsize=(14, 5.5), constrained_layout=True)
    best = selected[0][1]
    distance_grid = np.linspace(0.0, best.total_distance_m, 1401)
    progress = distance_grid / best.total_distance_m
    best_time = interp(best, best.time_s, progress)
    for i, (role, lap) in enumerate(selected[1:], start=1):
        lap_time = interp(lap, lap.time_s, progress)
        delta = lap_time - best_time
        ax.plot(
            distance_grid,
            delta,
            color=PLOT_COLORS[i % len(PLOT_COLORS)],
            linestyle=PLOT_STYLES[i % len(PLOT_STYLES)],
            linewidth=1.4,
            label=clean_label(lap, role),
        )
    add_segment_guides(ax, segments, best.total_distance_m)
    ax.axhline(0, color="#27343A", lw=0.9)
    ax.set(
        title="Cumulative time delta to best lap",
        xlabel="Reconstructed lap distance (m)",
        ylabel="Time delta (s, positive = slower)",
    )
    ax.grid(True)
    ax.legend(frameon=False)
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def save_racing_line(path: Path, selected: list[tuple[str, PreparedLap]]) -> None:
    fig, ax = plt.subplots(figsize=(9, 9), constrained_layout=True)
    for i, (role, lap) in enumerate(selected):
        sample_progress = np.linspace(0, 1, 1800)
        x = interp(lap, lap.x, sample_progress)
        z = interp(lap, lap.z, sample_progress)
        ax.plot(
            x,
            z,
            color=PLOT_COLORS[i % len(PLOT_COLORS)],
            linestyle=PLOT_STYLES[i % len(PLOT_STYLES)],
            linewidth=1.5 if i == 0 else 0.9,
            alpha=1.0 if i == 0 else 0.8,
            label=clean_label(lap, role),
        )
    ax.set(title="Racing line comparison", xlabel="GT7 world X (m)", ylabel="GT7 world Z (m)")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True)
    ax.legend(
        frameon=False,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.06),
        ncol=1,
    )
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def save_lap_trend(path: Path, laps: list[PreparedLap]) -> None:
    ordered = sorted(laps, key=lambda lap: lap.start_timestamp)
    fig, ax = plt.subplots(figsize=(10, 5), constrained_layout=True)
    positions = {lap.uid: index for index, lap in enumerate(ordered, start=1)}
    for color_index, car_id in enumerate(sorted({lap.car_id for lap in ordered})):
        car_laps = [lap for lap in ordered if lap.car_id == car_id]
        x = [positions[lap.uid] for lap in car_laps]
        y = [lap.lap_time_s for lap in car_laps]
        ax.plot(
            x,
            y,
            color=PLOT_COLORS[color_index % len(PLOT_COLORS)],
            marker="o",
            linewidth=1.6,
            label=car_laps[0].car_name,
        )
        for xi, yi, lap in zip(x, y, car_laps):
            ax.annotate(
                lap.title,
                (xi, yi),
                xytext=(0, 8),
                textcoords="offset points",
                ha="center",
                fontsize=8,
            )
    all_x = np.arange(1, len(ordered) + 1)
    ax.set(title="Lap time progression by car", xlabel="Recorded lap order", ylabel="Lap time (s)", xticks=all_x)
    ax.margins(y=0.12)
    ax.grid(True)
    ax.legend(frameon=False)
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def aggregate_sectors(sector_df: pd.DataFrame, best_uid: str) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for segment_id, group in sector_df.groupby("segment_id", sort=False):
        best_row = group.loc[group["lap_uid"] == best_uid].iloc[0]
        fastest_row = group.loc[group["sector_time_s"].idxmin()]
        rows.append(
            {
                "segment_id": segment_id,
                "segment_name": best_row["segment_name"],
                "segment_name_ja": best_row["segment_name_ja"],
                "start_m": best_row["start_m"],
                "end_m": best_row["end_m"],
                "best_lap_sector_time_s": best_row["sector_time_s"],
                "fastest_sector_time_s": fastest_row["sector_time_s"],
                "fastest_sector_lap": fastest_row["lap_title"],
                "best_lap_potential_s": best_row["sector_time_s"] - fastest_row["sector_time_s"],
                "mean_sector_time_s": group["sector_time_s"].mean(),
                "sector_time_std_s": group["sector_time_s"].std(ddof=0),
                "min_speed_mean_kmh": group["min_speed_kmh"].mean(),
                "min_speed_std_kmh": group["min_speed_kmh"].std(ddof=0),
                "brake_start_std_m": group["brake_start_m"].std(ddof=0),
                "full_throttle_std_m": group["full_throttle_m"].std(ddof=0),
                "line_delta_mean_m": group["mean_line_delta_to_best_m"].mean(),
            }
        )
    result = pd.DataFrame(rows)
    result["consistency"] = np.select(
        [result["sector_time_std_s"] <= 0.12, result["sector_time_std_s"] <= 0.30],
        ["高", "中"],
        default="低",
    )
    return result


def lap_distance_for_mask(lap: PreparedLap, mask: np.ndarray) -> float:
    increments = np.diff(lap.distance_m, prepend=lap.distance_m[0])
    return float(np.sum(increments[mask]))


def build_car_summaries(
    laps: list[PreparedLap], sector_df: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    car_rows: list[dict[str, Any]] = []
    sector_frames: list[pd.DataFrame] = []
    for car_id in sorted({lap.car_id for lap in laps}):
        car_laps = [lap for lap in laps if lap.car_id == car_id]
        best = min(car_laps, key=lambda lap: lap.lap_time_s)
        car_sectors = sector_df[sector_df["car_id"] == car_id].copy()
        aggregate = aggregate_sectors(car_sectors, best.uid)
        aggregate.insert(0, "car_name", best.car_name)
        aggregate.insert(0, "car_id", car_id)
        sector_frames.append(aggregate)

        lap_times = [lap.lap_time_s for lap in car_laps]
        full_throttle_rates = [
            float(np.mean(lap.throttle_pct >= 95.0) * 100.0) for lap in car_laps
        ]
        coast_distances = [
            lap_distance_for_mask(
                lap, (lap.throttle_pct < 5.0) & (lap.brake_pct < 5.0)
            )
            for lap in car_laps
        ]
        braking_distances = [
            lap_distance_for_mask(lap, lap.brake_pct >= 5.0) for lap in car_laps
        ]

        def sector_mean(segment_id: str, field: str) -> float:
            values = car_sectors.loc[
                car_sectors["segment_id"] == segment_id, field
            ].dropna()
            return float(values.mean()) if len(values) else float("nan")

        lap_std = statistics.pstdev(lap_times)
        reproducibility = "高" if lap_std <= 0.30 else "中" if lap_std <= 1.00 else "低"
        theoretical = float(aggregate["fastest_sector_time_s"].sum())
        car_rows.append(
            {
                "car_id": car_id,
                "car_name": best.car_name,
                "lap_count": len(car_laps),
                "best_lap_s": best.lap_time_s,
                "best_lap": format_time(best.lap_time_s),
                "average_lap_s": statistics.mean(lap_times),
                "average_lap": format_time(statistics.mean(lap_times)),
                "median_lap_s": statistics.median(lap_times),
                "lap_time_std_s": lap_std,
                "theoretical_best_s": theoretical,
                "theoretical_best": format_time(theoretical),
                "theoretical_potential_s": best.lap_time_s - theoretical,
                "max_speed_kmh": max(float(np.max(lap.speed_kmh)) for lap in car_laps),
                "kemmel_exit_speed_mean_kmh": sector_mean("kemmel", "exit_speed_kmh"),
                "pouhon_min_speed_mean_kmh": sector_mean("pouhon", "min_speed_kmh"),
                "blanchimont_min_speed_mean_kmh": sector_mean(
                    "blanchimont", "min_speed_kmh"
                ),
                "full_throttle_rate_mean_pct": statistics.mean(full_throttle_rates),
                "coast_distance_mean_m": statistics.mean(coast_distances),
                "braking_distance_mean_m": statistics.mean(braking_distances),
                "reproducibility": reproducibility,
                "best_lap_uid": best.uid,
            }
        )
    return pd.DataFrame(car_rows), pd.concat(sector_frames, ignore_index=True)


def diagnose_sector(best_row: pd.Series, fastest_row: pd.Series) -> tuple[str, str]:
    messages: list[str] = []
    actions: list[str] = []

    def diff(field: str) -> float | None:
        a, b = best_row.get(field), fastest_row.get(field)
        if pd.isna(a) or pd.isna(b):
            return None
        return float(a) - float(b)

    brake_diff = diff("brake_start_m")
    min_speed_diff = diff("min_speed_kmh")
    full_diff = diff("full_throttle_m")
    coast_diff = diff("coast_distance_m")

    if brake_diff is not None and brake_diff < -5:
        messages.append(f"ブレーキ開始が{abs(brake_diff):.0f}m早い")
        actions.append("出口姿勢を崩さない範囲でブレーキ基準を少し遅らせる")
    elif brake_diff is not None and brake_diff > 5:
        messages.append(f"ブレーキ開始が{brake_diff:.0f}m遅い")
        actions.append("少し早めから穏やかに制動する")
    if min_speed_diff is not None and min_speed_diff < -2:
        messages.append(f"最低速度が{abs(min_speed_diff):.1f}km/h低い")
        actions.append("減速しすぎない")
    if full_diff is not None and full_diff > 8:
        messages.append(f"全開到達が{full_diff:.0f}m遅い")
        actions.append("出口優先でアクセルを早く決める")
    if coast_diff is not None and coast_diff > 8:
        messages.append(f"惰性区間が{coast_diff:.0f}m長い")
        actions.append("長い惰性を減らし、ブレーキからアクセルへの移行を明確にする")
    if not messages:
        messages.append("差が単一の操作点ではなく区間全体に分散している")
        actions.append("ブレーキ位置を変える前に、速い周の速度推移とラインを再現する")
    return "、".join(messages), "。".join(dict.fromkeys(actions))


def build_report(
    path: Path,
    track: str,
    all_laps: list[PreparedLap],
    focus_laps: list[PreparedLap],
    inventory: pd.DataFrame,
    sector_df: pd.DataFrame,
    aggregate_df: pd.DataFrame,
    car_summary_df: pd.DataFrame,
) -> dict[str, Any]:
    valid = [lap for lap in focus_laps if lap.validity == "included"]
    best = min(valid, key=lambda lap: lap.lap_time_s)
    average = statistics.mean(lap.lap_time_s for lap in valid)
    median = statistics.median(lap.lap_time_s for lap in valid)
    std = statistics.pstdev(lap.lap_time_s for lap in valid)
    ordered_times = sorted(lap.lap_time_s for lap in valid)
    top_two_gap_ms = (
        (ordered_times[1] - ordered_times[0]) * 1000 if len(ordered_times) > 1 else 0.0
    )
    theoretical = float(aggregate_df["fastest_sector_time_s"].sum())
    potential = best.lap_time_s - theoretical
    top = aggregate_df.sort_values(
        ["best_lap_potential_s", "sector_time_std_s"], ascending=False
    ).head(3)

    recommendations: list[dict[str, Any]] = []
    for _, summary in top.iterrows():
        group = sector_df[sector_df["segment_id"] == summary["segment_id"]]
        best_row = group[group["lap_uid"] == best.uid].iloc[0]
        fastest_row = group.loc[group["sector_time_s"].idxmin()]
        cause, action = diagnose_sector(best_row, fastest_row)
        recommendations.append(
            {
                "segment_name_ja": summary["segment_name_ja"],
                "segment_name": summary["segment_name"],
                "potential_s": float(summary["best_lap_potential_s"]),
                "best_sector_s": float(summary["best_lap_sector_time_s"]),
                "fastest_sector_s": float(summary["fastest_sector_time_s"]),
                "fastest_lap": str(summary["fastest_sector_lap"]),
                "cause": cause,
                "action": action,
                "consistency": summary["consistency"],
            }
        )

    lines = [
        f"# {track} テレメトリ解析",
        "",
        "## 全体結論",
        "",
        f"- 対象は **{valid[0].car_name}** の比較可能な{len(valid)}周です。ベストは **{format_time(best.lap_time_s)}**、平均は **{format_time(average)}** で、差は **{average - best.lap_time_s:.3f}秒** でした。",
        f"- 区間最速の単純合算による理論ベストは **{format_time(theoretical)}**、実ベストとの差は **{potential:.3f}秒** です。区間同士のつながりを無視した理論値なので、その全量が同時に再現できるとは限りません。",
        f"- ラップタイム標準偏差は **{std:.3f}秒**。{len(valid)}周中の上位2周は{top_two_gap_ms:.0f}ms差です。出口速度や操作タイミングのばらつきを縮める余地があります。",
        "",
        "## 最大の改善ポイント3件",
        "",
    ]
    for index, item in enumerate(recommendations, start=1):
        lines.extend(
            [
                f"### {index}. {item['segment_name_ja']} ({item['segment_name']})",
                "",
                "**データから確実に言えること**  ",
                f"実ベスト周の区間タイムは {item['best_sector_s']:.3f}秒、同区間の最速は {item['fastest_sector_s']:.3f}秒で、理論上 {item['potential_s']:.3f}秒の差があります。区間最速はラップ {item['fastest_lap']} で記録されています。再現性評価は {item['consistency']} です。",
                "",
                "**推測される原因**  ",
                f"比較すると、{item['cause']}。これは操作とラインの組み合わせによる可能性が高いですが、ステアリング舵角がないため断定はできません。",
                "",
                "**次に試すこと**  ",
                f"{item['action']}。1回に変える基準は1つに絞り、区間タイムと出口速度の両方で確認してください。",
                "",
            ]
        )

    if len(car_summary_df) > 1:
        ranked_cars = car_summary_df.sort_values("best_lap_s").reset_index(drop=True)
        fastest_car = ranked_cars.iloc[0]
        lines.extend(
            [
                "## 車種比較",
                "",
                f"今回の最速車は **{fastest_car['car_name']}** です。車種ごとのベスト、平均、理論ベスト、直線・高速コーナー指標を同じ距離区間で比較しました。",
                "",
                "| 車種 | 周回数 | ベスト | 最速車との差 | 平均 | 理論ベスト | 最高速 | ケメル終端 | プーオン最低速 | ブランシモン最低速 | 全開率 | 再現性 |",
                "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
            ]
        )
        for _, car in ranked_cars.iterrows():
            lines.append(
                f"| {car['car_name']} | {int(car['lap_count'])} | {car['best_lap']} | {car['best_lap_s'] - fastest_car['best_lap_s']:+.3f}秒 | {car['average_lap']} | {car['theoretical_best']} | {car['max_speed_kmh']:.1f}km/h | {car['kemmel_exit_speed_mean_kmh']:.1f}km/h | {car['pouhon_min_speed_mean_kmh']:.1f}km/h | {car['blanchimont_min_speed_mean_kmh']:.1f}km/h | {car['full_throttle_rate_mean_pct']:.1f}% | {car['reproducibility']} |"
            )
        if len(ranked_cars) >= 2:
            second_car = ranked_cars.iloc[1]
            lines.extend(
                [
                    "",
                    f"**{fastest_car['car_name']} は {second_car['car_name']} よりベストで {second_car['best_lap_s'] - fastest_car['best_lap_s']:.3f}秒、平均で {second_car['average_lap_s'] - fastest_car['average_lap_s']:.3f}秒速い**結果でした。車種差と習熟度が同時に含まれるため、車両性能だけの差とは断定できません。",
                    "",
                ]
            )

    lines.extend(
        [
            "## ベストラップと平均ラップ",
            "",
            f"| 指標 | 値 |",
            "|---|---:|",
            f"| ベストラップ | {format_time(best.lap_time_s)} |",
            f"| 平均ラップ | {format_time(average)} |",
            f"| 中央値 | {format_time(median)} |",
            f"| 標準偏差 | {std:.3f}秒 |",
            f"| ベストと平均の差 | {average - best.lap_time_s:.3f}秒 |",
            "",
            "## コーナー別評価",
            "",
            "| 区間 | 実ベスト周 | 区間最速 | 改善余地 | 再現性 | 最低速度平均 |",
            "|---|---:|---:|---:|---|---:|",
        ]
    )
    for _, row in aggregate_df.iterrows():
        lines.append(
            f"| {row['segment_name_ja']} | {row['best_lap_sector_time_s']:.3f}秒 | {row['fastest_sector_time_s']:.3f}秒 | {row['best_lap_potential_s']:.3f}秒 | {row['consistency']} | {row['min_speed_mean_kmh']:.1f}km/h |"
        )

    lines.extend(
        [
            "",
            "## 再現性",
            "",
            f"ラップ全体の標準偏差は {std:.3f}秒です。区間ごとの再現性は、区間タイム標準偏差が0.12秒以下を高、0.30秒以下を中、それより大きい場合を低として評価しました。ブレーキ位置・全開地点・最低速度・走行ラインのばらつきは `sector_aggregate.csv` に保存しています。",
            "",
            "## 理論ベスト",
            "",
            f"- 実ベスト: **{format_time(best.lap_time_s)}**",
            f"- 理論ベスト: **{format_time(theoretical)}**",
            f"- 差: **{potential:.3f}秒**",
            f"- 最大の改善余地: **{recommendations[0]['segment_name_ja']} ({recommendations[0]['potential_s']:.3f}秒)**",
            "- 現実的な目標は、まず上位3区間の改善余地の半分程度を安定して回収することです。区間最速の連結は進入・出口条件が同時成立しない場合があります。",
            "",
            "## 次の走行で試すこと",
            "",
        ]
    )
    for i, item in enumerate(recommendations, start=1):
        lines.append(f"{i}. **{item['segment_name_ja']}**: {item['action']}。")

    missing_fields = [
        "コース名",
        "タイヤ銘柄",
        "ステアリング舵角",
        "公式の無効ラップ判定",
    ]
    all_valid = [lap for lap in all_laps if lap.validity == "included"]
    duplicate_count = int(inventory["is_exact_duplicate"].sum())
    unique_session_count = len(inventory) - duplicate_count
    replay_count = sum(lap.is_replay for lap in all_valid)
    lines.extend(
        [
            "",
            "## データ品質と解析上の注意点",
            "",
            f"- 入力JSONは{len(inventory)}件で、{duplicate_count}件が完全重複でした。解析にはユニークな{unique_session_count}セッションを使用しました。",
            f"- 1ファイルは1周ではなく複数周を含むセッションです。今回は{len(all_valid)}周が完走データとして利用可能でした。",
            f"- {len(all_valid)}周中{replay_count}周がリプレイ記録です。記録モードの違いを含む比較であることを明示します。",
            f"- 保存データにない項目: {', '.join(missing_fields)}。コースは依頼内容に基づきスパと仮定し、ステアリングの代わりにヨーレートを使いました。",
            "- 区間境界は初期推定です。`spa_segments.json` を編集すれば再実行時に反映されます。",
            "",
            "## 生成グラフ",
            "",
            "- `graphs/01_speed_comparison.png`",
            "- `graphs/02_throttle_comparison.png`",
            "- `graphs/03_brake_comparison.png`",
            "- `graphs/04_gear_comparison.png`",
            "- `graphs/05_cumulative_delta.png`",
            "- `graphs/06_racing_line.png`",
            "- `graphs/07_lap_time_progression.png`",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "focus_car_id": best.car_id,
        "focus_car_name": best.car_name,
        "best_lap_s": best.lap_time_s,
        "average_lap_s": average,
        "median_lap_s": median,
        "lap_std_s": std,
        "theoretical_best_s": theoretical,
        "potential_s": potential,
        "recommendations": recommendations,
        "car_comparison": car_summary_df.drop(columns=["best_lap_uid"]).to_dict(
            orient="records"
        ),
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    graphs_dir = output_dir / "graphs"
    output_dir.mkdir(parents=True, exist_ok=True)
    graphs_dir.mkdir(parents=True, exist_ok=True)

    global plt, pd
    try:
        import matplotlib
        import pandas
    except ImportError as error:
        raise SystemExit(
            f"このスクリプトには追加ライブラリが必要です ({error.name})。\n"
            "  .venv\\Scripts\\python.exe -m pip install -r requirements-full.txt\n"
            "HTMLレポート (build_report.py) はこれらなしで動きます。"
        ) from error

    matplotlib.use("Agg")
    import matplotlib.pyplot

    plt = matplotlib.pyplot
    pd = pandas

    sessions, inventory_rows = load_sessions(args.data_dir.resolve())
    inventory = pd.DataFrame(inventory_rows)
    car_names = load_car_names(DEFAULT_CARS_CSV)
    laps = deduplicate_laps(sessions, car_names)
    definition = load_segments(args.segments.resolve())
    segments = definition["segments"]
    valid_laps = [lap for lap in laps if lap.validity == "included"]
    if len(valid_laps) < 2:
        raise ValueError("At least two complete laps are required for comparison")
    overall_best_lap = min(valid_laps, key=lambda lap: lap.lap_time_s)
    if args.focus_car_id is None:
        focus_car_id = overall_best_lap.car_id
    else:
        available_car_ids = {lap.car_id for lap in valid_laps}
        if args.focus_car_id not in available_car_ids:
            raise ValueError(
                f"Focus car ID {args.focus_car_id} was not found. "
                f"Available car IDs: {sorted(available_car_ids)}"
            )
        focus_car_id = args.focus_car_id
    focus_laps = [lap for lap in valid_laps if lap.car_id == focus_car_id]
    best_lap = min(focus_laps, key=lambda lap: lap.lap_time_s)

    lap_rows = []
    for order, lap in enumerate(laps, start=1):
        lap_rows.append(
            {
                "recorded_order": order,
                "lap_uid": lap.uid,
                "source_file": lap.source_file,
                "start_timestamp": lap.start_timestamp,
                "end_timestamp": lap.end_timestamp,
                "lap_number": lap.number,
                "lap_title": lap.title,
                "lap_time_s": lap.lap_time_s,
                "live_time_s": lap.live_time_s,
                "distance_m": lap.total_distance_m if len(lap.distance_m) else None,
                "max_speed_kmh": float(np.max(lap.speed_kmh)) if len(lap.speed_kmh) else None,
                "min_speed_kmh": float(np.min(lap.speed_kmh)) if len(lap.speed_kmh) else None,
                "car_id": lap.car_id,
                "car_name": lap.car_name,
                "is_replay": lap.is_replay,
                "is_manual": lap.is_manual,
                "comparison_status": lap.validity,
                "exclusion_reason": lap.exclusion_reason,
                "validity_basis": "heuristic_complete_lap; official invalid flag unavailable",
            }
        )
    lap_df = pd.DataFrame(lap_rows)

    sector_rows = [
        sector_metrics(lap, segment, best_lap)
        for segment in segments
        for lap in valid_laps
    ]
    sector_df = pd.DataFrame(sector_rows)
    best_lap_by_car = {
        car_id: min(
            (lap for lap in valid_laps if lap.car_id == car_id),
            key=lambda lap: lap.lap_time_s,
        )
        for car_id in {lap.car_id for lap in valid_laps}
    }
    for (car_id, segment_id), group in sector_df.groupby(
        ["car_id", "segment_id"]
    ):
        fastest = float(group["sector_time_s"].min())
        sector_df.loc[group.index, "delta_to_fastest_sector_s"] = group["sector_time_s"] - fastest
        car_best_uid = best_lap_by_car[int(car_id)].uid
        best_value = float(
            group.loc[group["lap_uid"] == car_best_uid, "sector_time_s"].iloc[0]
        )
        sector_df.loc[group.index, "delta_to_best_lap_sector_s"] = group["sector_time_s"] - best_value

    focus_sector_df = sector_df[sector_df["car_id"] == focus_car_id].copy()
    aggregate_df = aggregate_sectors(focus_sector_df, best_lap.uid)
    car_summary_df, vehicle_sector_df = build_car_summaries(valid_laps, sector_df)
    selected = choose_comparison_laps(valid_laps, focus_car_id)

    inventory.to_csv(output_dir / "file_inventory.csv", index=False, encoding="utf-8-sig")
    lap_df.to_csv(output_dir / "lap_summary.csv", index=False, encoding="utf-8-sig")
    sector_df.to_csv(output_dir / "sector_summary.csv", index=False, encoding="utf-8-sig")
    aggregate_df.to_csv(output_dir / "sector_aggregate.csv", index=False, encoding="utf-8-sig")
    car_summary_df.to_csv(output_dir / "car_summary.csv", index=False, encoding="utf-8-sig")
    vehicle_sector_df.to_csv(
        output_dir / "vehicle_sector_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )

    adjusted_definition = dict(definition)
    adjusted_definition["reconstructed_reference_distance_m"] = best_lap.total_distance_m
    adjusted_definition["segments"] = [
        {
            **segment,
            "start_m_reference": float(segment["start_fraction"] * best_lap.total_distance_m),
            "end_m_reference": float(segment["end_fraction"] * best_lap.total_distance_m),
        }
        for segment in segments
    ]
    resolved_segments_name = f"{args.segments.stem}_resolved.json"
    (output_dir / resolved_segments_name).write_text(
        json.dumps(adjusted_definition, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    setup_plot()
    save_line_plot(graphs_dir / "01_speed_comparison.png", selected, segments, "speed_kmh", "Speed comparison", "Speed (km/h)")
    save_line_plot(graphs_dir / "02_throttle_comparison.png", selected, segments, "throttle_pct", "Throttle comparison", "Throttle (%)")
    save_line_plot(graphs_dir / "03_brake_comparison.png", selected, segments, "brake_pct", "Brake comparison", "Brake (%)")
    save_line_plot(graphs_dir / "04_gear_comparison.png", selected, segments, "gear", "Gear comparison", "Gear", step=True)
    save_delta_plot(graphs_dir / "05_cumulative_delta.png", selected, segments)
    save_racing_line(graphs_dir / "06_racing_line.png", selected)
    save_lap_trend(graphs_dir / "07_lap_time_progression.png", valid_laps)

    summary = build_report(
        output_dir / "analysis_report.md",
        args.track,
        laps,
        focus_laps,
        inventory,
        focus_sector_df,
        aggregate_df,
        car_summary_df,
    )
    run_metadata = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "input_directory": str(args.data_dir.resolve()),
        "track_assumption": args.track,
        "unique_session_count": len(sessions),
        "input_file_count": len(inventory),
        "exact_duplicate_file_count": int(inventory["is_exact_duplicate"].sum()),
        "lap_count": len(laps),
        "included_lap_count": len(valid_laps),
        "focus_car_id": focus_car_id,
        "focus_car_name": best_lap.car_name,
        "overall_best_car_id": overall_best_lap.car_id,
        "overall_best_car_name": overall_best_lap.car_name,
        "overall_best_lap": format_time(overall_best_lap.lap_time_s),
        "overall_best_lap_s": overall_best_lap.lap_time_s,
        "car_ids": sorted({lap.car_id for lap in valid_laps}),
        "car_names": sorted({lap.car_name for lap in valid_laps}),
        "car_summary": car_summary_df.drop(columns=["best_lap_uid"]).to_dict(
            orient="records"
        ),
        "summary": summary,
    }
    (output_dir / "run_metadata.json").write_text(
        json.dumps(run_metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(run_metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
