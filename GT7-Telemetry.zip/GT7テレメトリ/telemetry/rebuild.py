"""Rebuilds the reports of sessions already on disk with the current code.

A report is a finished HTML file: once written, it keeps the analysis and the
wording of the version that made it. After an update, the laps recorded last
week would go on showing last week's advice. Everything a report needs is still
in its session folder, so it can simply be built again.
"""

from __future__ import annotations

from pathlib import Path

from telemetry import sessions


def rebuild(root: Path, directory: Path) -> Path:
    """Builds one session's report (and its per-car reports) again, in place.

    `root` is the sessions folder, where each circuit keeps its corner names and
    the earlier sessions the history ghost is drawn from.
    """
    meta = sessions.read_meta(directory)
    if meta is None or not (directory / sessions.SESSION_FILENAME).exists():
        raise ValueError(f"{directory} は走行記録のフォルダではありません")

    # Imported here: only rebuilding needs the report builder and its numpy.
    import build_report

    segments = root / meta.track_slug / sessions.SEGMENTS_FILENAME
    common = {
        "data_dir": directory,
        # The corner names were saved by the first build; reading them back
        # keeps every report of this circuit naming the corners the same way.
        "segments": segments if segments.exists() else None,
        "auto_segments": not segments.exists(),
        "track_slug": meta.track_slug,
        "track_name": meta.track,
        "history_root": root,
    }
    outcome = build_report.build(
        out=directory / sessions.REPORT_FILENAME, save_segments=segments, **common
    )
    for car in meta.cars:
        if car.id is None or not car.report or car.report == sessions.REPORT_FILENAME:
            continue
        build_report.build(out=directory / car.report, car_id=car.id, **common)
    return outcome.path


def rebuild_all(root: Path) -> tuple[int, list[str]]:
    """Rebuilds every session under `root`. Returns the count and any failures.

    One broken session must not stop the rest, so each failure is collected and
    reported instead of raised.
    """
    rebuilt = 0
    failures: list[str] = []
    for meta in sessions.collect(root):
        try:
            rebuild(root, meta.directory)
            rebuilt += 1
        except Exception as error:  # noqa: BLE001 - keep going with the others
            failures.append(f"{meta.directory.relative_to(root)}: {error}")
    sessions.write_index(root)
    return rebuilt, failures
