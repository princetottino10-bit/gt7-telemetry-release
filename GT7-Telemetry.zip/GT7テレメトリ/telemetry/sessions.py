"""Where recorded sessions live on disk, and the page that lists them.

Every session gets its own folder under the circuit it was driven on:

    sessions/watkins-glen-long/2026-08-20_2029/
        session.json   the laps
        report.html    the analysis
        meta.json      a few fields, so the index does not have to open the rest

Keeping sessions apart matters for more than tidiness: a report is built from
every session file in one folder, so two different circuits sharing a folder
produce a report that silently averages two different lap shapes together.

`index.html` at the top lists everything and shows whether the times are coming
down, which is the part worth looking at after a few weeks.
"""

from __future__ import annotations

import html
import json
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
from typing import Any

from telemetry import tracks

try:
    import icons
except ImportError:  # pragma: no cover - the page reads fine without them
    icons = None

META_FILENAME = "meta.json"
SESSION_FILENAME = "session.json"
REPORT_FILENAME = "report.html"
INDEX_FILENAME = "index.html"
RAW_FILENAME = "raw.bin"
# Corner names belong to the circuit, so they sit one level up from a session.
SEGMENTS_FILENAME = "segments.json"


def car_slug(car_id: int | None, car_name: str | None) -> str:
    """A filesystem-safe stem for one car, for the per-car report's filename."""
    # The apostrophe in a GT7 model year ("GT-R '17") survives tracks.slug and is
    # legal in a filename, but it quotes badly in a shell and reads as a typo in
    # a folder listing, so it goes.
    name = (car_name or "").replace("'", "").replace(",", "")
    stem = tracks.slug(name) if name.strip() else ""
    if stem and stem != "unknown-track":
        return stem
    return f"car-{car_id}" if car_id is not None else "car-unknown"


def car_report_filename(car_id: int | None, car_name: str | None) -> str:
    """Where one car's own report lives inside a session folder."""
    return f"report.{car_slug(car_id, car_name)}.html"


@dataclass(frozen=True)
class CarMeta:
    """One car driven during a session, and where its own report sits."""

    id: int | None
    name: str | None
    laps: int
    best_lap_s: float | None
    report: str | None

    @property
    def label(self) -> str:
        return self.name or (str(self.id) if self.id is not None else "—")


@dataclass(frozen=True)
class SessionMeta:
    """The handful of facts the index page needs."""

    track: str
    track_slug: str
    recorded_at: str
    laps: int
    best_lap_s: float | None
    theoretical_s: float | None
    car_id: int | None
    car_name: str | None
    lap_distance_m: float | None
    directory: Path
    # Every car driven in this session. Sessions recorded before cars could be
    # swapped mid-recording have no `cars` key at all, so this is rebuilt from
    # the singular carId/carName for them and is never empty.
    cars: tuple[CarMeta, ...] = ()

    @property
    def moment(self) -> datetime | None:
        try:
            return datetime.fromisoformat(self.recorded_at)
        except ValueError:
            return None


def session_directory(root: Path, track_name: str, started_at: datetime) -> Path:
    """Creates and returns the folder this session belongs in."""
    stamp = started_at.strftime("%Y-%m-%d_%H%M")
    directory = root / tracks.slug(track_name) / stamp
    # Two sessions inside the same minute would otherwise land on each other.
    suffix = 2
    while directory.exists() and any(directory.iterdir()):
        directory = root / tracks.slug(track_name) / f"{stamp}-{suffix}"
        suffix += 1
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def write_meta(directory: Path, meta: dict[str, Any]) -> Path:
    path = directory / META_FILENAME
    path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def read_meta(directory: Path) -> SessionMeta | None:
    path = directory / META_FILENAME
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    track = str(payload.get("track") or "不明なコース")
    return SessionMeta(
        track=track,
        track_slug=str(payload.get("trackSlug") or tracks.slug(track)),
        recorded_at=str(payload.get("recordedAt") or ""),
        laps=int(payload.get("laps") or 0),
        best_lap_s=_optional_float(payload.get("bestLapS")),
        theoretical_s=_optional_float(payload.get("theoreticalS")),
        car_id=_optional_int(payload.get("carId")),
        car_name=payload.get("carName"),
        lap_distance_m=_optional_float(payload.get("lapDistanceM")),
        directory=directory,
        cars=_read_cars(payload),
    )


def _read_cars(payload: dict[str, Any]) -> tuple[CarMeta, ...]:
    """The session's cars, whichever shape the sidecar was written in.

    `cars` arrived with mid-session car changes. Every session recorded before
    it has one car described by the singular fields, so those are read back into
    the same shape rather than leaving the caller to handle two layouts.
    """
    entries = payload.get("cars")
    if isinstance(entries, list) and entries:
        cars: list[CarMeta] = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            cars.append(
                CarMeta(
                    id=_optional_int(entry.get("id")),
                    name=entry.get("name"),
                    laps=int(_optional_int(entry.get("laps")) or 0),
                    best_lap_s=_optional_float(entry.get("bestLapS")),
                    report=entry.get("report"),
                )
            )
        if cars:
            return tuple(cars)

    return (
        CarMeta(
            id=_optional_int(payload.get("carId")),
            name=payload.get("carName"),
            laps=int(payload.get("laps") or 0),
            best_lap_s=_optional_float(payload.get("bestLapS")),
            report=payload.get("report"),
        ),
    )


def _optional_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _optional_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def repair_placeholder_names(root: Path, metas: list[SessionMeta], registry) -> list[SessionMeta]:
    """Gives a name to sessions recorded before their circuit had one.

    A circuit is named once, and everything recorded on it before that keeps the
    placeholder it was saved under - so answering the question could leave the
    listing still calling it "未設定のコース 3.570km". The name is looked up by
    the folder the session sits in first, and by lap length only when that is
    unambiguous, then written back so the repair happens once.
    """
    if registry is None or not registry.entries:
        return metas
    repaired: list[SessionMeta] = []
    for meta in metas:
        if not tracks.is_placeholder(meta.track):
            repaired.append(meta)
            continue
        found = registry.name_for_slug(meta.directory.parent.name)
        if found is None and meta.lap_distance_m:
            found = registry.name_for_length(meta.lap_distance_m)
        if found is None:
            repaired.append(meta)
            continue
        _rewrite_track_name(meta.directory, found)
        repaired.append(replace(meta, track=found, track_slug=tracks.slug(found)))
    return repaired


def _rewrite_track_name(directory: Path, name: str) -> None:
    """Puts the circuit's name into a session's own record of itself."""
    path = directory / META_FILENAME
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["track"] = name
        payload["trackSlug"] = tracks.slug(name)
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    except (OSError, json.JSONDecodeError):
        # The listing is worth showing even if the file cannot be corrected.
        return


def collect(root: Path) -> list[SessionMeta]:
    """Every recorded session under `root`, newest first."""
    if not root.exists():
        return []
    found = [
        meta
        for path in sorted(root.glob("*/*/" + META_FILENAME))
        if (meta := read_meta(path.parent)) is not None
    ]
    found.sort(key=lambda meta: meta.recorded_at, reverse=True)
    return found


def _format_time(seconds: float | None) -> str:
    if seconds is None or seconds <= 0:
        return "—"
    minutes, remainder = divmod(seconds, 60)
    return f"{int(minutes)}:{remainder:06.3f}"


def _format_date(meta: SessionMeta) -> str:
    moment = meta.moment
    return moment.strftime("%Y-%m-%d %H:%M") if moment else meta.recorded_at


def _delta_label(seconds: float | None) -> tuple[str, str]:
    """A signed gap to the circuit's best, and the class that colours it."""
    if seconds is None:
        return "", ""
    if abs(seconds) < 0.0005:
        return "自己ベスト", "best"
    return f"+{seconds:.3f}", "slower"


# Geometry of the per-circuit trend chart, in the SVG's own user units. The
# element is scaled to the panel width by its viewBox, so these are proportions
# rather than pixels.
_TREND_WIDTH = 640
_TREND_HEIGHT = 170
# Wide enough for a right-aligned "2:04.812" even at the enlarged label size the
# stylesheet switches to on a phone.
_TREND_LEFT = 88
_TREND_RIGHT = 16
_TREND_TOP = 16
_TREND_BOTTOM = 30


def _trend_points(entries: list[SessionMeta]) -> list[SessionMeta]:
    """The timed sessions of one circuit, oldest first.

    A session with no best lap has nothing to plot - it would either break the
    line or invent a time - so it is left out here and still listed in the table.
    """
    timed = [entry for entry in entries if entry.best_lap_s]
    timed.sort(key=lambda entry: entry.recorded_at)
    return timed


def _cars_of(meta: SessionMeta) -> tuple[CarMeta, ...]:
    """The session's cars, standing in for a sidecar that predates the field."""
    if meta.cars:
        return meta.cars
    return (
        CarMeta(
            id=meta.car_id,
            name=meta.car_name,
            laps=meta.laps,
            best_lap_s=meta.best_lap_s,
            report=None,
        ),
    )


# One colour per car on a circuit's chart. The first is the accent the chart has
# always used, so a single-car circuit is unchanged.
_TREND_COLOURS = ("#2ad4e8", "#f5a524", "#a78bfa", "#4ade80", "#f472b6", "#38bdf8")

TrendSeries = tuple[str, list[tuple[int, float, SessionMeta]]]


def _trend_series(points: list[SessionMeta]) -> list[TrendSeries]:
    """One line's worth of points per car, keyed by the name shown in the legend.

    Splitting by car is the whole point of the chart being per-car: swapping into
    a quicker car drops the lap time without the driver having improved at all,
    and a single line through both would read as progress.
    """
    series: dict[str, list[tuple[int, float, SessionMeta]]] = {}
    for index, entry in enumerate(points):
        for car in _cars_of(entry):
            if not car.best_lap_s:
                continue
            series.setdefault(car.label, []).append((index, car.best_lap_s, entry))
    return list(series.items())


def _trend_svg(entries: list[SessionMeta]) -> str:
    """A best-lap-per-session line per car, or "" if there is no trend yet.

    Drawn inline so the page stays a file that can be opened from the disk with no
    network and no library. The time axis is deliberately upside down: a quicker
    lap is a smaller number, and plotting it lower means the line falls as the
    driver improves, which is the way everyone reads a progress chart.
    """
    points = _trend_points(entries)
    series = _trend_series(points)
    values = [seconds for _, entries_for_car in series for _, seconds, _ in entries_for_car]
    if len(values) < 2:
        return ""

    fastest = min(values)
    slowest = max(values)
    span = slowest - fastest
    multi = len(series) > 1
    legend_height = 22 if multi else 0
    height = _TREND_HEIGHT + legend_height
    plot_width = _TREND_WIDTH - _TREND_LEFT - _TREND_RIGHT
    plot_height = _TREND_HEIGHT - _TREND_TOP - _TREND_BOTTOM

    def x_at(index: int) -> float:
        if len(points) <= 1:
            return _TREND_LEFT + plot_width / 2
        return _TREND_LEFT + plot_width * index / (len(points) - 1)

    def y_at(seconds: float) -> float:
        # Every session within a few thousandths: centre the flat line rather
        # than magnifying rounding noise into a mountain range.
        if span < 0.01:
            return _TREND_TOP + plot_height / 2
        # Upside down on purpose: quicker is a smaller number and belongs lower.
        return _TREND_TOP + plot_height * (slowest - seconds) / span

    # Slowest at the top, quickest at the bottom, with the midpoint for scale.
    ticks = [slowest, (slowest + fastest) / 2, fastest] if span >= 0.01 else [fastest]
    grid: list[str] = []
    for value in ticks:
        y = y_at(value)
        grid.append(
            f'<line x1="{_TREND_LEFT}" y1="{y:.1f}" x2="{_TREND_WIDTH - _TREND_RIGHT}" y2="{y:.1f}" class="tg"/>'
            f'<text x="{_TREND_LEFT - 8}" y="{y + 3.5:.1f}" class="tl">{_format_time(value)}</text>'
        )

    lines: list[str] = []
    dots: list[str] = []
    legend: list[str] = []
    for position, (name, plotted) in enumerate(series):
        colour = _TREND_COLOURS[position % len(_TREND_COLOURS)]
        # A single-car circuit keeps the stylesheet's own colours, so nothing
        # about the chart it has always drawn changes.
        stroke = f' style="stroke:{colour}"' if multi else ""
        if len(plotted) > 1:
            path = " ".join(
                f"{'M' if step == 0 else 'L'}{x_at(index):.1f},{y_at(seconds):.1f}"
                for step, (index, seconds, _) in enumerate(plotted)
            )
            lines.append(f'<path d="{path}" class="tp"{stroke}/>')
        for index, seconds, entry in plotted:
            # Green marks the quickest lap on the circuit. With more than one car
            # that would praise the faster car rather than the driver, so the
            # marker is dropped and each car keeps its own colour instead.
            best = not multi and seconds == fastest
            label = f"{_format_date(entry)} · {_format_time(seconds)}"
            if multi:
                label = f"{name} · {label}"
            dots.append(
                f'<circle cx="{x_at(index):.1f}" cy="{y_at(seconds):.1f}" r="4.5" '
                f'class="{"td tb" if best else "td"}"{stroke}>'
                f"<title>{html.escape(label)}</title></circle>"
            )
        if multi:
            legend_x = _TREND_LEFT + position * 190
            legend_y = height - 6
            legend.append(
                f'<rect x="{legend_x}" y="{legend_y - 9:.0f}" width="10" height="10" '
                f'rx="2" fill="{colour}"/>'
                f'<text x="{legend_x + 16}" y="{legend_y}" class="tx">{html.escape(name)}</text>'
            )

    first = _format_date(points[0])[:10]
    last = _format_date(points[-1])[:10]
    baseline = _TREND_HEIGHT - _TREND_BOTTOM + 16
    # One caption rather than a label at each end of the axis: the tick times sit
    # at the same left margin, and two more labels there only collide with them.
    axis = (
        f'<text x="0" y="{baseline}" class="tx">↓速い</text>'
        f'<text x="{_TREND_LEFT}" y="{baseline}" class="tx">{html.escape(first)}</text>'
        f'<text x="{_TREND_WIDTH - _TREND_RIGHT}" y="{baseline}" class="tx te">{html.escape(last)}</text>'
    )

    aria = "車ごとのベストタイム推移" if multi else "セッションごとのベストタイム推移"
    return (
        f'<svg class="trend" viewBox="0 0 {_TREND_WIDTH} {height}" '
        f'role="img" aria-label="{aria}">'
        + "".join(grid)
        + "".join(lines)
        + "".join(dots)
        + axis
        + "".join(legend)
        + "</svg>"
    )


def _car_cell(root: Path, entry: SessionMeta) -> str:
    """The car column: every car driven, each linking to its own report.

    A session with one car is left as plain text, because the row's own レポート
    link already opens the only report there is.
    """
    cars = _cars_of(entry)
    parts: list[str] = []
    for car in cars:
        label = html.escape(car.label)
        report = entry.directory / car.report if car.report else None
        if len(cars) > 1 and report is not None and report.exists():
            link = html.escape(report.relative_to(root).as_posix())
            parts.append(f'<a href="{link}" title="{label} だけのレポート">{label}</a>')
        else:
            parts.append(label)
    # One line per car, in the same order as the time and gap columns, so a
    # row with two cars reads across as two aligned lines.
    return _per_car_lines(parts)


def _car_bests(entries: list[SessionMeta]) -> dict[str, float]:
    """The quickest lap each car has ever done on this circuit, by car label.

    The gap column is measured against this rather than the circuit's outright
    best. A lap in a slower car compared with the quickest car on the circuit
    says nothing about the driving; compared with the same car's own best it does.
    """
    bests: dict[str, float] = {}
    for entry in entries:
        for car in _cars_of(entry):
            if not car.best_lap_s:
                continue
            label = car.label
            if label not in bests or car.best_lap_s < bests[label]:
                bests[label] = car.best_lap_s
    return bests


def _per_car_lines(parts: list[str]) -> str:
    """Stacks one line per car, so the car, time and gap columns line up."""
    if len(parts) == 1:
        return parts[0]
    return "".join(f'<div class="carline">{part}</div>' for part in parts)


def _best_cell(entry: SessionMeta) -> str:
    cars = _cars_of(entry)
    return _per_car_lines([_format_time(car.best_lap_s) for car in cars])


def _gap_cell(entry: SessionMeta, car_bests: dict[str, float], track_best: float | None) -> str:
    """The gap to the same car's best on this circuit, one line per car.

    When the circuit has seen more than one car, the gap to the outright best is
    kept in a tooltip: still there for whoever wants it, no longer in the way.
    """
    cars = _cars_of(entry)
    several_on_circuit = len(car_bests) > 1
    lines: list[str] = []
    for car in cars:
        own_best = car_bests.get(car.label)
        gap = None
        if car.best_lap_s is not None and own_best is not None:
            gap = car.best_lap_s - own_best
        text, css = _delta_label(gap)
        title = ""
        if several_on_circuit and car.best_lap_s is not None and track_best is not None:
            overall = car.best_lap_s - track_best
            overall_text = "コース最速" if abs(overall) < 0.0005 else f"コース最速 +{overall:.3f}"
            title = f' title="{html.escape(overall_text)}（{html.escape(_format_time(track_best))}）"'
        lines.append(f'<span class="{css}"{title}>{html.escape(text)}</span>')
    return _per_car_lines(lines)


RECENT_LIMIT = 8


def _relative_day(moment: datetime | None, *, now: datetime | None = None) -> str:
    """When it was, in the terms the driver would use."""
    if moment is None:
        return ""
    now = now or datetime.now()
    days = (now.date() - moment.date()).days
    if days == 0:
        return "今日"
    if days == 1:
        return "昨日"
    if days < 7:
        return f"{days}日前"
    if days < 30:
        return f"{days // 7}週間前"
    if days < 365:
        return f"{days // 30}か月前"
    return f"{days // 365}年前"


def _overview(root: Path, sessions: list[SessionMeta]) -> str:
    """What has been driven, and when - which the per-circuit sections cannot say.

    Grouping by circuit answers "am I getting quicker at Laguna Seca"; it does
    not answer "what did I drive last week", because every session of a given
    circuit sits together however long ago it was. This is that other question.
    """
    if not sessions:
        return ""

    tracks = {meta.track for meta in sessions}
    laps = sum(meta.laps for meta in sessions)
    dated = sorted(
        (meta for meta in sessions if meta.moment is not None),
        key=lambda meta: meta.moment,
        reverse=True,
    )
    latest = dated[0].moment if dated else None

    stats = [
        ("i-route", f"{len(tracks)}", "コース"),
        ("i-layers", f"{len(sessions)}", "セッション"),
        ("i-loop", f"{laps}", "周"),
        ("i-clock", _relative_day(latest) or "—", "最後の走行"),
    ]
    cards = "".join(
        f'<div class="stat"><span class="stat__label">'
        f'<svg class="ic ic--sm"><use href="#{icon}"/></svg>{html.escape(label)}</span>'
        f'<span class="stat__value">{html.escape(value)}</span></div>'
        for icon, value, label in stats
    )

    jumps = "".join(
        f'<a class="jump" href="#{html.escape(_anchor(track))}">{html.escape(track)}</a>'
        for track in sorted(tracks)
    )

    rows: list[str] = []
    for meta in dated[:RECENT_LIMIT]:
        report = meta.directory / REPORT_FILENAME
        label = f"{meta.laps}周"
        if meta.best_lap_s:
            label += f" / ベスト {_format_time(meta.best_lap_s)}"
        line = (
            f'<span class="recent__when">{html.escape(_relative_day(meta.moment))}</span>'
            f'<span class="recent__track">{html.escape(meta.track)}</span>'
            f'<span class="recent__what">{html.escape(label)}</span>'
        )
        if report.exists():
            href = html.escape(report.relative_to(root).as_posix())
            rows.append(f'<a class="recent" href="{href}">{line}</a>')
        else:
            rows.append(f'<div class="recent recent--dead">{line}</div>')

    return (
        '<section class="overview">'
        f'<div class="stats">{cards}</div>'
        f'<div class="jumps">{jumps}</div>'
        '<h2><svg class="ic ic--h2"><use href="#i-clock"/></svg>最近の走行</h2>'
        f'<div class="recents">{"".join(rows)}</div>'
        "</section>"
    )


def _anchor(track: str) -> str:
    """A stable id for a circuit's section, so the jump links reach it."""
    return "t-" + tracks.slug(track)


def _mark() -> str:
    """The badge beside the title: the app icon if it shipped, the drawn flag if not."""
    if icons is not None and icons.favicon_uri():
        return '<span class="mark mark--art" aria-hidden="true"></span>'
    return '<span class="mark"><svg class="ic ic--mark"><use href="#i-flag"/></svg></span>'


def render_index(root: Path, sessions: list[SessionMeta]) -> str:
    """The listing page: circuits, their sessions, and whether times are falling."""
    by_track: dict[str, list[SessionMeta]] = {}
    for meta in sessions:
        by_track.setdefault(meta.track, []).append(meta)

    blocks: list[str] = []
    for track, entries in sorted(by_track.items(), key=lambda item: item[0]):
        timed = [entry for entry in entries if entry.best_lap_s]
        track_best = min((entry.best_lap_s for entry in timed), default=None)
        car_bests = _car_bests(entries)
        rows: list[str] = []
        for entry in entries:
            report = entry.directory / REPORT_FILENAME
            link = report.relative_to(root).as_posix() if report.exists() else None
            name = _car_cell(root, entry)
            rows.append(
                "<tr>"
                f"<td class=\"when\">{html.escape(_format_date(entry))}</td>"
                f"<td>{name}</td>"
                f"<td class=\"num\">{entry.laps}</td>"
                f"<td class=\"num time\">{_best_cell(entry)}</td>"
                f"<td class=\"num\">{_gap_cell(entry, car_bests, track_best)}</td>"
                f"<td class=\"num faint\">{_format_time(entry.theoretical_s)}</td>"
                + (
                    f"<td class=\"go\"><a href=\"{html.escape(link)}\">"
                    '<svg class="ic ic--sm"><use href="#i-report"/></svg>レポート</a></td>'
                    if link
                    else "<td class=\"go faint\">—</td>"
                )
                + "</tr>"
            )
        distance = next(
            (entry.lap_distance_m for entry in entries if entry.lap_distance_m), None
        )
        subtitle = f"{len(entries)}セッション"
        if distance:
            subtitle += f" / 1周 {distance / 1000:.3f} km"
        if track_best:
            subtitle += f" / ベスト {_format_time(track_best)}"
            if len(car_bests) > 1:
                holder = min(car_bests, key=car_bests.get)
                subtitle += f"（{holder}）"
        blocks.append(
            f"<section class=\"track\" id=\"{html.escape(_anchor(track))}\">"
            '<h2><svg class="ic ic--h2"><use href="#i-route"/></svg>'
            f"{html.escape(track)}</h2>"
            f"<p class=\"subtitle\">{html.escape(subtitle)}</p>"
            + _trend_svg(entries)
            + "<table><thead><tr>"
            "<th>走行日</th><th>車</th><th>周</th><th>ベスト</th>"
            "<th>同じ車のベストとの差</th><th>理論ベスト</th><th></th>"
            "</tr></thead><tbody>" + "".join(rows) + "</tbody></table></section>"
        )

    if not blocks:
        blocks.append(
            '<section class="track empty"><h2><svg class="ic ic--h2"><use href="#i-flag"/></svg>まだ記録がありません</h2>'
            "<p class=\"subtitle\">GT7でコースに出た状態で記録を始めてください。</p></section>"
        )

    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    return (
        _INDEX_TEMPLATE.replace("{{OVERVIEW}}", _overview(root, sessions))
        .replace("{{BLOCKS}}", "".join(blocks))
        .replace("{{GENERATED}}", generated)
        .replace("{{SPRITE}}", icons.sprite() if icons else "")
        .replace("{{FAVICON}}", icons.favicon_link() if icons else "")
        .replace("{{ICON_STYLES}}", icons.STYLES if icons else "")
        .replace("{{HERO_STYLE}}", icons.hero_style() if icons else "")
        .replace("{{MARK}}", _mark())
    )


def write_index(root: Path, registry=None) -> Path:
    """Refreshes the listing page and returns its path."""
    root.mkdir(parents=True, exist_ok=True)
    path = root / INDEX_FILENAME
    metas = repair_placeholder_names(root, collect(root), registry)
    path.write_text(render_index(root, metas), encoding="utf-8")
    return path


_INDEX_TEMPLATE = """<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GT7 走行記録</title>
{{FAVICON}}
<style>
{{ICON_STYLES}}
{{HERO_STYLE}}
  :root {
    color-scheme: dark;
    --bg: #0d1117; --panel: #161b22; --line: #263040;
    --text: #e6edf3; --dim: #8b949e; --accent: #2ad4e8; --best: #4ade80;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 40px 24px 64px; background: var(--bg); color: var(--text);
    font-family: system-ui, "Segoe UI", sans-serif; line-height: 1.6;
  }
  .wrap { max-width: 980px; margin: 0 auto; }
  h1 { font-size: 26px; margin: 0 0 4px; letter-spacing: .02em; }
  .lead { color: var(--dim); margin: 0 0 36px; font-size: 14px; }
  .track { background: var(--panel); border: 1px solid var(--line); border-radius: 12px;
           padding: 22px 24px; margin-bottom: 22px; }
  .track h2 { font-size: 18px; margin: 0; }
  .subtitle { color: var(--dim); font-size: 13px; margin: 2px 0 16px; }
  .trend { display: block; width: 100%; height: auto; margin: 0 0 18px; overflow: visible; }
  .trend .tg { stroke: var(--line); stroke-width: 1; }
  .trend .tp { fill: none; stroke: var(--accent); stroke-width: 2.5;
               stroke-linejoin: round; stroke-linecap: round; }
  .trend .td { fill: var(--bg); stroke: var(--accent); stroke-width: 2.5; }
  .trend .td:hover { fill: var(--accent); }
  .trend .tb { stroke: var(--best); }
  .trend .tb:hover { fill: var(--best); }
  .trend .tl { fill: var(--dim); font-size: 13px; text-anchor: end;
               font-variant-numeric: tabular-nums; }
  .trend .tx { fill: var(--dim); font-size: 13px; }
  .trend .te { text-anchor: end; }
  /* Icons are stroked, not filled, so they sit at the weight of the text
     beside them rather than shouting over it. The shared rules arrive with the
     sprite; only what this page adds is here. */
  .ic--mark { width: 21px; height: 21px; stroke-width: 1.8; }
  h1 { display: flex; align-items: center; gap: 12px; }
  /* The header banner. The art is dark on its left by design, and a gradient
     deepens that further so the title reads whatever the image does. Without
     the art the variable is unset and the banner is simply the panel colour. */
  .hero { position: relative; overflow: hidden; border-radius: 14px;
          border: 1px solid var(--line); margin: 0 0 26px;
          padding: 44px 32px 34px; min-height: 210px;
          display: flex; flex-direction: column; justify-content: flex-end;
          background-color: var(--panel);
          background-image:
            linear-gradient(90deg, rgba(13,17,23,.96) 0%, rgba(13,17,23,.82) 38%,
                            rgba(13,17,23,.25) 72%, rgba(13,17,23,0) 100%),
            var(--hero-art, none);
          background-size: cover; background-position: right center; }
  .hero h1 { font-size: 34px; margin: 0 0 6px; letter-spacing: .01em;
             text-shadow: 0 2px 18px rgba(0,0,0,.6); }
  .hero .lead { margin: 0; max-width: 34em; color: #b8c2cf; }
  .hero__eyebrow { margin: 0 0 10px; font-size: 11px; font-weight: 700;
                   letter-spacing: .28em; color: var(--accent); }
  /* The app icon from Canva stands in for the drawn flag when it is there. */
  @media (max-width: 640px) {
    .hero { padding: 30px 20px 24px; min-height: 170px;
            background-position: 70% center; }
    .hero h1 { font-size: 26px; }
  }
  .mark { display: inline-grid; place-items: center; width: 38px; height: 38px;
          border-radius: 11px; color: var(--accent);
          background: linear-gradient(145deg, rgba(42,212,232,.16), rgba(42,212,232,.04));
          border: 1px solid rgba(42,212,232,.3); }
  /* The Canva app icon, when it is there, replaces the drawn flag outright. */
  .mark--art { background: var(--app-mark) center / cover no-repeat;
               border: 0; width: 44px; height: 44px; border-radius: 11px;
               box-shadow: 0 0 24px rgba(42,212,232,.35); }
  .track h2, .overview h2 { display: flex; align-items: center; }
  footer { display: flex; align-items: center; }
  .stat__label { display: flex; align-items: center; }
  .go a { display: inline-flex; align-items: center; }
  .overview { background: var(--panel); border: 1px solid var(--line); border-radius: 12px;
              padding: 22px 24px; margin-bottom: 22px; }
  .stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr));
           gap: 14px; margin-bottom: 18px; }
  .stat { display: flex; flex-direction: column-reverse; gap: 3px;
          justify-content: flex-end; }
  .stat__value { font-size: 26px; font-weight: 650; letter-spacing: -.01em;
                 font-variant-numeric: tabular-nums; line-height: 1.15; }
  .stat__label { font-size: 12px; color: var(--dim); letter-spacing: .04em; }
  .jumps { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 22px; }
  .jump { font-size: 13px; color: var(--accent); text-decoration: none;
          border: 1px solid var(--line); border-radius: 999px; padding: 4px 12px; }
  .jump:hover { border-color: var(--accent); }
  .overview h2 { font-size: 15px; margin: 0 0 10px; }
  .recents { display: flex; flex-direction: column; }
  .recent { display: grid; grid-template-columns: 5.5em minmax(0, 1fr) auto;
            gap: 12px; align-items: baseline; padding: 9px 0;
            border-bottom: 1px solid rgba(38,48,64,.55); color: inherit;
            text-decoration: none; font-size: 14px; }
  .recent:last-child { border-bottom: 0; }
  .recent:hover { color: var(--accent); }
  .recent--dead { color: var(--dim); }
  .recent__when { color: var(--dim); font-size: 13px; white-space: nowrap; }
  .recent__track { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .recent__what { color: var(--dim); font-variant-numeric: tabular-nums;
                  white-space: nowrap; font-size: 13px; }
  .recent:hover .recent__what { color: inherit; }
  @media (max-width: 640px) {
    .stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .recent { grid-template-columns: 4.5em minmax(0, 1fr); }
    .recent__what { grid-column: 2; }
  }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th { text-align: left; font-weight: 600; font-size: 12px; color: var(--dim);
       border-bottom: 1px solid var(--line); padding: 0 10px 8px 0; white-space: nowrap; }
  td { padding: 9px 10px 9px 0; border-bottom: 1px solid rgba(38,48,64,.55); }
  tr:last-child td { border-bottom: 0; }
  .num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
  .time { font-weight: 600; }
  .when { white-space: nowrap; }
  .faint { color: var(--dim); }
  .best { color: var(--best); font-weight: 600; }
  .slower { color: var(--dim); }
  .carline { line-height: 1.45; }
  .carline + .carline { margin-top: 2px; }
  [title] { cursor: help; }
  td a { color: var(--accent); text-decoration: none; }
  td a:hover { text-decoration: underline; }
  .go a { color: var(--accent); text-decoration: none; font-weight: 600; }
  .go a:hover { text-decoration: underline; }
  .go { text-align: right; }
  footer { color: var(--dim); font-size: 12px; margin-top: 30px; }
  @media (max-width: 640px) {
    body { padding: 24px 14px 48px; }
    th:nth-child(6), td:nth-child(6) { display: none; }
    /* Seven columns do not fit a phone however they are squeezed. The table
       scrolls inside its panel instead of pushing the whole page sideways. */
    .track table { display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; }
    .go .ic { display: none; }
    /* The chart is scaled to the panel by its viewBox, so on a phone its labels
       shrink with it. These are in the same user units, so a larger number here
       lands back at a readable size on screen. */
    .trend .tl, .trend .tx { font-size: 20px; }
  }
</style>
</head>
<body>
{{SPRITE}}
<div class="wrap">
  <header class="hero">
    <p class="hero__eyebrow">GT7 TELEMETRY</p>
    <h1>{{MARK}}走行記録</h1>
    <p class="lead">走った記録の一覧です。行を選ぶとそのセッションのレポートが開きます。</p>
  </header>
  {{OVERVIEW}}
  {{BLOCKS}}
  <footer><svg class="ic ic--sm"><use href="#i-watch"/></svg>更新: {{GENERATED}}</footer>
</div>
</body>
</html>
"""
