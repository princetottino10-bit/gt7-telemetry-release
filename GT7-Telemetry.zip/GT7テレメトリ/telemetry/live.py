"""Serves the live view over HTTP, using server-sent events.

The recorder runs on the capture thread; this only reads the snapshot it
publishes. Server-sent events are enough because the stream is one-way, and they
need no dependencies beyond the standard library.
"""

from __future__ import annotations

import json
from html import escape as html_escape
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, quote, unquote, urlsplit

from telemetry import qr

try:
    import icons
except ImportError:  # pragma: no cover - the page reads fine without them
    icons = None

UI_FILE = Path(__file__).parent / "live_ui.html"
DEFAULT_PORT = 8770
# The console streams at 60 Hz; the eye does not need that, and the browser has
# to draw between updates.
STREAM_HZ = 20


def _live_page() -> bytes:
    """The live view, with the shared icons folded in.

    Read fresh each time rather than cached: editing the page during a session
    and reloading the tab is how it gets worked on, and a capture can run for
    hours.
    """
    page = UI_FILE.read_text(encoding="utf-8")
    return (
        page.replace("__SPRITE__", icons.sprite() if icons else "")
        .replace("__FAVICON__", icons.favicon_link() if icons else "")
        .replace("__ICON_STYLES__", icons.STYLES if icons else "")
    ).encode("utf-8")


class _Handler(BaseHTTPRequestHandler):
    # Injected by LiveServer.
    state_provider: Callable[[], dict[str, Any]]
    on_stop: Callable[[], None] | None = None
    on_resume: Callable[[], None] | None = None
    server_ref: Any = None

    def log_message(self, *_args: Any) -> None:
        """Silence per-request logging; the capture output is the useful stream."""

    def _send_headers(self, status: int, content_type: str, **extra: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        for key, value in extra.items():
            self.send_header(key.replace("_", "-"), value)
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        if self.path.startswith("/events"):
            self._stream_events()
        elif self.path.startswith("/state"):
            payload = json.dumps(type(self).state_provider()).encode("utf-8")
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(payload)
        elif self.path.startswith("/report"):
            self._serve_report()
        elif self.path.startswith("/sessions"):
            self._serve_from_sessions()
        elif self.path.startswith("/qr"):
            self._serve_qr()
        elif self.path.startswith("/lan"):
            server = type(self).server_ref
            payload = json.dumps({"url": getattr(server, "lan_url", None)})
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(payload.encode("utf-8"))
        elif self.path in ("/", "/index.html"):
            self._send_headers(200, "text/html; charset=utf-8")
            self.wfile.write(_live_page())
        else:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write(b"not found")


    def do_POST(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        if self.path.startswith("/stop"):
            handler = type(self).on_stop
            if handler is not None:
                handler()
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(b'{"stopping": true}')
            return
        if self.path.startswith("/resume"):
            handler = type(self).on_resume
            if handler is not None:
                handler()
            self._send_headers(200, "application/json; charset=utf-8")
            self.wfile.write(b'{"resuming": true}')
            return
        self._send_headers(404, "text/plain; charset=utf-8")
        self.wfile.write(b"not found")

    def _serve_report(self) -> None:
        """Hands over the report once the capture has produced one."""
        server = type(self).server_ref
        path = getattr(server, "report_path", None)
        if path is None or not Path(path).exists():
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("レポートはまだありません".encode("utf-8"))
            return
        self._send_headers(200, "text/html; charset=utf-8")
        body = Path(path).read_bytes()
        body = _with_report_bar(
            body,
            resume=type(self).on_resume is not None,
            phone_path=_sessions_link(server, Path(path)),
        )
        self.wfile.write(body)

    def _serve_from_sessions(self) -> None:
        """Serves the listing page and the reports underneath it.

        Past sessions are ordinary files on disk, and a browser showing a page
        from this server will not follow a file:// link to them. Handing them
        out here is what makes "look at last week's lap" reachable without
        leaving the tab - or hunting through folders for it.
        """
        root = getattr(type(self).server_ref, "sessions_root", None)
        if root is None:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("走行記録の場所が設定されていません".encode("utf-8"))
            return

        relative = unquote(self.path[len("/sessions") :].split("?", 1)[0]).lstrip("/")
        target = (Path(root) / relative) if relative else (Path(root) / "index.html")
        if target.is_dir():
            target = target / "index.html"

        # Nothing outside the sessions folder, whatever the URL asks for.
        try:
            resolved = target.resolve()
            resolved.relative_to(Path(root).resolve())
        except (ValueError, OSError):
            self._send_headers(403, "text/plain; charset=utf-8")
            self.wfile.write(b"forbidden")
            return

        if not resolved.is_file():
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("見つかりません".encode("utf-8"))
            return

        kind = "text/html; charset=utf-8" if resolved.suffix == ".html" else "application/octet-stream"
        body = resolved.read_bytes()
        # Reports get the bar so one can be sent to a phone from wherever it was
        # opened; the listing already is the way back, so it is left alone.
        if resolved.suffix == ".html" and resolved.name != "index.html":
            body = _with_report_bar(body, resume=False, phone_path=_sessions_link(type(self).server_ref, resolved))
        self._send_headers(200, kind)
        self.wfile.write(body)

    def _serve_qr(self) -> None:
        """The live page's address as a scannable code.

        Drawn here rather than printed in the console window: the terminal's
        colours are the driver's to change, and an inverted code does not scan.
        """
        server = type(self).server_ref
        target = getattr(server, "lan_url", None)
        if not target:
            self._send_headers(404, "text/plain; charset=utf-8")
            self.wfile.write("このPCはネットワーク上のアドレスを持っていません".encode("utf-8"))
            return
        # A report asks for its own address. Only pages this server hands out
        # can be asked for, so the code never points a phone anywhere else.
        page = parse_qs(urlsplit(self.path).query).get("path", [""])[0]
        if page:
            if not (page == "/report" or page.startswith("/sessions/")):
                self._send_headers(400, "text/plain; charset=utf-8")
                self.wfile.write(b"bad path")
                return
            target = target.rstrip("/") + page
        self._send_headers(200, "image/svg+xml; charset=utf-8")
        self.wfile.write(qr.to_svg(target).encode("utf-8"))

    def _stream_events(self) -> None:
        self._send_headers(200, "text/event-stream", connection="keep-alive")
        interval = 1.0 / STREAM_HZ
        try:
            while True:
                payload = json.dumps(type(self).state_provider())
                self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                self.wfile.flush()
                time.sleep(interval)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            return  # The browser navigated away.


# Added to a report while this tool is the one serving it: a way to send the
# report to a phone, and - straight after a capture - a way to start another
# session without going back to the desktop. The saved file on disk never
# carries any of it: opened later, or sent to someone else, it is the report
# and nothing more.
REPORT_BAR_STYLE = """
<style>
  #gt7-resume { position: fixed; right: 18px; bottom: 18px; z-index: 9999;
    display: flex; align-items: center; gap: 12px; padding: 10px 14px;
    background: rgba(13, 17, 23, 0.94); border: 1px solid #2b3542;
    border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,.45);
    font-family: system-ui, "Segoe UI", sans-serif; font-size: 13px; color: #8b949e; }
  #gt7-resume button { font: inherit; font-weight: 700; color: #06111a;
    background: #2ad4e8; border: 0; border-radius: 7px; padding: 8px 14px;
    cursor: pointer; }
  #gt7-resume button:hover { filter: brightness(1.08); }
  #gt7-resume button:disabled { background: #46525f; color: #98a4b0; cursor: default; }
  #gt7-resume button.gt7-quiet { color: #2ad4e8; background: transparent;
    border: 1px solid #2b3542; }
  #gt7-resume button[hidden] { display: none; }
  #gt7-resume a { color: #2ad4e8; text-decoration: none; font-weight: 600; }
  #gt7-resume a:hover { text-decoration: underline; }
  #gt7-phone { position: fixed; inset: 0; z-index: 10000; display: grid;
    place-items: center; background: rgba(8, 11, 16, 0.88);
    font-family: system-ui, "Segoe UI", sans-serif; color: #8b949e; text-align: center; }
  #gt7-phone[hidden] { display: none; }
  #gt7-phone img { width: min(46vh, 70vw); height: auto; display: block;
    margin: 0 auto; border-radius: 12px; background: #fff; }
  #gt7-phone p { margin: 0.8rem 0 0; font-size: 14px; }
  #gt7-phone .gt7-url { color: #2ad4e8; font-size: 12px; word-break: break-all; }
  @media (max-width: 640px) {
    /* Whoever is reading this is already holding the phone. The bar spans the
       bottom edge instead of floating over the cards, and the page gets room
       underneath so the last card is not hidden behind it. */
    #gt7-resume { left: 0; right: 0; bottom: 0; border-radius: 0;
      justify-content: space-between; border-width: 1px 0 0;
      padding: 10px 16px calc(10px + env(safe-area-inset-bottom)); }
    #gt7-resume .gt7-send { display: none; }
    body { padding-bottom: 72px; }
  }
</style>
"""

REPORT_BAR_SCRIPT = """
<script>
(function () {
  var bar = document.getElementById("gt7-resume");
  var resume = bar.querySelector(".gt7-resume");
  if (resume) {
    resume.addEventListener("click", function () {
      resume.disabled = true;
      resume.textContent = "準備しています…";
      fetch("/resume", { method: "POST" })
        .then(function () { window.location.href = "/"; })
        .catch(function () {
          resume.disabled = false;
          resume.textContent = "続けて記録する";
        });
    });
  }
  var send = bar.querySelector(".gt7-send");
  if (!send) return;
  var panel = document.getElementById("gt7-phone");
  var path = send.getAttribute("data-path");
  // The button only appears once there is an address a phone could reach.
  fetch("/lan").then(function (response) { return response.json(); }).then(function (lan) {
    if (!lan.url) return;
    panel.querySelector(".gt7-url").textContent = lan.url.replace(/[/]$/, "") + path;
    send.hidden = false;
  }).catch(function () {});
  send.addEventListener("click", function () {
    var code = panel.querySelector("img");
    if (!code.getAttribute("src")) code.setAttribute("src", "/qr?path=" + encodeURIComponent(path));
    panel.hidden = false;
  });
  panel.addEventListener("click", function () { panel.hidden = true; });
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") panel.hidden = true;
  });
})();
</script>
"""


def _report_bar(*, resume: bool, phone_path: str | None) -> str:
    parts = ['<div id="gt7-resume">', '  <a href="/sessions">過去の記録</a>']
    if phone_path:
        parts.append(
            f'  <button type="button" class="gt7-send gt7-quiet" data-path="{html_escape(phone_path)}" hidden>'
            "スマホで開く</button>"
        )
    if resume:
        parts.append('  <button type="button" class="gt7-resume">続けて記録する</button>')
    parts.append("</div>")
    if phone_path:
        parts.append(
            '<div id="gt7-phone" hidden>\n  <div>\n'
            '    <img alt="このレポートのアドレスのQRコード">\n'
            "    <p>スマホのカメラで読み取ると、このレポートが開きます</p>\n"
            '    <p class="gt7-url"></p>\n'
            "    <p>同じWi-Fiにつないだ端末から開けます</p>\n  </div>\n</div>"
        )
    return "\n".join(parts) + REPORT_BAR_STYLE + REPORT_BAR_SCRIPT


def _with_report_bar(body: bytes, *, resume: bool = True, phone_path: str | None = None) -> bytes:
    """Puts the report bar just before the report's closing body tag."""
    bar = _report_bar(resume=resume, phone_path=phone_path).encode("utf-8")
    marker = b"</body>"
    index = body.rfind(marker)
    if index == -1:
        return body + bar
    return body[:index] + bar + body[index:]


# The name the tests and older callers know it by.
_with_resume_bar = _with_report_bar


def _sessions_link(server: Any, report: Path) -> str:
    """The lasting address of a report, for a phone to open.

    `/report` follows whatever the latest capture produced, so a code drawn
    from it would show a different session once the next one finishes. The
    copy under the sessions folder stays put.
    """
    root = getattr(server, "sessions_root", None)
    if root is not None:
        try:
            relative = Path(report).resolve().relative_to(Path(root).resolve())
            return "/sessions/" + quote(relative.as_posix())
        except (ValueError, OSError):
            pass
    return "/report"


# How many ports past the requested one to try before giving up.
PORT_SEARCH_RANGE = 20


class _ExclusiveServer(ThreadingHTTPServer):
    """A server that refuses to share its port.

    HTTPServer sets SO_REUSEADDR, and on Windows that lets a second process bind
    a port another one is already listening on. Both then accept connections and
    the browser reaches whichever the OS happens to pick - so leaving yesterday's
    capture window open made a fresh recording show stale numbers, with nothing
    on screen to say why.

    Dropping SO_REUSEADDR is not enough once this binds 0.0.0.0: on Windows a
    wildcard bind and a specific-address bind of the same port coexist happily,
    so an old capture window holding 127.0.0.1 and a new one holding 0.0.0.0
    both answer - and the browser at 127.0.0.1 reaches the old one. Verified
    both ways on this machine; SO_EXCLUSIVEADDRUSE closes both directions, and
    a port someone else already holds fails the bind so the search moves on.
    """

    allow_reuse_address = False

    def server_bind(self) -> None:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def lan_address() -> str | None:
    """This machine's address on the local network, or None if it has none.

    Asking the routing table which interface would carry a packet outwards is
    the only reliable way to pick the right address on a machine with several -
    a wired link, a wireless one, and whatever a VPN or virtual machine has
    added. Nothing is sent: a connected UDP socket only fixes the route.
    """
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 53))
        address = probe.getsockname()[0]
    except OSError:
        address = None
    finally:
        probe.close()
    if address and not address.startswith("127."):
        return address
    # No route to the internet does not mean no network: the PlayStation link
    # needs only the LAN. Fall back to whatever addresses the hostname carries.
    try:
        for candidate in socket.gethostbyname_ex(socket.gethostname())[2]:
            if candidate and not candidate.startswith("127."):
                return candidate
    except OSError:
        pass
    return None


def _bind(handler, port: int, *, host: str) -> tuple[ThreadingHTTPServer, int]:
    """Binds the first free port at or after `port`, and says which it took."""
    last_error: OSError | None = None
    for candidate in range(port, port + PORT_SEARCH_RANGE):
        try:
            return _ExclusiveServer((host, candidate), handler), candidate
        except OSError as error:
            last_error = error
    raise OSError(
        f"{port}番から{PORT_SEARCH_RANGE}個のポートがすべて使用中です。"
        "前回の記録ウィンドウが残っていないか確認してください。"
    ) from last_error


class LiveServer:
    """Runs the live view in a background thread alongside the capture loop.

    The view can also stop the capture, so a session can be run start to finish
    from the browser without touching the console window.
    """

    def __init__(
        self,
        state_provider: Callable[[], dict[str, Any]],
        *,
        port: int = DEFAULT_PORT,
        on_stop: Callable[[], None] | None = None,
        on_resume: Callable[[], None] | None = None,
        local_only: bool = False,
    ) -> None:
        self.requested_port = port
        # Open to the local network unless told otherwise, so the delta can be
        # watched on a phone propped against the wheel. Anyone on the same
        # network can then see lap times and past reports; `local_only` is there
        # for whoever would rather they could not.
        self.local_only = local_only
        # Set once a capture has been turned into a report, so the page can
        # send the driver straight to it. `report_error` covers the cases where
        # no report is coming, so the page can say why instead of waiting.
        self.report_path: Path | None = None
        self.report_error: str | None = None
        # Where every session lives, so the listing page and the reports under
        # it can be reached from the browser rather than from the file system.
        self.sessions_root: Path | None = None
        handler = type(
            "BoundHandler",
            (_Handler,),
            {
                "state_provider": staticmethod(state_provider),
                "on_stop": staticmethod(on_stop) if on_stop else None,
                "on_resume": staticmethod(on_resume) if on_resume else None,
                "server_ref": self,
            },
        )
        self._server, self.port = _bind(
            handler, port, host="127.0.0.1" if local_only else "0.0.0.0"
        )
        self._server.daemon_threads = True
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        """The address for the browser on this machine."""
        return f"http://127.0.0.1:{self.port}/"

    @property
    def lan_url(self) -> str | None:
        """The address a phone on the same network would use, if there is one."""
        if self.local_only:
            return None
        address = lan_address()
        return f"http://{address}:{self.port}/" if address else None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)
