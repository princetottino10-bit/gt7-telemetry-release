"""The one thing to work on, shown on the live view while the driver is out.

Each report saves its "first thing to do" beside itself (webreport/first.py).
Driving, nobody reads a paragraph, so the live view carries that one line:
the corner, the number, the action. It has to be the line for the circuit
being driven, and the circuit is only known once a lap has been completed and
its shape matched; until then the most recent line from any circuit is shown,
named as such, since it is usually the circuit the driver is about to run.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any, Callable

from telemetry import sessions, tracks

REPORT_FIRST = Path(sessions.REPORT_FILENAME).stem + ".first.json"


def _read(path: Path) -> dict[str, Any] | None:
    from webreport import first  # the capture side may run without the report pipeline

    return first.read(path)


def latest_line(root: Path, track_slug: str | None = None) -> dict[str, Any] | None:
    """The newest saved line, for one circuit or for any."""
    if not root.is_dir():
        return None
    pattern = f"{track_slug}/*/{REPORT_FIRST}" if track_slug else f"*/*/{REPORT_FIRST}"
    # Folders are named by start time, and a session started later may have
    # been rebuilt earlier, so the folder name orders them rather than mtime.
    for path in sorted(root.glob(pattern), key=lambda path: path.parent.name, reverse=True):
        line = _read(path)
        if line:
            return line
    return None


class LiveFocus:
    """Works out which saved line belongs on the live view right now."""

    def __init__(self, root: Path, registry_factory: Callable[[], tracks.Registry]) -> None:
        self.root = root
        self.registry_factory = registry_factory
        self._lock = threading.Lock()
        self._laps_seen: int | None = None
        self._value: dict[str, Any] | None = None

    def current(self, recorder: Any) -> dict[str, Any] | None:
        laps = list(recorder.laps)
        with self._lock:
            # Matching a shape walks every sample of a lap; once per lap is plenty.
            if self._laps_seen == len(laps):
                return self._value
            self._laps_seen = len(laps)
            self._value = self._work_out(laps, getattr(recorder, "best_lap", None))
            return self._value

    def refresh(self) -> None:
        """Forgets the cached answer, e.g. after a new report has been written."""
        with self._lock:
            self._laps_seen = None

    def _work_out(self, laps: list[Any], best: Any) -> dict[str, Any] | None:
        name = None
        if laps:
            try:
                # The lap capture_gt7.identify_track would name the session by.
                reference = best or laps[-1]
                name = self.registry_factory().identify(tracks.fingerprint_from_lap(reference))
            except Exception:  # noqa: BLE001 - a missing line must never stop a recording
                name = None
        if name:
            line = latest_line(self.root, tracks.slug(name))
            return {**line, "matched": True} if line else None
        line = latest_line(self.root)
        return {**line, "matched": False} if line else None
