@echo off
rem Builds every recorded session's report again with this version of the tool,
rem so last week's laps get this week's analysis and wording.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=runtime\python.exe"
if not exist "%PY%" set "PY=python"

if not exist "sessions" (
    echo まだ走行記録がありません。
    echo.
    pause
    exit /b 1
)

echo 過去のレポートを、今の版で作り直しています。数が多いと時間がかかります...
"%PY%" -X utf8 -c "import sys; sys.path.insert(0,'.'); from pathlib import Path; from telemetry import rebuild; n, failed = rebuild.rebuild_all(Path('sessions')); print(f'{n} 件を作り直しました。'); [print('作り直せませんでした:', f) for f in failed]"
echo.
pause
