"use strict";

/* Track map: circuit shape from telemetry coordinates, optionally on top of a
   background course diagram the user drops in and aligns. */

const MAP_PADDING = 26;
const TRACK_WIDTH_PX = 5;

function createTrackMap(data, state, elements) {
  const canvas = elements.canvas;
  const stage = elements.stage;
  const legend = elements.legend;
  let background = null; // { image, params }
  let view = null;

  /* Fits the circuit into the canvas without distorting it. The map can be
     spun so the telemetry lines up with a conventionally oriented course
     diagram; the bounding box is recomputed from the rotated outline so the
     fit stays tight at any angle. */
  function computeView(width, height, rotationDeg, outlineX, outlineZ, from = 0, to = -1) {
    const radians = (rotationDeg * Math.PI) / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    const last = to < 0 ? outlineX.length - 1 : to;
    let xMin = Infinity;
    let xMax = -Infinity;
    let zMin = Infinity;
    let zMax = -Infinity;
    for (let i = from; i <= last; i += 1) {
      const rx = outlineX[i] * cos - outlineZ[i] * sin;
      const rz = outlineX[i] * sin + outlineZ[i] * cos;
      if (rx < xMin) xMin = rx;
      if (rx > xMax) xMax = rx;
      if (rz < zMin) zMin = rz;
      if (rz > zMax) zMax = rz;
    }
    // A padded box, so a zoomed corner is not pressed against the canvas edge.
    const margin = Math.max((xMax - xMin) * 0.08, (zMax - zMin) * 0.08, 3);
    xMin -= margin;
    xMax += margin;
    zMin -= margin;
    zMax += margin;
    const worldWidth = Math.max(xMax - xMin, 1);
    const worldHeight = Math.max(zMax - zMin, 1);
    const scale = Math.min(
      (width - MAP_PADDING * 2) / worldWidth,
      (height - MAP_PADDING * 2) / worldHeight
    );
    const offsetX = (width - worldWidth * scale) / 2 - xMin * scale;
    const offsetY = (height - worldHeight * scale) / 2 - zMin * scale;
    return {
      scale,
      rotationDeg,
      /* World +Z goes DOWN the screen, not up. Drawing it upwards mirrors the
         circuit: a clockwise track came out anticlockwise, which was confirmed
         two ways on real data - the lap encloses its area the wrong way round,
         and the left-hand tyres run hotter, which only happens on a track of
         mostly right-hand corners. */
      toScreen: (x, z) => [
        (x * cos - z * sin) * scale + offsetX,
        offsetY + (x * sin + z * cos) * scale
      ]
    };
  }

  function strokePath(ctx, xs, zs, from, to) {
    const [sx, sy] = view.toScreen(xs[from], zs[from]);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    for (let i = from + 1; i <= to; i += 1) {
      const [px, py] = view.toScreen(xs[i], zs[i]);
      ctx.lineTo(px, py);
    }
    ctx.stroke();
  }

  /* Draws one lap as short runs of constant colour, so the line can carry a
     per-metre value (delta rate or speed) without 2000 separate strokes. */
  function strokeColoured(ctx, xs, zs, colorAt, step) {
    ctx.lineWidth = TRACK_WIDTH_PX;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    for (let i = 0; i < data.points - 1; i += step) {
      const end = Math.min(i + step, data.points - 1);
      ctx.strokeStyle = colorAt(Math.floor((i + end) / 2));
      strokePath(ctx, xs, zs, i, end);
    }
  }

  function drawBackground(ctx) {
    if (!background) return;
    const p = background.params;
    const image = background.image;
    const [cx, cy] = view.toScreen(p.centerX, p.centerZ);
    const widthPx = p.widthM * view.scale;
    const heightPx = (widthPx / image.width) * image.height;
    ctx.save();
    ctx.globalAlpha = p.opacity;
    ctx.translate(cx, cy);
    // The map rotation is applied in world space, so the image has to follow it
    // on top of its own alignment angle.
    ctx.rotate(((p.rotationDeg - view.rotationDeg) * Math.PI) / 180);
    ctx.scale(p.flipX ? -1 : 1, p.flipY ? -1 : 1);
    ctx.drawImage(image, -widthPx / 2, -heightPx / 2, widthPx, heightPx);
    ctx.restore();
  }

  function drawSegmentTicks(ctx, xs, zs, activeSegment) {
    for (const segment of data.segments) {
      const isActive = segment.id === activeSegment;
      const i = segment.start;
      const next = Math.min(i + 6, data.points - 1);
      const [x1, y1] = view.toScreen(xs[i], zs[i]);
      const [x2, y2] = view.toScreen(xs[next], zs[next]);
      const angle = Math.atan2(y2 - y1, x2 - x1) + Math.PI / 2;
      const length = isActive ? 16 : 9;
      ctx.strokeStyle = isActive ? COLORS.ref : "rgba(154, 168, 187, 0.45)";
      ctx.lineWidth = isActive ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(x1 - Math.cos(angle) * length, y1 - Math.sin(angle) * length);
      ctx.lineTo(x1 + Math.cos(angle) * length, y1 + Math.sin(angle) * length);
      ctx.stroke();
    }
  }

  function drawActiveSegment(ctx, xs, zs, activeSegment) {
    const segment = data.segments.find((entry) => entry.id === activeSegment);
    if (!segment) return;
    ctx.save();
    ctx.strokeStyle = "rgba(42, 212, 232, 0.85)";
    ctx.lineWidth = TRACK_WIDTH_PX + 7;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.globalAlpha = 0.35;
    strokePath(ctx, xs, zs, segment.start, segment.end);
    ctx.restore();
  }

  function drawCursor(ctx, xs, zs, cursor) {
    if (cursor === null) return;
    const [x, y] = view.toScreen(xs[cursor], zs[cursor]);
    ctx.save();
    ctx.strokeStyle = "rgba(232, 237, 244, 0.9)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, 7, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "rgba(232, 237, 244, 0.95)";
    ctx.beginPath();
    ctx.arc(x, y, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /* The two cars at the current playback time, on the same clock. */
  function drawGhosts(ctx, s) {
    if (s.ghostTime === null || s.ghostTime === undefined) return;
    for (const car of [
      { lap: s.refIndex, color: COLORS.ref },
      { lap: s.cmpIndex, color: COLORS.cmp }
    ]) {
      const point = positionAtIndex(data, car.lap, indexAtTime(data, car.lap, s.ghostTime));
      const [x, y] = view.toScreen(point.x, point.z);
      ctx.save();
      ctx.shadowColor = car.color;
      ctx.shadowBlur = 10;
      ctx.fillStyle = car.color;
      ctx.strokeStyle = "rgba(8, 11, 16, 0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 6.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawStartLine(ctx, xs, zs) {
    const [x, y] = view.toScreen(xs[0], zs[0]);
    const [nx, ny] = view.toScreen(xs[5], zs[5]);
    const angle = Math.atan2(ny - y, nx - x) + Math.PI / 2;
    ctx.save();
    ctx.strokeStyle = COLORS.text;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(x - Math.cos(angle) * 13, y - Math.sin(angle) * 13);
    ctx.lineTo(x + Math.cos(angle) * 13, y + Math.sin(angle) * 13);
    ctx.stroke();
    ctx.restore();
  }

  function updateLegend(mode, extent) {
    if (mode === "line") {
      legend.innerHTML =
        `<span style="color:${COLORS.ref}">━</span> 基準` +
        `<span style="color:${COLORS.cmp}">━</span> 比較`;
      return;
    }
    if (mode === "slide") {
      const ramp = [0, 0.35, 0.7, 1].map((t) => slideColor(t * extent.scale, extent.scale)).join(", ");
      legend.innerHTML =
        "<span>素直</span>" +
        `<span class="map-legend__ramp" style="background:linear-gradient(90deg, ${ramp})"></span>` +
        `<span>滑り (${extent.scale.toFixed(1)}°)</span>`;
      return;
    }
    if (mode === "offset") {
      const ramp = [-1, -0.5, 0, 0.5, 1].map((t) => offsetColor(t * extent.scale, extent.scale)).join(", ");
      legend.innerHTML =
        "<span>左</span>" +
        `<span class="map-legend__ramp" style="background:linear-gradient(90deg, ${ramp})"></span>` +
        `<span>右 (±${extent.scale.toFixed(1)}m)</span>`;
      return;
    }
    if (mode === "speed") {
      const ramp = [0, 0.25, 0.5, 0.75, 1]
        .map((t) => speedColor(extent.min + (extent.max - extent.min) * t, extent.min, extent.max))
        .join(", ");
      legend.innerHTML =
        `<span>${Math.round(extent.min)}</span>` +
        `<span class="map-legend__ramp" style="background:linear-gradient(90deg, ${ramp})"></span>` +
        `<span>${Math.round(extent.max)} km/h</span>`;
      return;
    }
    const ramp = [-1, -0.5, 0, 0.5, 1].map((t) => rateColor(t * extent.scale, extent.scale)).join(", ");
    legend.innerHTML =
      `<span style="color:${COLORS.gain}">速い</span>` +
      `<span class="map-legend__ramp" style="background:linear-gradient(90deg, ${ramp})"></span>` +
      `<span style="color:${COLORS.loss}">遅い</span>`;
  }


  /* Corner names on the map itself, so a finding about "Degner 2" can be found
     without counting segments. Labels that would overlap are dropped rather than
     stacked, since an unreadable pile helps nobody. */
  function drawSegmentLabels(ctx, xs, zs, s, zoomed) {
    const segment = data.segments.find((entry) => entry.id === s.activeSegment);

    if (zoomed && segment) {
      ctx.save();
      ctx.font = "600 15px system-ui, sans-serif";
      ctx.fillStyle = COLORS.text;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.fillText(segment.name, 14, 12);
      ctx.font = "11px system-ui, sans-serif";
      ctx.fillStyle = COLORS.textFaint;
      ctx.fillText("この区間を拡大中 — Esc で全体に戻る", 14, 32);
      ctx.restore();
      return;
    }

    ctx.save();
    ctx.font = "11px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const placed = [];
    for (const entry of data.segments) {
      const middle = Math.round((entry.start + entry.end) / 2);
      const [x, y] = view.toScreen(xs[middle], zs[middle]);
      const width = ctx.measureText(entry.name).width + 8;
      const box = { x1: x - width / 2, y1: y - 9, x2: x + width / 2, y2: y + 9 };
      const clash = placed.some(
        (other) => box.x1 < other.x2 && box.x2 > other.x1 && box.y1 < other.y2 && box.y2 > other.y1
      );
      if (clash) continue;
      placed.push(box);

      // A dark plate keeps the text readable over the track and any background.
      ctx.fillStyle = "rgba(8, 11, 16, 0.72)";
      ctx.beginPath();
      ctx.roundRect(box.x1, box.y1, box.x2 - box.x1, box.y2 - box.y1, 4);
      ctx.fill();
      ctx.fillStyle = entry.id === s.activeSegment ? COLORS.ref : COLORS.textDim;
      ctx.fillText(entry.name, x, y);
    }
    ctx.restore();
  }

  function render() {
    const fitted = fitCanvas(canvas);
    if (!fitted) return;
    const { ctx, width, height } = fitted;

    const s = state.get();
    const refX = data.channels.x[s.refIndex];
    const refZ = data.channels.z[s.refIndex];
    // Selecting a corner zooms the map onto it. Racing lines differ by a couple
    // of metres on a five-kilometre lap; at full-circuit scale that is invisible.
    const segment = data.segments.find((entry) => entry.id === s.activeSegment);
    const from = segment ? segment.start : 0;
    const to = segment ? segment.end : data.points - 1;
    view = computeView(width, height, s.mapRotationDeg, refX, refZ, from, to);
    const cmpX = data.channels.x[s.cmpIndex];
    const cmpZ = data.channels.z[s.cmpIndex];
    const zoomed = Boolean(segment);

    drawBackground(ctx);

    // A faint reference outline keeps the circuit readable in every mode.
    ctx.strokeStyle = COLORS.ghost;
    ctx.lineWidth = TRACK_WIDTH_PX + 9;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    strokePath(ctx, refX, refZ, 0, data.points - 1);

    if (!zoomed) drawActiveSegment(ctx, refX, refZ, s.activeSegment);

    if (zoomed) {
      // Draw the reference line under whatever the mode paints, so the two are
      // directly comparable at this scale.
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(42, 212, 232, 0.75)";
      strokePath(ctx, refX, refZ, from, to);
    }

    if (s.mapMode === "line") {
      ctx.lineWidth = 3;
      ctx.strokeStyle = COLORS.ref;
      strokePath(ctx, refX, refZ, 0, data.points - 1);
      ctx.strokeStyle = COLORS.cmp;
      strokePath(ctx, cmpX, cmpZ, 0, data.points - 1);
      updateLegend("line", null);
    } else if (s.mapMode === "slide" && data.hasExtended) {
      const slide = data.extended.slideAngle[s.cmpIndex];
      const scale = Math.max(2, percentileAbs(slide, 0, data.points - 1, 0.95));
      strokeColoured(ctx, cmpX, cmpZ, (i) => slideColor(slide[i], scale), 3);
      updateLegend("slide", { scale });
    } else if (s.mapMode === "offset") {
      const offset = s.lateral;
      const scale = Math.max(0.4, percentileAbs(offset, 0, data.points - 1, 0.92));
      strokeColoured(ctx, cmpX, cmpZ, (i) => offsetColor(offset[i], scale), 3);
      updateLegend("offset", { scale });
    } else if (s.mapMode === "speed") {
      const speed = data.channels.speed_kmh[s.cmpIndex];
      let min = Infinity;
      let max = -Infinity;
      for (let i = 0; i < data.points; i += 1) {
        if (speed[i] < min) min = speed[i];
        if (speed[i] > max) max = speed[i];
      }
      strokeColoured(ctx, cmpX, cmpZ, (i) => speedColor(speed[i], min, max), 3);
      updateLegend("speed", { min, max });
    } else {
      const rate = s.deltaRate;
      let peak = 0;
      for (let i = 0; i < data.points; i += 1) peak = Math.max(peak, Math.abs(rate[i]));
      const scale = Math.max(0.03, peak * 0.75);
      strokeColoured(ctx, cmpX, cmpZ, (i) => rateColor(rate[i], scale), 3);
      updateLegend("delta", { scale });
    }

    drawSegmentTicks(ctx, refX, refZ, s.activeSegment);
    if (!zoomed) drawStartLine(ctx, refX, refZ);
    drawSegmentLabels(ctx, refX, refZ, s, zoomed);
    drawCursor(ctx, s.mapMode === "line" ? refX : cmpX, s.mapMode === "line" ? refZ : cmpZ, s.cursor);
    drawGhosts(ctx, s);
  }

  /* Maps a pointer position to the nearest grid index on the displayed lap. */
  function nearestIndex(clientX, clientY) {
    if (!view) return null;
    const rect = canvas.getBoundingClientRect();
    const px = clientX - rect.left;
    const py = clientY - rect.top;
    const s = state.get();
    const xs = data.channels.x[s.cmpIndex];
    const zs = data.channels.z[s.cmpIndex];
    let best = null;
    let bestDistance = Infinity;
    for (let i = 0; i < data.points; i += 1) {
      const [sx, sy] = view.toScreen(xs[i], zs[i]);
      const distance = (sx - px) ** 2 + (sy - py) ** 2;
      if (distance < bestDistance) {
        bestDistance = distance;
        best = i;
      }
    }
    return bestDistance <= 40 * 40 ? best : null;
  }

  canvas.addEventListener("pointermove", (event) => {
    state.set({ cursor: nearestIndex(event.clientX, event.clientY) });
  });
  canvas.addEventListener("pointerleave", () => state.set({ cursor: null }));

  function setBackground(image, params) {
    background = image ? { image, params } : null;
    render();
  }

  function updateBackgroundParams(params) {
    if (background) {
      background.params = params;
      render();
    }
  }

  return { render, setBackground, updateBackgroundParams, stage };
}
