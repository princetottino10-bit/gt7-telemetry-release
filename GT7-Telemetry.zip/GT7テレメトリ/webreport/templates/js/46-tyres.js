"use strict";

/* What the four tyre temperatures say about the session.
 *
 * The temperatures were recorded from the first capture but never shown, so a
 * driver could not tell a car that was working its tyres evenly from one that
 * was cooking a corner of itself. This turns them into two things: a curve per
 * wheel along the lap (drawn in 30-charts.js) and, here, a plain sentence about
 * the session as a whole.
 *
 * Thresholds come from first_session.bin - Watkins Glen Long, 296 GTB '22, four
 * usable laps. Per-lap means over the distance grid, in degrees C:
 *
 *     lap    FL    FR    RL    RR   4-wheel   left-right  rear-front
 *      2   70.9  65.4  80.1  76.4    73.2        4.6         10.1
 *      3   75.8  70.5  85.0  81.8    78.3        4.2         10.2
 *      4   78.9  72.9  87.7  84.1    80.9        4.8         10.0
 *      5   80.9  74.3  89.5  86.5    82.8        4.8         10.4
 *
 * So on a circuit of mostly right-hand corners the left tyres run about 5 C
 * hotter all session, and the driven rear axle about 10 C hotter than the front,
 * every lap. Neither is a fault, and the thresholds below sit above both so they
 * do not get reported as one. The four-wheel mean climbed 73.2 -> 82.8 across the
 * four laps, with the largest single lap-to-lap step 5.0 C; a session is only
 * called "rising" once it moves by more than one such step.
 *
 * Overheating is judged on the 90th percentile of a lap rather than its peak. The
 * hottest sustained reading of this session was 95.0 C on the left rear, while
 * the peaks reached 160 C - but only for the fraction of a second of the spin on
 * the last lap, which is an incident, not a tyre that has been overworked. */

const TYRE_WHEELS = [
  { key: "tempFL", label: "左前", color: "#38bdf8" },
  { key: "tempFR", label: "右前", color: "#a78bfa" },
  { key: "tempRL", label: "左後", color: "#f5a524" },
  { key: "tempRR", label: "右後", color: "#ff5a5f" }
];

// A four-wheel mean that moves by more than one lap's own step across the
// session is a trend rather than scatter.
const TEMP_RISE_C = 5.0;
// Above the 4.8 C of left-right bias this circuit produces on its own.
const TEMP_SIDE_C = 8.0;
// Above the 10.4 C the driven rear axle runs hotter here as a matter of course.
const TEMP_AXLE_C = 15.0;
// Above anything this session sustained (95.0 C at the 90th percentile).
const TEMP_HOT_C = 120.0;

function hasTyreTemps(data) {
  return Boolean(data.hasExtended && data.extended.tempFL);
}

function mean(values) {
  let total = 0;
  for (let i = 0; i < values.length; i += 1) total += values[i];
  return values.length ? total / values.length : NaN;
}

/* Value below which `ratio` of the lap's samples sit. Used instead of the peak so
   a momentary spike during an incident cannot be read as an overheated tyre. */
function percentileOf(values, ratio) {
  const sorted = Array.from(values).sort((a, b) => a - b);
  if (!sorted.length) return NaN;
  return sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * ratio))];
}

/* Mean and sustained-peak temperature of each wheel over one lap. */
function lapTemperatures(data, lapIndex) {
  const entry = { lapIndex };
  for (const wheel of TYRE_WHEELS) {
    const series = data.extended[wheel.key][lapIndex];
    entry[wheel.key] = mean(series);
    entry[wheel.key + "P90"] = percentileOf(series, 0.9);
  }
  entry.mean =
    (entry.tempFL + entry.tempFR + entry.tempRL + entry.tempRR) / 4;
  entry.sideGap = (entry.tempFL + entry.tempRL) / 2 - (entry.tempFR + entry.tempRR) / 2;
  entry.axleGap = (entry.tempRL + entry.tempRR) / 2 - (entry.tempFL + entry.tempFR) / 2;
  return entry;
}

/* Every lap of this session in the order it was driven.
   Laps carried in from an earlier session are left out: their tyres were heated
   on a different day, so putting them in the sequence would invent a trend.
   `lapIndexes` does the same job for a car change mid-session: lap numbers start
   again in the new car, and its tyres started cold, so the two cars laid end to
   end would read as a temperature that fell and climbed again. */
function temperatureTrend(data, lapIndexes = null) {
  if (!hasTyreTemps(data)) return [];
  return data.laps
    .filter((lap) => !lap.isHistory)
    .filter((lap) => lapIndexes === null || lapIndexes.includes(lap.index))
    .sort((a, b) => a.number - b.number)
    .map((lap) => ({ ...lapTemperatures(data, lap.index), lap }));
}

/* The session's tyre temperatures in words, or "" when there are none. */
function temperatureFinding(data, lapIndexes = null) {
  const trend = temperatureTrend(data, lapIndexes);
  if (!trend.length) return "";

  const sentences = [];
  const overall = mean(trend.map((entry) => entry.mean));

  if (trend.length > 1) {
    const rise = trend[trend.length - 1].mean - trend[0].mean;
    if (rise >= TEMP_RISE_C) {
      sentences.push(
        `4輪平均が ${trend[0].mean.toFixed(0)}→${trend[trend.length - 1].mean.toFixed(0)}°C と` +
          ` ${rise.toFixed(1)}°C 上がり続けています（冷える間がなく、終盤はグリップが落ちます）`
      );
    } else if (rise <= -TEMP_RISE_C) {
      sentences.push(
        `4輪平均が ${trend[0].mean.toFixed(0)}→${trend[trend.length - 1].mean.toFixed(0)}°C と` +
          ` ${Math.abs(rise).toFixed(1)}°C 下がっています（ペースが落ちて熱が入っていません）`
      );
    } else {
      sentences.push(`4輪平均は ${overall.toFixed(0)}°C 前後で安定しています`);
    }
  } else {
    sentences.push(`4輪平均 ${overall.toFixed(0)}°C`);
  }

  const sideGap = mean(trend.map((entry) => entry.sideGap));
  if (Math.abs(sideGap) >= TEMP_SIDE_C) {
    const hot = sideGap > 0 ? "左" : "右";
    sentences.push(`${hot}側が反対側より平均 ${Math.abs(sideGap).toFixed(1)}°C 高く、片側に負担が寄っています`);
  }

  const axleGap = mean(trend.map((entry) => entry.axleGap));
  if (Math.abs(axleGap) >= TEMP_AXLE_C) {
    const hot = axleGap > 0 ? "リア" : "フロント";
    sentences.push(`${hot}が反対側の軸より平均 ${Math.abs(axleGap).toFixed(1)}°C 高い状態です`);
  }

  let hottest = null;
  for (const entry of trend) {
    for (const wheel of TYRE_WHEELS) {
      const value = entry[wheel.key + "P90"];
      if (value >= TEMP_HOT_C && (hottest === null || value > hottest.value)) {
        hottest = { value, label: wheel.label };
      }
    }
  }
  if (hottest) {
    sentences.push(`${hottest.label}が ${hottest.value.toFixed(0)}°C まで上がりきっており、過熱しています`);
  }

  return "タイヤ温度: " + sentences.join(" · ") + "。";
}
