"use strict";

/* The short answer: what to change next time out.
 *
 * Everything else in the report explains the lap. This works out which three
 * corners are worth the most, why each one is losing time, and states it as one
 * thing to try. The evidence is always the driver's own faster lap through that
 * corner, so nothing here asks for a pace they have not already shown. */

// Below these, a difference is noise rather than a finding.
const MIN_GAIN_S = 0.03;
const MIN_SPEED_DIFF_KMH = 2.5;
const MIN_POINT_DIFF_M = 8;
const MIN_LINE_DIFF_M = 1.2;
const MIN_SLIDE_DIFF_DEG = 1.0;
const SPIN_SLIP = 1.06;
const LOCK_SLIP = 0.94;
/* Share of a corner's braking done while the car is already turning. Two laps
   closer together than this are within the driver's own lap-to-lap scatter:
   webreport/trailbrake.py measures that scatter on first_session.bin at 0.088
   pooled, and this sits a little over twice it. */
const MIN_TRAIL_DIFF = 0.2;
// A braking or throttle point further out than this share of the segment is a
// detection artefact (common in linked corners), not a real difference.
const MAX_CREDIBLE_SHARE = 0.35;

/* The card says what to change; this says why it works and how to practise it.
   The diagnosis only knows that the driver did something differently on their
   quicker lap, so the explanation is general driving technique, written in our
   own words: it never quotes a number the telemetry has not measured. Keyed by
   the variant of the finding, since "brake later" and "brake earlier" share a
   tag but not a reason. */
const TECHNIQUES = {
  carryOver: {
    principle:
      "この区間は加速しているだけなので、差は前のコーナーの立ち上がりで生まれています。出口の速度は次のブレーキングまでずっと効くため、前のコーナー単体で少し損をしても、早く全開にしたほうが合計では速くなります",
    drill:
      "前のコーナーで進入を気持ち抑え、クリップを少し奥にとって、全開地点を手前にします。前のコーナーとこの区間の合計タイムで比べてください"
  },
  consistency: {
    principle:
      "操作の差は小さいのにタイムがばらつくのは、毎周の基準がぶれているサインです。目印が決まると、どこを直せばいいかが見えるようになります",
    drill:
      "この区間で「ブレーキング開始」「ハンドルを切り始める」「全開」の3つの目印を決め、数周はタイムより目印どおりに走ることを優先します"
  },
  minSpeed: {
    principle:
      "コーナーで一番遅い地点の速度は、そこからの加速の出発点です。ここで落としすぎると、出口から次のブレーキングまで遅れが残ります",
    drill:
      "ブレーキング開始地点は変えずに、踏力だけを少し弱めるか、早めに緩めて数周走ります。曲がり切れたらもう少し速度を持ち込み、外へふくらむようなら1つ前に戻します"
  },
  trailMore: {
    principle:
      "ブレーキを残したまま曲げ始めると、前に荷重が乗って前タイヤがよく効き、車の向きが変わりやすくなります。直線で止め切ってからハンドルを切ると、荷重が後ろに戻って前が曲がりにくく、その分を速度を落として払うことになります",
    drill:
      "ハンドルを切り始める瞬間にブレーキを0にせず、少しだけ残します。ハンドルを切り足すのに合わせて、ブレーキを少しずつ緩めていきます"
  },
  trailLess: {
    principle:
      "タイヤのグリップは減速と旋回で分け合っています。大きく曲がっている最中にブレーキを残しすぎると、グリップの取り合いになって曲がらなくなるか、リアが軽くなって不安定になります。回すにも速度が要るので、残しすぎは落としすぎにもつながります",
    drill:
      "ハンドルを一番切った地点、遅くともクリップでブレーキが0になっていることを目標にします。ゴースト再生で、速かった周のブレーキがどこで0になるかを確かめてから走ります"
  },
  throttle: {
    principle:
      "出口の速度は、次の直線の終わりまでずっと効きます。後ろの直線が長いコーナーほど、進入より立ち上がりを優先したほうが得になります",
    drill:
      "踏み始めたら戻さずに全開まで行ける地点を探します。少し待ってから一気に全開にするほうが、長く半開きで待つより全開地点は手前に来ます。踏んでから戻しているなら、進入を少し抑えてでも、向きを変え切ってから踏みます"
  },
  overEntry: {
    principle:
      "コーナーは、入口の速さより出口の速さのほうが長く効きます。速度を持ち込んで最低速度を上げても、向きが変わり切らずに全開が遅れるなら、入口で得た分を出口で返しています",
    drill:
      "進入の速度をほんの少し落とし、早めに向きを変え切ります。全開地点が手前に来たかを、カードの数字で確かめます"
  },
  brakeEarly: {
    principle:
      "ブレーキングが早いと、速度の落ちた状態で走る距離が伸び、最低速度まで落としすぎやすくなります。同じクリップに着けるなら、遅らせた分はそのまま得になります",
    drill:
      "看板や路面の継ぎ目など動かない目印を1つ決め、車2台分ずつ奥にずらします。踏み始めは強く、そこから緩めていきます。最低速度か出口の速度が落ちたら、1つ前の目印に戻します"
  },
  brakeLate: {
    principle:
      "ブレーキングが遅いと減速し切れずに突っ込みすぎ、向きを変えられないまま立ち上がりが遅れます。ブレーキングで得た分は、立ち上がりでそれ以上に失いやすいものです。出口の速度のほうが、ブレーキングの数メートルより価値があります",
    drill:
      "目印を少し手前に戻し、踏み始めはしっかり強く踏みます。狙ったクリップに着けて、早く全開にすることを優先します"
  },
  line: {
    principle:
      "ラインのずれは、進入・クリップ・出口のどこかから始まります。どこで始まったかによって、直すべきものがブレーキなのか、ハンドルを切るタイミングなのか、アクセルなのかが変わります",
    drill:
      "マップの「ライン差」で、ずれが始まる地点を確かめます。ハンドルを切る前から始まっていればブレーキ、切り始めのあたりならハンドルを切るタイミングを直します"
  },
  slide: {
    principle:
      "車が流れている間、タイヤは前に進む以外の方向にグリップを使っています。速かった周より流れているなら、その分だけ速さを捨てています",
    drill:
      "ハンドルを切る量を減らし、ゆっくり切ります。切っても曲がらないときは、さらに切り足すのではなくハンドルを少し戻し、次の周で進入の速度を落とします"
  },
  spin: {
    principle:
      "後輪が空転すると、加速に使えるグリップを捨てたうえに車の向きも乱れます。少し遅く踏んで空転させないほうが、出口の速度は上がりやすくなります",
    drill:
      "ハンドルが戻り始めるのに合わせてアクセルを踏み足し、ハンドルを大きく切ったまま全開にしないようにします"
  },
  lock: {
    principle:
      "タイヤがロックすると、止まる力も曲がる力も落ちます。ブレーキは踏み始めを一番強くしてよいのですが、それはタイヤが回っている範囲でのことです",
    drill:
      "踏み始めの一瞬を少し弱くしてから強めます。曲げながら止まるときは、ハンドルを切るほどブレーキを緩めていきます"
  },
  unclear: {
    principle: "数値にはっきりした差が出ないときは、小さな違いがいくつも積み重なっています",
    drill: "ゴースト再生で2つの周を重ね、ブレーキを緩め終える地点と全開地点を見比べます"
  }
};

function techniqueNote(key) {
  return TECHNIQUES[key] || null;
}

function segmentById(data, id) {
  return data.segments.find((segment) => segment.id === id);
}

function channelExtremes(data, channel, lapIndex, from, to) {
  const values = data.extended[channel][lapIndex];
  let min = Infinity;
  let max = -Infinity;
  for (let i = from; i <= to; i += 1) {
    if (values[i] < min) min = values[i];
    if (values[i] > max) max = values[i];
  }
  return { min, max };
}

function previousSegment(data, id) {
  const index = data.segments.findIndex((segment) => segment.id === id);
  return data.segments[(index - 1 + data.segments.length) % data.segments.length];
}

// The same thresholds webreport/sectors.py uses for the braking point, so the
// points on a card line up with the ones in the sector table.
const BRAKE_ON_PCT = 8;
const SUSTAIN_SAMPLES = 6;
// Under this, two laps' peak brake pressure is the same press.
const MIN_PEAK_BRAKE_DIFF_PCT = 8;

/* Where one lap reached its slowest point in a segment, how hard it braked on
   the way there and where the braking ended. The diagnosis only has one number
   per lap per segment; these turn "brake a little less" into a place and an
   amount the driver can find on track. Null when the channels are missing. */
function cornerProfile(data, lapIndex, segment) {
  const channels = data.channels;
  if (!channels || !channels.speed_kmh || !channels.brake_pct || !data.distance) return null;
  const speed = channels.speed_kmh[lapIndex];
  const brake = channels.brake_pct[lapIndex];
  let apex = segment.start;
  for (let i = segment.start; i <= segment.end; i += 1) {
    if (speed[i] < speed[apex]) apex = i;
  }
  let peakBrake = 0;
  let firstOn = null;
  for (let i = segment.start; i <= apex; i += 1) {
    if (brake[i] > peakBrake) peakBrake = brake[i];
    if (firstOn === null && brake[i] >= BRAKE_ON_PCT) firstOn = i;
  }
  // The braking ends where the pedal drops under the threshold and stays there,
  // so a brief lift mid-zone is not read as the release.
  let release = null;
  if (firstOn !== null) {
    for (let i = firstOn; i <= segment.end - SUSTAIN_SAMPLES + 1; i += 1) {
      let off = true;
      for (let k = 0; k < SUSTAIN_SAMPLES; k += 1) {
        if (brake[i + k] >= BRAKE_ON_PCT) {
          off = false;
          break;
        }
      }
      if (off) {
        release = i;
        break;
      }
    }
  }
  return {
    apexM: data.distance[apex],
    minSpeedKmh: speed[apex],
    peakBrakePct: firstOn === null ? null : peakBrake,
    releaseM: release === null ? null : data.distance[release]
  };
}

// "クリップの 120m 手前" / "クリップの 30m 先", for a point relative to the apex.
function fromApex(pointM, apexM) {
  const gap = Math.round(apexM - pointM);
  if (Math.abs(gap) < 5) return "クリップ付近";
  return gap > 0 ? `クリップの ${gap}m 手前` : `クリップの ${-gap}m 先`;
}

/* Differences that are usually one mistake seen twice. Ranking by weight alone
   would report whichever symptom carries more weight, and the driver would go
   out and work on the consequence. When the top finding is the consequence in
   one of these pairs and its cause was also measured, the cause leads and the
   card says how the two connect. No new thresholds: a pair only forms from
   findings that already cleared their own. Trail braking and sliding are in no
   pair, so a corner they explain is diagnosed exactly as before. */
const CAUSE_CHAINS = [
  {
    cause: "brakeEarly",
    effect: "minSpeed",
    link: "ブレーキングが早いぶん、最低速度まで落としすぎています"
  },
  {
    cause: "brakeLate",
    effect: "throttle",
    link: "ブレーキングが遅いぶん突っ込みすぎて向きが変わるのが遅れ、その結果全開も遅れています"
  },
  {
    cause: "overEntry",
    effect: "throttle",
    link: "速度を持ち込みすぎて向きが変わり切らず、全開が遅れています"
  },
  {
    cause: "brakeLate",
    effect: "lock",
    link: "ブレーキングが遅いぶん奥で強く踏むことになり、前輪がロックしています"
  },
  {
    cause: "spin",
    effect: "throttle",
    link: "空転してアクセルを戻したぶん、全開が遅れています"
  }
];

/* Picks the finding to lead with, and keeps the rest so the card can say what
   else was different. Expects candidates sorted by weight. */
function resolveCauses(candidates) {
  let lead = candidates[0];
  let link = null;
  const chain = CAUSE_CHAINS.find(
    (item) => item.effect === lead.technique && candidates.some((c) => c.technique === item.cause)
  );
  let consumed = null;
  if (chain) {
    consumed = lead;
    lead = candidates.find((c) => c.technique === chain.cause);
    link = chain.link;
  }
  // "Lap times scatter although the inputs barely differ" contradicts any
  // input difference listed beside it, so it is only ever a lead, never an aside.
  const also = candidates.filter(
    (c) => c !== lead && c !== consumed && c.weight > 0 && c.technique !== "consistency"
  );
  return {
    ...lead,
    link,
    also: also.map((c) => ({ tag: c.tag, why: c.why }))
  };
}

// True when the reference lap pressed clearly harder than the quicker one.
function peakBrakeGap(refCorner, bestCorner) {
  return Boolean(
    refCorner &&
      bestCorner &&
      refCorner.peakBrakePct !== null &&
      bestCorner.peakBrakePct !== null &&
      refCorner.peakBrakePct - bestCorner.peakBrakePct >= MIN_PEAK_BRAKE_DIFF_PCT
  );
}

/* Too slow at the apex has two usual causes, and the channels say which one
   this lap had: pressing harder than the quicker lap, or staying on the brake
   for longer. Only when neither shows does the card fall back to the general
   advice. The target is always the driver's own quicker minimum speed. */
function minSpeedTodo(refCorner, bestCorner, onAStraight, sector, refIndex, bestIndex) {
  const target =
    `最低速度は ${Math.round(sector.minSpeedKmh[bestIndex])}km/h まで残す` +
    `（今は ${Math.round(sector.minSpeedKmh[refIndex])}km/h）`;
  if (peakBrakeGap(refCorner, bestCorner)) {
    return (
      `ブレーキング開始はそのままで、踏力の最大を ${Math.round(refCorner.peakBrakePct)}% から ` +
      `${Math.round(bestCorner.peakBrakePct)}% くらいに弱める。${target}`
    );
  }
  if (refCorner && bestCorner && refCorner.releaseM !== null && bestCorner.releaseM !== null) {
    const held = refCorner.releaseM - bestCorner.releaseM;
    if (held > MIN_POINT_DIFF_M) {
      return (
        `ブレーキを緩め終えるのを ${held.toFixed(0)}m 早める` +
        `（速かった周は${fromApex(bestCorner.releaseM, bestCorner.apexM)}で緩め終えている）。${target}`
      );
    }
  }
  return (
    (onAStraight
      ? "ブレーキを少し弱めるか早めに緩め、速度を落としすぎない。"
      : "ブレーキを少し早めに緩め、速度を残したまま向きを変える。") + target
  );
}

/* Trail braking is about where the pedal comes off relative to the apex, so
   that is the number the card gives when both laps have one. */
function releaseTodo(refCorner, bestCorner, fallback) {
  if (!refCorner || !bestCorner || refCorner.releaseM === null || bestCorner.releaseM === null) {
    return fallback;
  }
  return (
    `${fallback}。速かった周は${fromApex(bestCorner.releaseM, bestCorner.apexM)}で緩め終えています` +
    `（今は${fromApex(refCorner.releaseM, refCorner.apexM)}）`
  );
}

// Under this, two laps were on the same throttle at the same spot.
const MIN_THROTTLE_DIFF_PCT = 10;

// Index of the largest value of a channel in a range, by `score`.
function peakIndex(values, from, to, score) {
  let peak = from;
  for (let i = from; i <= to; i += 1) {
    if (score(values[i]) > score(values[peak])) peak = i;
  }
  return peak;
}

/* Wheelspin is a throttle problem at one spot, so the card names the spot and
   how much throttle the quicker lap had there. Without that lap's throttle to
   point at, it still says where. */
function spinTodo(data, refIndex, bestIndex, segment, refCorner) {
  const general = "アクセルの開け方を一段ゆるやかにする";
  const slip = data.extended.slipRear;
  if (!slip || !data.distance) return general;
  const spot = peakIndex(slip[refIndex], segment.start, segment.end, (v) => v);
  const where = refCorner ? fromApex(data.distance[spot], refCorner.apexM) : null;
  const throttle = data.channels && data.channels.throttle_pct;
  if (throttle) {
    const mine = Math.round(throttle[refIndex][spot]);
    const quicker = Math.round(throttle[bestIndex][spot]);
    if (mine - quicker >= MIN_THROTTLE_DIFF_PCT) {
      return (
        `${where ? where + "では" : ""}アクセルを ${quicker}% くらいに抑え、空転が収まってから全開にする` +
        `（今は ${mine}%）`
      );
    }
  }
  return where ? `${where}で空転しています。そこまではアクセルの開け方を一段ゆるやかにする` : general;
}

/* Where the car slid most, and by how much against the quicker lap, so "do not
   turn in so hard" has a place on track attached to it. */
function slideTodo(data, refIndex, segment, refCorner, slideRef, slideBest) {
  const general = "ハンドルを切りすぎず、ゆっくり切る";
  const angle = data.extended.slideAngle;
  if (!angle || !data.distance || !refCorner) return general;
  const spot = peakIndex(angle[refIndex], segment.start, segment.end, (v) => v);
  return (
    `${fromApex(data.distance[spot], refCorner.apexM)}で${general}` +
    `（流れる角度は速かった周 ${Math.abs(slideBest.max).toFixed(1)}°、今は ${Math.abs(slideRef.max).toFixed(1)}°）`
  );
}

// Less total turning than this and the segment is a straight or a kink, where
// inside and outside mean nothing to the driver.
const MIN_TURN_DEG = 15;

/* Where in the segment the quicker lap's line was furthest from this one, and
   on which side of the corner. Measured against the quicker lap itself, not the
   comparison lap the charts happen to show, because that is the lap the card
   quotes as evidence. Inside and outside come from which way the reference
   line bends, in the same frame as the offset, so the answer does not depend on
   how the map is drawn. Null when the lap has no positions. */
function lineDifference(data, refIndex, bestIndex, segment, refCorner) {
  if (!data.channels || !data.channels.x || !data.distance) return null;
  const offset = computeLateralOffset(data, refIndex, bestIndex);
  let peak = segment.start;
  for (let i = segment.start; i <= segment.end; i += 1) {
    if (Math.abs(offset[i]) > Math.abs(offset[peak])) peak = i;
  }
  const x = data.channels.x[refIndex];
  const z = data.channels.z[refIndex];
  let turn = 0;
  for (let i = segment.start + 1; i < segment.end; i += 1) {
    const ax = x[i] - x[i - 1];
    const az = z[i] - z[i - 1];
    const bx = x[i + 1] - x[i];
    const bz = z[i + 1] - z[i];
    if ((ax === 0 && az === 0) || (bx === 0 && bz === 0)) continue;
    // Positive when the path bends toward the offset's positive side.
    turn += Math.atan2(ax * bz - az * bx, ax * bx + az * bz);
  }
  const turning = Math.abs(turn) >= (MIN_TURN_DEG * Math.PI) / 180;
  const inside = turning && Math.sign(offset[peak]) === Math.sign(turn);
  return {
    offsetM: offset[peak],
    side: turning ? (inside ? "イン側" : "アウト側") : null,
    where: refCorner ? fromApex(data.distance[peak], refCorner.apexM) : null
  };
}

/* Compares the reference lap with whichever lap was quickest through this
   segment, and names the biggest single difference between them. */
function diagnose(data, state, entry, stats) {
  const s = state.get();
  const segment = segmentById(data, entry.id);
  const sector = data.sectorsById[entry.id];
  const lengthM = ((segment.end - segment.start) / (data.points - 1)) * data.lapDistanceM;
  const credible = Math.max(MIN_POINT_DIFF_M, lengthM * MAX_CREDIBLE_SHARE);

  const refIndex = s.refIndex;
  const bestIndex = entry.bestLapIndex;
  const difference = (field) => {
    const a = sector[field][refIndex];
    const b = sector[field][bestIndex];
    return a === null || b === null ? null : a - b;
  };

  const refCorner = cornerProfile(data, refIndex, segment);
  const bestCorner = cornerProfile(data, bestIndex, segment);
  const kmh = (value) => `${Math.round(value)}km/h`;
  const minSpeedDiff = difference("minSpeedKmh");
  const entrySpeedDiff = difference("entrySpeedKmh");
  const brakeDiff = difference("brakePointM");
  const throttleDiff = difference("fullThrottleM");

  // When the slowest point of a segment is the moment the car enters it, the car
  // only ever accelerated here: the time was lost on the way out of the previous
  // corner. Telling the driver to brake less would make no sense on a stretch
  // where they never braked.
  const slowest = sector.minSpeedKmh[refIndex];
  const entering = sector.entrySpeedKmh[refIndex];
  const isFlowing = Math.abs(slowest - entering) < 1.0;

  const candidates = [];

  if (isFlowing && entrySpeedDiff !== null && entrySpeedDiff < -MIN_SPEED_DIFF_KMH) {
    candidates.push({
      weight: 4,
      tag: "手前の立ち上がり",
      technique: "carryOver",
      why: `この区間に入る速度が ${Math.abs(entrySpeedDiff).toFixed(1)}km/h 低く、差が最後まで残っています`,
      todo:
        `直前のコーナー（${previousSegment(data, entry.id).name}）を出口優先で走り、全開を早める。` +
        `この区間に入る速度の目安は ${kmh(sector.entrySpeedKmh[bestIndex])}（今は ${kmh(entering)}）`
    });
  }

  // Ranked last on purpose: "be more consistent" is a symptom, not an action.
  // It only surfaces when no concrete input difference explains the gap.
  const spread = stats.find((item) => item.id === entry.id);
  if (spread && spread.erratic) {
    candidates.push({
      weight: 1,
      tag: "再現性",
      technique: "consistency",
      why: `操作の差は小さいのに、周ごとのタイムが ${spread.sd.toFixed(2)}秒 ばらついています`,
      todo: `${data.laps[entry.bestLapIndex].title} の周をゴースト再生で並べ、違いを1つ見つける`
    });
  }

  if (!isFlowing && minSpeedDiff !== null && minSpeedDiff < -MIN_SPEED_DIFF_KMH) {
    /* The detector names a stretch by where it sits between two apexes, so a
       braking zone on the way into a corner can be called a straight. The
       measurement holds either way, but telling someone to turn in on a piece
       of circuit they read as a straight makes the whole card look wrong. */
    const onAStraight = entry.id.startsWith("straight");
    candidates.push({
      weight: 4,
      tag: "落としすぎ",
      technique: "minSpeed",
      why: `最低速度が ${Math.abs(minSpeedDiff).toFixed(1)}km/h 低く、落としすぎています`,
      todo: minSpeedTodo(refCorner, bestCorner, onAStraight, sector, refIndex, bestIndex)
    });
  }

  /* How much of the corner's braking each lap did with the car already turning.
     A large difference here is a different technique on entry, not a different
     braking point, so it gets said in those words. */
  const trail = sector.trailBrake || null;
  const refTrail = trail ? trail[refIndex] : null;
  const bestTrail = trail ? trail[bestIndex] : null;
  if (refTrail !== null && bestTrail !== null) {
    const trailDiff = bestTrail - refTrail;
    if (trailDiff > MIN_TRAIL_DIFF) {
      candidates.push({
        weight: 5,
        tag: "残しブレーキ",
        technique: "trailMore",
        why:
          `ブレーキの ${(refTrail * 100).toFixed(0)}% しか旋回中に残しておらず、` +
          `速かった周の ${(bestTrail * 100).toFixed(0)}% より少なくなっています`,
        todo: releaseTodo(
          refCorner,
          bestCorner,
          "ブレーキを少し残したまま向きを変え、ハンドルを切るほど緩める"
        )
      });
    } else if (trailDiff < -MIN_TRAIL_DIFF) {
      candidates.push({
        weight: 5,
        tag: "残しブレーキ",
        technique: "trailLess",
        why:
          `ブレーキの ${(refTrail * 100).toFixed(0)}% を旋回中まで残していて、` +
          `速かった周の ${(bestTrail * 100).toFixed(0)}% より残しすぎています`,
        todo: releaseTodo(
          refCorner,
          bestCorner,
          "向きが変わり始めたらブレーキを緩め切り、遅くともクリップで0にする"
        )
      });
    }
  }

  if (throttleDiff !== null && Math.abs(throttleDiff) <= credible && throttleDiff > MIN_POINT_DIFF_M) {
    candidates.push({
      weight: 4,
      tag: "立ち上がり",
      technique: "throttle",
      why: `全開に入るのが ${throttleDiff.toFixed(0)}m 遅れています`,
      todo:
        `出口優先のラインで早く向きを変え切り、全開を ${throttleDiff.toFixed(0)}m 早める` +
        (bestCorner
          ? `（速かった周は${fromApex(sector.fullThrottleM[bestIndex], bestCorner.apexM)}で全開）`
          : "")
    });

    /* Carrying more speed to the apex than the quicker lap and still getting on
       the throttle later is the classic trade the wrong way round. Weight 0:
       a higher minimum speed is not a fault on its own, so this only ever
       surfaces through CAUSE_CHAINS as the reason the exit was late. */
    if (!isFlowing && minSpeedDiff !== null && minSpeedDiff > MIN_SPEED_DIFF_KMH) {
      candidates.push({
        weight: 0,
        tag: "突っ込みすぎ",
        technique: "overEntry",
        why: `最低速度は速かった周より ${minSpeedDiff.toFixed(1)}km/h 高いのに、全開は ${throttleDiff.toFixed(0)}m 遅れています`,
        todo:
          `進入の速度を ${minSpeedDiff.toFixed(0)}km/h ほど落とし（最低速度の目安は ` +
          `${kmh(sector.minSpeedKmh[bestIndex])}）、向きを変え切ってから全開にする`
      });
    }
  }

  if (brakeDiff !== null && Math.abs(brakeDiff) <= credible && Math.abs(brakeDiff) > MIN_POINT_DIFF_M) {
    const early = brakeDiff < 0;
    candidates.push({
      weight: 3,
      tag: "ブレーキング開始",
      technique: early ? "brakeEarly" : "brakeLate",
      why: early
        ? `ブレーキング開始が ${Math.abs(brakeDiff).toFixed(0)}m 手前で、早すぎます`
        : `ブレーキング開始が ${brakeDiff.toFixed(0)}m 奥で、遅れています`,
      todo:
        (early
          ? `ブレーキング開始をあと ${Math.abs(brakeDiff).toFixed(0)}m 奥へ。目印まで我慢してから、踏み始めを強く`
          : `ブレーキング開始を ${brakeDiff.toFixed(0)}m 手前に戻し、クリップに着ける`) +
        (bestCorner ? `（速かった周は${fromApex(sector.brakePointM[bestIndex], bestCorner.apexM)}で開始）` : "")
    });
  }

  const line = lineDifference(data, refIndex, bestIndex, segment, refCorner);
  if (line && Math.abs(line.offsetM) > MIN_LINE_DIFF_M) {
    const metres = Math.abs(line.offsetM).toFixed(1);
    const where = line.where ? `${line.where}で` : "";
    candidates.push({
      weight: 2,
      tag: "ライン",
      technique: "line",
      why: line.side
        ? `速かった周は${where} ${metres}m ${line.side}を通っています`
        : `走行ラインが${where}最大 ${metres}m ずれています`,
      todo: line.side
        ? `${where}今より ${metres}m ${line.side}を通る（マップの「ライン差」で確認できます）`
        : "速かった周のラインを、マップの「ライン差」で確認する"
    });
  } else if (!line && Math.abs(entry.maxOffset) > MIN_LINE_DIFF_M) {
    candidates.push({
      weight: 2,
      tag: "ライン",
      technique: "line",
      why: `走行ラインが最大 ${Math.abs(entry.maxOffset).toFixed(1)}m ずれています`,
      todo: "速かった周のラインを、マップの「ライン差」で確認する"
    });
  }

  if (data.hasExtended) {
    const slideRef = channelExtremes(data, "slideAngle", refIndex, segment.start, segment.end);
    const slideBest = channelExtremes(data, "slideAngle", bestIndex, segment.start, segment.end);
    const slideGap = Math.abs(slideRef.max) - Math.abs(slideBest.max);
    if (slideGap > MIN_SLIDE_DIFF_DEG) {
      candidates.push({
        weight: 5,
        tag: "滑り",
        technique: "slide",
        why: `速かった周より ${slideGap.toFixed(1)}° 多く流れています`,
        todo: slideTodo(data, refIndex, segment, refCorner, slideRef, slideBest)
      });
    }
    const rear = channelExtremes(data, "slipRear", refIndex, segment.start, segment.end);
    if (rear.max > SPIN_SLIP) {
      candidates.push({
        weight: 4,
        tag: "空転",
        technique: "spin",
        why: `立ち上がりでリアが ${rear.max.toFixed(2)} まで空転しています`,
        todo: spinTodo(data, refIndex, bestIndex, segment, refCorner)
      });
    }
    const front = channelExtremes(data, "slipFront", refIndex, segment.start, segment.end);
    if (front.min < LOCK_SLIP) {
      candidates.push({
        weight: 4,
        tag: "ロック",
        technique: "lock",
        why: `ブレーキングで前輪が ${front.min.toFixed(2)} までロックしています`,
        todo: peakBrakeGap(refCorner, bestCorner)
          ? `踏力の最大を ${Math.round(refCorner.peakBrakePct)}% から ${Math.round(bestCorner.peakBrakePct)}% くらいに落とし、ハンドルを切るほどブレーキを緩める`
          : "初期踏力を少し落とし、ハンドルを切るほどブレーキを緩める"
      });
    }
  }

  if (!candidates.length) {
    return {
      tag: "要確認",
      technique: "unclear",
      link: null,
      also: [],
      why: "操作の差がはっきり出ていません",
      todo: `${data.laps[bestIndex].title} の周をゴースト再生で見比べる`
    };
  }
  candidates.sort((a, b) => b.weight - a.weight);
  return resolveCauses(candidates);
}

/* The three segments where the reference lap gives away the most against the
   driver's own best run through each one. */
function buildActions(data, state, limit = 3) {
  const s = state.get();
  // Only the reference lap's own car. In a session with two cars the other
  // one's laps stay on the charts, the ghost and the segment table, but a lap
  // set in a different car cannot prove that a braking point or a line is
  // available in this one, so nothing here is built from them.
  const evidence = sameCarLapIndexes(data, s.refIndex);
  const stats = classifySegments(segmentStats(data, evidence));
  const rows = buildSectorRows(data, state);

  const entries = rows
    .map((row) => {
      const times = data.sectorsById[row.id].timeS;
      // Evidence has to be a run the driver actually drove. A spin or an off
      // through this corner can post a quicker time than any clean lap, and the
      // advice built from it would ask for something impossible.
      const bestLapIndex = fastestLapForSegment(data, row.id, { lapIndexes: evidence });
      return {
        ...row,
        bestLapIndex,
        gain: times[s.refIndex] - times[bestLapIndex]
      };
    })
    .filter(
      (entry) =>
        entry.gain > MIN_GAIN_S &&
        entry.bestLapIndex !== s.refIndex &&
        // Nothing to learn from a corner where the reference lap itself went
        // wrong: the fix there is to drive it, not to change a technique.
        !entry.refFlag &&
        !sectorFlag(data, entry.id, entry.bestLapIndex)
    )
    .sort((a, b) => b.gain - a.gain)
    .slice(0, limit);

  const actions = entries.map((entry) => ({ ...entry, ...diagnose(data, state, entry, stats) }));
  /* A stretch that loses time only because the corner before it was slow on
     the way out shares its fix with that corner. When both made the list, say
     so, or the driver reads two problems where there is one. */
  for (const action of actions) {
    if (action.technique !== "carryOver") continue;
    const before = previousSegment(data, action.id);
    const rank = actions.findIndex((other) => other.id === before.id);
    action.sameRootAs = rank >= 0 ? rank + 1 : null;
  }
  return actions;
}

/* Folded away by default: the instruction is what a driver reads between
   sessions, and the reasoning is there for when they want to know why. */
function learnMore(key) {
  const note = techniqueNote(key);
  if (!note) return "";
  return (
    '<details class="action__learn">' +
    "<summary>なぜ効くのか・次の練習</summary>" +
    `<p><b>なぜ</b>${note.principle}。</p>` +
    `<p><b>練習</b>${note.drill}。</p>` +
    "</details>"
  );
}

function renderActions(data, state, elements, onSelect) {
  const s = state.get();
  const actions = buildActions(data, state);
  const evidence = sameCarLapIndexes(data, s.refIndex);
  const totalOnTable = data.segments.reduce((total, segment) => {
    const times = data.sectorsById[segment.id].timeS;
    const bestIndex = fastestLapForSegment(data, segment.id, { lapIndexes: evidence });
    if (bestIndex === null || sectorFlag(data, segment.id, s.refIndex)) return total;
    return total + Math.max(0, times[s.refIndex] - times[bestIndex]);
  }, 0);
  // Said out loud rather than left implicit: a mixed report shows both cars
  // everywhere else, so the panel has to explain why its numbers are smaller.
  const carNote = hasSeveralCars(data)
    ? ` 根拠は <b>${data.laps[s.refIndex].carName}</b> の周だけです（他の車の周は運転の助言の根拠になりません）。`
    : "";

  if (!actions.length) {
    elements.list.innerHTML =
      '<p class="subtle">この周は全区間で自己ベストを出しています。別の周と比べるか、もっと走って比較対象を増やしてください。</p>';
    elements.summary.innerHTML = carNote.trim();
    return;
  }

  const claimable = actions.reduce((total, action) => total + action.gain, 0);
  elements.summary.innerHTML =
    `基準ラップ <b>${data.laps[s.refIndex].title}</b> を、自分が別の周で出したペースで埋めると ` +
    `<b>${formatDelta(-totalOnTable)}秒</b>。まずは下の3つで <b>${formatDelta(-claimable)}秒</b> です。` +
    carNote;

  elements.list.innerHTML = actions
    .map((action, index) => {
      const evidence = data.laps[action.bestLapIndex];
      return (
        `<article class="action" data-segment="${action.id}">` +
        `<div class="action__rank">${index + 1}</div>` +
        '<div class="action__body">' +
        '<header class="action__head">' +
        `<h3>${action.name}</h3>` +
        `<span class="action__tag">${action.tag}</span>` +
        `<span class="action__gain">−${action.gain.toFixed(3)}s</span>` +
        "</header>" +
        `<p class="action__todo">${action.todo}</p>` +
        (action.link ? `<p class="action__link">${action.link}。</p>` : "") +
        (action.sameRootAs
          ? `<p class="action__link">${action.sameRootAs}番目のカードと根っこは同じです。そちらを直せばここも縮みます。</p>`
          : "") +
        `<p class="action__why">${action.why}。` +
        /* Say what the seconds are. The card used to print a bare "14.166秒"
           against a corner, which names neither what was measured nor what it
           should be read against - a reader has no way to place the number. */
        `<span class="action__evidence">ここを抜けるのに ${formatSeconds(
          data.sectorsById[action.id].timeS[s.refIndex]
        )}秒かかっています。${evidence.title} の周は ${formatSeconds(
          data.sectorsById[action.id].timeS[action.bestLapIndex]
        )}秒でした</span></p>` +
        (action.also && action.also.length
          ? `<p class="action__also">ほかにも差があります: ${action.also
              .map((other) => `${other.tag}（${other.why}）`)
              .join("、")}</p>`
          : "") +
        learnMore(action.technique) +
        "</div>" +
        "</article>"
      );
    })
    .join("");

  elements.list.querySelectorAll(".action").forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
  });
  // Opening the explanation is reading, not choosing a corner: without this the
  // click would also zoom the charts away from wherever the driver was looking.
  elements.list.querySelectorAll(".action__learn").forEach((node) => {
    node.addEventListener("click", (event) => event.stopPropagation());
  });
}
