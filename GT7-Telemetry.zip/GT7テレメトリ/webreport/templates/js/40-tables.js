"use strict";

/* Gap bars, sector table, lap table, header stats and the cursor readout. */

function sectorValue(data, segmentId, field, lapIndex) {
  const entry = data.sectorsById[segmentId];
  if (!entry) return null;
  const value = entry[field][lapIndex];
  return value === null || value === undefined ? null : value;
}

/* Why a lap's run through a segment cannot be believed, or null when it can.
   Sessions recorded before the behaviour checks existed carry no flags at all. */
function sectorFlag(data, segmentId, lapIndex) {
  const entry = data.sectorsById[segmentId];
  if (!entry || !entry.flagged) return null;
  return entry.flagged[lapIndex] || null;
}

/* The quickest lap through a segment, ignoring runs that were spins, offs or
   impacts: a corner cut sideways can post a time nobody drove, and it would
   otherwise set the theoretical best and the advice for the whole report.
   If every lap misbehaved here, the fastest of them is still returned rather
   than dropping the segment and shortening the ideal lap.

   `lapIndexes` narrows the search to a subset of the laps; the advice panel
   passes the reference lap's own car so a quicker car cannot become the target
   the driver is told to match. Left out, every lap is considered. */
function fastestLapForSegment(
  data,
  segmentId,
  { includeFlagged = false, lapIndexes = null } = {}
) {
  const times = data.sectorsById[segmentId].timeS;
  const pool = lapIndexes || times.map((_value, index) => index);
  let best = null;
  for (const i of pool) {
    if (times[i] === null || times[i] === undefined) continue;
    if (!includeFlagged && sectorFlag(data, segmentId, i)) continue;
    if (best === null || times[i] < times[best]) best = i;
  }
  if (best === null && !includeFlagged) {
    return fastestLapForSegment(data, segmentId, { includeFlagged: true, lapIndexes });
  }
  return best;
}

/* How many lap-through-segment runs the behaviour checks refused to believe. */
function flaggedRunCount(data) {
  return data.segments.reduce((total, segment) => {
    const entry = data.sectorsById[segment.id];
    if (!entry || !entry.flagged) return total;
    return total + entry.flagged.filter(Boolean).length;
  }, 0);
}

function theoreticalBest(data, lapIndexes = null) {
  return data.segments.reduce((total, segment) => {
    const best = fastestLapForSegment(data, segment.id, { lapIndexes });
    return total + (best === null ? 0 : data.sectorsById[segment.id].timeS[best]);
  }, 0);
}

/* ---------- header stats ---------- */

function renderStats(data, state, element) {
  const s = state.get();
  // An ideal lap or an average taken across two cars describes neither of them.
  // Both are the reference lap's car; with one car that is the whole report.
  const pool = sameCarLapIndexes(data, s.refIndex);
  const poolTimes = pool.map((index) => data.laps[index].lapTimeS);
  const times = data.laps.map((lap) => lap.lapTimeS);
  const best = Math.min(...times);
  const poolBest = Math.min(...poolTimes);
  const mean = poolTimes.reduce((total, value) => total + value, 0) / poolTimes.length;
  const variance =
    poolTimes.reduce((total, value) => total + (value - mean) ** 2, 0) / poolTimes.length;
  const ideal = theoreticalBest(data, pool);
  const cars = new Set(data.laps.map((lap) => lap.carName));
  const bestLap = data.laps.find((lap) => lap.lapTimeS === best);
  const ignored = flaggedRunCount(data);
  const carNote = cars.size > 1 ? ` · ${data.laps[s.refIndex].carName}` : "";

  const entries = [
    {
      label: "ベストラップ",
      value: formatLapTime(best),
      note: bestLap.isHistory ? `歴代ベスト · ${bestLap.carName}` : bestLap.carName
    },
    {
      label: "理論ベスト",
      value: formatLapTime(ideal),
      note:
        `区間最速の合算 ${formatDelta(ideal - poolBest)}` +
        (ignored ? ` / 乱れた${ignored}区間は除外` : "") +
        carNote
    },
    {
      label: "平均",
      value: formatLapTime(mean),
      note: `σ ${Math.sqrt(variance).toFixed(3)}s${carNote}`
    },
    { label: "解析ラップ", value: String(data.laps.length), note: `${cars.size}車種` },
    {
      label: "選択中の差",
      value: formatDelta(data.laps[s.cmpIndex].lapTimeS - data.laps[s.refIndex].lapTimeS),
      note: "比較 − 基準"
    }
  ];

  element.innerHTML = entries
    .map(
      (entry) =>
        `<div><dt>${entry.label}</dt><dd>${entry.value}<small>${entry.note}</small></dd></div>`
    )
    .join("");
}

/* ---------- gap bars ---------- */

function renderGapBars(data, state, element, onSelect) {
  const s = state.get();
  const rows = data.segments.map((segment) => ({
    segment,
    gap:
      sectorValue(data, segment.id, "timeS", s.cmpIndex) -
      sectorValue(data, segment.id, "timeS", s.refIndex)
  }));
  const peak = Math.max(0.05, ...rows.map((row) => Math.abs(row.gap)));

  element.innerHTML = rows
    .map((row) => {
      const ratio = Math.abs(row.gap) / peak;
      const halfWidth = ratio * 50;
      const left = row.gap >= 0 ? 50 : 50 - halfWidth;
      const color = row.gap >= 0 ? COLORS.loss : COLORS.gain;
      const active = row.segment.id === s.activeSegment ? " is-active" : "";
      return (
        `<div class="gap-row${active}" data-segment="${row.segment.id}" title="${row.segment.nameEn}">` +
        `<span class="gap-row__name">${row.segment.name}</span>` +
        `<span class="gap-row__track"><span class="gap-row__fill" style="left:${left}%;width:${halfWidth}%;background:${color}"></span></span>` +
        `<span class="gap-row__value ${deltaClass(row.gap)}">${formatDelta(row.gap)}</span>` +
        "</div>"
      );
    })
    .join("");

  element.querySelectorAll(".gap-row").forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
  });
}

/* ---------- sector table ---------- */

const SECTOR_COLUMNS = [
  {
    key: "name",
    label: "区間",
    cell: (row) =>
      `<td title="${row.flagNote || row.note}">${row.name}` +
      (row.flagNote ? ' <span class="warn" title="' + row.flagNote + '">⚠</span>' : "") +
      "</td>"
  },
  { key: "ref", label: "基準", cell: (row) => `<td>${formatSeconds(row.ref)}</td>` },
  { key: "cmp", label: "比較", cell: (row) => `<td>${formatSeconds(row.cmp)}</td>` },
  {
    key: "gap",
    label: "差",
    cell: (row) => `<td class="${deltaCellClass(row.gap)}">${formatDelta(row.gap)}</td>`
  },
  { key: "bestTime", label: "区間最速", cell: (row) => `<td class="cell-dim">${formatSeconds(row.bestTime)}</td>` },
  {
    key: "toBest",
    label: "最速との差",
    cell: (row) => `<td class="${deltaCellClass(row.toBest)}">${formatDelta(row.toBest)}</td>`
  },
  {
    key: "minSpeedGap",
    label: "最低速差 km/h",
    cell: (row) => `<td class="${deltaCellClass(-row.minSpeedGap)}">${formatDelta(row.minSpeedGap, 1)}</td>`
  },
  { key: "maxOffset", label: "最大ライン差 m", cell: (row) => `<td class="cell-dim">${row.maxOffset.toFixed(2)}</td>` },
  {
    key: "brakeGap",
    label: "ブレーキ点差 m",
    cell: (row) => `<td class="cell-dim">${row.brakeGap === null ? "—" : formatDelta(row.brakeGap, 0)}</td>`
  },
  {
    key: "throttleGap",
    label: "全開点差 m",
    cell: (row) => `<td class="cell-dim">${row.throttleGap === null ? "—" : formatDelta(row.throttleGap, 0)}</td>`
  }
];

/* Columns that only mean anything when the session was captured directly. */
const BEHAVIOUR_COLUMNS = [
  {
    key: "slideGap",
    label: "スライド差 °",
    cell: (row) =>
      `<td class="${row.slideGap > 0.5 ? "cell-loss" : "cell-dim"}">${formatDelta(row.slideGap, 1)}</td>`
  },
  {
    key: "maxRearSlip",
    label: "最大空転",
    cell: (row) =>
      `<td class="${row.maxRearSlip > 1.05 ? "cell-loss" : "cell-dim"}">${row.maxRearSlip.toFixed(3)}</td>`
  },
  {
    key: "minFrontSlip",
    label: "最小ロック",
    cell: (row) =>
      `<td class="${row.minFrontSlip < 0.95 ? "cell-loss" : "cell-dim"}">${row.minFrontSlip.toFixed(3)}</td>`
  }
];

function sectorColumns(data) {
  return data.hasExtended ? [...SECTOR_COLUMNS, ...BEHAVIOUR_COLUMNS] : SECTOR_COLUMNS;
}

function buildSectorRows(data, state) {
  const s = state.get();
  return data.segments.map((segment) => {
    const id = segment.id;
    const ref = sectorValue(data, id, "timeS", s.refIndex);
    const cmp = sectorValue(data, id, "timeS", s.cmpIndex);
    const bestIndex = fastestLapForSegment(data, id);
    const bestTime = bestIndex === null ? null : data.sectorsById[id].timeS[bestIndex];
    const refBrake = sectorValue(data, id, "brakePointM", s.refIndex);
    const cmpBrake = sectorValue(data, id, "brakePointM", s.cmpIndex);
    let maxOffset = 0;
    for (let i = segment.start; i <= segment.end; i += 1) {
      if (Math.abs(s.lateral[i]) > Math.abs(maxOffset)) maxOffset = s.lateral[i];
    }
    let slideGap = 0;
    let maxRearSlip = 1;
    let minFrontSlip = 1;
    if (data.hasExtended) {
      let refSlide = 0;
      let cmpSlide = 0;
      for (let i = segment.start; i <= segment.end; i += 1) {
        refSlide = Math.max(refSlide, Math.abs(data.extended.slideAngle[s.refIndex][i]));
        cmpSlide = Math.max(cmpSlide, Math.abs(data.extended.slideAngle[s.cmpIndex][i]));
        maxRearSlip = Math.max(maxRearSlip, data.extended.slipRear[s.cmpIndex][i]);
        minFrontSlip = Math.min(minFrontSlip, data.extended.slipFront[s.cmpIndex][i]);
      }
      slideGap = cmpSlide - refSlide;
    }
    const refThrottle = sectorValue(data, id, "fullThrottleM", s.refIndex);
    const cmpThrottle = sectorValue(data, id, "fullThrottleM", s.cmpIndex);
    const refFlag = sectorFlag(data, id, s.refIndex);
    const cmpFlag = sectorFlag(data, id, s.cmpIndex);
    const flagNote = [
      refFlag ? `基準の周: ${refFlag}` : "",
      cmpFlag ? `比較の周: ${cmpFlag}` : ""
    ]
      .filter(Boolean)
      .join(" / ");
    return {
      id,
      name: segment.name,
      note: segment.note,
      refFlag,
      cmpFlag,
      flagNote,
      ref,
      cmp,
      gap: cmp - ref,
      bestTime,
      bestLap: bestIndex === null ? null : data.laps[bestIndex],
      toBest: cmp - bestTime,
      minSpeedGap:
        sectorValue(data, id, "minSpeedKmh", s.cmpIndex) -
        sectorValue(data, id, "minSpeedKmh", s.refIndex),
      brakeGap: refBrake === null || cmpBrake === null ? null : cmpBrake - refBrake,
      throttleGap:
        refThrottle === null || cmpThrottle === null ? null : cmpThrottle - refThrottle,
      maxOffset,
      slideGap,
      maxRearSlip,
      minFrontSlip
    };
  });
}

function renderSectorTable(data, state, table, onSelect) {
  const s = state.get();
  const rows = buildSectorRows(data, state);
  const sortKey = s.sectorSort.key;
  const direction = s.sectorSort.desc ? -1 : 1;
  rows.sort((a, b) => {
    if (sortKey === "name") return a.name.localeCompare(b.name, "ja") * direction;
    const av = a[sortKey];
    const bv = b[sortKey];
    if (av === null) return 1;
    if (bv === null) return -1;
    return (av - bv) * direction;
  });

  const columns = sectorColumns(data);
  const head = columns
    .map(
      (column) =>
        `<th data-key="${column.key}" class="${column.key === sortKey ? "is-sorted" : ""}">${column.label}</th>`
    )
    .join("");

  const body = rows
    .map((row) => {
      const active = row.id === s.activeSegment ? " class=\"is-active\"" : "";
      const cells = columns.map((column) => column.cell(row)).join("");
      return `<tr data-segment="${row.id}"${active}>${cells}</tr>`;
    })
    .join("");

  table.innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body}</tbody>`;

  table.querySelectorAll("thead th").forEach((node) => {
    node.addEventListener("click", () => {
      const key = node.dataset.key;
      const current = state.get().sectorSort;
      state.set({
        sectorSort: { key, desc: current.key === key ? !current.desc : key !== "name" }
      });
    });
  });
  table.querySelectorAll("tbody tr").forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
  });
}

/* ---------- lap table ---------- */

function renderLapTable(data, state, table, onSelect) {
  const s = state.get();
  const bestTime = Math.min(...data.laps.map((lap) => lap.lapTimeS));
  const head = ["ラップ", "タイム", "ベスト差", "車種", "最高速", "セッション"]
    .map((label) => `<th>${label}</th>`)
    .join("");

  const body = data.laps
    .map((lap) => {
      const classes = [];
      if (lap.index === s.refIndex) classes.push("is-ref");
      if (lap.index === s.cmpIndex) classes.push("is-cmp");
      const gap = lap.lapTimeS - bestTime;
      return (
        `<tr data-index="${lap.index}" class="${classes.join(" ")}">` +
        `<td>${lap.isHistory ? '<span class="pill">歴代</span>' : `#${lap.number}`}${
          lap.index === s.refIndex ? ' <span class="pill">基準</span>' : ""
        }${lap.index === s.cmpIndex ? ' <span class="pill">比較</span>' : ""}</td>` +
        `<td>${lap.title}</td>` +
        `<td class="${gap > 0 ? "cell-loss" : "cell-dim"}">${gap === 0 ? "—" : formatDelta(gap)}</td>` +
        `<td style="text-align:left">${lap.carName}</td>` +
        `<td>${lap.topSpeedKmh.toFixed(1)}</td>` +
        `<td class="cell-dim" style="text-align:left">${lap.sourceFile.replace(/\.json$/, "")}</td>` +
        "</tr>"
      );
    })
    .join("");

  table.innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body}</tbody>`;
  table.querySelectorAll("tbody tr").forEach((node) => {
    node.addEventListener("click", () => onSelect(Number(node.dataset.index)));
  });
}

/* ---------- verdict and cursor readout ---------- */

function renderVerdict(data, state, element) {
  const s = state.get();
  const gap = data.laps[s.cmpIndex].lapTimeS - data.laps[s.refIndex].lapTimeS;
  const rows = buildSectorRows(data, state).filter((row) => row.gap > 0);
  rows.sort((a, b) => b.gap - a.gap);
  const worst = rows[0];
  element.className = `picker__verdict ${deltaClass(gap)}`;
  /* This is where the *comparison* lap lost most against the reference, which
     runs the opposite way to the cards below - those say where the reference
     lap could still gain. Reading "最大の損失" as "the thing to work on" and
     finding a different corner in the cards looks like a contradiction, so the
     line names whose loss it is. */
  element.innerHTML = worst
    ? `<strong>${formatDelta(gap)}s</strong> ` +
      `<span title="この周が基準ラップに対して最も失った区間です。下のカードは逆に、基準ラップを自分の他の周で埋められる区間を示します。">` +
      `比較ラップが最も失ったのは <b>${worst.name}</b> の ${formatDelta(worst.gap)}s</span>`
    : `<strong>${formatDelta(gap)}s</strong>`;
}

/* Describes how far off the reference line the comparison lap ran. */
function lateralLabel(metres) {
  if (!isFinite(metres)) return "—";
  if (Math.abs(metres) < 0.15) return "<b>ほぼ同じ</b>";
  // The normal used by computeLateralOffset is the tangent turned toward +Z,
  // which with Z running down the screen is the driver's right hand.
  const side = metres > 0 ? "右" : "左";
  return `<b>${Math.abs(metres).toFixed(2)}m ${side}</b>`;
}

function segmentAt(data, index) {
  return data.segments.find((segment) => index >= segment.start && index <= segment.end);
}

function renderCursor(data, state, element) {
  const s = state.get();
  if (s.cursor === null) {
    element.innerHTML =
      "グラフやマップにカーソルを合わせると各地点の値を表示します · " +
      "<b>← →</b> カーソル移動（Shiftで大きく） · <b>Space</b> 再生 · <b>Esc</b> ズーム解除";
    return;
  }
  const i = s.cursor;
  const segment = segmentAt(data, i);
  const ref = s.refIndex;
  const cmp = s.cmpIndex;
  const channel = (name, lap, digits = 0) => data.channels[name][lap][i].toFixed(digits);
  element.innerHTML =
    `<b>${Math.round(data.distance[i])}m</b> · ${segment ? segment.name : "—"} · ` +
    `Δ<b>${formatDelta(s.delta[i])}s</b> · ` +
    `速度 <span class="v-ref">${channel("speed_kmh", ref, 1)}</span> / <span class="v-cmp">${channel("speed_kmh", cmp, 1)}</span> km/h · ` +
    `スロットル <span class="v-ref">${channel("throttle_pct", ref)}</span> / <span class="v-cmp">${channel("throttle_pct", cmp)}</span>% · ` +
    `ブレーキ <span class="v-ref">${channel("brake_pct", ref)}</span> / <span class="v-cmp">${channel("brake_pct", cmp)}</span>% · ` +
    `ギア <span class="v-ref">${channel("gear", ref)}</span> / <span class="v-cmp">${channel("gear", cmp)}</span> · ` +
    `ライン ${lateralLabel(s.lateral[i])}`;
}
