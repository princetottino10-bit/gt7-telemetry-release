"use strict";

/* The reference lap against the theoretical best, corner by corner.
 *
 * The theoretical best is the driver's own fastest run through each corner,
 * strung together. Every corner where the reference lap is slower gets a card
 * with the two numbers a driver can check on track - minimum speed and exit
 * speed - and the reason read straight off the pedal traces: braking started
 * earlier, full throttle came later, the throttle was held part-open where the
 * faster run was flat out, or the car arrived too fast.
 *
 * A corner here runs from its braking point to the next corner's braking point.
 * The segment table cuts corners where the car starts turning, which leaves the
 * braking zone in the straight before; that split hid the braking point (every
 * lap "started braking" on the segment's first sample) and put the loss on the
 * straight after a slow exit in a different row from the exit that caused it.
 *
 * Measured on Interlagos, GR Supra RC, 2026-10-21/22 (14 laps): the 1:37.243
 * reference lost 0.86 s to the theoretical best through the Senna S, with the
 * same minimum speed (88 vs 85 km/h) but 60-65% throttle between T1 and T2
 * where the faster lap was flat out. That is the case the "part throttle"
 * reason exists for: neither the minimum speed nor the full-throttle point,
 * which both came out the same, could show it.
 */

// Braking zones are bounded this far before the earliest lap's braking point,
// so a lap that braked a little earlier still has its whole zone inside.
const THEORY_BRAKE_LEAD_M = 20;
// GT7 reports zero throttle for a moment at every upshift. A dip shorter than
// this between two stretches of full throttle is a gear change, not a lift.
const THEORY_SHIFT_GAP_M = 15;
const THEORY_FULL_PCT = 95;
// The reference counts as holding back where it was this many points under
// the faster run (the cards' MIN_THROTTLE_DIFF_PCT).
const THEORY_PARTIAL_DIFF_PCT = 10;
// Shorter stretches of part throttle are a hand settling, not a habit.
const THEORY_PARTIAL_MIN_M = 20;
// A phase (into the corner / out of it) has to lose this much to be explained.
const THEORY_PHASE_MIN_S = 0.05;
// Cards that lose at least this much are drawn larger, at most two of them.
const THEORY_HIGHLIGHT_S = 0.15;
const THEORY_HIGHLIGHT_COUNT = 2;
// The minimum-speed point counts as moved deeper past this distance.
const THEORY_APEX_SHIFT_M = 8;

function theoryCorners(data) {
  return data.segments.filter((segment) => segment.id.startsWith("corner"));
}

/* First index in [from, to] where `test` holds for SUSTAIN_SAMPLES samples. */
function firstSustainedIndex(values, from, to, test) {
  for (let i = from; i <= to - SUSTAIN_SAMPLES + 1; i += 1) {
    let held = true;
    for (let k = 0; k < SUSTAIN_SAMPLES; k += 1) {
      if (!test(values[i + k])) {
        held = false;
        break;
      }
    }
    if (held) return i;
  }
  return null;
}

/* Throttle with the gear-change dips filled in, over [from, to]. */
function throttleWithoutShifts(data, lapIndex, from, to) {
  const raw = data.channels.throttle_pct[lapIndex];
  const step = data.lapDistanceM / (data.points - 1);
  const maxGap = Math.max(1, Math.round(THEORY_SHIFT_GAP_M / step));
  const out = Float32Array.from(raw.subarray(from, to + 1));
  let lastFull = null;
  for (let i = 0; i < out.length; i += 1) {
    if (out[i] < THEORY_FULL_PCT) continue;
    if (lastFull !== null && i - lastFull > 1 && i - lastFull - 1 <= maxGap) {
      for (let k = lastFull + 1; k < i; k += 1) out[k] = 100;
    }
    lastFull = i;
  }
  return out;
}

/* Where each lap starts braking for a corner, searched from the end of the
   corner before so a late lift on the previous exit is not read as braking. */
function brakeStartIndex(data, lapIndex, searchFrom, apex) {
  const brake = data.channels.brake_pct[lapIndex];
  return firstSustainedIndex(brake, searchFrom, apex, (value) => value >= BRAKE_ON_PCT);
}

function apexIndex(data, lapIndex, segment) {
  const speed = data.channels.speed_kmh[lapIndex];
  let apex = segment.start;
  for (let i = segment.start; i <= segment.end; i += 1) {
    if (speed[i] < speed[apex]) apex = i;
  }
  return apex;
}

/* Grid index where each corner's stretch begins: just before the earliest
   braking point any lap in `pool` used, or the corner's own start where
   nobody braked. */
function theoryBoundaries(data, corners, pool) {
  return corners.map((corner, k) => {
    const searchFrom = k === 0 ? 0 : corners[k - 1].end;
    let earliest = null;
    for (const lap of pool) {
      const start = brakeStartIndex(data, lap, searchFrom, apexIndex(data, lap, corner));
      if (start !== null && (earliest === null || start < earliest)) earliest = start;
    }
    if (earliest === null) return corner.start;
    const step = data.lapDistanceM / (data.points - 1);
    return Math.max(searchFrom, Math.min(corner.start, earliest - Math.round(THEORY_BRAKE_LEAD_M / step)));
  });
}

/* One lap's figures through one corner stretch [from, to]. */
function theoryFigures(data, lapIndex, corner, from, to) {
  const speed = data.channels.speed_kmh[lapIndex];
  const apex = apexIndex(data, lapIndex, corner);
  const brakeAt = brakeStartIndex(data, lapIndex, from, apex);
  // Full throttle that is then held to the end of the stretch: a lap that
  // touches 100% between two parts of an S and lifts again has not finished
  // the corner yet.
  const throttle = throttleWithoutShifts(data, lapIndex, apex, to);
  let fullAt = null;
  for (let i = throttle.length - 1; i >= 0; i -= 1) {
    if (throttle[i] < THEORY_FULL_PCT) break;
    fullAt = apex + i;
  }
  // The first time the lap went flat out, and where it then backed off again
  // before the point it was finally held from. A late "held" point is two
  // different habits: never getting there, or getting there and lifting.
  const firstFull = firstSustainedIndex(throttle, 0, throttle.length - 1, (value) => value >= THEORY_FULL_PCT);
  let liftAt = null;
  if (firstFull !== null && fullAt !== null && apex + firstFull < fullAt) {
    const lift = firstSustainedIndex(throttle, firstFull, fullAt - apex, (value) => value < THEORY_FULL_PCT);
    if (lift !== null) liftAt = apex + lift;
  }
  let lock = null;
  if (data.hasExtended && data.extended.slipFront && brakeAt !== null) {
    const slip = data.extended.slipFront[lapIndex];
    lock = Infinity;
    for (let i = brakeAt; i <= apex; i += 1) lock = Math.min(lock, slip[i]);
  }
  return {
    apex,
    apexM: data.distance[apex],
    minSpeedKmh: speed[apex],
    brakeAt,
    brakeM: brakeAt === null ? null : data.distance[brakeAt],
    fullAt,
    fullM: fullAt === null ? null : data.distance[fullAt],
    firstFullM: firstFull === null ? null : data.distance[apex + firstFull],
    liftM: liftAt === null ? null : data.distance[liftAt],
    lock
  };
}

/* Distance over which the reference held less throttle than the faster lap,
   between the faster lap's apex and the end of the stretch. Both the straight
   part-throttle case (60% where the other was flat) and a gentler ramp out of
   the apex (40-70% where the other was already at 85%) count. */
function partialThrottle(data, refIndex, bestIndex, from, to) {
  if (from >= to) return null;
  const ref = throttleWithoutShifts(data, refIndex, from, to);
  const best = throttleWithoutShifts(data, bestIndex, from, to);
  const brake = data.channels.brake_pct[refIndex];
  const step = data.lapDistanceM / (data.points - 1);
  let count = 0;
  let sum = 0;
  let sumBest = 0;
  for (let i = 0; i < ref.length; i += 1) {
    if (best[i] - ref[i] >= THEORY_PARTIAL_DIFF_PCT && brake[from + i] < BRAKE_OFF_PCT) {
      count += 1;
      sum += ref[i];
      sumBest += best[i];
    }
  }
  return count ? { metres: count * step, meanPct: sum / count, bestPct: sumBest / count } : null;
}

function lapTime(data, lapIndex, from, to) {
  const time = data.channels.time_s[lapIndex];
  return time[to] - time[from];
}

/* Reasons, each measured directly against the faster run, in driving order.
   A reason for the way out is only given when the way in did not already
   explain the corner: a lap that arrived too fast also leaves slowly, and
   that slow exit is the same mistake. */
function theoryReasons(ref, best, entryLoss, exitLoss, partial) {
  const reasons = [];
  const brakeGap = ref.brakeM !== null && best.brakeM !== null ? ref.brakeM - best.brakeM : null;
  const exitDown = best.exitSpeedKmh - ref.exitSpeedKmh;
  const apexDeeper = ref.apexM - best.apexM >= THEORY_APEX_SHIFT_M;
  const locked = ref.lock !== null && ref.lock < LOCK_SLIP && (best.lock === null || best.lock >= LOCK_SLIP);

  if (brakeGap !== null && brakeGap >= MIN_POINT_DIFF_M && exitDown >= MIN_SPEED_DIFF_KMH && (apexDeeper || locked)) {
    const proof = [apexDeeper ? `最低速度の地点が ${(ref.apexM - best.apexM).toFixed(0)}m 奥` : "", locked ? "前輪がロック気味" : ""]
      .filter(Boolean)
      .join("、");
    reasons.push({
      key: "overspeed",
      tag: "突っ込みすぎ",
      text: `ブレーキング開始が ${brakeGap.toFixed(0)}m 遅く（${proof}）、脱出速度が ${exitDown.toFixed(0)}km/h 低い。踏み始めを手前にしてクリップに着ける`
    });
    return reasons;
  }

  if (entryLoss >= THEORY_PHASE_MIN_S) {
    if (brakeGap !== null && brakeGap <= -MIN_POINT_DIFF_M) {
      reasons.push({
        key: "brakeEarly",
        tag: "ブレーキングが早い",
        text: `踏み始めが ${(-brakeGap).toFixed(0)}m 手前（${ref.brakeM.toFixed(0)}m地点、速い周は ${best.brakeM.toFixed(0)}m地点）`
      });
    } else if (best.minSpeedKmh - ref.minSpeedKmh >= MIN_SPEED_DIFF_KMH) {
      reasons.push({
        key: "minSpeed",
        tag: "落としすぎ",
        text: `最低速度が ${(best.minSpeedKmh - ref.minSpeedKmh).toFixed(0)}km/h 低い（ブレーキング開始の差は ${brakeGap === null ? "—" : `${Math.abs(brakeGap).toFixed(0)}m`}）`
      });
    }
  }

  if (exitLoss >= THEORY_PHASE_MIN_S) {
    const fullGap = ref.fullM !== null && best.fullM !== null ? ref.fullM - best.fullM : null;
    // Lifting after going flat also shows up as part throttle over the same
    // metres; it is reported once, as the lift.
    const lifted =
      fullGap !== null &&
      fullGap >= MIN_POINT_DIFF_M &&
      ref.liftM !== null &&
      ref.firstFullM !== null &&
      ref.firstFullM - best.fullM < MIN_POINT_DIFF_M;
    if (lifted) {
      reasons.push({
        key: "lift",
        tag: "出口で戻している",
        text: `一度全開にしたあと ${ref.liftM.toFixed(0)}m地点で戻し、${ref.fullM.toFixed(0)}m地点まで全開に戻っていない（速い周は ${best.fullM.toFixed(0)}m地点から全開のまま）`
      });
    } else {
      if (partial && partial.metres >= THEORY_PARTIAL_MIN_M) {
        reasons.push({
          key: "partial",
          tag: "アクセル開度が低い",
          text: `${partial.metres.toFixed(0)}m のあいだ速い周より踏めていない（平均 ${partial.meanPct.toFixed(0)}%、速い周は ${partial.bestPct.toFixed(0)}%）`
        });
      }
      if (fullGap !== null && fullGap >= MIN_POINT_DIFF_M) {
        reasons.push({
          key: "throttle",
          tag: "全開が遅い",
          text: `全開が ${fullGap.toFixed(0)}m 遅い（${ref.fullM.toFixed(0)}m地点、速い周は ${best.fullM.toFixed(0)}m地点）`
        });
      }
    }
  }
  return reasons;
}

/* The theoretical best and one entry per corner for the reference lap. */
function theoryComparison(data, refIndex) {
  const corners = theoryCorners(data);
  const pool = sameCarLapIndexes(data, refIndex);
  if (!corners.length || !pool.length || !data.channels.time_s) return null;
  const bounds = theoryBoundaries(data, corners, pool);
  const last = data.points - 1;

  // The part before the first corner's braking zone is timed too, so the
  // theoretical lap covers the whole lap.
  const parts = [{ from: 0, to: bounds[0], corner: null, flagSegment: null }];
  corners.forEach((corner, k) => {
    parts.push({ from: bounds[k], to: k + 1 < corners.length ? bounds[k + 1] : last, corner, flagSegment: corner.id });
  });

  let theoretical = 0;
  let refTotal = 0;
  const entries = [];
  for (const part of parts) {
    if (part.to <= part.from) continue;
    const usable = pool.filter((lap) => !part.flagSegment || !sectorFlag(data, part.flagSegment, lap));
    const candidates = usable.length ? usable : pool;
    let bestLap = candidates[0];
    for (const lap of candidates) {
      if (lapTime(data, lap, part.from, part.to) < lapTime(data, bestLap, part.from, part.to)) bestLap = lap;
    }
    const bestTime = lapTime(data, bestLap, part.from, part.to);
    const refTime = lapTime(data, refIndex, part.from, part.to);
    theoretical += bestTime;
    refTotal += refTime;
    if (!part.corner) continue;

    const loss = refTime - bestTime;
    const ref = theoryFigures(data, refIndex, part.corner, part.from, part.to);
    const best = theoryFigures(data, bestLap, part.corner, part.from, part.to);
    // Exit speed is read at one place for both laps: where the later of the two
    // went flat out for good, so both have finished the corner there. The
    // segment's own end can sit far down the next straight (the Senna S segment
    // ends after the curve that follows it), and by then both laps are near top
    // speed and the difference has washed out. The faster run's point alone is
    // too early for a lap that braked later and is still slowing there.
    const fullPoints = [ref.fullAt, best.fullAt].filter((value) => value !== null);
    const exitAt = fullPoints.length ? Math.max(...fullPoints) : part.corner.end;
    ref.exitSpeedKmh = data.channels.speed_kmh[refIndex][exitAt];
    best.exitSpeedKmh = data.channels.speed_kmh[bestLap][exitAt];
    // Split at the faster run's minimum-speed point: before it is braking and
    // turning in, after it is the way out and the straight that follows.
    const timeRef = data.channels.time_s[refIndex];
    const timeBest = data.channels.time_s[bestLap];
    const entryLoss = timeRef[best.apex] - timeRef[part.from] - (timeBest[best.apex] - timeBest[part.from]);
    const exitLoss = loss - entryLoss;
    const partial = bestLap === refIndex ? null : partialThrottle(data, refIndex, bestLap, best.apex, part.to);
    entries.push({
      segment: part.corner,
      exitM: data.distance[exitAt],
      from: part.from,
      to: part.to,
      bestLap,
      loss,
      entryLoss,
      exitLoss,
      ref,
      best,
      reasons: bestLap === refIndex ? [] : theoryReasons(ref, best, entryLoss, exitLoss, partial)
    });
  }

  // The reference's own time over the same parts, so the gap and the lap time
  // agree even where the grid's last sample is not quite the timing line.
  const refLapTime = data.laps[refIndex].lapTimeS;
  const theoreticalS = refLapTime - (refTotal - theoretical);
  const ranked = entries.filter((entry) => entry.loss >= THEORY_HIGHLIGHT_S).sort((a, b) => b.loss - a.loss);
  for (const entry of ranked.slice(0, THEORY_HIGHLIGHT_COUNT)) entry.highlight = true;
  return { theoreticalS, refLapTime, entries };
}

function theorySpeed(refValue, bestValue) {
  const gap = refValue - bestValue;
  const cls = gap <= -MIN_SPEED_DIFF_KMH ? "is-loss" : gap >= MIN_SPEED_DIFF_KMH ? "is-gain" : "";
  return (
    `<span class="theory__now ${cls}">${refValue.toFixed(0)}</span>` +
    `<span class="theory__best">理論 ${bestValue.toFixed(0)}</span>`
  );
}

/* The whole track, large, with each losing corner drawn in and labelled with
   its loss, so the cards beside it read as "where" first and "why" second. */
function theoryTrackMap(data, entries, rotationDeg = 0) {
  const lapIndex = Math.max(0, data.laps.findIndex((lap) => lap.isReference));
  const xs = data.channels && data.channels.x ? data.channels.x[lapIndex] : null;
  const zs = xs ? data.channels.z[lapIndex] : null;
  if (!xs || !zs) return "";
  const radians = (rotationDeg * Math.PI) / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  const rotated = Array.from(xs, (x, i) => [x * cos - zs[i] * sin, x * sin + zs[i] * cos]);
  const us = rotated.map((point) => point[0]);
  const vs = rotated.map((point) => point[1]);
  const uMin = Math.min(...us);
  const vMin = Math.min(...vs);
  const uSpan = Math.max(Math.max(...us) - uMin, 1);
  const vSpan = Math.max(Math.max(...vs) - vMin, 1);
  // Room around the track for the labels, which sit outside it. The box takes
  // the track's own shape, so a tall circuit is not shrunk into a wide frame.
  const pad = 80;
  const width = 600;
  const height = Math.round(Math.min(760, Math.max(380, pad * 2 + ((width - pad * 2) * vSpan) / uSpan)));
  const scale = Math.min((width - pad * 2) / uSpan, (height - pad * 2) / vSpan);
  const offsetX = (width - uSpan * scale) / 2;
  const offsetY = (height - vSpan * scale) / 2;
  // World +Z runs down the screen, as on the big map (see computeView).
  const point = (i) => [(rotated[i][0] - uMin) * scale + offsetX, (rotated[i][1] - vMin) * scale + offsetY];
  const at = (i) => point(i).map((value) => value.toFixed(1)).join(",");
  const path = (from, to, step) => {
    const parts = [];
    for (let i = from; i < to; i += step) parts.push(at(i));
    parts.push(at(to));
    return "M" + parts.join("L");
  };
  const step = Math.max(1, Math.floor(xs.length / 400));
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < xs.length; i += step) {
    const [px, py] = point(i);
    cx += px;
    cy += py;
  }
  const samples = Math.ceil(xs.length / step);
  cx /= samples;
  cy /= samples;

  // The start line across the track, and an arrow a little way on for the
  // direction of travel.
  const [sx, sy] = point(0);
  const ahead = Math.min(xs.length - 1, Math.round(xs.length * 0.025));
  const [ax, ay] = point(ahead);
  const [bx, by] = point(Math.max(0, ahead - 3));
  const dirLen = Math.hypot(ax - bx, ay - by) || 1;
  const dx = (ax - bx) / dirLen;
  const dy = (ay - by) / dirLen;
  const [s1x, s1y] = point(Math.min(xs.length - 1, 3));
  const tLen = Math.hypot(s1x - sx, s1y - sy) || 1;
  const nx = -(s1y - sy) / tLen;
  const ny = (s1x - sx) / tLen;
  const arrow =
    `M${(ax + dx * 9).toFixed(1)},${(ay + dy * 9).toFixed(1)}` +
    `L${(ax - dx * 6 + nx * 7).toFixed(1)},${(ay - dy * 6 + ny * 7).toFixed(1)}` +
    `L${(ax - dx * 6 - nx * 7).toFixed(1)},${(ay - dy * 6 - ny * 7).toFixed(1)}Z`;

  const corners = entries
    .map((entry) => {
      const { segment } = entry;
      const colour = entry.highlight ? COLORS.loss : COLORS.cmp;
      const middle = Math.round((segment.start + segment.end) / 2);
      const [mx, my] = point(middle);
      const away = Math.hypot(mx - cx, my - cy) || 1;
      const lx = Math.min(width - 50, Math.max(50, mx + ((mx - cx) / away) * 62));
      const ly = Math.min(height - 14, Math.max(22, my + ((my - cy) / away) * 48));
      // The leader stops short of the label so it does not run through the text.
      const reach = Math.hypot(lx - mx, ly - my);
      const short = reach > 1 ? Math.max(0, reach - 26) / reach : 0;
      const tipX = mx + (lx - mx) * short;
      const tipY = my + (ly - my) * short;
      return (
        `<g class="theory-map__corner${entry.highlight ? " is-key" : ""}" data-segment="${segment.id}">` +
        `<path d="${path(segment.start, segment.end, 1)}" fill="none" stroke="${colour}" stroke-width="${entry.highlight ? 9 : 6}" stroke-linecap="round" stroke-linejoin="round"/>` +
        `<line x1="${mx.toFixed(1)}" y1="${my.toFixed(1)}" x2="${tipX.toFixed(1)}" y2="${tipY.toFixed(1)}" stroke="${colour}" stroke-width="1" opacity="0.6"/>` +
        `<text x="${lx.toFixed(1)}" y="${(ly - 4).toFixed(1)}" text-anchor="middle" class="theory-map__name">${segment.name}</text>` +
        `<text x="${lx.toFixed(1)}" y="${(ly + 14).toFixed(1)}" text-anchor="middle" class="theory-map__loss" fill="${colour}">+${entry.loss.toFixed(2)}</text>` +
        "</g>"
      );
    })
    .join("");

  return (
    `<svg class="theory-map" viewBox="0 0 ${width} ${height}" role="img" aria-label="負けているコーナーの場所">` +
    `<path d="${path(0, xs.length - 1, step)}" fill="none" stroke="${COLORS.neutral}" stroke-width="4" stroke-linejoin="round"/>` +
    `<line x1="${(sx + nx * 12).toFixed(1)}" y1="${(sy + ny * 12).toFixed(1)}" x2="${(sx - nx * 12).toFixed(1)}" y2="${(sy - ny * 12).toFixed(1)}" stroke="${COLORS.text}" stroke-width="3"/>` +
    `<path d="${arrow}" fill="${COLORS.text}"/>` +
    `<text x="${(sx + nx * 24).toFixed(1)}" y="${(sy + ny * 24 + 4).toFixed(1)}" text-anchor="middle" class="theory-map__start">スタート</text>` +
    corners +
    "</svg>"
  );
}

function renderTheory(data, state, elements, onSelect) {
  if (!elements.list) return;
  const s = state.get();
  const result = theoryComparison(data, s.refIndex);
  if (!result) {
    elements.list.innerHTML = "";
    elements.summary.textContent = "";
    if (elements.map) elements.map.innerHTML = "";
    return;
  }
  const refTitle = data.laps[s.refIndex].title;
  const gap = result.refLapTime - result.theoreticalS;
  elements.summary.innerHTML =
    `理論ベスト <b>${formatLapTime(result.theoreticalS)}</b>（コーナーごとに一番速く抜けた周をつないだタイム）。` +
    `基準ラップ <b>${refTitle}</b> との差は <b>+${gap.toFixed(2)}秒</b>。` +
    (hasSeveralCars(data) ? ` 比べているのは <b>${data.laps[s.refIndex].carName}</b> の周だけです。` : "");

  const losing = result.entries.filter((entry) => entry.loss >= MIN_GAIN_S);
  const even = result.entries.filter((entry) => entry.loss < MIN_GAIN_S);
  elements.list.innerHTML =
    losing
      .map((entry) => {
        const bestTitle = data.laps[entry.bestLap].title;
        const reasons = entry.reasons.length
          ? entry.reasons
              .map((reason) => `<li><span class="theory__tag">${reason.tag}</span>${reason.text}</li>`)
              .join("")
          : '<li><span class="theory__tag">要確認</span>ブレーキとアクセルにははっきりした差がありません。走行ラインを比べてください</li>';
        return (
          `<article class="theory${entry.highlight ? " theory--key" : ""}" data-segment="${entry.segment.id}">` +
          '<div class="theory__body">' +
          '<header class="theory__head">' +
          `<h3>${entry.segment.name}</h3>` +
          `<span class="theory__loss">+${entry.loss.toFixed(2)}秒</span>` +
          "</header>" +
          `<p class="theory__split">入口 ${formatDelta(entry.entryLoss, 2)} ／ 出口 ${formatDelta(entry.exitLoss, 2)}</p>` +
          '<dl class="theory__speeds">' +
          `<div><dt>最低速度</dt><dd>${theorySpeed(entry.ref.minSpeedKmh, entry.best.minSpeedKmh)}</dd></div>` +
          `<div><dt>脱出速度（${entry.exitM.toFixed(0)}m地点）</dt><dd>${theorySpeed(entry.ref.exitSpeedKmh, entry.best.exitSpeedKmh)}</dd></div>` +
          "</dl>" +
          `<ul class="theory__reasons">${reasons}</ul>` +
          `<p class="theory__from">理論側の周: ${bestTitle}</p>` +
          "</div>" +
          "</article>"
        );
      })
      .join("") +
    (even.length
      ? `<p class="subtle theory__even">差なし: ${even.map((entry) => entry.segment.name).join("、")}</p>`
      : "");

  if (elements.map) elements.map.innerHTML = theoryTrackMap(data, losing, s.mapRotationDeg);
  // Pointing at a card lights its corner on the map, and the other way round.
  const mark = (segmentId, on) => {
    const root = elements.list.parentElement || elements.list;
    root.querySelectorAll(`[data-segment="${segmentId}"]`).forEach((node) => node.classList.toggle("is-hover", on));
  };
  const nodes = [...elements.list.querySelectorAll(".theory")];
  if (elements.map) nodes.push(...elements.map.querySelectorAll(".theory-map__corner"));
  nodes.forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
    node.addEventListener("mouseenter", () => mark(node.dataset.segment, true));
    node.addEventListener("mouseleave", () => mark(node.dataset.segment, false));
  });
}
