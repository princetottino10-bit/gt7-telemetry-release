"use strict";

/* The reference lap against the theoretical best, corner by corner.
 *
 * The theoretical best is the driver's own fastest run through each corner,
 * strung together. Every corner where the reference lap is slower gets a card
 * with the two numbers a driver can check on track - minimum speed and exit
 * speed - and the reason read straight off the pedal traces: braking started
 * earlier, full throttle came later, the throttle was held part-open where the
 * faster run was flat out, or the car arrived too fast.
 *
 * A corner here runs from its braking point to the next corner's braking point.
 * The segment table cuts corners where the car starts turning, which leaves the
 * braking zone in the straight before; that split hid the braking point (every
 * lap "started braking" on the segment's first sample) and put the loss on the
 * straight after a slow exit in a different row from the exit that caused it.
 *
 * Measured on Interlagos, GR Supra RC, 2026-10-21/22 (14 laps): the 1:37.243
 * reference lost 0.86 s to the theoretical best through the Senna S, with the
 * same minimum speed (88 vs 85 km/h) but 60-65% throttle between T1 and T2
 * where the faster lap was flat out. That is the case the "part throttle"
 * reason exists for: neither the minimum speed nor the full-throttle point,
 * which both came out the same, could show it.
 */

// Braking zones are bounded this far before the earliest lap's braking point,
// so a lap that braked a little earlier still has its whole zone inside.
const THEORY_BRAKE_LEAD_M = 20;
// GT7 reports zero throttle for a moment at every upshift. A dip shorter than
// this between two stretches of full throttle is a gear change, not a lift.
const THEORY_SHIFT_GAP_M = 15;
const THEORY_FULL_PCT = 95;
// The reference counts as holding back where it was this many points under
// the faster run (the cards' MIN_THROTTLE_DIFF_PCT).
const THEORY_PARTIAL_DIFF_PCT = 10;
// Shorter stretches of part throttle are a hand settling, not a habit.
const THEORY_PARTIAL_MIN_M = 20;
// A phase (into the corner / out of it) has to lose this much to be explained.
const THEORY_PHASE_MIN_S = 0.05;
// Cards that lose at least this much are drawn larger, at most two of them.
const THEORY_HIGHLIGHT_S = 0.15;
const THEORY_HIGHLIGHT_COUNT = 2;
// The minimum-speed point counts as moved deeper past this distance.
const THEORY_APEX_SHIFT_M = 8;

function theoryCorners(data) {
  return data.segments.filter((segment) => segment.id.startsWith("corner"));
}

/* First index in [from, to] where `test` holds for SUSTAIN_SAMPLES samples. */
function firstSustainedIndex(values, from, to, test) {
  for (let i = from; i <= to - SUSTAIN_SAMPLES + 1; i += 1) {
    let held = true;
    for (let k = 0; k < SUSTAIN_SAMPLES; k += 1) {
      if (!test(values[i + k])) {
        held = false;
        break;
      }
    }
    if (held) return i;
  }
  return null;
}

/* Throttle with the gear-change dips filled in, over [from, to]. */
function throttleWithoutShifts(data, lapIndex, from, to) {
  const raw = data.channels.throttle_pct[lapIndex];
  const step = data.lapDistanceM / (data.points - 1);
  const maxGap = Math.max(1, Math.round(THEORY_SHIFT_GAP_M / step));
  const out = Float32Array.from(raw.subarray(from, to + 1));
  let lastFull = null;
  for (let i = 0; i < out.length; i += 1) {
    if (out[i] < THEORY_FULL_PCT) continue;
    if (lastFull !== null && i - lastFull > 1 && i - lastFull - 1 <= maxGap) {
      for (let k = lastFull + 1; k < i; k += 1) out[k] = 100;
    }
    lastFull = i;
  }
  return out;
}

/* Where each lap starts braking for a corner, searched from the end of the
   corner before so a late lift on the previous exit is not read as braking. */
function brakeStartIndex(data, lapIndex, searchFrom, apex) {
  const brake = data.channels.brake_pct[lapIndex];
  return firstSustainedIndex(brake, searchFrom, apex, (value) => value >= BRAKE_ON_PCT);
}

function apexIndex(data, lapIndex, segment) {
  const speed = data.channels.speed_kmh[lapIndex];
  let apex = segment.start;
  for (let i = segment.start; i <= segment.end; i += 1) {
    if (speed[i] < speed[apex]) apex = i;
  }
  return apex;
}

/* Grid index where each corner's stretch begins: just before the earliest
   braking point any lap in `pool` used, or the corner's own start where
   nobody braked. */
function theoryBoundaries(data, corners, pool) {
  return corners.map((corner, k) => {
    const searchFrom = k === 0 ? 0 : corners[k - 1].end;
    let earliest = null;
    for (const lap of pool) {
      const start = brakeStartIndex(data, lap, searchFrom, apexIndex(data, lap, corner));
      if (start !== null && (earliest === null || start < earliest)) earliest = start;
    }
    if (earliest === null) return corner.start;
    const step = data.lapDistanceM / (data.points - 1);
    return Math.max(searchFrom, Math.min(corner.start, earliest - Math.round(THEORY_BRAKE_LEAD_M / step)));
  });
}

/* One lap's figures through one corner stretch [from, to]. */
function theoryFigures(data, lapIndex, corner, from, to) {
  const speed = data.channels.speed_kmh[lapIndex];
  const apex = apexIndex(data, lapIndex, corner);
  const brakeAt = brakeStartIndex(data, lapIndex, from, apex);
  // Full throttle that is then held to the end of the stretch: a lap that
  // touches 100% between two parts of an S and lifts again has not finished
  // the corner yet.
  const throttle = throttleWithoutShifts(data, lapIndex, apex, to);
  let fullAt = null;
  for (let i = throttle.length - 1; i >= 0; i -= 1) {
    if (throttle[i] < THEORY_FULL_PCT) break;
    fullAt = apex + i;
  }
  // The first time the lap went flat out, and where it then backed off again
  // before the point it was finally held from. A late "held" point is two
  // different habits: never getting there, or getting there and lifting.
  const firstFull = firstSustainedIndex(throttle, 0, throttle.length - 1, (value) => value >= THEORY_FULL_PCT);
  let liftAt = null;
  if (firstFull !== null && fullAt !== null && apex + firstFull < fullAt) {
    const lift = firstSustainedIndex(throttle, firstFull, fullAt - apex, (value) => value < THEORY_FULL_PCT);
    if (lift !== null) liftAt = apex + lift;
  }
  let lock = null;
  if (data.hasExtended && data.extended.slipFront && brakeAt !== null) {
    const slip = data.extended.slipFront[lapIndex];
    lock = Infinity;
    for (let i = brakeAt; i <= apex; i += 1) lock = Math.min(lock, slip[i]);
  }
  return {
    apex,
    apexM: data.distance[apex],
    minSpeedKmh: speed[apex],
    brakeAt,
    brakeM: brakeAt === null ? null : data.distance[brakeAt],
    fullAt,
    fullM: fullAt === null ? null : data.distance[fullAt],
    firstFullM: firstFull === null ? null : data.distance[apex + firstFull],
    liftM: liftAt === null ? null : data.distance[liftAt],
    lock
  };
}

/* Distance over which the reference held less throttle than the faster lap,
   between the faster lap's apex and the end of the stretch. Both the straight
   part-throttle case (60% where the other was flat) and a gentler ramp out of
   the apex (40-70% where the other was already at 85%) count. */
function partialThrottle(data, refIndex, bestIndex, from, to) {
  if (from >= to) return null;
  const ref = throttleWithoutShifts(data, refIndex, from, to);
  const best = throttleWithoutShifts(data, bestIndex, from, to);
  const brake = data.channels.brake_pct[refIndex];
  const step = data.lapDistanceM / (data.points - 1);
  let count = 0;
  let sum = 0;
  let sumBest = 0;
  for (let i = 0; i < ref.length; i += 1) {
    if (best[i] - ref[i] >= THEORY_PARTIAL_DIFF_PCT && brake[from + i] < BRAKE_OFF_PCT) {
      count += 1;
      sum += ref[i];
      sumBest += best[i];
    }
  }
  return count ? { metres: count * step, meanPct: sum / count, bestPct: sumBest / count } : null;
}

function lapTime(data, lapIndex, from, to) {
  const time = data.channels.time_s[lapIndex];
  return time[to] - time[from];
}

/* Reasons, each measured directly against the faster run, in driving order.
   A reason for the way out is only given when the way in did not already
   explain the corner: a lap that arrived too fast also leaves slowly, and
   that slow exit is the same mistake. */
function theoryReasons(ref, best, entryLoss, exitLoss, partial) {
  const reasons = [];
  const brakeGap = ref.brakeM !== null && best.brakeM !== null ? ref.brakeM - best.brakeM : null;
  const exitDown = best.exitSpeedKmh - ref.exitSpeedKmh;
  const apexDeeper = ref.apexM - best.apexM >= THEORY_APEX_SHIFT_M;
  const locked = ref.lock !== null && ref.lock < LOCK_SLIP && (best.lock === null || best.lock >= LOCK_SLIP);

  if (brakeGap !== null && brakeGap >= MIN_POINT_DIFF_M && exitDown >= MIN_SPEED_DIFF_KMH && (apexDeeper || locked)) {
    const proof = [apexDeeper ? `最低速度の地点が ${(ref.apexM - best.apexM).toFixed(0)}m 奥` : "", locked ? "前輪がロック気味" : ""]
      .filter(Boolean)
      .join("、");
    reasons.push({
      key: "overspeed",
      tag: "突っ込みすぎ",
      text: `ブレーキング開始が ${brakeGap.toFixed(0)}m 遅く（${proof}）、脱出速度が ${exitDown.toFixed(0)}km/h 低い。踏み始めを手前にしてクリップに着ける`
    });
    return reasons;
  }

  if (entryLoss >= THEORY_PHASE_MIN_S) {
    if (brakeGap !== null && brakeGap <= -MIN_POINT_DIFF_M) {
      reasons.push({
        key: "brakeEarly",
        tag: "ブレーキングが早い",
        text: `踏み始めが ${(-brakeGap).toFixed(0)}m 手前（${ref.brakeM.toFixed(0)}m地点、速い周は ${best.brakeM.toFixed(0)}m地点）`
      });
    } else if (best.minSpeedKmh - ref.minSpeedKmh >= MIN_SPEED_DIFF_KMH) {
      reasons.push({
        key: "minSpeed",
        tag: "落としすぎ",
        text: `最低速度が ${(best.minSpeedKmh - ref.minSpeedKmh).toFixed(0)}km/h 低い（ブレーキング開始の差は ${brakeGap === null ? "—" : `${Math.abs(brakeGap).toFixed(0)}m`}）`
      });
    }
  }

  if (exitLoss >= THEORY_PHASE_MIN_S) {
    const fullGap = ref.fullM !== null && best.fullM !== null ? ref.fullM - best.fullM : null;
    // Lifting after going flat also shows up as part throttle over the same
    // metres; it is reported once, as the lift.
    const lifted =
      fullGap !== null &&
      fullGap >= MIN_POINT_DIFF_M &&
      ref.liftM !== null &&
      ref.firstFullM !== null &&
      ref.firstFullM - best.fullM < MIN_POINT_DIFF_M;
    if (lifted) {
      reasons.push({
        key: "lift",
        tag: "出口で戻している",
        text: `一度全開にしたあと ${ref.liftM.toFixed(0)}m地点で戻し、${ref.fullM.toFixed(0)}m地点まで全開に戻っていない（速い周は ${best.fullM.toFixed(0)}m地点から全開のまま）`
      });
    } else {
      if (partial && partial.metres >= THEORY_PARTIAL_MIN_M) {
        reasons.push({
          key: "partial",
          tag: "アクセル開度が低い",
          text: `${partial.metres.toFixed(0)}m のあいだ速い周より踏めていない（平均 ${partial.meanPct.toFixed(0)}%、速い周は ${partial.bestPct.toFixed(0)}%）`
        });
      }
      if (fullGap !== null && fullGap >= MIN_POINT_DIFF_M) {
        reasons.push({
          key: "throttle",
          tag: "全開が遅い",
          text: `全開が ${fullGap.toFixed(0)}m 遅い（${ref.fullM.toFixed(0)}m地点、速い周は ${best.fullM.toFixed(0)}m地点）`
        });
      }
    }
  }
  return reasons;
}

/* The theoretical best and one entry per corner for the reference lap. */
function theoryComparison(data, refIndex) {
  const corners = theoryCorners(data);
  const pool = sameCarLapIndexes(data, refIndex);
  if (!corners.length || !pool.length || !data.channels.time_s) return null;
  const bounds = theoryBoundaries(data, corners, pool);
  const last = data.points - 1;

  // The part before the first corner's braking zone is timed too, so the
  // theoretical lap covers the whole lap.
  const parts = [{ from: 0, to: bounds[0], corner: null, flagSegment: null }];
  corners.forEach((corner, k) => {
    parts.push({ from: bounds[k], to: k + 1 < corners.length ? bounds[k + 1] : last, corner, flagSegment: corner.id });
  });

  let theoretical = 0;
  let refTotal = 0;
  const entries = [];
  for (const part of parts) {
    if (part.to <= part.from) continue;
    const usable = pool.filter((lap) => !part.flagSegment || !sectorFlag(data, part.flagSegment, lap));
    const candidates = usable.length ? usable : pool;
    let bestLap = candidates[0];
    for (const lap of candidates) {
      if (lapTime(data, lap, part.from, part.to) < lapTime(data, bestLap, part.from, part.to)) bestLap = lap;
    }
    const bestTime = lapTime(data, bestLap, part.from, part.to);
    const refTime = lapTime(data, refIndex, part.from, part.to);
    theoretical += bestTime;
    refTotal += refTime;
    if (!part.corner) continue;

    const loss = refTime - bestTime;
    const ref = theoryFigures(data, refIndex, part.corner, part.from, part.to);
    const best = theoryFigures(data, bestLap, part.corner, part.from, part.to);
    // Exit speed is read at one place for both laps: where the later of the two
    // went flat out for good, so both have finished the corner there. The
    // segment's own end can sit far down the next straight (the Senna S segment
    // ends after the curve that follows it), and by then both laps are near top
    // speed and the difference has washed out. The faster run's point alone is
    // too early for a lap that braked later and is still slowing there.
    const fullPoints = [ref.fullAt, best.fullAt].filter((value) => value !== null);
    const exitAt = fullPoints.length ? Math.max(...fullPoints) : part.corner.end;
    ref.exitSpeedKmh = data.channels.speed_kmh[refIndex][exitAt];
    best.exitSpeedKmh = data.channels.speed_kmh[bestLap][exitAt];
    // Split at the faster run's minimum-speed point: before it is braking and
    // turning in, after it is the way out and the straight that follows.
    const timeRef = data.channels.time_s[refIndex];
    const timeBest = data.channels.time_s[bestLap];
    const entryLoss = timeRef[best.apex] - timeRef[part.from] - (timeBest[best.apex] - timeBest[part.from]);
    const exitLoss = loss - entryLoss;
    const partial = bestLap === refIndex ? null : partialThrottle(data, refIndex, bestLap, best.apex, part.to);
    entries.push({
      segment: part.corner,
      exitM: data.distance[exitAt],
      exitAt,
      from: part.from,
      to: part.to,
      bestLap,
      loss,
      entryLoss,
      exitLoss,
      ref,
      best,
      reasons: bestLap === refIndex ? [] : theoryReasons(ref, best, entryLoss, exitLoss, partial)
    });
  }

  // The reference's own time over the same parts, so the gap and the lap time
  // agree even where the grid's last sample is not quite the timing line.
  const refLapTime = data.laps[refIndex].lapTimeS;
  const theoreticalS = refLapTime - (refTotal - theoretical);
  const ranked = entries.filter((entry) => entry.loss >= THEORY_HIGHLIGHT_S).sort((a, b) => b.loss - a.loss);
  for (const entry of ranked.slice(0, THEORY_HIGHLIGHT_COUNT)) entry.highlight = true;
  return { theoreticalS, refLapTime, entries };
}

function theorySpeed(refValue, bestValue) {
  const gap = refValue - bestValue;
  const cls = gap <= -MIN_SPEED_DIFF_KMH ? "is-loss" : gap >= MIN_SPEED_DIFF_KMH ? "is-gain" : "";
  const shown = Math.abs(gap) < MIN_SPEED_DIFF_KMH ? "±0" : `${gap > 0 ? "+" : "−"}${Math.abs(gap).toFixed(0)}`;
  return (
    // The driver steers by the number to hit, so that is the large one; what
    // the reference lap did sits under it.
    // Already faster than the target: nothing to chase there, so it steps back.
    `<span class="theory__now${cls === "is-gain" ? " is-met" : ""}">${bestValue.toFixed(0)}</span>` +
    `<span class="theory__best">今回 ${refValue.toFixed(0)} <b class="${cls}">(${shown})</b></span>`
  );
}

/* The one reason a row is labelled with: from the side, entry or exit, where
   most of the time went, so the label agrees with the numbers beside it. */
const THEORY_ENTRY_KEYS = ["overspeed", "brakeEarly", "minSpeed"];
function theoryMainReason(entry) {
  if (!entry.reasons.length) return null;
  const entrySide = entry.entryLoss >= entry.exitLoss;
  return (
    entry.reasons.find((reason) => THEORY_ENTRY_KEYS.includes(reason.key) === entrySide) || entry.reasons[0]
  );
}

/* The whole track, large, with each losing corner drawn in and labelled with
   its loss, so the cards beside it read as "where" first and "why" second. */
function theoryTrackMap(data, entries, rotationDeg = 0) {
  const lapIndex = Math.max(0, data.laps.findIndex((lap) => lap.isReference));
  const xs = data.channels && data.channels.x ? data.channels.x[lapIndex] : null;
  const zs = xs ? data.channels.z[lapIndex] : null;
  if (!xs || !zs) return "";
  // Turned so the circuit lies wide, as the frame beside the cards is wide.
  // Of the two turns that do that, the one nearer the big map's is taken.
  const sampleStep = Math.max(1, Math.floor(xs.length / 200));
  const spans = (deg) => {
    const r = (deg * Math.PI) / 180;
    let uLo = Infinity, uHi = -Infinity, vLo = Infinity, vHi = -Infinity;
    for (let i = 0; i < xs.length; i += sampleStep) {
      const u = xs[i] * Math.cos(r) - zs[i] * Math.sin(r);
      const v = xs[i] * Math.sin(r) + zs[i] * Math.cos(r);
      uLo = Math.min(uLo, u); uHi = Math.max(uHi, u);
      vLo = Math.min(vLo, v); vHi = Math.max(vHi, v);
    }
    return (uHi - uLo) / Math.max(vHi - vLo, 1);
  };
  let turn = rotationDeg;
  let best = -Infinity;
  for (let deg = 0; deg < 180; deg += 5) {
    const ratio = spans(deg);
    if (ratio > best + 1e-6) {
      best = ratio;
      turn = deg;
    }
  }
  const away180 = (deg) => Math.abs(((deg - rotationDeg + 540) % 360) - 180);
  if (away180(turn + 180) < away180(turn)) turn += 180;
  const radians = (turn * Math.PI) / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  const rotated = Array.from(xs, (x, i) => [x * cos - zs[i] * sin, x * sin + zs[i] * cos]);
  const us = rotated.map((point) => point[0]);
  const vs = rotated.map((point) => point[1]);
  const uMin = Math.min(...us);
  const vMin = Math.min(...vs);
  const uSpan = Math.max(Math.max(...us) - uMin, 1);
  const vSpan = Math.max(Math.max(...vs) - vMin, 1);
  // Room around the track for the labels, which sit outside it.
  const pad = 58;
  const width = 640;
  const height = 400;
  const scale = Math.min((width - pad * 2) / uSpan, (height - pad * 2) / vSpan);
  const offsetX = (width - uSpan * scale) / 2;
  const offsetY = (height - vSpan * scale) / 2;
  // World +Z runs down the screen, as on the big map (see computeView).
  const point = (i) => [(rotated[i][0] - uMin) * scale + offsetX, (rotated[i][1] - vMin) * scale + offsetY];
  const at = (i) => point(i).map((value) => value.toFixed(1)).join(",");
  const path = (from, to, step) => {
    const parts = [];
    for (let i = from; i < to; i += step) parts.push(at(i));
    parts.push(at(to));
    return "M" + parts.join("L");
  };
  const step = Math.max(1, Math.floor(xs.length / 400));
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < xs.length; i += step) {
    const [px, py] = point(i);
    cx += px;
    cy += py;
  }
  const samples = Math.ceil(xs.length / step);
  cx /= samples;
  cy /= samples;

  // The start line across the track, and an arrow a little way on for the
  // direction of travel.
  const [sx, sy] = point(0);
  const ahead = Math.min(xs.length - 1, Math.round(xs.length * 0.025));
  const [ax, ay] = point(ahead);
  const [bx, by] = point(Math.max(0, ahead - 3));
  const dirLen = Math.hypot(ax - bx, ay - by) || 1;
  const dx = (ax - bx) / dirLen;
  const dy = (ay - by) / dirLen;
  const [s1x, s1y] = point(Math.min(xs.length - 1, 3));
  const tLen = Math.hypot(s1x - sx, s1y - sy) || 1;
  const nx = -(s1y - sy) / tLen;
  const ny = (s1x - sx) / tLen;
  const arrow =
    `M${(ax + dx * 9).toFixed(1)},${(ay + dy * 9).toFixed(1)}` +
    `L${(ax - dx * 6 + nx * 7).toFixed(1)},${(ay - dy * 6 + ny * 7).toFixed(1)}` +
    `L${(ax - dx * 6 - nx * 7).toFixed(1)},${(ay - dy * 6 - ny * 7).toFixed(1)}Z`;

  const theoryTick = (i, colour) => {
    const [px, py] = point(i);
    const [ax2, ay2] = point(Math.max(0, i - 2));
    const [bx2, by2] = point(Math.min(xs.length - 1, i + 2));
    const len = Math.hypot(bx2 - ax2, by2 - ay2) || 1;
    const ux = -(by2 - ay2) / len;
    const uy = (bx2 - ax2) / len;
    return (
      `<line x1="${(px + ux * 11).toFixed(1)}" y1="${(py + uy * 11).toFixed(1)}" x2="${(px - ux * 11).toFixed(1)}" y2="${(py - uy * 11).toFixed(1)}" ` +
      `stroke="${COLORS.text}" stroke-width="4" stroke-linecap="round"/>`
    );
  };
  const labels = [];
  const corners = entries
    .map((entry) => {
      const { segment } = entry;
      const colour = entry.highlight ? COLORS.loss : COLORS.cmp;
      const middle = Math.round((segment.start + segment.end) / 2);
      const [mx, my] = point(middle);
      const away = Math.hypot(mx - cx, my - cy) || 1;
      const lx = Math.min(width - 50, Math.max(50, mx + ((mx - cx) / away) * 62));
      const ly = Math.min(height - 24, Math.max(30, my + ((my - cy) / away) * 48));
      labels.push([lx, ly - 12], [lx, ly + 14]);
      // The leader stops short of the label so it does not run through the text.
      const reach = Math.hypot(lx - mx, ly - my);
      const short = reach > 1 ? Math.max(0, reach - 28) / reach : 0;
      const tipX = mx + (lx - mx) * short;
      const tipY = my + (ly - my) * short;
      return (
        `<g class="theory-map__corner${entry.highlight ? " is-key" : ""}" data-segment="${segment.id}">` +
        `<path d="${path(segment.start, segment.end, 1)}" fill="none" stroke="${colour}" stroke-width="${entry.highlight ? 9 : 6}" stroke-linecap="round" stroke-linejoin="round"/>` +
        // Where the two speeds are read: the target lap's minimum and the
        // fixed exit point, as ring and tick.
        theoryTick(entry.exitAt, colour) +
        `<circle cx="${point(entry.best.apex)[0].toFixed(1)}" cy="${point(entry.best.apex)[1].toFixed(1)}" r="6.5" fill="#0a0d12" stroke="${COLORS.text}" stroke-width="3"/>` +
        `<line x1="${mx.toFixed(1)}" y1="${my.toFixed(1)}" x2="${tipX.toFixed(1)}" y2="${tipY.toFixed(1)}" stroke="${colour}" stroke-width="1" opacity="0.6"/>` +
        `<circle cx="${lx.toFixed(1)}" cy="${(ly - 12).toFixed(1)}" r="13" fill="${colour}"/>` +
        `<text x="${lx.toFixed(1)}" y="${(ly - 7).toFixed(1)}" text-anchor="middle" class="theory-map__rank">${entry.rank}</text>` +
        `<text x="${lx.toFixed(1)}" y="${(ly + 18).toFixed(1)}" text-anchor="middle" class="theory-map__loss" fill="${colour}">+${entry.loss.toFixed(2)}</text>` +
        "</g>"
      );
    })
    .join("");

  // "スタート" goes on whichever side of the line is clearer of the corner labels.
  const clearance = (x, y) => Math.min(Infinity, ...labels.map(([lx, ly]) => Math.hypot(lx - x, ly - y)));
  const sides = [];
  for (const reach of [30, 50, 70]) {
    sides.push([sx + nx * reach, sy + ny * reach], [sx - nx * reach, sy - ny * reach]);
  }
  // A nearer spot wins unless a farther one is clearly clearer.
  const clear = (x, y) => Math.min(60, clearance(x, y));
  const [startX, startY] = sides.reduce((best, side) => (clear(...side) > clear(...best) ? side : best));
  return (
    `<svg class="theory-map" viewBox="0 0 ${width} ${height}" role="img" aria-label="負けているコーナーの場所">` +
    `<path d="${path(0, xs.length - 1, step)}" fill="none" stroke="${COLORS.neutral}" stroke-width="4" stroke-linejoin="round"/>` +
    `<line x1="${(sx + nx * 12).toFixed(1)}" y1="${(sy + ny * 12).toFixed(1)}" x2="${(sx - nx * 12).toFixed(1)}" y2="${(sy - ny * 12).toFixed(1)}" stroke="${COLORS.text}" stroke-width="3"/>` +
    `<path d="${arrow}" fill="${COLORS.text}"/>` +
    `<text x="${startX.toFixed(1)}" y="${(startY + 4).toFixed(1)}" text-anchor="middle" class="theory-map__start">スタート</text>` +
    corners +
    `<g class="theory-map__legend"><circle cx="16" cy="${height - 16}" r="6" fill="#0a0d12" stroke="${COLORS.text}" stroke-width="3"/>` +
    `<text x="27" y="${height - 11}">最低速度の地点</text>` +
    `<line x1="146" y1="${height - 25}" x2="146" y2="${height - 7}" stroke="${COLORS.text}" stroke-width="4" stroke-linecap="round"/>` +
    `<text x="157" y="${height - 11}">脱出速度を測る地点</text></g>` +
    "</svg>"
  );
}

function renderTheory(data, state, elements, onSelect) {
  if (!elements.list) return;
  const s = state.get();
  const result = theoryComparison(data, s.refIndex);
  if (!result) {
    elements.list.innerHTML = "";
    elements.summary.textContent = "";
    if (elements.map) elements.map.innerHTML = "";
    return;
  }
  const refTitle = data.laps[s.refIndex].title;
  const gap = result.refLapTime - result.theoreticalS;
  // Biggest loss first, numbered, and the same number on the map: the order
  // to read in is the order to work in.
  const losing = result.entries
    .filter((entry) => entry.loss >= MIN_GAIN_S)
    .sort((a, b) => b.loss - a.loss)
    .map((entry, i) => ({ ...entry, rank: i + 1 }));
  const even = result.entries.filter((entry) => entry.loss < MIN_GAIN_S);

  elements.summary.innerHTML =
    `<span class="theory-sum__label">理論ベストまで</span><span class="theory-sum__value">+${gap.toFixed(2)}<small>秒</small></span>` +
    `<span class="theory-sum__times">基準ラップ ${refTitle} ／ 理論ベスト ${formatLapTime(result.theoreticalS)}` +
    (hasSeveralCars(data) ? `（${data.laps[s.refIndex].carName} の周だけ）` : "") +
    "</span>";

  // One row a corner: the verdict in a word, the two speeds, the time. The
  // sentences behind the verdict are folded away until asked for.
  elements.list.innerHTML =
    (losing.length
      ? '<div class="theory-cols" aria-hidden="true"><span></span><span>最低速度の目標</span><span>脱出速度の目標</span><span>負け</span></div>'
      : "") +
    losing
      .map((entry) => {
        const bestTitle = data.laps[entry.bestLap].title;
        const main = theoryMainReason(entry);
        const reasons = entry.reasons.length
          ? entry.reasons
              .map((reason) => `<li><span class="theory__tag">${reason.tag}</span>${reason.text}</li>`)
              .join("")
          : "<li>ブレーキとアクセルにははっきりした差がありません。走行ラインを比べてください</li>";
        return (
          `<article class="theory${entry.highlight ? " theory--key" : ""}" data-segment="${entry.segment.id}">` +
          '<div class="theory__row">' +
          '<div class="theory__name">' +
          `<span class="theory__rank">${entry.rank}</span>` +
          `<div><h3>${entry.segment.name}</h3><p class="theory__verdict">${main ? main.tag : "要確認"}</p></div>` +
          "</div>" +
          `<div class="theory__speed" data-label="最低速度の目標">${theorySpeed(entry.ref.minSpeedKmh, entry.best.minSpeedKmh)}</div>` +
          `<div class="theory__speed" data-label="脱出速度の目標">${theorySpeed(entry.ref.exitSpeedKmh, entry.best.exitSpeedKmh)}</div>` +
          `<div class="theory__loss">+${entry.loss.toFixed(2)}<small>秒</small></div>` +
          "</div>" +
          '<details class="theory__more"><summary>詳しく</summary>' +
          `<ul class="theory__reasons">${reasons}</ul>` +
          `<p class="theory__from">入口 ${formatDelta(entry.entryLoss, 2)} ／ 出口 ${formatDelta(entry.exitLoss, 2)}（最低速度の地点で分けた負け）。` +
          `脱出速度は ${entry.exitM.toFixed(0)}m地点。理論側の周: ${bestTitle}</p>` +
          "</details>" +
          "</article>"
        );
      })
      .join("") +
    (even.length
      ? `<p class="subtle theory__even">差なし: ${even.map((entry) => entry.segment.name).join("、")}</p>`
      : "");
  // Opening the details is reading, not choosing the corner to zoom to.
  elements.list.querySelectorAll(".theory__more").forEach((node) => {
    node.addEventListener("click", (event) => event.stopPropagation());
  });

  if (elements.map) elements.map.innerHTML = theoryTrackMap(data, losing, s.mapRotationDeg);
  // Pointing at a card lights its corner on the map, and the other way round.
  const mark = (segmentId, on) => {
    const root = elements.list.closest(".panel") || elements.list;
    root.querySelectorAll(`[data-segment="${segmentId}"]`).forEach((node) => node.classList.toggle("is-hover", on));
  };
  const nodes = [...elements.list.querySelectorAll(".theory")];
  if (elements.map) nodes.push(...elements.map.querySelectorAll(".theory-map__corner"));
  nodes.forEach((node) => {
    node.addEventListener("click", () => onSelect(node.dataset.segment));
    node.addEventListener("mouseenter", () => mark(node.dataset.segment, true));
    node.addEventListener("mouseleave", () => mark(node.dataset.segment, false));
  });
}
