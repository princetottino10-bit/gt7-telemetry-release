"""Builds the interactive HTML telemetry report from GT7 Dashboard sessions.

Example:
    .venv\\Scripts\\python.exe build_report.py --data-dir data_suzuka \\
        --segments suzuka_segments.json --out output/suzuka/report.html
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import analyze_gt7 as core
from webreport import autoseg, history, html, loader, pack, resample, sectors

ASSETS_DIR = Path(__file__).parent / "assets" / "tracks"
TRACKS_CONFIG = Path(__file__).parent / "tracks.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, default=core.DEFAULT_DATA_DIR, help="Folder holding GT7 Dashboard session JSON files.")
    parser.add_argument("--segments", type=Path, default=Path("suzuka_segments.json"), help="Segment definition for the circuit.")
    parser.add_argument("--auto-segments", action="store_true", help="Detect segments from the telemetry instead of reading --segments.")
    parser.add_argument("--track-name", default=None, help="Track name shown in the report. Required with --auto-segments unless the definition supplies one.")
    parser.add_argument("--cars-csv", type=Path, default=core.DEFAULT_CARS_CSV, help="GT7 Dashboard car name table.")
    parser.add_argument("--out", type=Path, default=Path("output/report.html"), help="Destination HTML file.")
    parser.add_argument("--track-slug", default=None, help="Overrides the slug used for the background image and saved alignment.")
    parser.add_argument("--track-image", type=Path, default=None, help="Background course diagram to embed. Defaults to assets/tracks/<slug>.*")
    parser.add_argument("--car-id", type=int, default=None, help="Restrict the report to a single car ID.")
    parser.add_argument("--max-laps", type=int, default=None, help="Keep only the N fastest laps.")
    parser.add_argument("--pace-cutoff", type=float, default=loader.DEFAULT_PACE_CUTOFF, help="Drop laps slower than best x this ratio.")
    parser.add_argument("--grid-points", type=int, default=resample.DEFAULT_GRID_POINTS, help="Samples per lap on the shared distance grid.")
    parser.add_argument("--history-root", type=Path, default=None, help="Sessions folder to pull this circuit's all-time best lap from.")
    return parser.parse_args()


def load_track_config(slug: str) -> dict[str, Any]:
    """Optional per-track settings, currently just the background alignment."""
    if not TRACKS_CONFIG.exists():
        return {}
    try:
        config = json.loads(TRACKS_CONFIG.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise SystemExit(f"tracks.json is not valid JSON: {error}") from error
    entry = config.get(slug)
    return entry if isinstance(entry, dict) else {}


def session_summary(selection: loader.LapSelection, definition: dict[str, Any]) -> str:
    cars = sorted({lap.car_name for lap in selection.laps})
    dates = sorted({lap.start_timestamp[:10] for lap in selection.laps if lap.start_timestamp})
    span = dates[0] if len(dates) <= 1 else f"{dates[0]} 〜 {dates[-1]}"
    return f"{span} / {len(selection.laps)}周 / {' / '.join(cars)}"


@dataclass
class BuildOutcome:
    """What a build produced, for callers that want to report on it."""

    path: Path
    track_name: str
    lap_count: int
    excluded_count: int
    best_lap_s: float
    theoretical_s: float
    segment_count: int
    background: Path | None
    # The same figure with only this session's own laps, for the index page.
    theoretical_this_session_s: float = 0.0
    # The past lap mixed in as a ghost, and how many segment runs the behaviour
    # checks refused to believe. Both default so older callers keep working.
    history_lap: str | None = None
    flagged_count: int = 0


def build(
    *,
    data_dir: Path,
    out: Path,
    segments: Path | None = None,
    auto_segments: bool = False,
    save_segments: Path | None = None,
    track_name: str | None = None,
    track_slug: str | None = None,
    track_image: Path | None = None,
    cars_csv: Path = core.DEFAULT_CARS_CSV,
    car_id: int | None = None,
    max_laps: int | None = None,
    pace_cutoff: float = loader.DEFAULT_PACE_CUTOFF,
    grid_points: int = resample.DEFAULT_GRID_POINTS,
    history_root: Path | None = None,
) -> BuildOutcome:
    """Reads a folder of sessions and writes one interactive report.

    `history_root` is the folder every session lives under. When it is given, the
    fastest lap ever recorded on this circuit joins the report as a ghost, so a
    session can be compared with the driver's all-time best and not only with
    itself. Leaving it out keeps the original behaviour exactly.
    """
    if auto_segments:
        slug = track_slug or data_dir.name.replace("data_", "")
    else:
        if segments is None:
            raise ValueError("either segments or auto_segments is required")
        slug = track_slug or segments.stem.replace("_segments", "")
    track_config = load_track_config(slug)

    laps = loader.load_laps(data_dir, cars_csv)
    selection = loader.select_laps(
        laps, car_id=car_id, max_laps=max_laps, pace_cutoff=pace_cutoff
    )
    selection = history.attach(
        selection,
        root=history_root,
        track_slug=slug,
        exclude=data_dir,
        cars_csv=cars_csv,
    )
    history_lap = next((lap for lap in selection.laps if lap.is_history), None)
    history_uids = {lap.uid for lap in selection.laps if lap.is_history}

    grid = resample.build_grid(selection.laps, points=grid_points)
    traces = resample.build_traces(selection.laps, grid, selection.reference.uid)

    if auto_segments:
        detected = autoseg.detect(traces, grid)
        definition = autoseg.to_definition(detected, grid, track_name or slug)
        if save_segments is not None:
            # Written out so the numbered corners can be given their real names
            # once; every later report on this circuit then reads them back.
            save_segments.parent.mkdir(parents=True, exist_ok=True)
            save_segments.write_text(
                json.dumps(definition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
    else:
        definition = core.load_segments(segments)

    sector_results = sectors.compute_all(traces, grid, definition["segments"])
    # An ideal lap assembled from two different cars is a lap nobody could drive,
    # so the figure reported back - and shown on the listing page - is the
    # reference lap's own car. With a single car in the report this is every
    # result there is, and the number is unchanged.
    own_car = {
        lap.uid for lap in selection.laps if lap.car_id == selection.reference.car_id
    }
    own_car_results = [result for result in sector_results if result.lap_uid in own_car]

    image_path = track_image if track_image is not None else html.find_track_image(ASSETS_DIR, slug)
    if track_image is not None and not track_image.exists():
        raise SystemExit(f"Background image not found: {track_image}")
    resolved_name = track_name or str(definition.get("track", slug))
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    meta = {
        "trackName": resolved_name,
        "trackSlug": slug,
        "sessionSummary": session_summary(selection, definition),
        "trackImage": html.encode_image(image_path) if image_path else None,
        "calibration": track_config.get("calibration"),
        "colophon": (
            f"{generated_at} 生成 / {data_dir} / グリッド{grid.points}点 "
            f"(約{grid.lap_distance_m / (grid.points - 1):.1f}m間隔) / "
            f"再構成ラップ長 {grid.lap_distance_m:.0f}m"
        ),
    }

    payload = pack.build_payload(
        traces, grid, definition["segments"], sector_results, selection.reference.uid, meta
    )
    document = html.render(payload, title=f"{resolved_name} — GT7 テレメトリ解析")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(document, encoding="utf-8")

    return BuildOutcome(
        path=out,
        track_name=resolved_name,
        lap_count=len(selection.laps),
        excluded_count=len(selection.excluded),
        best_lap_s=selection.reference.lap_time_s,
        theoretical_s=sectors.theoretical_best_s(own_car_results),
        # Without the laps carried in from earlier sessions. The report is
        # rightly measured against the best ever driven here, but the index
        # column beside it is headed "this session", and mixing the two made a
        # quiet session look like it had matched a past best it never saw.
        theoretical_this_session_s=sectors.theoretical_best_s(
            [result for result in own_car_results if result.lap_uid not in history_uids]
        ),
        segment_count=len(definition["segments"]),
        background=image_path,
        history_lap=history_lap.title if history_lap is not None else None,
        flagged_count=len(sectors.flagged_results(sector_results)),
    )


def main() -> None:
    """Command line entry point. The work itself all happens in `build`."""
    args = parse_args()

    outcome = build(
        data_dir=args.data_dir,
        out=args.out,
        segments=None if args.auto_segments else args.segments,
        auto_segments=args.auto_segments,
        track_name=args.track_name,
        track_slug=args.track_slug,
        track_image=args.track_image,
        cars_csv=args.cars_csv,
        car_id=args.car_id,
        max_laps=args.max_laps,
        pace_cutoff=args.pace_cutoff,
        grid_points=args.grid_points,
        history_root=args.history_root,
    )

    print(f"Wrote {outcome.path}  ({outcome.path.stat().st_size / 1e6:.2f} MB)")
    print(f"  track      : {outcome.track_name}")
    print(f"  segments   : {outcome.segment_count}")
    print(f"  laps       : {outcome.lap_count} kept, {outcome.excluded_count} excluded")
    print(f"  best lap   : {core.format_time(outcome.best_lap_s)}")
    print(f"  theoretical: {core.format_time(outcome.theoretical_s)}")
    if outcome.history_lap:
        print(f"  history    : {outcome.history_lap}")
    if outcome.flagged_count:
        print(f"  flagged    : {outcome.flagged_count} segment runs excluded as incidents")
    print(f"  background : {outcome.background if outcome.background else 'none (drop an image onto the map)'}")


if __name__ == "__main__":
    main()
